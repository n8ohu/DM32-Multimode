"""Reserve the published NRFB 050 codec table window in an experimental build.

The pinned board source stays untouched. This changes only the modem SRAM table
ceiling, by 16 bytes; application RAM, executable codec RAM and flash are fixed.
This reservation does not qualify RF-B hardware or enable its installation.
"""
import argparse
import hashlib
from pathlib import Path

PINNED_SOURCE_SHA256 = "5173bcd32ca07acd76e0c3af6d5be73a15fe9b717eb46ee0bf4c9b3f70af6d4c"
CLASSIC_TABLE_HI = 0x18003E28
EXPERIMENTAL_TABLE_HI = 0x18003E38


def generate(text, *, experimental_rf_b=False):
    text = text.replace("\r\n", "\n")
    if hashlib.sha256(text.encode()).hexdigest() != PINNED_SOURCE_SHA256:
        raise ValueError("DM32 memory source does not match the reviewed upstream pin")
    if not experimental_rf_b:
        return text
    old = "__codec_tab_hi = 0x18003E28;"
    if text.count(old) != 1:
        raise ValueError("Expected one pinned codec table ceiling")
    return ("/* Generated experimental NRFB 050 table reservation; RF-B remains unqualified. */\n"
            + text.replace(old, "__codec_tab_hi = 0x18003E38;", 1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--experimental-rf-b", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = args.output.resolve()
    if not output.is_relative_to((root / "build").resolve()):
        parser.error("generated linker script must stay under the ignored project build directory")
    generated = generate(args.source.read_text(), experimental_rf_b=args.experimental_rf_b)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(generated, newline="\n")


if __name__ == "__main__":
    main()
