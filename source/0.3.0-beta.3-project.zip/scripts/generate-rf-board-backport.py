"""Generate the experimental RF-B board adapter from the pinned DM32 source.

Narrow adaptation of RadioFoundry PR 490 at f07134f2576f286e95a839b3e4cea791ce4f1a8d.
The existing interrupt callbacks, PA one-shot and P25 hook ownership stay in
place. Detection runs once at initialization, with the PA off, in task context.
No binary blobs or device access are involved. The external checkout is read-only.
"""
import argparse
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PINNED_SHA256 = "5c9fc8a0b1a411dc57afa1b7325661b315cef23abe07e3d889546702dc10a2e7"


def generate(text):
    text = text.replace("\r\n", "\n")
    if hashlib.sha256(text.encode()).hexdigest() != PINNED_SHA256:
        raise ValueError("RF board input does not match the reviewed upstream pin")

    def replace(old, new):
        nonlocal text
        if text.count(old) != 1:
            raise ValueError("Pinned RF board anchor is absent or ambiguous: " + old[:60])
        text = text.replace(old, new, 1)

    replace('#include "radio/ref_trim.h"', '#include "radio/ref_trim.h"\n#include "dm32_rf_compat.h"')
    replace("static hrc7000_t modem;", """static hrc7000_t modem;
static bool rf_b;
static bool rf_unlocked = true; // fail closed until a complete RX-only probe

#define RF_PROBE_HZ 145000000u
#define RF_LOCK_MS 20u
#define FD_REG_TX_AUX 0x50u
#define C7_RF_MODE_RX_INVERT (1u << 15)

char dm32_rf_compat_setup(void)
{
\treturn rf_unlocked ? '-' : rf_b ? 'B' : 'A';
}""")
    replace("return bw == RADIO_BW_25K ? FD6818_BW_FM_25K : FD6818_BW_FM_12K5;",
            "return bw == RADIO_BW_25K ? fd.variant->bw_fm_25k : fd.variant->bw_fm_12k5;")
    replace("static void dmr_rf_switch(bool tx)\n{", """static void dmr_rf_switch(bool tx)
{
\t// Also guard callbacks arriving after a failed probe; never key or retune TX.
\tif (rf_unlocked) {
\t\tpa_off();
\t\treturn;
\t}""")
    replace("fd6818_dmr_burst_at(&fd, tx, FD6818_BW_DMR, synth_hz(tx ? tx_hz : rx_hz));", """fd6818_dmr_burst_at(&fd, tx, fd.variant->bw_dmr, synth_hz(tx ? tx_hz : rx_hz));
\tif (tx && rf_b) {
\t\tfd6818_write(&fd, FD_REG_TX_AUX, 0x3B18u);
\t}""")
    replace("if (dmr_keyed) {", "if (dmr_keyed && !rf_unlocked) {")
    replace("static void init(void)\n{", """// Set-up B can lock classic hardware too: always qualify A first. This
// synthesizer check identifies an RF setup, not the flash manufacturer or codec.
static void rf_detect(void)
{
\trf_b = false;
\trf_unlocked = true;
\tconst fd6818_variant_t *variants[] = {
\t\t&fd6818_variant_default, &fd6818_variant_b_dmr6943
\t};
\tfor (unsigned i = 0; i < 2; ++i) {
\t\tfd6818_attach_variant(&fd, &fd_bus.bus, variants[i]);
\t\tfd6818_init(&fd);
\t\tfd6818_set_mode(&fd, FD6818_MODE_FM);
\t\tfd6818_set_freq(&fd, RF_PROBE_HZ);
\t\tfd6818_set_state(&fd, FD6818_STATE_RX);
\t\tif (fd6818_pll_locked(&fd, RF_LOCK_MS)) {
\t\t\trf_b = i == 1;
\t\t\trf_unlocked = false;
\t\t\tbreak;
\t\t}
\t}
\tif (rf_unlocked) {
\t\tfd6818_attach_variant(&fd, &fd_bus.bus, &fd6818_variant_default);
\t\tfd6818_init(&fd);
\t\tfd6818_set_mode(&fd, FD6818_MODE_FM);
\t}
\tfd6818_set_state(&fd, FD6818_STATE_IDLE);
\tif (rf_b) {
\t\thrc7000_wr(&modem, C7_RF_MODE,
\t\t\thrc7000_rd(&modem, C7_RF_MODE) & ~C7_RF_MODE_RX_INVERT);
\t}
}

static void init(void)
{
\tdmr_keyed = false;
\ttransmitting = false;
\tasleep = false;
\thave_rx = false;
\trx_am_on = false;""")
    replace("\tfd6818_attach(&fd, &fd_bus.bus);\n\tfd6818_init(&fd);\n\tfd6818_set_mode(&fd, FD6818_MODE_FM);",
            "\trf_detect();")
    replace("if (!board_in_band(hz, false) || (am && mode != RADIO_MODE_FM)) {",
            "if (!board_in_band(hz, false) || (am && (mode != RADIO_MODE_FM || rf_b))) {")
    # Both the normal RX path and the DMR TX arm use the variant's bandwidth.
    old_bw = "fd6818_set_bandwidth(&fd, FD6818_BW_DMR);"
    if text.count(old_bw) != 2:
        raise ValueError("Pinned DMR bandwidth sites changed")
    text = text.replace(old_bw, "fd6818_set_bandwidth(&fd, fd.variant->bw_dmr);")
    replace("\t\tif (am != rx_am_on) {", """\t\tif (rf_b) {
\t\t\tbool ctcss = tone != NULL && tone->type == TONE_CTCSS;
\t\t\tfd6818_write(&fd, 0x2Eu, ctcss ? 0x8608u : 0x9608u);
\t\t\tfd6818_write(&fd, 0x2Fu, ctcss ? 0x1890u : 0x9890u);
\t\t}
\t\tif (am != rx_am_on) {""")
    replace("if (!board_in_band(hz, true)) {", "if (!board_in_band(hz, true) || rf_unlocked) {")
    replace("\t\tfd6818_fm_tx_prepare(&fd);", """\t\tfd6818_fm_tx_prepare(&fd);
\t\tif (rf_b && bf_cal_valid()) {
\t\t\tfd6818_write(&fd, FD6818_REG_BAND_B,
\t\t\t\t(uint16_t)(0x3480u + bf_cal_tx_byte(hz, BF_ROW_REG40)));
\t\t}""")
    replace("\t\tfd6818_set_state(&fd, FD6818_STATE_TX);\n\t\tpa_key();", """\t\tif (rf_b) {
\t\t\tfd6818_write(&fd, FD_REG_TX_AUX, 0xBB20u);
\t\t}
\t\tfd6818_set_state(&fd, FD6818_STATE_TX);
\t\tif (rf_b) {
\t\t\tfd6818_write(&fd, FD_REG_TX_AUX, 0x3B20u);
\t\t\thal_delay_ms(1); // task-level FM key-up only, never a burst callback
\t\t}
\t\tpa_key();""")
    # Deeper RF-B receive sleep and AM are deferred until measured on RF-B.
    replace("\t\tfd6818_rx_sleep(&fd, false, FD6818_MODE_FM);", """\t\tif (!rf_b) {
\t\t\tfd6818_rx_sleep(&fd, false, FD6818_MODE_FM);
\t\t}""")
    replace("\t\tfd6818_rx_sleep(&fd, true, FD6818_MODE_FM);", """\t\tif (rf_b) {
\t\t\tfd6818_set_state(&fd, FD6818_STATE_IDLE);
\t\t} else {
\t\t\tfd6818_rx_sleep(&fd, true, FD6818_MODE_FM);
\t\t}""")
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to((ROOT / "build").resolve()):
        parser.error("generated RF sources must remain under the ignored project build directory")
    result = generate(args.source.read_text())
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(result, newline="\n")


if __name__ == "__main__":
    main()
