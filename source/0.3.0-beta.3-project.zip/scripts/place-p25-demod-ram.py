"""Place only the four named P25 demod hot sections in startup-copied RAM."""
import argparse
from pathlib import Path
import struct
import subprocess
import tempfile

PREFIX = '.ramfunc.p25_demod_hot'
SECTIONS = ('.text.push', '.text.symbol', '.text.acquire', '.rodata.p25_interp')


def allocated_sections(data):
    if len(data) < 52 or data[:7] != b'\x7fELF\x01\x01\x01':
        raise ValueError('Expected ELF32 little-endian object')
    if struct.unpack_from('<HH', data, 16) != (1, 252):
        raise ValueError('Expected relocatable C-SKY object')
    offset = struct.unpack_from('<I', data, 32)[0]
    stride, count, strings = struct.unpack_from('<HHH', data, 46)
    if stride != 40 or not count or strings >= count or offset+stride*count > len(data):
        raise ValueError('Invalid ELF section table')
    headers = [struct.unpack_from('<10I', data, offset+i*stride) for i in range(count)]
    table = headers[strings]
    if table[1] != 3 or table[4]+table[5] > len(data):
        raise ValueError('Invalid ELF section-name table')
    names = data[table[4]:table[4]+table[5]]
    result = {}
    for header in headers:
        if not header[2] & 2:
            continue
        name_offset = header[0]
        end = names.find(b'\0', name_offset)
        if name_offset >= len(names) or end < 0:
            raise ValueError('Invalid allocated section name')
        name = names[name_offset:end].decode('ascii')
        if name in result:
            raise ValueError('Duplicate allocated section: '+name)
        kind, flags, address, begin, size = header[1:6]
        if kind != 8 and begin+size > len(data):
            raise ValueError('Allocated section exceeds ELF data: '+name)
        result[name] = (kind, flags, address, size,
                       data[begin:begin+size] if kind != 8 else None)
    return result


def selection(data):
    sections = allocated_sections(data)
    if any(name.startswith(PREFIX) for name in sections):
        raise ValueError('P25 demod hot sections already placed')
    for name in SECTIONS:
        section = sections.get(name)
        if section is None or section[0] != 1 or not section[3]:
            raise ValueError('Missing file-backed hot section: '+name)
        if section[1] != (6 if name.startswith('.text.') else 2) or section[2]:
            raise ValueError('Unexpected hot-section flags/address: '+name)
    return sections


def place(objcopy, path):
    path = Path(path)
    before = selection(path.read_bytes())
    expected = {PREFIX+name if name in SECTIONS else name: value
                for name, value in before.items()}
    # Validate a temporary output before replacing the original object. Neither
    # an objcopy error nor unexpected extra movement leaves a partial object.
    with tempfile.TemporaryDirectory(prefix='p25-demod-ram-', dir=path.parent) as temporary:
        destination = Path(temporary)/path.name
        command = [str(objcopy)]
        for name in SECTIONS:
            command += ['--rename-section', name+'='+PREFIX+name]
        subprocess.run(command+[str(path), str(destination)], check=True, timeout=120)
        after = allocated_sections(destination.read_bytes())
        if after != expected:
            raise ValueError('Objcopy changed sections outside the exact P25 hot allowlist')
        destination.replace(path)
    total = sum(before[name][3] for name in SECTIONS)
    print(f'{path.name}: startup RAM hot sections={len(SECTIONS)} bytes={total}; other allocated sections unchanged')
    return total


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('objcopy')
    parser.add_argument('object', type=Path)
    args = parser.parse_args()
    place(args.objcopy, args.object)


if __name__ == '__main__':
    main()
