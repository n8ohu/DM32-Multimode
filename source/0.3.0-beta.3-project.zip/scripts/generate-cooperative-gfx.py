"""Generate bounded, opt-in row output without editing the pinned gfx source."""
import argparse
import hashlib
from pathlib import Path

PINNED_SOURCE_SHA256 = '5a69a9ccd86d8653516eeec14aef1a61b0f0f8520cc173cec72fd9cb5eedf817'


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Pinned cooperative gfx structure changed: '+old[:70])
    return text.replace(old, new, 1)


STATE = '''
// Generated cooperative output state. The framebuffer, palette and row hashes
// remain upstream's only copies. Forced rows survive partial palette refreshes.
static bool radio_gfx_defer_enabled, radio_gfx_rescan;
static volatile bool radio_gfx_queued; // also read by gfx_frame_idle readers
static unsigned radio_gfx_cursor;
static uint32_t radio_gfx_queued_frame;
static uint8_t radio_gfx_forced[(GFX_MAX_ROWS+7u)/8u];
static void radio_gfx_reset_state(void)
{
    radio_gfx_defer_enabled=radio_gfx_queued=radio_gfx_rescan=false;
    radio_gfx_cursor=0;radio_gfx_queued_frame=0;
    memset(radio_gfx_forced,0,sizeof radio_gfx_forced);
}
'''

COOPERATIVE = '''
void radio_gfx_defer(bool enable) {radio_gfx_defer_enabled=enable;}
bool radio_gfx_deferred(void) {return radio_gfx_defer_enabled;}
bool radio_gfx_pending(void) {return display!=NULL&&radio_gfx_queued;}

// Capture the current palette before sending indexed rows. A changed old
// palette entry changes visible RGB565 even where framebuffer bytes are equal.
static bool radio_gfx_prepare_rows(void)
{
    bool force=all_dirty;
#if GFX_INDEXED
    if(bpp==4) {
        for(int radio_gfx_i=0;radio_gfx_i<pal_n_sent;++radio_gfx_i)
            if(pal[radio_gfx_i]!=pal_sent[radio_gfx_i])force=true;
        memcpy(pal_sent,pal,sizeof pal);pal_n_sent=pal_n;
    }
#endif
    if(force) {
        memset(radio_gfx_forced,0xff,sizeof radio_gfx_forced);
        all_dirty=false;
    }
    return force;
}

void gfx_flush(void)
{
    if(display==NULL)return;
    if(!radio_gfx_defer_enabled) {
        // A pending palette invalidation may already have consumed all_dirty.
        // Repaint all rows on explicit blocking fallback, then retire its queue.
        if(radio_gfx_queued)all_dirty=true;
        radio_gfx_blocking_flush();radio_gfx_queued=radio_gfx_rescan=false;
        radio_gfx_cursor=0;memset(radio_gfx_forced,0,sizeof radio_gfx_forced);
        return;
    }
    (void)radio_gfx_prepare_rows();
    if(radio_gfx_queued)radio_gfx_rescan=true;
    else {radio_gfx_cursor=0;radio_gfx_rescan=false;}
    radio_gfx_queued_frame=frames_begun;radio_gfx_queued=true;
}

bool radio_gfx_step(unsigned max_rows,unsigned max_scan_rows)
{
    if(!radio_gfx_pending()||!max_rows||!max_scan_rows)return radio_gfx_pending();
    if(radio_gfx_prepare_rows()&&radio_gfx_cursor)radio_gfx_rescan=true;
    unsigned radio_gfx_scanned=0,radio_gfx_sent=0;
    while(radio_gfx_queued&&radio_gfx_scanned<max_scan_rows&&radio_gfx_sent<max_rows) {
        unsigned radio_gfx_y=radio_gfx_cursor;
        uint32_t radio_gfx_hash=hash_row((int)radio_gfx_y);
        ++radio_gfx_scanned;
        uint8_t radio_gfx_bit=(uint8_t)(1u<<(radio_gfx_y&7u));
        bool radio_gfx_changed=(radio_gfx_forced[radio_gfx_y>>3]&radio_gfx_bit)
            ||radio_gfx_hash!=row_hash[radio_gfx_y];
        if(radio_gfx_changed) {
            // No draw/flush reentry from the HAL: publish the hash only after
            // the synchronous row transfer has completed and released its bus.
            send((int)radio_gfx_y,(int)radio_gfx_y+1);
            row_hash[radio_gfx_y]=radio_gfx_hash;
            radio_gfx_forced[radio_gfx_y>>3]&=(uint8_t)~radio_gfx_bit;
#if CONFIG_NET_WEBCTL
            row_new[radio_gfx_y>>3]|=radio_gfx_bit;
#endif
            ++radio_gfx_sent;
        }
        if(++radio_gfx_cursor==(unsigned)height) {
            if(radio_gfx_rescan) {radio_gfx_cursor=0;radio_gfx_rescan=false;}
            else {radio_gfx_queued=false;frames_done=radio_gfx_queued_frame;}
        }
    }
    return radio_gfx_pending();
}
'''


def generate(text):
    text = text.replace('\r\n', '\n')
    if hashlib.sha256(text.encode()).hexdigest() != PINNED_SOURCE_SHA256:
        raise ValueError('Graphics source does not match the reviewed upstream pin')
    text = replace_once(text, '#include "gfx.h"', '#include "ui/gfx.h"\n#include "radio_gfx.h"')
    text = replace_once(text, '''\t\tuint8_t i = pal_index(c);
\t\tfor (int x = x0; x < x1; x++)
\t\t\tput4(row, x, i);''', '''\t\tuint8_t i = pal_index(c);
        // Preserve the neighbouring pixel at each odd boundary; only whole
        // interior bytes contain two pixels owned by this span. Empty spans
        // retain the palette lookup above but must not touch a framebuffer byte.
        if (x0 < x1 && (x0 & 1)) put4(row, x0++, i);
        if (x0 < x1) {
            unsigned radio_gfx_bytes=(unsigned)(x1-x0)/2u;
            if (radio_gfx_bytes) memset(row+x0/2,(uint8_t)(i|(i<<4)),radio_gfx_bytes);
            x0+=(int)(radio_gfx_bytes*2u);
            if (x0 < x1) put4(row,x0,i);
        }''')
    text = replace_once(text, 'static volatile uint32_t frames_begun, frames_done;',
                        'static volatile uint32_t frames_begun, frames_done;\n'+STATE)
    text = replace_once(text, 'bool gfx_init(const hal_display_t *disp)\n{',
                        'bool gfx_init(const hal_display_t *disp)\n{\n\tradio_gfx_reset_state();')
    text = replace_once(text, 'void gfx_flush(void)\n{', 'static void radio_gfx_blocking_flush(void)\n{')
    text = replace_once(text, '\nvoid gfx_frame_begin(void)', COOPERATIVE+'\nvoid gfx_frame_begin(void)')
    text = replace_once(text, 'return b == frames_done;', 'return b == frames_done && !radio_gfx_pending();')
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = generate(args.source.read_text())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(result, encoding='utf-8', newline='\n')


if __name__ == '__main__':
    main()
