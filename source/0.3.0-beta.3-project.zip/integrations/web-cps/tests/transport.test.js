// SPDX-License-Identifier: GPL-3.0-or-later
import test from 'node:test';
import assert from 'node:assert/strict';
import { CpsClient, parseServices } from '../transport.js';
import { crc32, createDefaultModel, encodePayload, decodePayload, upgradeModel, createScanList } from '../model.js';

const hex = value => (value >>> 0).toString(16).toUpperCase().padStart(8, '0');
const bytesHex = value => Array.from(value, byte => byte.toString(16).toUpperCase().padStart(2, '0')).join('');
const tick = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
const origin = peer => ({ revision: peer.revision, crc: crc32(peer.active) });

test('service capabilities never infer messaging from individual voice or codeplug support', () => {
  const line = 'CPS SERVICES 1 heard=32 contacts=96 p25_unit=1 dmr_unit=1 p25_text=000 dmr_text=000';
  const caps = parseServices(line);
  assert.equal(caps.contactCapacity, 96);assert.equal(caps.historyCapacity, 32);
  assert.equal(caps.P25.individualVoice, true);assert.equal(caps.DMR.individualVoice, true);
  assert.deepEqual(caps.P25.messaging, {receive:false,transmit:false,acknowledgments:false});
  assert.deepEqual(caps.DMR.messaging, {receive:false,transmit:false,acknowledgments:false});
  assert.throws(() => parseServices(line.replace('SERVICES 1', 'SERVICES 2')));
  assert.throws(() => parseServices(line.replace('text=000', 'text=0011')));
  assert.throws(() => parseServices(line.replace('contacts=96', 'contacts=99999999999999')));
  assert.throws(() => parseServices(line + ' extra'));
});

function edited(payload) {
  const model = decodePayload(payload);
  model.settings.micGainDb = (model.settings.micGainDb + 1) % 43;
  return encodePayload(model);
}

/** Real WHATWG browser streams with a deterministic logical radio peer; no serial port is opened. */
class FakeSerial {
  constructor({ override, fragment = 0, revision = 19, protocol = 1 } = {}) {
    this.active = encodePayload(createDefaultModel(protocol >= 4 ? protocol : 3));
    this.revision = revision;
    this.protocol = protocol;
    this.stage = null;
    this.requests = [];
    this.duringStage = [];
    this.override = override;
    this.fragment = fragment;
    this.commits = this.aborts = this.requestCount = this.closeCount = 0;
    this.listeners = new Set();
    this.busy = false;
    this.port = {
      open: async options => {
        this.openOptions = options;
        this.closed = false;
        this.port.readable = new ReadableStream({ start: controller => { this.controller = controller; } });
        this.port.writable = new WritableStream({ write: async bytes => {
          const request = new TextDecoder().decode(bytes);
          assert.match(request, /^CPS [ -~]+\r\n$/);
          assert.ok(bytes.length <= 120);
          const command = request.slice(0, -2);
          this.requests.push(command);
          const response = this.handle(command);
          const changed = this.override ? await this.override(command, response, this) : response;
          if (changed !== undefined && changed !== null) this.reply(changed);
        } });
      },
      close: async () => { this.closeCount++; this.closed = true; },
    };
  }

  async requestPort() { this.requestCount++; return this.port; }
  addEventListener(name, listener) { assert.equal(name, 'disconnect'); this.listeners.add(listener); }
  removeEventListener(name, listener) { assert.equal(name, 'disconnect'); this.listeners.delete(listener); }

  reply(text, controller = this.controller) {
    const bytes = typeof text === 'string' ? new TextEncoder().encode(text) : text;
    try {
      if (!this.fragment) controller.enqueue(bytes);
      else for (let offset = 0; offset < bytes.length; offset += this.fragment) {
        controller.enqueue(bytes.subarray(offset, offset + this.fragment));
      }
    } catch { /* A timed-out stream has been cancelled; late ACKs cannot be reused. */ }
  }

  unplug() {
    for (const listener of this.listeners) listener({ target: this.port });
    try { this.controller.close(); } catch { /* already cancelled */ }
  }

  handle(command) {
    if (this.busy) return 'CPS ERR BUSY\r\n';
    const parts = command.split(' ');
    if (command === 'CPS HELLO') {
      if (this.stage) return 'CPS ERR TRANSACTION\r\n';
      return `CPS HELLO DM32P25 ${this.protocol} ${this.protocol >= 4 ? 256 : 32} 2 ${this.revision} ${hex(crc32(this.active))}\r\n`;
    }
    if (parts[1] === 'GET') {
      const index = Number(parts[2]);
      return `CPS DATA ${index} ${bytesHex(this.active.subarray(index * 32, (index + 1) * 32))}\r\n`;
    }
    if (parts[1] === 'BEGIN') {
      if (Number(parts[3]) !== this.revision || this.stage) return 'CPS ERR REVISION\r\n';
      this.tid = parts[2];
      this.stage = this.active.slice();
      return `CPS OK BEGIN ${this.tid}\r\n`;
    }
    if (!this.stage || parts[2] !== this.tid) return 'CPS ERR TRANSACTION\r\n';
    if (parts[1] === 'PUT') {
      const data = Uint8Array.from(parts[4].match(/../g), byte => parseInt(byte, 16));
      this.stage.set(data, Number(parts[3]) * 32);
      this.duringStage.push(this.active.slice());
      return `CPS OK PUT ${this.tid} ${parts[3]}\r\n`;
    }
    if (parts[1] === 'ABORT') {
      this.aborts++;
      this.stage = null;
      return `CPS OK ABORT ${this.tid}\r\n`;
    }
    if (parts[1] === 'COMMIT') {
      if (hex(crc32(this.stage)) !== parts[3]) return 'CPS ERR COMMIT\r\n';
      decodePayload(this.stage);
      this.active = this.stage.slice();
      this.stage = null;
      this.revision = (this.revision + 1) >>> 0;
      this.commits++;
      return `CPS OK COMMIT ${this.tid} ${this.revision} ${hex(crc32(this.active))}\r\n`;
    }
    throw new Error(`Unexpected fake command ${command}`);
  }
}

async function setup(t, peer = new FakeSerial(), options = {}) {
  // Parallel codec/property tests can stall a one-byte stream on busy CI hosts.
  // Deliberate deadline tests below retain their explicit short timeouts.
  const client = new CpsClient({ serial: peer, timeoutMs: 500, ...options });
  t.after(() => client.disconnect());
  await client.connect();
  return { client, peer };
}

test('explicit connect requests a port, opens exact UART settings and only sends HELLO', async t => {
  const peer = new FakeSerial();
  const client = new CpsClient({ serial: peer });
  t.after(() => client.disconnect());
  assert.equal(client.connected, false);
  assert.equal(peer.requestCount, 0);
  assert.deepEqual(await client.connect(), origin(peer));
  assert.equal(client.connected, true);
  assert.equal(peer.requestCount, 1);
  assert.deepEqual(peer.openOptions, { baudRate: 115200, dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none' });
  assert.deepEqual(peer.requests, ['CPS HELLO']);
  await assert.rejects(client.write(edited(peer.active), origin(peer)), { code: 'NEED_READ' });
  assert.deepEqual(peer.requests, ['CPS HELLO']);
});

test('35 records download between matching HELLOs, strict CRC and one-byte stream chunks', async t => {
  const progress = [];
  const { client, peer } = await setup(t, new FakeSerial({ fragment: 1 }), { onProgress: event => progress.push(event) });
  peer.requests.length = 0;
  const read = await client.read();
  assert.deepEqual(read, { payload: peer.active, ...origin(peer) });
  assert.deepEqual(peer.requests, ['CPS HELLO', ...Array.from({ length: 35 }, (_, n) => `CPS GET ${n}`), 'CPS HELLO']);
  assert.equal(progress.length, 35);
  assert.deepEqual(progress.at(-1), { phase: 'read', current: 35, total: 35, message: 'Reading radio configuration' });
  read.payload[0] = 23;
  assert.equal(peer.active[0], 0, 'download buffer never aliases the radio state');
});

test('V2 DMR uploads and legacy V1 refuses DMR before BEGIN', async t => {
  for (const protocol of [1, 2, 3]) {
    const {client, peer} = await setup(t, new FakeSerial({protocol}));
    const read = await client.read(); const model = decodePayload(read.payload);
    model.channels[0] = {name: 'DMR TEST', rxHz:145700000, txHz:145700000, mode:'DMR', rxOnly:false,
      scanLists:[0], destinationId:0xffffff, colorCode:0, timeslot:2, privateCall:true, repeater:true, filter:'PROM', powerLevel:0};
    const payload = encodePayload(model);peer.requests.length=0;
    if (protocol === 1) {
      await assert.rejects(client.write(payload, read), {code:'UNSUPPORTED_MODE'});
      assert.deepEqual(peer.requests, []); assert.equal(peer.commits, 0);
    } else {
      await client.write(payload, read);assert.deepEqual(peer.active,payload);assert.equal(peer.commits,1);
    }
  }
});

test('schema changes within a connected baseline fail before programming', async t => {
  const {client, peer} = await setup(t, new FakeSerial({protocol:2}));
  const read = await client.read();peer.protocol=1;peer.requests.length=0;
  await assert.rejects(client.write(edited(read.payload), read), /protocol/);
  assert.deepEqual(peer.requests,['CPS HELLO']);assert.equal(peer.commits,0);
});

test('V3 programmable functions upload and read back with pinned schema', async t => {
  const {client, peer} = await setup(t, new FakeSerial({protocol:3}));
  assert.equal(client.protocolVersion, 3);
  const read = await client.read(), model = decodePayload(read.payload);
  model.vfos[0].powerLevel = 8;
  Object.assign(model.settings, {totSeconds:600, p1Action:4, p2Action:8, sk1Action:6, sk2Action:3, broadcastKHz:108000});
  const payload = encodePayload(model);
  await client.write(payload, read);
  assert.equal(peer.commits, 1);
  assert.deepEqual(decodePayload((await client.read()).payload), model);
});

test('V1/V2 uploads refuse every nondefault V3 field before BEGIN without discarding the read baseline', async t => {
  for (const protocol of [1, 2]) {
    const {client, peer} = await setup(t, new FakeSerial({protocol}));
    const read = await client.read();
    const changes = [model => {model.vfos[0].powerLevel=1;}, ...[
      ['totSeconds',30], ['p1Action',1], ['p2Action',1], ['sk1Action',1], ['sk2Action',1], ['broadcastKHz',87500],
    ].map(([key,value]) => model => {model.settings[key]=value;})];
    for (const change of changes) {
      const model = decodePayload(read.payload); change(model); peer.requests.length=0;
      await assert.rejects(client.write(encodePayload(model), read), {code:'UNSUPPORTED_FUNCTIONS'});
      assert.deepEqual(peer.requests, []);
      assert.equal(peer.commits, 0);
    }
    // Original reserved defaults stay zero, permitting lossless legacy edits.
    await client.write(edited(read.payload), read);
    assert.equal(peer.commits, 1);
  }
});

test('upload stages all records, publishes one atomic commit, verifies HELLO and advances origin', async t => {
  const { client, peer } = await setup(t);
  const baseline = await client.read();
  const next = edited(baseline.payload), before = peer.active.slice();
  peer.requests.length = 0;
  const result = await client.write(next, baseline);
  assert.deepEqual(result, { ...origin(peer), unchanged: false });
  assert.deepEqual(peer.active, next);
  assert.equal(peer.commits, 1);
  assert.equal(peer.duringStage.length, 35);
  for (const snapshot of peer.duringStage) assert.deepEqual(snapshot, before);
  assert.match(peer.requests[1], /^CPS BEGIN (?!00000000)[0-9A-F]{8} 19$/);
  assert.equal(peer.requests.filter(command => command.startsWith('CPS PUT')).length, 35);
  assert.equal(peer.requests.filter(command => command.startsWith('CPS COMMIT')).length, 1);
  assert.equal(peer.requests.at(-1), 'CPS HELLO');
  const second = await client.write(edited(next), result);
  assert.equal(second.revision, 21);
  assert.equal(peer.commits, 2);
});

test('unchanged upload sends HELLO only, writes no settings, and presentation exceptions are harmless', async t => {
  const { client, peer } = await setup(t, new FakeSerial(), { onProgress() { throw new Error('UI failed'); } });
  const read = await client.read();
  peer.requests.length = 0;
  assert.deepEqual(await client.write(read.payload, read), { ...origin(peer), unchanged: true });
  assert.deepEqual(peer.requests, ['CPS HELLO']);
  assert.equal(peer.commits, 0);
});

test('stale radio revision or CRC refuses before BEGIN and requires a new download', async t => {
  for (const change of [peer => peer.revision++, peer => { peer.active = edited(peer.active); }]) {
    const { client, peer } = await setup(t);
    const read = await client.read();
    change(peer);
    peer.requests.length = 0;
    await assert.rejects(client.write(edited(read.payload), read), { code: 'STALE' });
    assert.deepEqual(peer.requests, ['CPS HELLO']);
    await assert.rejects(client.write(edited(read.payload), origin(peer)), { code: 'NEED_READ' });
    assert.equal(peer.requests.length, 1);
  }
});

test('invalid payload or forged origin is rejected before any serial request', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read();
  peer.requests.length = 0;
  const invalid = read.payload.slice(); invalid[31] = 1;
  await assert.rejects(client.write(invalid, read), /empty record contains data/);
  await assert.rejects(client.write(edited(read.payload), { revision: read.revision, crc: read.crc ^ 1 }), { code: 'NEED_READ' });
  assert.deepEqual(peer.requests, []);
});

test('clean staging refusal aborts once and preserves the old valid snapshot', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read(), before = peer.active.slice();
  peer.override = (command, response) => command.startsWith('CPS PUT') && command.split(' ')[3] === '7'
    ? 'CPS ERR INVALID\r\n' : response;
  await assert.rejects(client.write(edited(read.payload), read), { code: 'REFUSED', radioCode: 'INVALID' });
  assert.deepEqual(peer.active, before);
  assert.equal(peer.commits, 0);
  assert.equal(peer.aborts, 1);
  assert.equal(peer.stage, null);
  assert.equal(client.connected, true);
});

test('ambiguous staging acknowledgement taints the stream, sends no more commands, keeps old snapshot', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read(), before = peer.active.slice();
  peer.override = (command, response) => command.startsWith('CPS PUT') ? response.replace('CPS OK PUT', 'CPS OK WRONG') : response;
  await assert.rejects(client.write(edited(read.payload), read), { code: 'PROTOCOL' });
  assert.equal(client.connected, false);
  assert.deepEqual(peer.active, before);
  assert.equal(peer.commits, 0);
  assert.equal(peer.aborts, 0);
  const requests = peer.requests.length;
  await assert.rejects(client.read(), { code: 'NOT_CONNECTED' });
  assert.equal(peer.requests.length, requests);
});

test('lost COMMIT ACK is uncertain, never retried; reconnect and actual read resolve it', async t => {
  const { client, peer } = await setup(t, new FakeSerial(), { timeoutMs: 500 });
  const read = await client.read(), next = edited(read.payload);
  peer.override = (command, response) => command.startsWith('CPS COMMIT') ? undefined : response;
  await assert.rejects(client.write(next, read), { code: 'UNCERTAIN', uncertain: true });
  assert.deepEqual(peer.active, next);
  assert.equal(peer.commits, 1);
  assert.equal(peer.aborts, 0);
  assert.equal(client.connected, false);
  await assert.rejects(client.write(next, read), { code: 'NOT_CONNECTED' });
  assert.equal(peer.commits, 1);
  await client.disconnect();
  peer.override = null;
  await client.connect();
  await assert.rejects(client.write(edited(next), origin(peer)), { code: 'NEED_READ' });
  const resolved = await client.read();
  assert.deepEqual(resolved.payload, next);
  assert.equal(resolved.revision, 20);
});

test('wrong COMMIT acknowledgement and failed post-commit HELLO both require fresh read', async t => {
  for (const mode of ['commit', 'post']) {
    const { client, peer } = await setup(t);
    const read = await client.read();
    peer.override = (command, response, radio) => {
      if (mode === 'commit' && command.startsWith('CPS COMMIT')) return response.replace(' 20 ', ' 21 ');
      if (mode === 'post' && command === 'CPS HELLO' && radio.commits) return response.replace(' 20 ', ' 21 ');
      return response;
    };
    await assert.rejects(client.write(edited(read.payload), read), { code: 'UNCERTAIN', uncertain: true });
    assert.equal(peer.commits, 1);
    assert.equal(peer.aborts, 0);
    assert.equal(client.connected, false);
  }
});

test('all failures after COMMIT, including a clean refusal, remain uncertain without retries', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read();
  peer.override = (command, response) => command.startsWith('CPS COMMIT') ? 'CPS ERR COMMIT\r\n' : response;
  await assert.rejects(client.write(edited(read.payload), read), { code: 'UNCERTAIN' });
  assert.equal(peer.commits, 1);
  assert.equal(peer.requests.filter(command => command.startsWith('CPS COMMIT')).length, 1);
  assert.equal(peer.aborts, 0);
});

test('USB disconnect after commit publication is uncertain, keeps published data and never retries', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read(), next = edited(read.payload);
  peer.override = (command, response, radio) => {
    if (command.startsWith('CPS COMMIT')) radio.unplug();
    return response;
  };
  await assert.rejects(client.write(next, read), { code: 'UNCERTAIN', uncertain: true });
  assert.equal(peer.commits, 1);
  assert.equal(peer.aborts, 0);
  assert.deepEqual(peer.active, next);
  assert.equal(client.connected, false);
});

test('bad identity, revision overflow and malformed bounded frames close connect without settings commands', async t => {
  const replies = [
    'CPS HELLO STOCK-DM32 1 32 2 19 12345678\r\n',
    'CPS HELLO DM32P25 4 32 2 19 12345678\r\n',
    'CPS HELLO DM32P25 1 32 2 4294967296 12345678\r\n',
    'CPS HELLO DM32P25 1 32 2 19 12345678\n',
    'CPS HELLO DM32P25 1 32 2 19 12345678\rX\n',
    new Uint8Array([255, 13, 10]),
    'X'.repeat(120) + '\r\n',
    'CPS ERR BUSY\r\nCPS ERR BUSY\r\n',
  ];
  for (const reply of replies) {
    const peer = new FakeSerial({ override: () => reply });
    const client = new CpsClient({ serial: peer, timeoutMs: 30 });
    t.after(() => client.disconnect());
    await assert.rejects(client.connect());
    assert.equal(client.connected, false);
    assert.deepEqual(peer.requests, ['CPS HELLO']);
    assert.equal(peer.closeCount, 1);
  }
});

test('late response after deadline is discarded; no following command can consume its ACK', async t => {
  const { client, peer } = await setup(t);
  client.timeoutMs = 20; // Restrict the delayed exchange, not recovery reads under CI load.
  const staleController = peer.controller;
  peer.override = (command, response) => {
    if (command === 'CPS GET 0') {
      setTimeout(() => peer.reply(response, staleController), 40);
      return undefined;
    }
    return response;
  };
  await assert.rejects(client.read(), { code: 'TIMEOUT' });
  const requests = peer.requests.length;
  await assert.rejects(client.read(), { code: 'NOT_CONNECTED' });
  await tick(50);
  assert.equal(peer.requests.length, requests);
  await client.disconnect();
  peer.override = null;
  client.timeoutMs = 500;
  await client.connect();
  assert.deepEqual((await client.read()).payload, peer.active);
});

test('physical disconnect rejects the pending read and clears qualification', async t => {
  const { client, peer } = await setup(t);
  await client.read();
  peer.override = command => {
    if (command === 'CPS GET 0') setTimeout(() => peer.unplug(), 0);
    return command.startsWith('CPS GET') ? undefined : peer.handle(command);
  };
  await assert.rejects(client.read(), { code: 'DISCONNECTED' });
  assert.equal(client.connected, false);
});

test('overlapping user operations are refused rather than interleaved on the stream', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read();
  client.timeoutMs = 30; // Only the intentionally unanswered exchange has a short deadline.
  peer.override = (command, response) => command === 'CPS GET 0' ? undefined : response;
  const pending = client.read();
  await assert.rejects(client.write(edited(read.payload), read), { code: 'IN_USE' });
  await assert.rejects(pending, { code: 'TIMEOUT' });
});

test('radio BUSY/PTT refuses programming without bypassing state or emitting BEGIN', async t => {
  const { client, peer } = await setup(t);
  const read = await client.read();
  peer.busy = true;
  peer.requests.length = 0;
  await assert.rejects(client.write(edited(read.payload), read), { code: 'REFUSED', radioCode: 'BUSY' });
  assert.deepEqual(peer.requests, ['CPS HELLO']);
  assert.equal(peer.commits, 0);
  assert.equal(client.connected, true);
});

test('download checksum, final revision and record identity failures never qualify an upload', async t => {
  for (const mode of ['crc', 'revision', 'record']) {
    const { client, peer } = await setup(t);
    let hellos = 0;
    peer.override = (command, response) => {
      if (command === 'CPS HELLO') {
        hellos++;
        if (mode === 'crc') return response.replace(/ [0-9A-F]{8}\r\n$/, ' 00000000\r\n');
        if (mode === 'revision' && hellos === 2) return response.replace(' 19 ', ' 20 ');
      }
      if (mode === 'record' && command === 'CPS GET 4') return response.replace('CPS DATA 4 ', 'CPS DATA 5 ');
      return response;
    };
    await assert.rejects(client.read());
    assert.equal(peer.commits, 0);
    if (client.connected) await assert.rejects(client.write(edited(peer.active), origin(peer)), { code: 'NEED_READ' });
  }
});

test('revision wrap uses uint32 acknowledgement and verification', async t => {
  const { client, peer } = await setup(t, new FakeSerial({ revision: 0xFFFFFFFF }));
  const read = await client.read();
  const result = await client.write(edited(read.payload), read);
  assert.equal(result.revision, 0);
  assert.equal(peer.commits, 1);
});

test('disconnect cancels a pending picker result before opening a port', async t => {
  const peer = new FakeSerial();
  let choose;
  peer.requestPort = () => new Promise(resolve => { choose = resolve; });
  const client = new CpsClient({ serial: peer });
  t.after(() => client.disconnect());
  const connecting = client.connect();
  await client.disconnect();
  choose(peer.port);
  await assert.rejects(connecting, { code: 'DISCONNECTED' });
  assert.equal(peer.openOptions, undefined);
  assert.deepEqual(peer.requests, []);
});

test('unsupported browser and user-cancelled chooser do not access any device', async () => {
  const unsupported = new CpsClient({ serial: {} });
  await assert.rejects(unsupported.connect(), { code: 'UNSUPPORTED' });
  const cancelled = new CpsClient({ serial: { requestPort: async () => { throw new Error('Chooser cancelled'); } } });
  await assert.rejects(cancelled.connect(), /Chooser cancelled/);
  assert.equal(cancelled.connected, false);
});

test('a hung browser write still reaches its deadline and bounded disconnect cleanup', { timeout: 700 }, async t => {
  const peer = new FakeSerial({ override: () => new Promise(() => {}) });
  const client = new CpsClient({ serial: peer, timeoutMs: 15 });
  t.after(() => client.disconnect());
  await assert.rejects(client.connect(), { code: 'TIMEOUT' });
  assert.equal(client.connected, false);
  assert.equal(peer.closeCount, 1);
  assert.deepEqual(peer.requests, ['CPS HELLO']);
});

test('an earlier staged transaction gives idle-timeout recovery guidance without issuing writes', async () => {
  const peer = new FakeSerial();
  peer.stage = peer.active.slice();
  const client = new CpsClient({serial: peer});
  await assert.rejects(client.connect(), error => error.code === 'REFUSED' &&
    error.radioCode === 'TRANSACTION' && /60 seconds/.test(error.message));
  assert.equal(client.connected, false);
  assert.deepEqual(peer.requests, ['CPS HELLO']);
  assert.equal(peer.commits, 0);
  assert.equal(peer.aborts, 0);
});

test('V4 pins 256/387 geometry and transfers high channels, zones and independent TG lists once', async t => {
  const progress = [], {client,peer}=await setup(t,new FakeSerial({protocol:4,fragment:7}),{onProgress:event=>progress.push(event),timeoutMs:3000});
  const read=await client.read();assert.equal(read.payload.length,12384);assert.equal(progress.at(-1).total,387);
  assert.equal(peer.requests.filter(x=>x.startsWith('CPS GET ')).length,387);
  const model=decodePayload(read.payload);model.channels[255]={...structuredClone(model.vfos[0]),name:'CH256'};
  model.zones[15]={name:'Last zone',channels:[256]};model.scanLists[15]={...createScanList('P25 TG','p25-tg',256),reply:'fixed',replyChannel:256,talkgroups:[1,10,100,1000]};
  Object.assign(model.settings,{selectionA:256,zoneA:16,scanList:15});
  peer.requests.length=0;const bytes=encodePayload(model),result=await client.write(bytes,read);
  assert.equal(peer.commits,1);assert.equal(peer.requests.filter(x=>x.startsWith('CPS PUT ')).length,387);
  assert(peer.requests.every(x=>new TextEncoder().encode(x+'\r\n').length<=120));
  assert.deepEqual(peer.active,bytes);assert.equal(result.revision,read.revision+1);
  assert.equal(peer.duringStage.length,387);assert(peer.duringStage.every(snapshot=>Buffer.from(snapshot).equals(Buffer.from(read.payload))));
  assert.deepEqual((await client.read()).payload,bytes);
});

test('geometry mismatches never silently truncate or start a transaction', async t => {
  for (const protocol of [1,2,3,4]) {
    const {client,peer}=await setup(t,new FakeSerial({protocol})),read=await client.read();
    const wrong=protocol===4?encodePayload(createDefaultModel(3)):encodePayload(upgradeModel(decodePayload(read.payload)));
    peer.requests.length=0;await assert.rejects(client.write(wrong,read),{code:'UNSUPPORTED_GEOMETRY'});
    assert.deepEqual(peer.requests,[]);assert.equal(peer.commits,0);
  }
});

test('V4 lost commit reply remains uncertain once and reconnect/read recovers full expanded snapshot', async t => {
  let drop=true;
  const peer=new FakeSerial({protocol:4,override:(command,response)=>drop&&command.startsWith('CPS COMMIT ')?null:response});
  const {client}=await setup(t,peer,{timeoutMs:200});
  const read=await client.read(),bytes=edited(read.payload);
  await assert.rejects(client.write(bytes,read),{code:'UNCERTAIN'});assert.equal(peer.commits,1);
  await assert.rejects(client.write(bytes,read),{code:'NOT_CONNECTED'});assert.equal(peer.commits,1);
  drop=false;await client.disconnect();await client.connect();assert.deepEqual((await client.read()).payload,bytes);
});


test('V5 contact directory and P25 individual destination transfer without truncation', async t => {
  const {client,peer}=await setup(t,new FakeSerial({protocol:5}),{timeoutMs:3000});
  const read=await client.read(), model=decodePayload(read.payload);
  assert.equal(model.contacts.length,96);assert.equal(read.payload.length,15456);
  model.contacts[95]={protocol:'Both',type:'unit',id:0xffffff,name:'LAST CONTACT'};
  model.vfos[0].privateCall=true;model.vfos[0].destinationId=0x123456;
  const payload=encodePayload(model);await client.write(payload,{revision:read.revision,crc:read.crc});
  assert.deepEqual(decodePayload(peer.active),model);
  assert.equal(peer.requests.filter(x=>x.startsWith('CPS PUT ')).length,483);
  assert.equal(peer.commits,1);
});

test('V6 transfers all 499 records and keeps older radio geometry refusal before BEGIN',async t=>{
  const {client,peer}=await setup(t,new FakeSerial({protocol:6}),{timeoutMs:3000});
  const read=await client.read(),model=decodePayload(read.payload);
  model.trunkSystems[7]={name:'RX SYSTEM',mode:'rx-only',wacn:0,systemId:0,nac:0x293,rfss:0,site:0,sourceId:0,talkgroup:1,controls:[440075000]};
  model.settings.trunkSystem=8;await client.write(encodePayload(model),read);
  assert.deepEqual(decodePayload(peer.active),model);assert.equal(peer.requests.filter(x=>x.startsWith('CPS PUT ')).length,499);
  const legacy=await setup(t,new FakeSerial({protocol:5})),old=await legacy.client.read(),count=legacy.peer.requests.length;
  await assert.rejects(legacy.client.write(encodePayload(model),old),{code:'UNSUPPORTED_GEOMETRY'});
  assert.equal(legacy.peer.requests.length,count);
});

test('V5 never upgrades a V4 snapshot implicitly before writing',async t=>{
  const {client,peer}=await setup(t,new FakeSerial({protocol:5}));
  const read=await client.read();const before=peer.requests.length;
  await assert.rejects(client.write(encodePayload(createDefaultModel(4)),{revision:read.revision,crc:read.crc}),{code:'UNSUPPORTED_GEOMETRY'});
  assert.equal(peer.requests.length,before);assert.equal(peer.commits,0);
});


test('V4 firmware refuses V5 directory and Last heard button data before any transaction',async t=>{
  const {client,peer}=await setup(t,new FakeSerial({protocol:4}),{timeoutMs:3000});
  const read=await client.read(),model=upgradeModel(decodePayload(read.payload));
  model.settings.p1Action=9;model.contacts[0]={protocol:'Both',type:'unit',id:1,name:'ONE'};
  const before=peer.requests.length;
  await assert.rejects(client.write(encodePayload(model),{revision:read.revision,crc:read.crc}),{code:'UNSUPPORTED_GEOMETRY'});
  assert.equal(peer.requests.length,before);assert.equal(peer.commits,0);
});
