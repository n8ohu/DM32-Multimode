// SPDX-License-Identifier: GPL-3.0-or-later
// Independent int64 convolution oracle for the production polyphase FIR.
#include "p25_demod_filter.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
static uint32_t random_state=1;
static unsigned cases;
static uint32_t next_random(void) {random_state=random_state*1664525u+1013904223u;return random_state;}
static int16_t reference(const int16_t *input,unsigned phase) {
    int64_t sum=0;
    for(unsigned k=phase;k<121u;k+=6u)sum+=(int64_t)p25_interp[k] * *input--;
    int64_t value=sum/32768; // C signed division truncates toward zero.
    return value>INT16_MAX?INT16_MAX:value<INT16_MIN?INT16_MIN:(int16_t)value;
}
static void check(const int16_t history[21]) {
    int16_t output[6];p25_interp_sample(history+20,output);
    for(unsigned phase=0;phase<6u;++phase) {assert(output[phase]==reference(history+20,phase));++cases;}
}
static void coefficient_proof(void) {
    const unsigned expected_abs[6]={32790,53933,68341,73448,68341,53933};
    for(unsigned phase=0;phase<6u;++phase) {
        uint64_t partial[2]={0},total=0;
        for(unsigned k=phase,tap=0;k<121u;k+=6u,++tap) {
            uint64_t magnitude=(uint64_t)(p25_interp[k]<0?-p25_interp[k]:p25_interp[k]);
            total+=magnitude;partial[tap>=10u]+=magnitude;
            if(!phase)assert(p25_interp[k]==(k==60u?32790:0));
        }
        assert(total==expected_abs[phase]);
        if(phase)for(unsigned half=0;half<2u;++half) {
            // This absolute bound proves EVERY intermediate addition fits for
            // all int16 input histories, rather than relying only on sampling.
            assert(partial[half]<=42363u&&partial[half]*32768u<=INT32_MAX);
        }
    }
}
static void extremes(void) {
    int16_t history[21];const int16_t edge[]={INT16_MIN,INT16_MIN+1,-1,0,1,INT16_MAX-1,INT16_MAX};
    for(unsigned e=0;e<sizeof edge/sizeof *edge;++e) {
        for(unsigned i=0;i<21u;++i)history[i]=edge[e];
        check(history);
        for(unsigned i=0;i<21u;++i)history[i]=(i&1u)?edge[e]:(int16_t)~edge[e];
        check(history);
    }
    // For each phase maximize/minimize the absolute convolution by aligning
    // every full-scale sample to its coefficient sign, exercising saturation.
    for(unsigned phase=0;phase<6u;++phase)for(unsigned sign=0;sign<2u;++sign) {
        for(unsigned i=0;i<21u;++i)history[i]=0;
        for(unsigned k=phase,j=0;k<121u;k+=6u,++j)
            history[20u-j]=((p25_interp[k]<0)^sign)?INT16_MIN:INT16_MAX;
        check(history);
    }
    // Exhaust the direct center phase's signed input domain, and impulse
    // histories expose every coefficient's sign/rounding near small values.
    for(unsigned i=0;i<21u;++i)history[i]=0;
    for(int32_t value=INT16_MIN;value<=INT16_MAX;++value) {history[10]=(int16_t)value;check(history);}
    for(unsigned at=0;at<21u;++at)for(unsigned e=0;e<sizeof edge/sizeof *edge;++e) {
        for(unsigned i=0;i<21u;++i)history[i]=0;
        history[at]=edge[e];check(history);
    }
}
int main(void) {
    coefficient_proof();extremes();int16_t history[21];
    for(unsigned n=0;n<1000000u;++n) {
        for(unsigned i=0;i<21u;++i)history[i]=(int16_t)(next_random()>>16);
        check(history);
    }
    printf("P25 FIR exact int64 oracle: PASS (%u outputs; all-domain partial-sum bounds)\n",cases);return 0;
}
