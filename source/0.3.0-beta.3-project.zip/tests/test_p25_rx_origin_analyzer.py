# SPDX-License-Identifier: GPL-3.0-or-later
"""Canonical new RXORIGIN wire fixtures; corruption tests without hardware."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("rx_origin_test_parser", ROOT / "scripts/analyze-p25-rx-origin.py")
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)
U32 = 0xFFFFFFFF


def half(index, origin=100000, **changes):
    values = dict(first=index * 256, origin=(origin + index * 32000) & U32,
                  complete=(origin + (index + 1) * 32000) & U32,
                  published=0xFFFA0000 + index, completed=0xFFFA0000 + index,
                  irq_count=index + 1, early=224, tail=32, verified=16,
                  mismatch=0, flags=8192, max_read=80, max_queue=3000,
                  last_delivery=(origin + (index + 1) * 32000 + 4000) & U32)
    values.update(changes)
    return struct.pack("<Q5I6H2I", *values.values())


def event(*, kind=1, tick=600, ordinal=120, origin=100000, cpu=None,
          stream=7, lane_epoch=1, chunk=None, read_begin=None, read_end=None,
          irq_origin=None, irq_count=None, nac=0x293, duid=7, status=3,
          lane=0, source_flags=0, evidence=3, descriptor=0, data=bytes(12)):
    chunk = ordinal // 16 * 16 if chunk is None else chunk
    irq_origin = (origin + (chunk // 256) * 32000) & U32 if irq_origin is None else irq_origin
    irq_count = chunk // 256 + 1 if irq_count is None else irq_count
    read_begin = (origin + (chunk + 16) * 125 + 500) & U32 if read_begin is None else read_begin
    read_end = (read_begin + 80) & U32 if read_end is None else read_end
    cpu = (read_end + 1700) & U32 if cpu is None else cpu
    return struct.pack("<Q7I2H4BH2B12sI", tick, cpu & U32, stream, lane_epoch,
                       read_begin & U32, read_end & U32, irq_origin, irq_count,
                       chunk, nac, kind, duid, status, lane, source_flags,
                       evidence, descriptor, data, ordinal)


def unit(ordinal=240, **changes):
    options = dict(kind=2, tick=ordinal * 6, ordinal=ordinal, status=0, lane=255,
                   evidence=4, descriptor=0x10,
                   data=bytes.fromhex("ba0000312301012000701c21"))
    options.update(changes)
    return event(**options)


def fault(reason=4, **changes):
    options = dict(kind=3, tick=0, ordinal=0, chunk=0, read_begin=0, read_end=0,
                   irq_origin=0, irq_count=0, nac=0, duid=0, status=0, lane=255,
                   evidence=0, descriptor=0, data=bytes([reason]) + bytes(11), cpu=160000)
    options.update(changes)
    return event(**options)


def capture(events=None, *, samples=512, origin=100000, halves=None,
            state="complete", faults=0, dump=1, extra="", consumed=None):
    events = [event(), unit()] if events is None else events
    halves = [half(i, origin=origin) for i in range(samples // 256)] if halves is None else halves
    consumed = samples if consumed is None else consumed
    header = (f"RXORIGIN schema=1 state={state} samples={samples} produced={samples} "
              f"consumed={consumed} verified={samples} halves={len(halves)} events={len(events)} "
              f"guard_us=2000 stream_epoch=7 faults={faults} half_bytes=48 event_bytes=64 "
              f"carrier_hz=440075000 marker_capacity=192 service=timer500 clock=recorder_unqualified dump={dump}{extra}")
    rows = ([f"RXORIGIN_HALF index={i} data={v.hex()}" for i, v in enumerate(halves)] +
            [f"RXORIGIN_EVENT index={i} data={v.hex()}" for i, v in enumerate(events)]) if dump else []
    return "\r\n".join([header, *rows,
                          f"RXORIGIN_END halves={len(halves)} events={len(events)} state={state}"]) + "\r\n"


class OriginAnalysisTests(unittest.TestCase):
    def refuses(self, text):
        with self.assertRaises(A.OriginError):
            A.parse_trace(text)

    def test_canonical_offsets_and_distinct_tick_meanings(self):
        self.assertEqual(A.EVENT.size, 64)
        wire = unit()
        self.assertEqual(struct.unpack_from("<Q", wire, 0)[0], 1440)
        self.assertEqual(struct.unpack_from("<H", wire, 36)[0], 240)
        self.assertEqual(wire[40:48], bytes([2, 7, 0, 255, 0, 0, 4, 0x10]))
        self.assertEqual(wire[48:60].hex(), "ba0000312301012000701c21")
        self.assertEqual(struct.unpack_from("<I", wire, 60)[0], 240)
        result = A.parse_trace(capture())
        self.assertTrue(result["all_streams_coherent"])
        self.assertTrue(result["all_producers_coherent"])
        rows = result["captures"][0]["events"]
        self.assertEqual(rows[0]["original_status_tick"], 600)
        self.assertIn("no frame edge", rows[1]["tick_scope"])
        self.assertEqual(rows[1]["event_tick"], rows[1]["delivery_input_ordinal"] * 6)
        for key in A.FLAGS:
            self.assertIs(result[key], False)
        self.assertFalse(result["captures"][0]["event_observations"]["external_rf_matching_performed"])

    def test_backdated_status_uses_delivery_chunk_irq_not_tick_half(self):
        # Original status is in half0, but its delivering chunk is in half1.
        row = event(tick=600, ordinal=300)
        result = A.parse_trace(capture([row]))["captures"][0]["events"][0]
        self.assertEqual(result["source_half_index"], 1)
        self.assertEqual(result["source_origin_irq_us"], 132000)
        self.assertEqual(result["source_chunk_first"], 288)
        self.assertGreater(result["nominal_original_status_age_from_source_irq_us"],
                           result["nominal_delivery_age_from_source_irq_us"])

    def test_uint32_wrap_is_supported(self):
        origin = U32 - 12000
        result = A.parse_trace(capture([event(origin=origin)], origin=origin))
        self.assertTrue(result["all_streams_coherent"])
        row = result["captures"][0]["events"][0]
        self.assertEqual(row["source_read_elapsed_us"], 80)
        self.assertEqual(row["read_end_to_callback_us"], 1700)

    def test_unknown_missing_duplicate_header_and_record_fields(self):
        base = capture()
        for changed in (base.replace("schema=1", "schema=2"),
                        base.replace("carrier_hz=440075000", "carrier_hz=440087500"),
                        base.replace("event_bytes=64", "event_bytes=32"),
                        base.replace("marker_capacity=192", "marker_capacity=384"),
                        base.replace("guard_us=2000", "guard_us=2000 alien=1"),
                        base.replace("schema=1", "schema=1 schema=1"),
                        base.replace(" schema=1", ""),
                        base.replace("RXORIGIN_EVENT index=0", "RXORIGIN_EVENT extra=0 index=0"),
                        base.replace("RXORIGIN_END halves=2", "RXORIGIN_END extra=0 halves=2")):
            with self.subTest(changed=changed[:100]): self.refuses(changed)

    def test_finite_sample_and_event_bounds(self):
        self.assertTrue(A.parse_trace(capture([], samples=8192))["all_streams_coherent"])
        self.refuses(capture([], samples=8448))
        self.refuses(capture([fault()] * 193, state="fault", faults=4096))
        self.refuses(capture().replace("samples=512", "samples=513"))

    def test_half_hash_counts_flags_and_order_are_not_bypassed(self):
        self.refuses(capture(halves=[half(0, completed=1), half(1)]))
        self.refuses(capture().replace("RXORIGIN_HALF index=1", "RXORIGIN_HALF index=0"))
        self.refuses(capture().replace("produced=512", "produced=496"))
        bad = capture(halves=[half(0, flags=8192 | 0x8000), half(1)])
        self.refuses(bad)
        bad = capture(halves=[half(0, flags=512, verified=15, mismatch=1), half(1)])
        bad = bad.replace("verified=512", "verified=496")
        self.assertFalse(A.parse_trace(bad)["all_streams_coherent"])

    def test_truncated_reordered_and_odd_hex_rows_fail(self):
        base = capture()
        for bad in (base[:base.index("RXORIGIN_END")],
                    base.replace("RXORIGIN_EVENT index=1", "RXORIGIN_EVENT index=0"),
                    base.replace("RXORIGIN_EVENT index=0 data=", "RXORIGIN_EVENT index=0 data=f"),
                    base.replace("events=2 state=complete", "events=1 state=complete"),
                    base.replace("RXORIGIN_EVENT", "RXSTREAM_MARK")):
            self.refuses(bad)
        lines = base.splitlines()
        lines[2], lines[3] = lines[3], lines[2]
        self.refuses("\n".join(lines))

    def test_source_context_must_match_delivery_chunk_and_half(self):
        changes = [dict(chunk=113), dict(ordinal=128, chunk=112), dict(ordinal=512),
                   dict(irq_count=2), dict(irq_origin=132000), dict(source_flags=1),
                   dict(stream=8), dict(nac=4096), dict(chunk=8192, ordinal=8192)]
        for change in changes:
            with self.subTest(change=change): self.refuses(capture([event(**change)]))

    def test_source_cpu_brackets_are_wrap_safe_and_bounded_by_half_read(self):
        for change in (dict(read_begin=120000, read_end=119999),
                       dict(read_begin=120000, read_end=120081),
                       dict(read_begin=120000, read_end=120080, cpu=120079),
                       dict(read_begin=99999, read_end=100000)):
            with self.subTest(change=change): self.refuses(capture([event(**change)]))

    def test_status_canonical_evidence_duid_lane_payload_and_tick(self):
        changes = [dict(kind=4), dict(duid=5), dict(status=0), dict(status=4),
                   dict(evidence=2), dict(evidence=4), dict(lane=10),
                   dict(evidence=0, lane=0), dict(data=b"x" * 12),
                   dict(descriptor=0x10), dict(tick=721)]
        for change in changes:
            with self.subTest(change=change): self.refuses(capture([event(**change)]))
        self.assertTrue(A.parse_trace(capture([event(evidence=0, lane=255)]))["all_streams_coherent"])
        self.assertTrue(A.parse_trace(capture([event(evidence=1)]))["all_streams_coherent"])

    def test_native_unit_canonical_fields_and_delivery_tick(self):
        for change in (dict(tick=1439), dict(status=1), dict(duid=5), dict(lane=0),
                       dict(evidence=7), dict(evidence=0), dict(descriptor=0),
                       dict(descriptor=0x40), dict(descriptor=0x11)):
            with self.subTest(change=change): self.refuses(capture([unit(**change)]))

    def test_native_multiblock_groups_are_contiguous_and_unambiguous(self):
        rows = [unit(descriptor=0x30 + i, data=bytes([i]) * 12) for i in range(3)]
        result = A.parse_trace(capture(rows))["captures"][0]["event_observations"]
        self.assertTrue(result["native_units"][0]["complete"])
        self.assertEqual(result["native_units"][0]["payload_blocks"], [bytes([i] * 12).hex() for i in range(3)])
        for bad in ([rows[1]], [rows[0], rows[2]], [rows[0], rows[1], rows[1]],
                    [unit(), unit()],
                    [rows[0], unit(descriptor=0x21)]):
            self.refuses(capture(bad))
        result = A.parse_trace(capture(rows[:1]))
        self.assertFalse(result["all_streams_coherent"])
        self.assertFalse(result["captures"][0]["event_observations"]["native_units"][0]["match_eligible"])

    def test_faults_are_canonical_and_cannot_claim_coherence(self):
        for reason in range(1, 7):
            parsed = A.parse_trace(capture([fault(reason)], state="fault", faults=16))
            self.assertFalse(parsed["all_streams_coherent"])
            self.assertEqual(parsed["captures"][0]["events"][0]["fault_reason"], reason)
        for change in (dict(tick=1), dict(ordinal=1), dict(nac=1), dict(duid=255),
                       dict(read_begin=1), dict(irq_count=1), dict(evidence=1),
                       dict(lane=0), dict(data=bytes([1, 1]) + bytes(10))):
            with self.subTest(change=change): self.refuses(capture([fault(**change)]))
        self.refuses(capture([fault(0)]))
        self.refuses(capture([fault(7)]))

    def test_initial_loss_is_retained_separately_from_coherent_producer(self):
        parsed = A.parse_trace(capture([fault(1, cpu=100000), event(), unit()]))
        self.assertTrue(parsed["all_producers_coherent"])
        self.assertFalse(parsed["all_streams_coherent"])
        item = parsed["captures"][0]
        self.assertTrue(item["producer_coherent"])
        self.assertEqual(item["events"][0]["fault_reason"], 1)
        segments = item["event_observations"]["segments"]
        self.assertEqual(len(segments), 2)
        self.assertFalse(segments[0]["locally_coherent"])
        self.assertTrue(segments[1]["locally_coherent"])
        self.assertEqual(segments[1]["boundary_reasons"][0]["name"], "lane_loss")
        self.assertEqual([e["segment_index"] for e in item["events"]], [0, 1, 1])
        self.assertFalse(item["events"][0]["mapping_eligible"])
        self.assertTrue(item["events"][1]["mapping_eligible"])
        self.assertTrue(item["event_observations"]["native_units"][0]["match_eligible"])
        self.assertFalse(parsed["sample_origin_qualified"])

    def test_identity_changes_segment_payload_matching_without_erasing_loss(self):
        rows = [unit(ordinal=120), unit(ordinal=240, lane_epoch=2)]
        parsed = A.parse_trace(capture(rows))
        self.assertTrue(parsed["all_producers_coherent"])
        self.assertFalse(parsed["all_streams_coherent"])
        observation = parsed["captures"][0]["event_observations"]
        self.assertEqual(observation["identity_change_events"], [1])
        self.assertEqual([unit["segment_index"] for unit in observation["native_units"]], [0, 1])
        self.assertTrue(all(unit["payload_identity_unique_within_segment"] for unit in observation["native_units"]))
        self.assertTrue(all(not unit["payload_identity_unique_within_capture"] for unit in observation["native_units"]))
        self.assertTrue(all(not unit["external_rf_match_qualified"] for unit in observation["native_units"]))

    def test_native_block_group_cannot_cross_a_fault_or_identity_boundary(self):
        first = unit(ordinal=120, descriptor=0x20)
        second = unit(ordinal=120, descriptor=0x21, lane_epoch=2)
        self.refuses(capture([first, second]))
        self.refuses(capture([first, fault(1, cpu=120000), unit(ordinal=240, descriptor=0x21)]))

    def test_callback_time_and_lane_epochs_cannot_regress(self):
        self.refuses(capture([event(), unit(cpu=100000)]))
        self.refuses(capture([event(lane_epoch=2), unit(lane_epoch=1)]))

    def test_delivery_ordinals_and_published_chunk_context_are_consistent(self):
        self.refuses(capture([unit(ordinal=240), event(ordinal=120, cpu=150000)]))
        self.refuses(capture([event(ordinal=120),
                              unit(ordinal=121, read_begin=116501, read_end=116581)]))

    def test_repeated_native_payload_is_not_a_unique_external_match(self):
        rows = [unit(ordinal=120), unit(ordinal=240)]
        parsed = A.parse_trace(capture(rows))
        self.assertTrue(parsed["all_streams_coherent"])
        observation = parsed["captures"][0]["event_observations"]
        self.assertEqual(observation["ambiguous_payload_only_unit_matches"], 2)
        self.assertTrue(all(not row["match_eligible"] for row in observation["native_units"]))
        self.assertTrue(all(not row["external_rf_match_qualified"] for row in observation["native_units"]))

    def test_duplicate_original_status_ticks_refused_and_gaps_incoherent(self):
        self.refuses(capture([event(), event(ordinal=200)]))
        result = A.parse_trace(capture([event(), event(tick=961, ordinal=200)]))
        self.assertTrue(result["all_streams_coherent"])
        result = A.parse_trace(capture([event(), event(tick=970, ordinal=200)]))
        self.assertFalse(result["all_streams_coherent"])

    def test_optional_worker_group_and_active_status_snapshots(self):
        workers = " worker_calls=32 worker_total_us=32000 worker_max_us=1800 worker_yields=2"
        parsed = A.parse_trace(capture(extra=workers))
        self.assertTrue(parsed["captures"][0]["worker_elapsed_observations"]["available"])
        self.assertTrue(A.parse_trace(capture(dump=0, state="recording") + capture())["all_streams_coherent"])
        self.refuses(capture(extra=" worker_calls=32"))
        self.refuses(capture(extra=workers.replace("worker_calls=32", "worker_calls=31")))

    def test_cli_exit_codes_and_input_byte_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "origin.log"
            output = Path(directory) / "report.json"
            source.write_text(capture())
            self.assertEqual(A.main([str(source), "--output", str(output)]), 0)
            self.assertTrue(json.loads(output.read_text())["all_streams_coherent"])
            source.write_text(capture([fault()], state="fault", faults=16))
            with redirect_stdout(io.StringIO()): self.assertEqual(A.main([str(source)]), 1)
            source.write_text("invalid")
            with redirect_stderr(io.StringIO()): self.assertEqual(A.main([str(source)]), 2)
            source.write_bytes(b"x" * (A.stream.MAX_INPUT_BYTES + 1))
            with redirect_stderr(io.StringIO()): self.assertEqual(A.main([str(source)]), 2)
        self.refuses("\0" + capture())


if __name__ == "__main__":
    unittest.main()
