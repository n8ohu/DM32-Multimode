"""Independent OP25 trunking fixtures; entirely offline and hardware-free."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("trunking_fixture", ROOT / "scripts/generate-p25-trunking-fixture.py")
generator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(generator)


class TrunkingFixtureTests(unittest.TestCase):
    def test_finite_reproducible_wire_and_serial_inventory(self):
        frames, manifest = generator.make_fixture(repetitions=2)
        self.assertEqual(generator.make_fixture(repetitions=2), (frames, manifest))
        self.assertEqual(list(map(len, frames)), [90, 45, 72]*2)
        self.assertEqual(manifest["units"], 6)
        self.assertEqual(manifest["airtime_seconds_without_preamble"], 414/1200)
        self.assertFalse(manifest["rf_verified"])
        self.assertFalse(manifest["contains_voice"])
        wire_offset = serial_offset = 0
        for frame, entry in zip(frames, manifest["frames"]):
            packet = generator.modem_packet(frame)
            self.assertEqual(packet[:4], bytes((0xE0, len(frame)+4, 0x31, 0)))
            self.assertEqual(packet[4:], frame)
            self.assertEqual(entry["wire_offset"], wire_offset)
            self.assertEqual(entry["serial_offset"], serial_offset)
            self.assertEqual(entry["wire_bytes"], len(frame))
            self.assertEqual(entry["serial_bytes"], len(packet))
            self.assertLessEqual(len(packet), 255)
            self.assertEqual([block["last"] for block in entry["blocks"]],
                             [False]*(len(entry["blocks"])-1)+[True])
            wire_offset += len(frame)
            serial_offset += len(packet)
        for name, data in (("control.bin", b"".join(frames)),
                           ("control-mmdvm.bin", b"".join(map(generator.modem_packet, frames)))):
            self.assertEqual(manifest["files"][name],
                             {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

    def test_pinned_fields_resolve_control_and_voice_without_generator_decoder(self):
        frames, manifest = generator.make_fixture(control_frequency=145712500,
                                                  voice_frequency=145700000,
                                                  talkgroup=1000, nac=0x2A3,
                                                  identifier=7, wacn=0x12345,
                                                  system_id=0x456, rfss=9, site=8,
                                                  source_id=42, repetitions=1)
        words = [bytes.fromhex(block["decoded_hex"])
                 for entry in manifest["frames"] for block in entry["blocks"]]
        self.assertEqual([word[0] & 0x3F for word in words], [0x34, 0x3A, 0x3B, 0, 2, 0])
        self.assertTrue(all(word[1] == 0 for word in words))
        # Decode field positions as documented by OP25 trunking.py, separate
        # from the generator's pack expressions and the native C decoder.
        tsbk = int.from_bytes(words[0], "big")
        identifier = (tsbk >> 76) & 15
        base = (tsbk & ((1 << 48)-1)) >> 16
        step = ((tsbk >> 48) & 1023)*125
        self.assertEqual((identifier, base*5, step), (7, 145700000, 12500))
        self.assertEqual((tsbk >> 72) & 15, 5)
        self.assertEqual((tsbk >> 58) & 0x3FFF, 0)
        def frequency(channel):
            self.assertEqual(channel >> 12, identifier)
            return base*5 + (channel & 4095)*step
        rfss = int.from_bytes(words[1], "big")
        self.assertEqual((rfss >> 56) & 0xFFF, 0x456)
        self.assertEqual(((rfss >> 48) & 255, (rfss >> 40) & 255), (9, 8))
        self.assertEqual(frequency((rfss >> 24) & 0xFFFF), 145712500)
        network = int.from_bytes(words[2], "big")
        self.assertEqual((network >> 52) & 0xFFFFF, 0x12345)
        self.assertEqual((network >> 40) & 0xFFF, 0x456)
        self.assertEqual(frequency((network >> 24) & 0xFFFF), 145712500)
        grant = int.from_bytes(words[3], "big")
        self.assertEqual((grant >> 72) & 255, 0)
        self.assertEqual(frequency((grant >> 56) & 0xFFFF), 145700000)
        self.assertEqual((grant >> 40) & 0xFFFF, 1000)
        self.assertEqual((grant >> 16) & 0xFFFFFF, 42)
        update = int.from_bytes(words[4], "big")
        self.assertEqual(frequency((update >> 64) & 0xFFFF), 145700000)
        self.assertEqual(frequency((update >> 32) & 0xFFFF), 145700000)
        self.assertEqual(((update >> 48) & 0xFFFF, (update >> 16) & 0xFFFF), (1000, 1000))
        self.assertEqual(words[3], words[5])
        self.assertEqual(len(frames), 3)

    def test_reference_loading_creates_no_p25_out(self):
        with tempfile.TemporaryDirectory() as directory:
            code = ("import importlib.util; "
                    f"s=importlib.util.spec_from_file_location('g',{str(ROOT/'scripts/generate-p25-trunking-fixture.py')!r}); "
                    "g=importlib.util.module_from_spec(s); s.loader.exec_module(g); "
                    "g.make_fixture(repetitions=1)")
            subprocess.run([sys.executable, "-c", code], cwd=directory, check=True,
                           capture_output=True, text=True)
            self.assertEqual(list(Path(directory).iterdir()), [])
            changed = Path(directory) / "changed.py"
            changed.write_text(generator.REFERENCE.read_text()+"\n# drift\n")
            with self.assertRaisesRegex(ValueError, "reviewed pin"):
                generator.load_reference(changed)

    def test_invalid_frequency_plan_metadata_and_unbounded_counts_fail(self):
        cases = ({"control_frequency": 430112500}, {"voice_frequency": 145700000},
                 {"control_frequency": 900000000}, {"voice_frequency": 430112501},
                 {"voice_frequency": 430112505}, {"spacing_hz": 126},
                 {"spacing_hz": 0}, {"talkgroup": 0}, {"talkgroup": 65536},
                 {"nac": 4096}, {"wacn": 1 << 20}, {"system_id": 4096},
                 {"rfss": 0}, {"site": 256}, {"source_id": 0},
                 {"identifier": 16}, {"repetitions": 0}, {"repetitions": 201},
                 {"repetitions": True}, {"voice_frequency": 430112500.0})
        for parameters in cases:
            with self.subTest(parameters=parameters), self.assertRaises(ValueError):
                generator.make_fixture(**parameters)
        with self.assertRaises(ValueError):
            generator.modem_packet(b"\0"*90)

    def test_cli_writes_documented_artifacts_only(self):
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()) as output:
            generator.main(["--output", directory, "--repetitions", "1", "--nac", "0x293"])
            folder = Path(directory)
            self.assertEqual({path.name for path in folder.iterdir()},
                             {"control.bin", "control-mmdvm.bin", "manifest.json"})
            frames, manifest = generator.make_fixture(repetitions=1)
            self.assertEqual(json.loads((folder / "manifest.json").read_text()), manifest)
            self.assertEqual((folder / "control.bin").read_bytes(), b"".join(frames))
            self.assertEqual((folder / "control-mmdvm.bin").read_bytes(),
                             b"".join(map(generator.modem_packet, frames)))
            self.assertEqual(json.loads(output.getvalue())["units"], 3)


if __name__ == "__main__":
    unittest.main()
