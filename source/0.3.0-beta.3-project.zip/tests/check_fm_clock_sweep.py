from pathlib import Path
import sys,json
import numpy as np
root=Path(__file__).resolve().parents[1]
import os
os.chdir(root)
sys.path.insert(0,str(root/'scripts'))
from p25_fm_search import search
x=np.fromfile('captures/rx/hotspot-8f875f8-wide-01/rx.be16',dtype='>i2')
results=[]
for ppm in (-200,-100,-50,0,50,100,200):
 report,_=search(x,ppm);results.append(report)
 print(ppm, len(report['sync_hits']),len(report['matching_nac_duid']),report['minimum_sync_bit_errors'],flush=True)
Path('research/analysis/p25-fm-clock-sweep.json').write_text(json.dumps({'capture':'hotspot-8f875f8-wide-01','results':results,'limitation':'Discrete constant-rate hypotheses only; not adaptive clock recovery and does not exclude other drift or filtering effects.'},indent=2)+'\n')

