// SPDX-License-Identifier: GPL-3.0-or-later
// Included by the actual live controller harness; no additional hardware model.
static void test_muted_call_redraw(void) {
    reset();memset(call_contacts,0,sizeof call_contacts);
    normal_mode=true;mon_running=true;mon_have_sync=true;mon_sync_us=now;
    rx_promiscuous=true;
    monitor.call=(p25_receive_policy){.active=true,.lc_valid=true,.source_valid=true,.group_valid=true,
        .state=P25_RX_ENCRYPTED,.nac=0x293,.source=42,.group=10,.emergency=true,.lc_encrypted=true};
    call_contacts[0][0]=P25_CS_CONTACT_OCCUPIED|P25_CS_CONTACT_P25;
    call_contacts[0][1]=42;memcpy(call_contacts[0]+4,"ENCRYPTED CALLER",16);
    mon_shown_context[0]=drawn_screen[0]=0;mon_indicator();
    assert(strstr(drawn_screen,"EMERGENCY CALL") && strstr(drawn_screen,"ENCRYPTED CALLER"));
    unsigned flushes=gfx_flushes;drawn_screen[0]=0;
    monitor.call.emergency=false;mon_indicator();
    assert(gfx_flushes==flushes+1 && strstr(drawn_screen,"GROUP CALL") && !strstr(drawn_screen,"EMERGENCY"));
    // Encrypted -> protected LC keeps the same receive class/phase, but none
    // of the old numeric identities or local names may remain on the display.
    flushes=gfx_flushes;drawn_screen[0]=0;
    p25_receive_clear_identity(&monitor.call);mon_indicator();
    assert(gfx_flushes==flushes+1 && strstr(drawn_screen,"TG -----") && strstr(drawn_screen,"ID --------"));
    assert(!strstr(drawn_screen,"ENCRYPTED CALLER"));
    // The identical muted state should not trigger another full call redraw.
    flushes=gfx_flushes;drawn_screen[0]=0;mon_indicator();
    assert(gfx_flushes==flushes && !drawn_screen[0]);
}
static void test_call_services_adapter(void) {
    test_muted_call_redraw();
    reset();memset(&heard_calls,0,sizeof heard_calls);memset(call_contacts,0,sizeof call_contacts);
    normal_mode=true;mon_running=true;control.source_id=123456;
    monitor.call=(p25_receive_policy){.active=true,.lc_valid=true,.source_valid=true,.group_valid=true,
        .state=P25_RX_CLEAR,.nac=0x293,.source=42,.group=10,.emergency=true};
    rx_promiscuous=true;call_services_p25(true);
    assert(heard_calls.count==1 && radio_history_get(&heard_calls,0)->flags&RADIO_CALL_EMERGENCY);
    now+=180000;call_services_p25(false);assert(heard_calls.count==1);
    radio_history_end(&heard_calls);call_services_p25(true);assert(heard_calls.count==2);
    uint8_t *name=call_contacts[0];name[0]=P25_CS_CONTACT_OCCUPIED|P25_CS_CONTACT_P25;
    name[1]=42;memcpy(name+4,"TEST CALLER",11);
    name=call_contacts[1];name[0]=P25_CS_CONTACT_OCCUPIED|P25_CS_CONTACT_P25|P25_CS_CONTACT_GROUP;
    name[1]=10;memcpy(name+4,"LOCAL GROUP",11);
    p25_ui_view v=ui_view(2);assert(!strcmp(v.source_name,"TEST CALLER") && !strcmp(v.target_name,"LOCAL GROUP") && v.emergency);
    menu_open=true;menu_page=MENU_HISTORY;menu_item=0;
    char label[32],value[48];menu_row(0,label,sizeof label,value,sizeof value);
    assert(!strcmp(label,"TEST CALLER") && strstr(value,"EMERGENCY"));
    local_action(ACT_SELECT,false);assert(menu_page==MENU_HEARD_CALL && heard_selection==0);
    menu_item=6;local_action(ACT_SELECT,false);assert(!menu_open && control.talkgroup==10 && !radio_channel_get_private(channel_record));
    assert(!control.tx_enabled); // Choosing a history target never enables TX.
    monitor.call.private_call=monitor.call.destination_valid=true;monitor.call.group_valid=false;
    monitor.call.destination=control.source_id;monitor.call.emergency=false;
    mon_running=true;call_services_p25(true);heard_selection=0;
    assert(history_reply() && radio_channel_get_private(channel_record) && radio_channel_get_destination(channel_record)==42);
    assert(ui_view(0).private_call);
    unsigned target=radio_channel_get_destination(channel_record);
    frequency+=25000;assert(!history_reply() && radio_channel_get_destination(channel_record)==target);
    frequency-=25000;
    channel_scan.running=true;assert(!history_reply());channel_scan.running=false;
    heard_calls.entries[heard_calls.head].flags|=RADIO_CALL_ENCRYPTED;assert(!history_reply());
    // DMR and P25 IDs share history storage, never their contact namespace.
    mon_running=false;channel_record[12]=P25_CS_OCCUPIED|P25_CS_DMR;
    digital_dmr.running=true;radio_dmr_stub.view=(dmr_call_view_t){.state=DMR_CALL_STATE_RX,.phase=DMR_CALL_PHASE_RX_VOICE,
        .cc=1,.ts=2,.call_start_ms=100,.caller={.src=42,.dst=98638,.group=true,.emergency=true}};
    dmr_history_active=false;call_services_poll();
    assert(radio_history_get(&heard_calls,0)->protocol==RADIO_PROTOCOL_DMR && radio_history_get(&heard_calls,0)->destination==98638);
    unsigned count=heard_calls.count;call_services_poll();assert(heard_calls.count==count);
    radio_dmr_stub.view.phase=DMR_CALL_PHASE_IDLE;call_services_poll();assert(!heard_calls.active && heard_calls.count==count);
    v=ui_view(0);assert(!v.rx_active && !v.emergency && !v.rx_source_valid && v.phase==1);
    radio_dmr_stub.view.phase=DMR_CALL_PHASE_RX_VOICE;call_services_poll();
    assert(heard_calls.count==count+1);count=heard_calls.count;
    v=ui_view(2);assert(!v.source_name[0] && v.emergency);
    radio_dmr_stub.view.state=DMR_CALL_STATE_IDLE;call_services_poll();assert(!heard_calls.active);
    radio_dmr_stub.view.state=DMR_CALL_STATE_RX;radio_dmr_stub.view.call_start_ms=200;call_services_poll();assert(heard_calls.count==count+1);
    digital_dmr.running=false;call_services_poll();assert(!heard_calls.active);
    // The shortcut is opt-in; the existing default P2 action remains status.
    memset(global_record+16,0,4);assert(radio_functions_get_action(global_record,RADIO_FUNCTION_P2)==RADIO_FUNCTION_STATUS);
    assert(radio_functions_set_action(global_record,RADIO_FUNCTION_P2,RADIO_FUNCTION_LAST_HEARD));
    menu_open=false;local_action(ACT_NAV_RIGHT,false);assert(menu_open && menu_page==MENU_HISTORY);
    reset();memset(&heard_calls,0,sizeof heard_calls);
    puts("Call services adapter: P25/DMR history, names, emergency, guarded replies and shortcut passed");
}
