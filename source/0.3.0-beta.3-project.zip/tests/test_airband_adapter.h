// SPDX-License-Identifier: GPL-3.0-or-later
// Actual auxiliary AM menu, input and ownership transitions; no radio hardware.
static void airband_test_ticks(normal_model *model,unsigned ticks) {
    for(unsigned i=0;i<ticks;++i)normal_step(model,false);
}
static void airband_test_input(const char *text) {
    for(;*text;++text)local_action(*text=='#' ? ACT_CONTEXT : ACT_DIGIT_0+*text-'0',false);
}
static void airband_test_open(normal_model *model) {
    choose(MENU_RECEIVERS,RECEIVERS_AIRBAND);normal_step(model,false);
    assert(airband_show && airband.owned && airband.running && mock_am_on);
    assert(!broadcast_show && !broadcast.owned && !mock_bcast_audio);
    assert(!mon_running && !analog_fm.owned && !digital_dmr.owned && !native_irq_owned);
    assert(!call_active && !hardware_running && !callback && !pcm_irq_enabled);
    assert(frontend_mode==RADIO_MODE_FM && tuned_rx==airband_hz);
    assert(ui_view(0).mode_am && !rf_keys && !pa_keys);
}
static void test_aux_airband_ownership(void) {
    for(unsigned channel_mode=0;channel_mode<3;++channel_mode) {
        normal_model model=normal_boot(false,false);
        for(unsigned i=0;i<channel_mode;++i)choose(MENU_CHANNEL,CHANNEL_MODE);
        home();normal_step(&model,false);
        uint8_t saved_channel[32],saved_global[32];
        memcpy(saved_channel,channel_record,32);memcpy(saved_global,global_record,32);
        signal_dbm=-40;airband_test_open(&model);
        assert(airband_hz==118000000 && tuned_bw==RADIO_BW_25K);
        assert(airband.audio_open && analog_audio && mock_green_led && !mock_red_led);
        // The permanent P25 worker survives menu changes. A stopped worker
        // must not disable AM's analog route or touch its shared PCM state.
        TaskHandle_t worker=mon_task_handle;assert(worker);
        uint32_t prior_regs[512];memcpy(prior_regs,regs,sizeof regs);
        bool prior_irqs[64];memcpy(prior_irqs,mock_irq_enabled,sizeof prior_irqs);
        for(unsigned wake=0;wake<128;++wake) {
            mon_speaker_step();
            assert(!memcmp(prior_regs,regs,sizeof regs));
            assert(!memcmp(prior_irqs,mock_irq_enabled,sizeof prior_irqs));
            assert(analog_audio && mon_task_handle==worker && !mon_running);
        }
        local_action(ACT_BACK,false);normal_step(&model,false);
        assert(!airband_show && !airband.owned && !mock_am_on);
        if(channel_mode!=1)assert(!analog_audio);
        assert(channel_mode==0 ? mon_running : channel_mode==1 ? analog_fm.running : digital_dmr.running);
        assert(!memcmp(saved_channel,channel_record,32) && !memcmp(saved_global,global_record,32));
        assert(frequency==440075000 && !owner_tx_inhibit);
        // PTT exits AM; the held key can never key the saved channel.
        airband_test_open(&model);normal_step(&model,true);
        assert(!airband_show && !airband.owned && ptt_release_required && !call_active);
        for(unsigned i=0;i<200;++i)normal_step(&model,true);
        assert(!call_active && !rf_keys && !pa_keys);
        airband_test_ticks(&model,51);assert(!ptt_release_required);
        assert(!memcmp(saved_channel,channel_record,32) && !memcmp(saved_global,global_record,32));
        reset();
    }
}
static void test_aux_airband_input(void) {
    normal_model model=normal_boot(false,false);signal_dbm=-40;
    airband_test_open(&model);
    unsigned writes=pref_flash_writes,erases=pref_flash_erases;
    uint8_t saved_channel[32],saved_global[32];
    memcpy(saved_channel,channel_record,32);memcpy(saved_global,global_record,32);
    local_action(ACT_NAV_UP,false);assert(airband_hz==118025000 && tuned_rx==118025000);
    local_action(ACT_NAV_DOWN,false);assert(airband_hz==118000000);
    local_action(ACT_NAV_RIGHT,false);assert(airband_hz==118025000);
    local_action(ACT_NAV_LEFT,false);assert(airband_hz==118000000);
    encoder_delta=3;normal_step(&model,false);assert(airband_hz==118075000 && tuned_rx==118075000);
    encoder_delta=-2;normal_step(&model,false);assert(airband_hz==118025000);
    airband_test_input("123#45");local_action(ACT_SELECT,false);
    assert(!editing && airband_hz==123450000 && tuned_rx==123450000);
    const char *invalid[]={"107#999","137","999#999","1#2#3"};
    for(unsigned i=0;i<sizeof invalid/sizeof *invalid;++i) {
        unsigned tunes=mock_am_tunes;uint32_t original=airband_hz;
        airband_test_input(invalid[i]);local_action(ACT_SELECT,false);
        assert(editing && airband_hz==original && mock_am_tunes==tunes);
        local_action(ACT_BACK,false);assert(!editing && airband_show);
    }
    airband_test_input("125#09");unsigned count=digit_count;
    local_action(ACT_QUICK,false);assert(digit_count==count-1);
    local_action(ACT_BACK,false);assert(!editing && airband_show && airband_hz==123450000);
    // Tuning and the step/squelch UI are deliberately RAM-only, even after
    // the normal deferred-save interval; FM preferences retain their bytes.
    airband_test_ticks(&model,2200);
    assert(pref_flash_writes==writes && pref_flash_erases==erases);
    assert(!memcmp(saved_channel,channel_record,32) && !memcmp(saved_global,global_record,32));
    local_action(ACT_BACK,false);normal_step(&model,false);
    airband_test_open(&model);assert(airband_hz==123450000);
    local_action(ACT_BACK,false);normal_step(&model,false);
    choose(MENU_RECEIVERS,RECEIVERS_AM_STEP);assert(airband_step_hz==8333);home();
    airband_hz=118000000;airband_test_open(&model);
    local_action(ACT_NAV_UP,false);assert(airband_hz==118008333);
    local_action(ACT_NAV_UP,false);assert(airband_hz==118016667);
    local_action(ACT_NAV_UP,false);assert(airband_hz==118025000);
    encoder_delta=-3;normal_step(&model,false);assert(airband_hz==118000000);
    local_action(ACT_BACK,false);normal_step(&model,false);
    choose(MENU_RECEIVERS,RECEIVERS_AM_STEP);assert(airband_step_hz==25000);home();
    unsigned previous=airband_squelch;
    choose(MENU_RECEIVERS,RECEIVERS_AM_SQL);assert(airband_squelch==(previous+1)%10);home();
    assert(!memcmp(saved_channel,channel_record,32) && !memcmp(saved_global,global_record,32));
    model=normal_power_reload();
    assert(airband_hz==118000000 && airband_step_hz==25000 && airband_squelch==5);
    assert(mon_running && !airband_show && !airband.owned && !rf_keys && !pa_keys);
    reset();
}
static void test_aux_airband_cleanup(void) {
    for(unsigned end=0;end<3;++end) {
        normal_model model=normal_boot(false,false);signal_dbm=-40;airband_test_open(&model);
        if(end==0) {
            output_n=0;issue("RADIO",false);assert(strstr(output,"ERR") && airband_show);
            issue("STOP",false);normal_step(&model,false);
            assert(!airband_show && !airband.owned && !analog_audio);
        } else if(end==1) {
            output_n=0;issue("CPS HELLO",false);
            char hello[48];snprintf(hello,sizeof hello,"CPS HELLO DM32P25 %u ",P25_CS_VERSION);
            assert(strstr(output,hello) && !airband.owned && !airband_show && !analog_audio);
            now+=3000001u;normal_step(&model,false);assert(!cps_link && mon_running);
        } else {
            mock_power_on=false;airband_test_ticks(&model,100);
            assert(mock_power_offs && !airband_show && !airband.owned && !analog_audio);
        }
        assert(!call_active && !hardware_running && !rf_keys && !pa_keys && !mock_red_led);
        reset();
    }
    normal_model model=normal_boot(false,false);mock_am_tune_ok=false;
    choose(MENU_RECEIVERS,RECEIVERS_AIRBAND);normal_step(&model,false);
    assert(!airband.running && !airband.owned && !analog_audio && !rf_keys && !pa_keys);
    if(airband_show)local_action(ACT_BACK,false);else home();
    mock_am_tune_ok=true;normal_step(&model,false);assert(mon_running);
    airband_test_open(&model);mock_am_tune_ok=false;
    local_action(ACT_NAV_UP,false);normal_step(&model,false);
    assert(!airband.running && !airband.owned && !analog_audio && !rf_keys && !pa_keys);
    if(airband_show)local_action(ACT_BACK,false);else home();
    mock_am_tune_ok=true;normal_step(&model,false);assert(mon_running);
    // Carrier admission uses AM RSSI, never FM noise/tone/carrier bits.
    signal_dbm=-125;signal_noise=0;signal_tone_ok=true;airband_test_open(&model);
    assert(!analog_audio && !airband.audio_open && !mock_green_led);
    local_action(ACT_QUICK,false);airband_test_ticks(&model,30);
    assert(analog_audio && airband.audio_open);
    local_action(ACT_QUICK,false);airband_test_ticks(&model,60);
    assert(!analog_audio && !airband.audio_open);
    radio_ux_init(&radio_lights,now);
    radio_lights.screen_seconds=2;radio_lights.keypad_seconds=1;
    now+=3000000u;normal_step(&model,false);
    assert(!screen_backlight && !key_backlight);
    signal_dbm=-40;signal_noise=255;signal_tone_ok=false;airband_test_ticks(&model,30);
    assert(analog_audio && airband.audio_open && mock_green_led);
    assert(screen_backlight==80 && !key_backlight);
    assert(!rf_keys && !pa_keys && !pref_flash_writes);
    reset();
}
