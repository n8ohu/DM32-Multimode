# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent synthetic common-clock two-channel CU8; no hardware or RF.

OP25 constructs unknown NIDs/payloads. The analyzer receives only their IQ;
expected bytes and start/status positions are used solely by these assertions.
"""
import ast
import hashlib
import importlib.util
import json
import math
import math
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np
from scipy import signal

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build/test-p25-common-iq'
BUILD.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('common_iq', ROOT / 'scripts/analyze-p25-common-iq.py')
iq = importlib.util.module_from_spec(spec)
spec.loader.exec_module(iq)
CRAFT = ROOT / 'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py'
assert hashlib.sha256(CRAFT.read_bytes().replace(b'\r\n', b'\n')).hexdigest() == (
    '27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9')
spec = importlib.util.spec_from_file_location('common_iq_op25', CRAFT)
op = importlib.util.module_from_spec(spec)
previous = Path.cwd()
os.chdir(BUILD)
try:
    spec.loader.exec_module(op)
finally:
    os.chdir(previous)
op.outfile.close()
op.text_out = lambda *_: None
generated = []
op.print_spec = lambda dibits: generated.append(np.array(dibits, dtype=np.uint8))


def control(nac=0x293, marker=0, bad_crc=False, count=1):
    generated.clear()
    opcode, argument = 0x3B, 0x000ABCDE12300001 ^ marker
    op.construct_tsdu3(nac, 2, count, 0, [opcode] * count, [argument ^ i for i in range(count)])
    dibits = generated[0].copy()
    payload = op.construct_tsbk(1, 0, opcode, 0, argument)
    if bad_crc:
        payload ^= 1
        coded = op.data_interleave(op.trellis_1_2_encode(op.split_dibits(payload, 48)))
        for index, value in enumerate(coded):
            logical = 56 + index
            dibits[logical + logical // 35] = value
    return dibits, payload.to_bytes(12, 'big')


def carrier(dibits, samples, start, offset, amplitude, cfo=0, phase=.731):
    """Independent exact integral of rectangular frequency symbols at2.4MHz.

    Fractional raw-sample starts are integrated rather than rounded. CU8
    acquisition, filter delay and status END tests do not use a DSP template.
    """
    index = np.arange(samples, dtype=np.float64)
    position = np.clip((index - start) / 500, 0, len(dibits))
    symbol = position.astype(np.int64)
    values = np.array([1., 3., -1., -3.])[dibits]
    integral = np.r_[0, np.cumsum(values)]
    fraction = position - symbol
    integrated_levels = integral[symbol] + fraction * np.r_[values, 0][symbol]
    angle = (2 * np.pi * ((offset + cfo) * index / iq.INPUT_RATE +
                         600 * integrated_levels * 500 / iq.INPUT_RATE) + phase)
    mask = (index >= start) & (index < start + len(dibits) * 500)
    return amplitude * np.exp(1j * angle) * mask


def make_capture(control_amplitude=.44, uplink_amplitude=.12, control_cfo=213,
                 uplink_cfo=-387, fraction=.37, lead=0, bad_crc=False, short=False,
                 bad_nid=False, cc_frames=5, shaped=False, power_notch=False):
    samples = 576_000  #240ms, long enough for several complete control units.
    cc, cc_payload = control(marker=0x3200)
    uplink, uplink_payload = control(nac=0x1A7, marker=0x876542, bad_crc=bad_crc)
    cc_start = 48_000 + fraction
    up_start = 207_000 + 17.5 + fraction / 2
    preamble = np.tile(np.array([1, 3, 1, 3], dtype=np.uint8), lead * 4)
    if bad_nid:
        uplink[24] ^= 3
        uplink[25] ^= 3
        uplink[56] ^= 1  # Four BCH errors plus parity exceed the total4 budget.
    uplink = np.r_[preamble, uplink[:158] if short else uplink]
    modulator = shaped_carrier if shaped else carrier
    total = modulator(np.tile(cc, cc_frames), samples, cc_start, -500_000, control_amplitude, control_cfo)
    up = modulator(uplink, samples, up_start, 500_000, uplink_amplitude, uplink_cfo, phase=-1.17)
    if power_notch:
        # Independent AM dip inside NID. FM phase/data remain continuous;
        # correct decoding does not establish uninterrupted envelope coverage.
        position = np.arange(samples)-up_start-len(preamble)*500
        up *= np.where((position >= 16_000) & (position < 17_500), .1, 1.)
    total += up
    rng = np.random.default_rng(0x251250)
    total += (rng.normal(0, .0008, samples) + 1j * rng.normal(0, .0008, samples))
    components = np.stack((total.real, total.imag), axis=1)
    raw = np.rint(127.5 + 128 * components).astype(np.int16)
    assert raw.min() > 0 and raw.max() < 255, (raw.min(), raw.max())
    delay = (len(SHAPING_TAPS) - 1) / 2 * 50 - 250 if shaped else 0
    truth = dict(control_start=cc_start + delay, uplink_sync_start=up_start + len(preamble) * 500 + delay,
                 uplink_energy_start=up_start, cc_payload=cc_payload.hex(),
                 uplink_energy_end=up_start + len(uplink) * 500 +
                    ((len(SHAPING_TAPS) - 2) * 50 if shaped else 0),
                 uplink_payload=uplink_payload.hex(), control_cfo=control_cfo, uplink_cfo=uplink_cfo)
    return raw.astype(np.uint8), truth


MOD = CRAFT.with_name('op25_c4fm_mod.py').read_bytes().replace(b'\r\n', b'\n')
assert hashlib.sha256(MOD).hexdigest() == 'b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef'
tree = ast.parse(MOD)
nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))
         and node.name in {'transfer_function_tx', 'c4fm_taps'}]
scope = dict(np=np, pi=math.pi, sin=math.sin, cos=math.cos,
             _def_symbol_rate=4800, _def_output_sample_rate=48000, _def_span=13)
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'pinned-op25-shaping', 'exec'), scope)
SHAPING_TAPS = scope['c4fm_taps']().generate()


def shaped_carrier(dibits, samples, start, offset, amplitude, cfo=0, phase=.731):
    impulses = np.zeros(len(dibits) * 10)
    impulses[::10] = np.array([1., 3., -1., -3.])[dibits]
    frequency = np.convolve(impulses, SHAPING_TAPS) * 6000
    index = np.arange(samples, dtype=float)
    position = np.clip((index - start) / 50, 0, len(frequency) - 1)
    cell = position.astype(np.int64)
    fraction = position - cell
    integral = np.r_[0, np.cumsum((frequency[:-1] + frequency[1:]) / 2)]
    slope = np.r_[np.diff(frequency), 0]
    cycles = (integral[cell] + frequency[cell] * fraction + .5 * slope[cell] * fraction ** 2) / 48_000
    angle = 2 * np.pi * ((offset + cfo) * index / iq.INPUT_RATE + cycles) + phase
    mask = (index >= start) & (index < start + (len(frequency) - 1) * 50)
    return amplitude * np.exp(1j * angle) * mask


class CommonIqTests(unittest.TestCase):
    def assert_numeric_equivalent(self, actual, expected, path='result'):
        """Keep decoding/grid values exact; allow only DSP roundoff in floats.

        SciPy/NumPy builds can accumulate block-filter sums differently. This
        tolerance is far below one raw sample and cannot hide a timing-grid
        change, different acquired frame, decoded payload or status symbol.
        """
        self.assertIs(type(actual), type(expected), path)
        if type(expected) is float:
            self.assertTrue(math.isfinite(actual) and math.isfinite(expected), path)
            self.assertTrue(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-10),
                            f'{path}: {actual!r} != {expected!r}')
        elif isinstance(expected, dict):
            self.assertEqual(actual.keys(), expected.keys(), path)
            for key in expected:
                self.assert_numeric_equivalent(actual[key], expected[key], f'{path}.{key}')
        elif isinstance(expected, list):
            self.assertEqual(len(actual), len(expected), path)
            for index, (left, right) in enumerate(zip(actual, expected)):
                self.assert_numeric_equivalent(left, right, f'{path}[{index}]')
        else:
            self.assertEqual(actual, expected, path)

    @classmethod
    def setUpClass(cls):
        cls.native = iq.NativeDecoder(BUILD / 'native')
        cls.raw, cls.truth = make_capture()
        cls.result = iq.analyze_samples(cls.raw, cls.native)

    def frames(self, result, channel):
        return [frame for frame in result['channels'][channel]['frames'] if frame['crc_qualified']]

    def assert_events(self, result, truth, *, energy=True):
        control_frames = self.frames(result, 'control')
        uplink_frames = self.frames(result, 'uplink')
        self.assertEqual(len(control_frames), 5)
        self.assertEqual(len(uplink_frames), 1)
        for index, frame in enumerate(control_frames):
            self.assertEqual(frame['payload_blocks'], [truth['cc_payload']])
            self.assertEqual(frame['nac'], '293')
            expected = truth['control_start'] + index * 180 * 500
            self.assertLess(abs(frame['sync_start_raw_sample'] - expected), 50)
            for status in frame['status_symbols']:
                self.assertEqual(status['value'], 2)
                true_end = expected + (status['physical_dibit'] + 1) * 500
                self.assertLess(abs(status['end_raw_sample'] - true_end), 70)
                self.assertFalse(status['status_bits_protected'])
        frame = uplink_frames[0]
        self.assertEqual(frame['payload_blocks'], [truth['uplink_payload']])
        self.assertEqual(frame['nac'], '1A7')
        self.assertLess(abs(frame['sync_start_raw_sample'] - truth['uplink_sync_start']), 50)
        self.assertLess(abs(frame['carrier_offset_hz'] - truth['uplink_cfo']), 20)
        self.assertEqual(len(result['relative_observations']), 1)
        relative = result['relative_observations'][0]
        self.assertTrue(relative['simultaneous_control_decode_observed'])
        self.assertGreaterEqual(relative['interior_control_status_ends_during_uplink'], 2)
        # A one-block unit's final end180 status is beyond its native CRC
        # prefix. Its padding cannot make an otherwise stale predecessor fresh.
        status_ends = [truth['control_start'] + n * 180 * 500 + p * 500
                       for n in range(5) for p in (36, 72, 108, 144)]
        previous_end = max(end for end in status_ends if end <= truth['uplink_sync_start'])
        expected_delta = truth['uplink_sync_start'] - previous_end
        self.assertEqual(relative['phase_observation_usable'], expected_delta / 2.4 <= 8000)
        self.assertLess(abs(relative['phase_since_observed_status_raw_samples'] - expected_delta), 90)
        if energy:
            regions = result['channels']['uplink']['energy_regions']['0.5']
            self.assertEqual(len(regions), 1)
            # Energy thresholds have a waveform/filter bias. This bound is a
            # synthetic check, not a qualified physical first-air uncertainty.
            self.assertLess(abs(regions[0]['start_raw_sample'] - truth['uplink_energy_start']), 250)
            self.assertLess(abs(regions[0]['end_raw_sample'] - truth['uplink_energy_end']), 250)
            observed_edge = relative['energy_start_observation']
            previous_end = max(end for end in status_ends if end <= truth['uplink_energy_start'])
            true_phase = truth['uplink_energy_start'] - previous_end
            self.assertLess(abs(observed_edge['phase_since_observed_status_raw_samples'] - true_phase), 300)
            self.assertFalse(observed_edge['first_air_edge_qualified'])
        for record in [result, *result['channels'].values(), *result['relative_observations']]:
            for flag in iq.FLAGS:
                self.assertIs(record[flag], False)

    def test_two_unknown_payloads_and_common_status_phase(self):
        self.assert_events(self.result, self.truth)
        self.assertEqual(self.result['output_samples_per_channel'], len(self.raw) // 50)
        self.assertTrue(self.result['no_cu8_rail_clipping_observed'])

    def test_global_nco_grid_and_arbitrary_blocks_equal_one_block(self):
        expected = iq.channelize(self.raw, len(self.raw))
        engine = iq.CommonChannelizer()
        parts = {name: [] for name in iq.CHANNELS}
        pattern = (1, 49, 50, 51, 997, 4093, 65537)
        begin = turn = 0
        while begin < len(self.raw):
            end = min(len(self.raw), begin + pattern[turn % len(pattern)])
            for name, values in engine.push(self.raw[begin:end]).items():
                parts[name].append(values)
            begin, turn = end, turn + 1
        self.assertEqual(engine.samples, len(self.raw))
        self.assertEqual(engine.rail_components, 0)
        for name, values in parts.items():
            actual = np.concatenate(values)
            self.assertEqual(len(actual), len(expected[name]))
            np.testing.assert_allclose(actual, expected[name], atol=2e-13, rtol=2e-13)
        result = iq.analyze_samples(self.raw, self.native, block_samples=4093)
        self.assert_numeric_equivalent(result, self.result)

    def test_causal_decimator_against_direct_reference_and_delay(self):
        raw = self.raw[:12_347]
        result = iq.channelize(raw, block_samples=997)
        values = ((raw[:, 0].astype(float) - 127.5) + 1j * (raw[:, 1].astype(float) - 127.5)) / 128
        index = np.arange(len(values))
        for name, target in iq.CHANNELS.items():
            mixed = values * np.exp(2j * np.pi * (iq.CENTER_HZ - target) / iq.INPUT_RATE * index)
            direct = signal.lfilter(iq.FIR, [1.], mixed)[::50]
            np.testing.assert_allclose(result[name], direct, atol=2e-14, rtol=2e-13)
        self.assertEqual(iq.FIR_DELAY_RAW, 1000)
        np.testing.assert_allclose(iq.FIR, iq.FIR[::-1], atol=1e-15)
        self.assertEqual(iq.raw_coordinate(0), -750)
        self.assertEqual(iq.raw_coordinate(15), 0)

    def test_reverse_power_ratio_fractional_phase_and_cfo(self):
        raw, truth = make_capture(control_amplitude=.13, uplink_amplitude=.43,
                                  control_cfo=-463, uplink_cfo=591, fraction=23.81, lead=16)
        result = iq.analyze_samples(raw, self.native, block_samples=65537)
        self.assert_events(result, truth)

    def test_crc_invalid_clean_codeword_not_payload_qualified(self):
        raw, _ = make_capture(bad_crc=True)
        result = iq.analyze_samples(raw, self.native)
        self.assertEqual(len(self.frames(result, 'control')), 5)
        self.assertTrue(any(frame['nac'] == '1A7' for frame in result['channels']['uplink']['frames']))
        self.assertEqual(self.frames(result, 'uplink'), [])
        self.assertEqual(result['relative_observations'], [])

    def test_excess_nid_damage_cannot_be_rescued_by_valid_payload(self):
        raw, _ = make_capture(bad_nid=True)
        result = iq.analyze_samples(raw, self.native)
        self.assertEqual(len(self.frames(result, 'control')), 5)
        self.assertEqual(self.frames(result, 'uplink'), [])
        self.assertEqual(result['relative_observations'], [])

    def test_control_before_uplink_is_not_simultaneous_reception(self):
        raw, _ = make_capture(cc_frames=1)
        result = iq.analyze_samples(raw, self.native)
        self.assertEqual(len(self.frames(result, 'control')), 1)
        self.assertEqual(len(self.frames(result, 'uplink')), 1)
        self.assertFalse(result['relative_observations'][0]['simultaneous_control_decode_observed'])
        self.assertFalse(result['relative_observations'][0]['phase_observation_usable'])
        self.assertGreater(result['relative_observations'][0]['phase_since_observed_status_nominal_us'], 8000)

    def test_pinned_op25_shaped_carriers_preserve_relative_symbol_timing(self):
        raw, truth = make_capture(shaped=True, lead=16, fraction=37.27)
        result = iq.analyze_samples(raw, self.native)
        self.assert_events(result, truth)

    def test_three_block_control_unit_native_crc_all_blocks(self):
        cc, _ = control(count=3, marker=0x1234)
        uplink, payload = control(nac=0x531, marker=0x56)
        total = carrier(np.tile(cc, 2), 576_000, 48_000.3, -500_000, .42, cfo=119)
        total += carrier(uplink, 576_000, 225_017.8, 500_000, .13, cfo=-273)
        raw = np.rint(127.5 + 128 * np.stack((total.real, total.imag), axis=1)).astype(np.uint8)
        result = iq.analyze_samples(raw, self.native)
        frames = self.frames(result, 'control')
        self.assertEqual(len(frames), 2)
        self.assertTrue(all(len(frame['payload_blocks']) == 3 and frame['full_padded_unit_observed']
                            for frame in frames))
        self.assertEqual(self.frames(result, 'uplink')[0]['payload_blocks'], [payload.hex()])

    def test_partial_316_bit_prefix_has_crc_without_invented_padding(self):
        raw, truth = make_capture(short=True, lead=16)
        result = iq.analyze_samples(raw, self.native)
        frame = self.frames(result, 'uplink')[0]
        self.assertEqual(frame['payload_blocks'], [truth['uplink_payload']])
        self.assertFalse(frame['full_padded_unit_observed'])
        self.assertEqual([status['physical_dibit'] for status in frame['status_symbols']], [35, 71, 107, 143])

    def test_crc_recovery_with_envelope_dip_does_not_authorize_phase(self):
        raw, truth = make_capture(uplink_amplitude=.43, power_notch=True)
        result = iq.analyze_samples(raw, self.native)
        channel = result['channels']['uplink']
        frames = self.frames(result, 'uplink')
        self.assertEqual(len(frames), 1)
        frame = frames[0]
        self.assertEqual(frame['payload_blocks'], [truth['uplink_payload']])
        self.assertFalse(frame['header_envelope_complete'])
        self.assertGreater(frame['header_power_samples_below_threshold'], 0)
        self.assertFalse(frame['crc_prefix_envelope_complete'])
        self.assertFalse(frame['phase_observation_eligible'])
        self.assertFalse(frame['full_padded_unit_observed'])
        self.assertEqual(channel['decoded_crc_units'], 1)
        self.assertEqual(channel['envelope_complete_crc_units'], 0)
        counts = channel['acquisition_diagnostics']
        self.assertGreater(counts['seed_native_nid_accepted'], 0)
        self.assertGreater(counts['seed_header_envelope_incomplete'], 0)
        relative = result['relative_observations'][0]
        self.assertFalse(relative['phase_observation_usable'])
        if 'energy_start_observation' in relative:
            self.assertFalse(relative['energy_start_observation']['phase_observation_usable'])
        self.assertTrue(all(not result[flag] for flag in iq.FLAGS))

    def test_noise_has_no_native_nid_or_crc_packet_evidence(self):
        rng = np.random.default_rng(0x923141)
        components = rng.normal(0, .004, (240_000, 2))
        raw = np.rint(127.5+128*components).astype(np.uint8)
        result = iq.analyze_samples(raw, self.native)
        for channel in result['channels'].values():
            self.assertEqual(channel['frames'], [])
            self.assertEqual(channel['decoded_crc_units'], 0)
            self.assertEqual(channel['decoded_candidates_with_native_nid'], 0)
            self.assertLessEqual(len(channel['coarse_sync_candidates']), 256)
        self.assertEqual(result['relative_observations'], [])

    def test_partial_multiblock_crc_is_not_a_complete_unit(self):
        dibits, _ = control(count=3, marker=0x183251)
        # Only block0 is intact; later trellis data are extensively damaged.
        for logical in range(154, 350):
            physical = logical+logical//35
            dibits[physical] ^= (logical%3)+1
        samples = 240_000
        wave = carrier(dibits, samples, 24_000.3, -500_000, .43)
        raw = np.rint(127.5+128*np.stack((wave.real,wave.imag),axis=1)).astype(np.uint8)
        result = iq.analyze_samples(raw, self.native)
        channel = result['channels']['control']
        self.assertEqual(len(channel['frames']), 1)
        frame = channel['frames'][0]
        self.assertEqual(frame['native_crc_block_count'], 1)
        self.assertFalse(frame['crc_qualified'])
        self.assertFalse(frame['phase_observation_eligible'])
        self.assertEqual(channel['decoded_candidates_with_crc_blocks'], 1)
        self.assertEqual(channel['decoded_crc_units'], 0)

    def test_conflicting_native_crc_hypotheses_remain_ambiguous(self):
        # Exercise aggregation with two independently constructed valid words;
        # native FEC/CRC correctness is covered by the actual-IQ tests above.
        _, word_a = control(marker=0x1111)
        _, word_b = control(marker=0x2222)
        calls = 0
        def decoded(*args, **kwargs):
            nonlocal calls
            calls += 1
            return dict(nac='293',duid=7,nid_corrected_bits=0,normalized_header_rms=.1,
                        crc_qualified=True,payload_blocks=[(word_a if calls%2 else word_b).hex()],
                        phase_observation_eligible=True,calibration_scope='standard_sync_only')
        with patch.object(iq, 'decode_candidate', side_effect=decoded):
            frame = iq.refine(np.zeros(4096),np.ones(4096),.03,200,self.native)
        self.assertTrue(frame['payload_ambiguous'])
        self.assertEqual(frame['crc_payload_hypotheses'], 2)
        self.assertFalse(frame['crc_qualified'])
        self.assertFalse(frame['phase_observation_eligible'])

    def test_between_symbol_power_dip_blocks_phase_with_native_crc_intact(self):
        dibits, payload = control(marker=0x183214)
        demod = np.repeat(np.array([1.,3.,-1.,-3.])[dibits]*600, 10)
        demod = np.r_[np.zeros(200),demod,np.zeros(100)]
        # Symbol powers are sampled at205,215,...;208 is between centers.
        power = np.ones(len(demod)+10)
        power[208] = 0
        frame = iq.decode_candidate(demod,power,.03,200,10,self.native)
        self.assertTrue(frame['crc_qualified'])
        self.assertEqual(frame['payload_blocks'],[payload.hex()])
        self.assertEqual(frame['header_power_samples_below_threshold'],0)
        self.assertFalse(frame['header_envelope_complete'])
        self.assertFalse(frame['crc_prefix_envelope_complete'])
        self.assertFalse(frame['phase_observation_eligible'])

    def test_partial_crc_evidence_is_preserved_despite_better_empty_nid_fit(self):
        word = op.construct_tsbk(0,0,0x34,0,0x123).to_bytes(12,'big').hex()
        calls = 0
        def decoded(*args,**kwargs):
            nonlocal calls
            calls += 1
            empty = calls%2
            return dict(nac='293',duid=7,nid_corrected_bits=0 if empty else 3,
                        normalized_header_rms=.1,crc_qualified=False,
                        payload_blocks=[] if empty else [word],phase_observation_eligible=False,
                        calibration_scope='standard_sync_only')
        with patch.object(iq,'decode_candidate',side_effect=decoded):
            frame = iq.refine(np.zeros(4096),np.ones(4096),.03,200,self.native)
        self.assertEqual(frame['payload_blocks'],[word])
        self.assertFalse(frame['crc_qualified'])
        self.assertFalse(frame['partial_payload_ambiguous'])
        self.assertEqual(frame['crc_prefix_hypotheses'],1)

    def test_conflicting_partial_crc_prefixes_are_explicit(self):
        words = [op.construct_tsbk(0,0,0x34,0,value).to_bytes(12,'big').hex()
                 for value in (0x123,0x456)]
        calls = 0
        def decoded(*args,**kwargs):
            nonlocal calls
            calls += 1
            return dict(nac='293',duid=7,nid_corrected_bits=0,normalized_header_rms=.1,
                        crc_qualified=False,payload_blocks=[words[calls%2]],
                        phase_observation_eligible=False,calibration_scope='standard_sync_only')
        with patch.object(iq,'decode_candidate',side_effect=decoded):
            frame = iq.refine(np.zeros(4096),np.ones(4096),.03,200,self.native)
        self.assertTrue(frame['partial_payload_ambiguous'])
        self.assertTrue(frame['payload_ambiguous'])
        self.assertEqual(frame['crc_prefix_hypotheses'],2)
        self.assertFalse(frame['crc_qualified'])

    def test_competing_native_crc_identity_is_not_hidden_by_nid_selection(self):
        _,word = control(marker=0x112233)
        calls = 0
        def decoded(*args,**kwargs):
            nonlocal calls
            calls += 1
            return dict(nac='293' if calls%2 else '294',duid=7,nid_corrected_bits=0,
                        normalized_header_rms=.1,crc_qualified=True,payload_blocks=[word.hex()],
                        phase_observation_eligible=True,calibration_scope='standard_sync_only',
                        status_symbols=[dict(crc_unit_qualified=True)])
        with patch.object(iq,'decode_candidate',side_effect=decoded):
            frame = iq.refine(np.zeros(4096),np.ones(4096),.03,200,self.native)
        self.assertEqual(frame['crc_payload_hypotheses'],1)
        self.assertEqual(frame['crc_identity_hypotheses'],2)
        self.assertTrue(frame['payload_ambiguous'])
        self.assertFalse(frame['crc_qualified'])
        self.assertFalse(frame['phase_observation_eligible'])
        self.assertFalse(frame['status_symbols'][0]['crc_unit_qualified'])

    def test_clipping_and_malformed_arrays_refused(self):
        for rail in (0, 255):
            raw = self.raw.copy()
            raw[73, 0] = rail
            with self.assertRaisesRegex(ValueError, 'rail clipping'):
                iq.analyze_samples(raw, self.native)
        for raw in (np.zeros((100, 2)), np.zeros(200, dtype=np.uint8)):
            with self.assertRaises(ValueError):
                iq.channelize(raw)
        with self.assertRaises(ValueError):
            iq.channelize(self.raw, block_samples=0)

    def test_file_integrity_profile_and_metadata(self):
        path = BUILD / 'synthetic.cu8'
        self.raw.tofile(path)
        metadata = dict(format='cu8', complete=True, test_counter=False, sample_rate=2_400_000,
                        center_hz=440_575_000, bytes=path.stat().st_size,
                        sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        sidecar = path.with_suffix('.cu8.json')
        for key, wrong in [('sample_rate', 1_024_000), ('center_hz', 440_075_000),
                           ('complete', False), ('test_counter', True), ('bytes', 7), ('sha256', 'bad')]:
            sidecar.write_text(json.dumps(dict(metadata, **{key: wrong})))
            with self.assertRaises(ValueError):
                iq.analyze_file(path)
        sidecar.write_text(json.dumps(metadata))
        actual = iq.analyze_file(path, block_samples=4093)
        self.assert_numeric_equivalent(actual['channels'], self.result['channels'])
        self.assertEqual(actual['capture_sha256'], metadata['sha256'])
        self.assertEqual(actual['analyzer_sha256'],hashlib.sha256(Path(iq.__file__).read_bytes()).hexdigest())


def make_legacy5m_cs8_capture(*, center_hz=442_575_000, conjugate_uplink_image=0.,
                            control_amplitude=.44, uplink_amplitude=.12, uplink_hz=445_075_000):
    """Independent9.6MHz modulation, not a relabeled/upsampled CU8 capture."""
    rate, symbol_samples, samples = 9_600_000, 2000, 1_536_000
    cc, cc_payload = control(marker=0x8A731)
    uplink, up_payload = control(nac=0x1A7, marker=0x9B6F23)
    cc[35::36] = [3, 2, 2, 2, 2]
    preamble = np.array([1, 3] * 4, dtype=np.uint8)
    cc_start, up_start = 192_000.37, 829_070.185
    index = np.arange(samples, dtype=np.float64)

    def modulate(dibits, start, offset, amplitude, cfo):
        position = np.clip((index - start) / symbol_samples, 0, len(dibits))
        cell = position.astype(np.int64)
        fraction = position - cell
        levels = np.array([1., 3., -1., -3.])[dibits]
        integral = np.r_[0., np.cumsum(levels)]
        cycles = ((offset + cfo) * index + 600 * symbol_samples *
                  (integral[cell] + fraction * np.r_[levels, 0.][cell])) / rate
        present = (index >= start) & (index < start + len(dibits) * symbol_samples)
        return amplitude * np.exp(2j * np.pi * cycles) * present

    total = modulate(np.tile(cc, 3), cc_start, 440_075_000 - center_hz, control_amplitude, 213)
    up = modulate(np.r_[preamble, uplink], up_start, uplink_hz - center_hz, uplink_amplitude, -387)
    total += up + conjugate_uplink_image * up.conjugate()
    raw = np.rint(128 * np.stack((total.real, total.imag), axis=1)).astype(np.int16)
    assert raw.min() > -128 and raw.max() < 127
    return raw.astype(np.int8), dict(control_start=cc_start,
        uplink_sync_start=up_start + len(preamble) * symbol_samples,
        uplink_energy_start=up_start, cc_payload=cc_payload.hex(), uplink_payload=up_payload.hex())


class HackrfLegacy5mTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile = iq.HACKRF_PROFILE
        cls.native = iq.NativeDecoder(BUILD / 'native')
        cls.raw, cls.truth = make_legacy5m_cs8_capture()
        cls.result = iq.analyze_samples(cls.raw, cls.native, profile=cls.profile)

    def test_blind_native_crc_and_raw_rf_status_to_uplink_phase(self):
        result, truth = self.result, self.truth
        frames = {name: [frame for frame in value['frames'] if frame['crc_qualified']]
                  for name, value in result['channels'].items()}
        self.assertEqual(len(frames['control']), 3)
        self.assertEqual(len(frames['uplink']), 1)
        for index, frame in enumerate(frames['control']):
            expected = truth['control_start'] + index * 180 * 2000
            self.assertEqual(frame['payload_blocks'], [truth['cc_payload']])
            self.assertEqual(frame['nac'], '293')
            self.assertLess(abs(frame['sync_start_raw_sample'] - expected), 200)
            for status in frame['status_symbols']:
                self.assertEqual(status['value'], 3 if status['physical_dibit'] == 35 else 2)
                self.assertLess(abs(status['end_raw_sample'] -
                                    (expected + (status['physical_dibit'] + 1) * 2000)), 280)
        frame = frames['uplink'][0]
        self.assertEqual(frame['payload_blocks'], [truth['uplink_payload']])
        self.assertEqual(frame['nac'], '1A7')
        self.assertLess(abs(frame['sync_start_raw_sample'] - truth['uplink_sync_start']), 200)
        report = result['decoded_status_phase_observations']
        observation = report['relative_observations'][0]
        ends = [truth['control_start'] + n * 180 * 2000 + p * 2000
                for n in range(3) for p in (36, 72, 108, 144, 180)]
        previous = max(end for end in ends if end <= truth['uplink_sync_start'])
        expected_delta = truth['uplink_sync_start'] - previous
        self.assertLess(abs(observation['phase_since_observed_status_raw_samples'] - expected_delta), 360)
        self.assertAlmostEqual(observation['phase_since_observed_status_nominal_us'],
                               observation['phase_since_observed_status_raw_samples'] / 9.6)
        edge = observation['energy_start_observation']
        self.assertLess(abs(edge['start_raw_sample'] - truth['uplink_energy_start']), 1000)
        self.assertGreater(frame['sync_start_raw_sample'] - edge['start_raw_sample'], 14_000)
        self.assertGreaterEqual(len(observation['interior_control_status_ends_during_uplink']), 2)
        for record in (result, report, observation, edge):
            for flag in iq.FLAGS:
                self.assertIs(record[flag], False)
        self.assertFalse(report['slot_permission_qualified'])
        self.assertFalse(result['usb_continuity_qualified'])
        self.assertTrue(result['no_cs8_rail_clipping_observed'])
        self.assertNotIn('no_cu8_rail_clipping_observed', result)

    def test_scaled_filter_raw_coordinates_and_signed_conversion_keep_global_grid(self):
        profile = self.profile
        self.assertEqual(profile.decimation, 200)
        self.assertEqual(len(profile.fir), 8001)
        self.assertEqual(profile.fir_delay_raw, 4000)
        self.assertEqual(iq.raw_coordinate(0, profile), -3000)
        self.assertEqual(iq.raw_coordinate(15, profile), 0)
        self.assertEqual(self.result['profile']['discriminator_midpoint_raw_samples'], 100)
        self.assertEqual(self.result['profile']['demod_center_raw_formula'], '(index+5)*200-4000')
        self.assertIn('nominal9.6MHz', self.result['timing_units'])
        raw = self.raw[185_000:205_003]
        expected = iq.channelize(raw, len(raw), profile)
        samples = (raw[:, 0].astype(float) + 1j * raw[:, 1].astype(float)) / 128
        for name, target in profile.channels.items():
            mixed = samples * np.exp(2j * np.pi * (profile.center_hz - target) /
                                     profile.input_rate * np.arange(len(raw)))
            direct = signal.lfilter(profile.fir, [1.], mixed)[::200]
            np.testing.assert_allclose(expected[name], direct, rtol=1e-12, atol=1e-14)
        for block in (199, 200, 201, 4093):
            actual = iq.channelize(raw, block, profile)
            for name in expected:
                np.testing.assert_allclose(actual[name], expected[name], rtol=1e-12, atol=1e-14)
        # The existing profile has not been changed by a different profile call.
        self.assertEqual(iq.DECIMATION, 50)
        self.assertEqual(iq.FIR_DELAY_RAW, 1000)
        self.assertEqual(iq.INPUT_RATE, 2_400_000)

    def test_cs8_type_and_both_signed_rails_are_checked(self):
        for rail in (-128, 127):
            raw = np.zeros((100, 2), dtype=np.int8)
            raw[73, 0] = rail
            with self.assertRaisesRegex(ValueError, 'CS8 rail clipping'):
                iq.channelize(raw, profile=self.profile)
        with self.assertRaisesRegex(ValueError, 'CS8 sample pairs'):
            iq.channelize(np.zeros((100, 2), dtype=np.uint8), profile=self.profile)
        # Signed zero is a valid CS8 center, unlike the unsigned rails.
        actual = iq.channelize(np.zeros((100, 2), dtype=np.int8), profile=self.profile)
        self.assertTrue(all(np.all(values == 0) for values in actual.values()))

    def test_file_exact_profile_counts_hash_and_unqualified_continuity(self):
        path = BUILD / 'synthetic-legacy5m.cs8'
        self.raw.tofile(path)
        metadata = dict(format='cs8', capture_profile='hackrf-legacy5m', complete=True,
            count_complete=True, usb_continuity_qualified=False, test_counter=False,
            sample_rate=9_600_000, center_hz=442_575_000, bytes=path.stat().st_size,
            samples=len(self.raw), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        sidecar = path.with_suffix('.cs8.json')
        for key, wrong in [('sample_rate', 2_400_000), ('center_hz', 440_575_000),
                           ('format', 'cu8'), ('capture_profile', 'rtl-common1m'),
                           ('complete', False), ('count_complete', False),
                           ('usb_continuity_qualified', True), ('samples', len(self.raw) - 1),
                           ('test_counter', True), ('bytes', 7), ('sha256', 'bad')]:
            sidecar.write_text(json.dumps(dict(metadata, **{key: wrong})))
            with self.assertRaises(ValueError, msg=key):
                iq.analyze_file(path, profile='hackrf-legacy5m')
        sidecar.write_text(json.dumps(metadata))
        with self.assertRaises(ValueError):
            iq.analyze_file(path, profile='rtl-common1m')
        self.assertIs(iq.capture_profile(metadata), self.profile)
        self.assertIs(iq.capture_profile(metadata, 'hackrf-legacy5m'), self.profile)
        with patch.object(iq, 'analyze_samples', return_value={'profile': {}}) as analyze:
            result = iq.analyze_file(path, profile='hackrf-legacy5m')
            self.assertEqual(analyze.call_args.args[0].dtype, np.int8)
            self.assertIs(analyze.call_args.kwargs['profile'], self.profile)
            self.assertEqual(result['profile']['input_format'], 'cs8')
            self.assertFalse(result['capture_continuity']['usb_continuity_qualified'])

    def test_fixed_offset_profile_decodes_unknown_payloads_with_stronger_uplink_image(self):
        profile = iq.HACKRF_OFFSET_PROFILE
        self.assertEqual(profile.name, 'hackrf-legacy5m-offset')
        self.assertEqual(profile.center_hz, 442_325_000)
        self.assertIs(profile.fir, iq.HACKRF_PROFILE.fir)
        self.assertEqual(profile.channels, dict(control=440_075_000, uplink=445_075_000))
        # The conjugate image is11.5dB stronger than actual CC, but500kHz away.
        raw, truth = make_legacy5m_cs8_capture(center_hz=442_325_000,
            conjugate_uplink_image=.5, control_amplitude=.04, uplink_amplitude=.30)
        result = iq.analyze_samples(raw, self.native, profile=profile)
        cc = [frame for frame in result['channels']['control']['frames'] if frame['crc_qualified']]
        up = [frame for frame in result['channels']['uplink']['frames'] if frame['crc_qualified']]
        self.assertEqual(len(cc), 3)
        self.assertEqual(len(up), 1)
        self.assertTrue(all(frame['payload_blocks'] == [truth['cc_payload']] for frame in cc))
        self.assertEqual(up[0]['payload_blocks'], [truth['uplink_payload']])
        self.assertTrue(result['relative_observations'][0]['simultaneous_control_decode_observed'])
        self.assertGreaterEqual(result['relative_observations'][0]['interior_control_status_ends_during_uplink'], 2)
        for flag in iq.FLAGS:
            self.assertIs(result[flag], False)
        metadata = dict(format='cs8', capture_profile=profile.name, complete=True,
            count_complete=True, usb_continuity_qualified=False, test_counter=False,
            sample_rate=9_600_000, center_hz=442_325_000, bytes=raw.nbytes,
            samples=len(raw), sha256=hashlib.sha256(raw.tobytes()).hexdigest())
        self.assertIs(iq.capture_profile(metadata), profile)
        path = BUILD / 'synthetic-offset-image.cs8'
        raw.tofile(path)
        sidecar = path.with_suffix('.cs8.json')
        for key, wrong in [('count_complete', False), ('usb_continuity_qualified', True),
                           ('center_hz', 442_575_000), ('capture_profile', 'hackrf-legacy5m')]:
            sidecar.write_text(json.dumps(dict(metadata, **{key: wrong})))
            with self.assertRaises(ValueError, msg=key):
                iq.analyze_file(path, profile=profile.name)
        sidecar.write_text(json.dumps(metadata))
        with patch.object(iq, 'analyze_samples', return_value={'profile': {}}) as analyze:
            actual = iq.analyze_file(path, profile=profile.name)
            self.assertIs(analyze.call_args.kwargs['profile'], profile)
            self.assertEqual(actual['profile']['capture_profile'], profile.name)
            self.assertFalse(actual['capture_continuity']['usb_continuity_qualified'])

    def test_fixed_common1m_offset_profile_binds_actual_channels_and_recorded_name(self):
        profile = iq.HACKRF_COMMON1M_PROFILE
        self.assertEqual(profile.name, 'hackrf-common1m-offset')
        self.assertEqual(profile.center_hz, 442_325_000)
        self.assertEqual(profile.channels, dict(control=440_075_000, uplink=441_075_000))
        self.assertEqual((profile.input_rate, profile.decimation, profile.fir_delay_raw), (9_600_000, 200, 4000))
        self.assertIs(profile.fir, iq.HACKRF_OFFSET_PROFILE.fir)
        raw, truth = make_legacy5m_cs8_capture(center_hz=442_325_000, uplink_hz=441_075_000,
            conjugate_uplink_image=.3, control_amplitude=.15, uplink_amplitude=.30)
        result = iq.analyze_samples(raw, self.native, profile=profile)
        cc = [frame for frame in result['channels']['control']['frames'] if frame['crc_qualified']]
        up = [frame for frame in result['channels']['uplink']['frames'] if frame['crc_qualified']]
        self.assertEqual(len(cc), 3)
        self.assertEqual(len(up), 1)
        self.assertTrue(all(frame['payload_blocks'] == [truth['cc_payload']] for frame in cc))
        self.assertEqual(up[0]['payload_blocks'], [truth['uplink_payload']])
        self.assertLess(abs(up[0]['sync_start_raw_sample'] - truth['uplink_sync_start']), 200)
        self.assertTrue(result['relative_observations'][0]['simultaneous_control_decode_observed'])
        observation = result['decoded_status_phase_observations']['relative_observations'][0]
        self.assertIn('previous_control_status', observation)
        self.assertAlmostEqual(observation['phase_since_observed_status_nominal_us'],
                               observation['phase_since_observed_status_raw_samples'] / 9.6)
        for flag in iq.FLAGS:
            self.assertIs(result[flag], False)
        metadata = dict(format='cs8', capture_profile=profile.name, complete=True, count_complete=True,
            usb_continuity_qualified=False, test_counter=False, sample_rate=9_600_000,
            center_hz=442_325_000, samples=len(raw), bytes=raw.nbytes,
            sha256=hashlib.sha256(raw.tobytes()).hexdigest())
        self.assertIs(iq.capture_profile(metadata), profile)
        self.assertIs(iq.capture_profile(metadata, profile.name), profile)
        path = BUILD / 'synthetic-common1m-offset.cs8'
        raw.tofile(path)
        sidecar = path.with_suffix('.cs8.json')
        for key, wrong in [('capture_profile', 'hackrf-legacy5m-offset'), ('capture_profile', None),
                           ('sample_rate', 2_400_000), ('count_complete', False),
                           ('usb_continuity_qualified', True), ('samples', len(raw) - 1),
                           ('center_hz', 442_575_000)]:
            sidecar.write_text(json.dumps(dict(metadata, **{key: wrong})))
            with self.assertRaises(ValueError, msg=key):
                iq.analyze_file(path, profile=profile.name)
        sidecar.write_text(json.dumps(metadata))
        with self.assertRaises(ValueError):
            iq.analyze_file(path, profile='hackrf-legacy5m-offset')
        with patch.object(iq, 'analyze_samples', return_value={'profile': {}}) as analyze:
            actual = iq.analyze_file(path, profile=profile.name)
            self.assertIs(analyze.call_args.kwargs['profile'], profile)
            self.assertEqual(actual['profile']['capture_profile'], profile.name)
            self.assertFalse(actual['capture_continuity']['usb_continuity_qualified'])
        clipped = np.zeros((100, 2), dtype=np.int8); clipped[7, 0] = 127
        with self.assertRaisesRegex(ValueError, 'CS8 rail clipping'):
            iq.channelize(clipped, profile=profile)


class InformationalStatusTests(unittest.TestCase):
    """Aggregation only; actual blind NID/CRC and IQ tests remain above."""
    def fixture(self, complete=False):
        def frame(start, end, statuses, nac='293'):
            return dict(sync_start_raw_sample=start, sync_center_raw_sample=start + 250,
                crc_prefix_end_raw_sample=end, samples_per_symbol_48k=10.,
                nac=nac, duid=7, nid_corrected_bits=0, crc_qualified=True,
                payload_blocks=['received-native-crc-word'], crc_identity_hypotheses=1,
                crc_payload_hypotheses=1, crc_prefix_envelope_complete=complete,
                phase_observation_eligible=complete, status_symbols=[dict(
                    physical_dibit=35 + 36 * index, end_raw_sample=stamp, value=value,
                    nid_qualified=True, crc_unit_qualified=True, status_bits_protected=False)
                    for index, (stamp, value) in enumerate(statuses)])
        return dict(control=dict(frames=[frame(1000., 10000., [(2000., 3), (4000., 2), (6000., 2), (8000., 2)])]),
                    uplink=dict(frames=[frame(3000., 9000., [])], energy_regions={'0.5': [dict(
                        start_raw_sample=2500., end_raw_sample=9500.)]}))

    def test_incomplete_and_covered_units_have_separate_informational_geometry(self):
        for complete in (False, True):
            decoded = self.fixture(complete)
            before = json.loads(json.dumps(decoded))
            result = iq.decoded_status_phase_observations(decoded)
            self.assertEqual(decoded, before)
            observation = result['relative_observations'][0]
            self.assertEqual(observation['previous_control_status']['end_raw_sample'], 2000.)
            self.assertAlmostEqual(observation['phase_since_observed_status_nominal_us'], 1000 / 2.4)
            self.assertEqual(len(observation['control_status_ends_during_uplink']), 3)
            self.assertEqual(len(observation['interior_control_status_ends_during_uplink']), 3)
            self.assertEqual(observation['energy_start_observation']['start_raw_sample'], 2500.)
            self.assertEqual(observation['uplink_crc_prefix_envelope_complete'], complete)
            self.assertEqual(observation['previous_control_status']['sources'][0]['crc_prefix_envelope_complete'], complete)
            for record in (result, observation, observation['energy_start_observation']):
                self.assertTrue(record['informational_only'])
                self.assertFalse(record['phase_observation_usable'])
                for flag in iq.FLAGS:
                    self.assertIs(record[flag], False)
            self.assertFalse(result['continuous_envelope_qualified'])
            self.assertFalse(result['status_value_qualified'])
            self.assertFalse(result['slot_permission_qualified'])

    def test_ambiguous_identity_or_payload_does_not_supply_status_or_uplink(self):
        for changes in (dict(crc_qualified=False), dict(payload_ambiguous=True),
                        dict(partial_payload_ambiguous=True), dict(crc_identity_hypotheses=2),
                        dict(crc_payload_hypotheses=2), dict(payload_blocks=[])):
            decoded = self.fixture()
            decoded['control']['frames'][0].update(changes)
            observation = iq.decoded_status_phase_observations(decoded)['relative_observations'][0]
            self.assertEqual(observation['control_status_ends_during_uplink'], [])
            self.assertNotIn('previous_control_status', observation)
            decoded = self.fixture()
            decoded['uplink']['frames'][0].update(changes)
            self.assertEqual(iq.decoded_status_phase_observations(decoded)['relative_observations'], [])

    def test_missing_local_power_status_and_after_prefix_padding_are_not_invented(self):
        decoded = self.fixture()
        frame = decoded['control']['frames'][0]
        frame['status_symbols'] = []
        observation = iq.decoded_status_phase_observations(decoded)['relative_observations'][0]
        self.assertEqual(observation['control_status_ends_during_uplink'], [])
        self.assertNotIn('previous_control_status', observation)
        frame['status_symbols'] = [dict(physical_dibit=179, end_raw_sample=10001., value=2,
            nid_qualified=True, crc_unit_qualified=True, status_bits_protected=False)]
        decoded['uplink']['frames'][0].update(sync_start_raw_sample=11000., crc_prefix_end_raw_sample=20000.)
        observation = iq.decoded_status_phase_observations(decoded)['relative_observations'][0]
        self.assertNotIn('previous_control_status', observation)
        self.assertEqual(observation['control_status_ends_during_uplink'], [])
        frame['status_symbols'][0]['end_raw_sample'] = 10000.
        self.assertEqual(iq.decoded_status_phase_observations(decoded)['relative_observations'][0]
                         ['previous_control_status']['end_raw_sample'], 10000.)

    def test_strict_phase_does_not_use_status_360_after_crc_prefix_358(self):
        for profile in (iq.DEFAULT_PROFILE, iq.HACKRF_COMMON1M_PROFILE):
            for retain_older_status in (True, False):
                with self.subTest(profile=profile.name, older_status=retain_older_status):
                    dibit = profile.input_rate / 4800
                    decoded = self.fixture(True)
                    first = decoded['control']['frames'][0]
                    status = first['status_symbols'][0]

                    def observed(end, value, origin=0):
                        return dict(status, physical_dibit=end - origin - 1,
                                    end_raw_sample=end * dibit, value=value)

                    first.update(sync_start_raw_sample=0., crc_prefix_end_raw_sample=358 * dibit,
                        status_symbols=([observed(324, 2)] if retain_older_status else []) +
                                       [observed(360, 2)])
                    second = dict(first, sync_start_raw_sample=360 * dibit,
                        crc_prefix_end_raw_sample=718 * dibit,
                        status_symbols=[observed(end, value, 360) for end, value in
                                        [(396, 3), (432, 2), (468, 2), (504, 2), (540, 2), (576, 3)]])
                    decoded['control']['frames'].append(second)
                    decoded['uplink']['frames'][0].update(sync_start_raw_sample=378 * dibit,
                        sync_center_raw_sample=378.5 * dibit, crc_prefix_end_raw_sample=536 * dibit)
                    decoded['uplink']['energy_regions']['0.5'][0].update(
                        start_raw_sample=374 * dibit, end_raw_sample=540 * dibit)
                    before = json.loads(json.dumps(decoded))
                    with patch.object(iq, 'channelize', return_value={
                            'control': np.zeros(1), 'uplink': np.zeros(1)}), \
                         patch.object(iq, 'analyze_channel', side_effect=[
                            decoded['control'], decoded['uplink']]):
                        result = iq.analyze_samples(np.zeros((int(800 * dibit), 2),
                            dtype=np.uint8 if profile.format == 'cu8' else np.int8),
                            native=object(), profile=profile)
                    self.assertEqual(decoded, before)
                    strict = result['relative_observations'][0]
                    energy = strict['energy_start_observation']
                    self.assertFalse(strict['phase_observation_usable'])
                    self.assertFalse(energy['phase_observation_usable'])
                    self.assertEqual(strict['interior_control_status_ends_during_uplink'], 4)
                    if retain_older_status:
                        self.assertEqual(strict['previous_control_status_end_raw_sample'], 324 * dibit)
                        self.assertEqual(energy['previous_control_status_end_raw_sample'], 324 * dibit)
                        self.assertGreater(strict['phase_since_observed_status_nominal_us'], 8000)
                        self.assertGreater(energy['phase_since_observed_status_nominal_us'], 8000)
                    else:
                        self.assertNotIn('previous_control_status_end_raw_sample', strict)
                        self.assertNotIn('previous_control_status_end_raw_sample', energy)
                    observed_statuses = result['decoded_status_phase_observations']['relative_observations'][0]
                    self.assertEqual([row['value'] for row in
                        observed_statuses['control_status_ends_during_uplink']], [3, 2, 2, 2])

    def test_duplicate_statuses_collapse_and_conflicting_values_are_excluded(self):
        decoded = self.fixture()
        duplicate = json.loads(json.dumps(decoded['control']['frames'][0]))
        duplicate['status_symbols'] = [dict(duplicate['status_symbols'][1], end_raw_sample=4000.5)]
        decoded['control']['frames'].append(duplicate)
        result = iq.decoded_status_phase_observations(decoded)
        self.assertEqual(len(result['duplicate_status_groups']), 1)
        self.assertEqual(result['duplicate_status_groups'][0]['observation_count'], 2)
        self.assertEqual(len(result['relative_observations'][0]['control_status_ends_during_uplink']), 3)
        duplicate['status_symbols'][0]['value'] = 1
        result = iq.decoded_status_phase_observations(decoded)
        self.assertEqual(result['conflicting_status_groups'][0]['conflict_reasons'], ['status_value_disagreement'])
        self.assertEqual(result['conflicting_status_groups'][0]['observed_values'], [1, 2])
        observation = result['relative_observations'][0]
        self.assertEqual(len(observation['control_status_ends_during_uplink']), 2)
        self.assertEqual(len(observation['conflicting_status_ends_near_uplink']), 1)
        duplicate['status_symbols'][0]['value'] = 2
        duplicate['nac'] = '294'
        result = iq.decoded_status_phase_observations(decoded)
        self.assertEqual(result['conflicting_status_groups'][0]['conflict_reasons'], ['received_nac_disagreement'])

    def test_duplicate_tolerance_is_anchored_and_does_not_chain(self):
        decoded = self.fixture()
        frame = decoded['control']['frames'][0]
        frame['status_symbols'] = [dict(frame['status_symbols'][1], end_raw_sample=4000. + offset)
                                   for offset in (0., .75, 1.5)]
        result = iq.decoded_status_phase_observations(decoded)
        self.assertEqual(result['duplicate_status_groups'][0]['end_raw_sample_span'], [4000., 4000.75])
        self.assertEqual(len(result['relative_observations'][0]['control_status_ends_during_uplink']), 2)

    def test_new_report_leaves_all_existing_analysis_fields_and_strict_results_unchanged(self):
        for complete in (False, True):
            def analyze():
                decoded = self.fixture(complete)
                with patch.object(iq, 'channelize', return_value={'control': np.zeros(1), 'uplink': np.zeros(1)}), \
                     patch.object(iq, 'analyze_channel', side_effect=[decoded['control'], decoded['uplink']]):
                    return iq.analyze_samples(np.zeros((120000, 2), dtype=np.uint8), native=object())
            with patch.object(iq, 'decoded_status_phase_observations', return_value=None):
                baseline = analyze()
            actual = analyze()
            self.assertIsNone(baseline.pop('decoded_status_phase_observations'))
            report = actual.pop('decoded_status_phase_observations')
            self.assertEqual(actual, baseline)
            strict = actual['relative_observations'][0]
            self.assertIs(strict['phase_observation_usable'], complete)
            self.assertEqual(strict['control_status_ends_during_uplink'], 3 if complete else 0)
            self.assertEqual(len(report['relative_observations'][0]['control_status_ends_during_uplink']), 3)


if __name__ == '__main__':
    unittest.main()
