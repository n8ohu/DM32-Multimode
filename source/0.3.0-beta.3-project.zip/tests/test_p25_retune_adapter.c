// SPDX-License-Identifier: GPL-3.0-or-later
// Appended to the existing adapter HAL by test_p25_retune_adapter.py.
// Exercise the actual stop/start/ownership functions in both build profiles.
static void retune_safe(void) {
    assert(!rf_keys && !pa_keys && !hardware_running && !call_active && !prepared);
    assert(!mock_rf_selected && !mock_pa_selected && !mock_dac_drive);
    assert(!native_irq_owned && !digital_dmr.owned && !analog_fm.owned);
}
static void retune_receive(void) {
    p25_channel_frames frames;assert(p25_channel_build(&frames,0x293,10,42));
    p25_rx unit={0};unit.nac=0x293;unit.duid=0;
    memcpy(unit.frame,frames.hdu,sizeof frames.hdu);mon_receive(&unit,NULL);
    unit.duid=5;memcpy(unit.frame,frames.ldu1,sizeof frames.ldu1);mon_receive(&unit,NULL);
    assert(monitor.call.state==P25_RX_CLEAR && monitor.voices==9u && !mon_failed);
}
int main(void) {
    radio_dmr_stub_reset();
    assert(radio_codec_bind_dmr(&rx_storage,sizeof rx_storage));
    regs[C7_SYS_INTERP_MASK/4]=MOCK_NATIVE_SYS_MASK;
    __wrap_hrc_dmr_board_init(&modem,&rf_hooks);p25_irqs_install();ptt_mask=1;
    now=1000000u;mon_enabled=true;frequency=control.tx_frequency=440075000u;
    control.nac=0x293;control.source_id=1234567;control.talkgroup=10;
    channel_record[12]=1;mock_decode_value=1234;
#if DM32_LAB_DIAGNOSTICS
    mon_pcm_backend=true;
#endif
    radio_dmr_hal dmr_hal={.radio=board.radio,.modem=board.dmr,.audio=board.audio,
        .vocoder=board.vocoder,.acquire=dmr_acquire,.release=dmr_release};
    radio_dmr_init(&digital_dmr,&dmr_hal);
    assert(mon_start());assert(mon_running && frontend_mode==RADIO_MODE_DMR);
    assert(retune_mode_transitions==1u);retune_safe();
    for(unsigned repeat=0;repeat<12u;++repeat) {
        unsigned transitions=retune_mode_transitions;
        uint32_t epoch=trunk_stream_epoch;
        retune_receive();
        int16_t pcm[160]={0};for(unsigned i=0;i<18;++i)assert(mon_pcm_push(&monitor,pcm));
        mon_speaker_step();assert(mon_pcm_pending && mon_routed && pcm_irq_enabled);
        monitor.raw_head=3;monitor.raw_tail=1;monitor.have_raw=true;
        mon_stop_retune("known_p25_retune");
        assert(!mon_running && mon_frontend_ready && frontend_mode==RADIO_MODE_DMR);
        assert(!mon_pcm_pending && !mon_routed && !pcm_irq_enabled && !monitor.call.active);
        assert(monitor.raw_head==monitor.raw_tail && monitor.pcm_head==monitor.pcm_tail);
        assert(!monitor.playing && !monitor.ending && !monitor.have_raw);
        assert(!mock_irq_enabled[IRQ_MODEM_SYS] && !mock_irq_enabled[IRQ_MODEM_TS_RX]);
        assert(regs[C7_SYS_INTERP_MASK/4]==0 && regs[C7_LAYER2_TXRX_CTRL/4]==0);
        mon_speaker_step();mon_pcm_irq();assert(!mon_pcm_pending && !pcm_irq_enabled);
        mon_stop_retune("duplicate_p25_pause");assert(mon_frontend_ready);
        frequency+=12500u;assert(mon_start());
        assert(!mon_frontend_ready && mon_running && tuned_rx==frequency);
        assert(retune_mode_transitions==transitions && trunk_stream_epoch!=epoch);
        assert(!monitor.raw_head && !monitor.raw_tail && !monitor.have_raw);
        assert(!monitor.call.active && !monitor.voices && !monitor.pcm_head);
        assert(mock_irq_enabled[IRQ_MODEM_SYS] && !mock_irq_enabled[IRQ_MODEM_TS_RX]);
        assert(!radio_dmr_stub.native_enters);retune_safe();
    }
    // A full stop after an already-stopped retune closes the retained frontend.
    mon_stop_retune("pending");unsigned transitions=retune_mode_transitions;
    mon_stop("explicit_stop");assert(!mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    assert(retune_mode_transitions==transitions+1u && mon_start());
    // A PTT arriving before recalled-channel RX starts consumes the retained
    // token before preparing TX. Preparation itself must never key the PA.
    mon_stop_retune("immediate_ptt");transitions=retune_mode_transitions;
    session_enabled=true;control.tx_enabled=true;control.inhibit=false;
    assert(prepare_p25_tx_at(false,frequency));
    assert(prepared && !mon_running && !mon_frontend_ready);
    assert(retune_mode_transitions==transitions+2u && !rf_keys && !pa_keys);
    reason="cancelled";cleanup();session_enabled=false;
    assert(!prepared && frontend_mode==RADIO_MODE_FM && mon_start());retune_safe();
    // A rejected immediate PTT also closes the token; no later receiver can
    // mistake the abandoned handoff for an untouched retained frontend.
    mon_stop_retune("rejected_ptt");control.inhibit=true;
    assert(!prepare_p25_tx_at(false,frequency));
    assert(!mon_frontend_ready && frontend_mode==RADIO_MODE_FM && !prepared);
    control.inhibit=false;assert(mon_start());retune_safe();
    // Faulted reception never retains a frontend and never replays old audio.
    transitions=retune_mode_transitions;mon_failed=true;mon_stop_retune("input_fault");
    assert(!mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    mon_failed=false;assert(mon_start() && retune_mode_transitions==transitions+2u);
    // Task creation and tune failures close a one-shot retained frontend.
    mon_stop_retune("task_failure");mon_task_handle=NULL;retune_task_fail=true;
    assert(!mon_start() && !mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    retune_task_fail=false;assert(mon_start());
    mon_stop_retune("tune_failure");tune=false;
    assert(!mon_start() && !mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    tune=true;assert(mon_start());
    // Codec refusal is a setup failure too, even if RX tuning already succeeded.
    mon_stop_retune("codec_failure");assert(imbe_bench_release());
    assert(radio_codec_acquire(RADIO_CODEC_DMR));
    assert(!mon_start() && !mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    assert(radio_codec_release(RADIO_CODEC_DMR) && mon_start());
    // Native DMR must obtain a cold handoff and retain its own PCM/IRQ ownership.
    mon_stop_retune("native_dmr");transitions=retune_mode_transitions;
    radio_dmr_config config={.rx_hz=145700000u,.tx_hz=145700000u,
        .source_id=1234567,.target_id=98638,.cc=1,.ts=2,.tot_s=30,.power=0};
    assert(radio_dmr_start(&digital_dmr,&config));
    assert(!mon_frontend_ready && native_irq_owned && digital_dmr.running);
    assert(retune_mode_transitions>=transitions+2u && radio_dmr_stub.native_enters);
    hrc7000_audio_bits(&modem,C7_AUDIO_PCM_SPK,0);hrc_irq_enable(IRQ_PCM_RD,true);
    uint32_t audio_before=modem.audio_ctl;
    for(unsigned i=0;i<32u;++i)mon_speaker_step();
    assert(pcm_irq_enabled && modem.audio_ctl==audio_before && native_irq_owned);
    radio_dmr_stop(&digital_dmr);assert(!native_irq_owned && frontend_mode==RADIO_MODE_FM);
    assert(mon_start());retune_receive();retune_safe();
    // Explicit FM handoff discards the token, then P25 asserts digital routing.
    mon_stop_retune("fm_handoff");feature_pause();
    assert(!mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    assert(board.radio->rx(145700000u,RADIO_BW_12K5,NULL));board.radio->audio(true);
    assert(analog_audio);board.radio->audio(false);
    assert(mon_start() && !analog_audio);retune_receive();retune_safe();
    mon_stop("finished");assert(!mon_frontend_ready && frontend_mode==RADIO_MODE_FM);
    printf("P25 retune adapter: PASS (diagnostics %u, 12 retunes, no mode transitions)\n",DM32_LAB_DIAGNOSTICS);
    return 0;
}
