// SPDX-License-Identifier: GPL-3.0-or-later
// Opt-in control tracking and fresh-history fallback. No radio/CPU timers.
#include <assert.h>
#include <limits.h>
#include <string.h>
static unsigned test_symbol_visits;
#ifndef P25_TRACK_DEMOD_SOURCE
#define P25_TRACK_DEMOD_SOURCE "../src/firmware/p25_demod.c"
#endif
#include P25_TRACK_DEMOD_SOURCE
#include "p25_data_fec.h"

#define TRACK_MAX_FRAMES 128u
#define TRACK_FRAME_ROW 520u
#define TRACK_MAX_EVENTS 2048u
typedef struct {
    unsigned frames,events,current;
    unsigned char *frame_bytes;
    uint64_t *status_events;
} track_output;
static void track_frame(const p25_rx *received,void *context) {
    track_output *out=context;assert(out->frames<TRACK_MAX_FRAMES);
    if(out->frame_bytes) {
        unsigned char *row=out->frame_bytes+out->frames*TRACK_FRAME_ROW;memset(row,0,TRACK_FRAME_ROW);
        row[0]=(unsigned char)received->frame_bytes;row[1]=(unsigned char)(received->frame_bytes>>8);
        row[2]=(unsigned char)received->nac;row[3]=(unsigned char)(received->nac>>8);row[4]=received->duid;
        assert(received->frame_bytes<=512u);memcpy(row+8,received->frame,received->frame_bytes);
    }
    ++out->frames;
}
static void track_status(const p25_demod_status *event,void *context) {
    track_output *out=context;assert(out->events<TRACK_MAX_EVENTS);
    if(out->status_events) {
        uint64_t *row=out->status_events+out->events*8u;
        row[0]=event->sample_tick;row[1]=event->stream_epoch;row[2]=event->lane_epoch;
        row[3]=event->nac;row[4]=event->status;row[5]=event->lane;
        row[6]=(event->selected?1u:0u)|(event->qualified?2u:0u)|((unsigned)event->duid<<8);
        row[7]=out->current;
    }
    ++out->events;
}
static void seed(p25_demod *d,track_output *out,bool enable) {
    unsigned char wire[90],block[1][12]={{0xbb,0,0,0xab,0xcd,0xe1,0x23,0,0,1,0,0}};
    uint16_t crc=p25_data_crc16(block[0],10);block[0][10]=(uint8_t)(crc>>8);block[0][11]=(uint8_t)crc;
    assert(p25_tsdu_encode(wire,sizeof wire,0x293u,(const uint8_t (*)[12])block,1,3u)==45u);
    p25_demod_init(d);memset(out,0,sizeof *out);d->status_emit=track_status;d->status_context=out;
    d->have_input_time=true;d->stream_epoch=11;d->decision_valid=true;d->lane[0].gain=1000;
    p25_demod_control_tracking(d,enable);assert(p25_demod_control_tracking_lanes(d)==0x3ffu);
    static const int16_t level[4]={1000,3000,-1000,-3000};
    for(unsigned i=0;i<24u;++i)(void)p25_rx_push(&d->lane[0].rx,p25_data_get_dibit(wire,i));
    for(unsigned i=24;i<180u;++i) {d->decision_tick=10000u+10u*i;
        symbol(d,&d->lane[0],level[p25_data_get_dibit(wire,i)]);}
    assert(d->pending_ticks&&!d->pending_errors&&d->selected_lane==UINT8_MAX);
    status_select(d);d->pending_ticks=0;assert(d->selected_lane==0u&&d->selected_nac==0x293u);
    assert(p25_demod_control_tracking_lanes(d)==(enable?0x203u:0x3ffu));
}
static void candidate_failure(unsigned fault,bool selected_failure,bool neighbor_first) {
    uint8_t healthy[45],damaged[45];
    uint8_t block[1][12]={{0xbb,0,0,0xab,0xcd,0xe1,0x23,0,0,1,0,0}};
    uint16_t crc=p25_data_crc16(block[0],10);block[0][10]=(uint8_t)(crc>>8);block[0][11]=(uint8_t)crc;
    assert(p25_tsdu_encode(healthy,sizeof healthy,0x293u,(const uint8_t (*)[12])block,1,3u)==45u);
    assert(p25_tsdu_encode(damaged,sizeof damaged,fault==1u?0x2a3u:0x293u,
                          (const uint8_t (*)[12])block,1,3u)==45u);
    unsigned final=56u;
    if(fault==0u) {
        // Four BCH errors plus parity exceed the existing total-four budget.
        damaged[6]^=0xf0u;damaged[14]^=0x40u;
    } else if(fault==2u) {
        // A perfect trellis for an all-zero block has a deliberately bad CRC.
        // Keep sync/NID/status intact so only the later control parser fails.
        for(unsigned i=0;i<98u;++i) {
            unsigned data=56u+i,physical=data+data/35u,shift=6u-2u*(physical%4u);
            damaged[physical/4u]=(uint8_t)((damaged[physical/4u]&~(3u<<shift))
                                         |((i%2u?2u:0u)<<shift));
        }
        uint8_t decoded[12];assert(!p25_tsdu_decode_block(damaged,sizeof damaged,0,decoded));
        final=157u;
    }
    p25_demod d;track_output out;seed(&d,&out,true);
    uint64_t records[16u*8u]={0};out.status_events=records;
    uint32_t epoch=d.lane_epoch;
    const int16_t levels[4]={1000,3000,-1000,-3000};
    unsigned victim=selected_failure?0u:1u;
    for(unsigned lane=0;lane<2u;++lane) {
        p25_rx_gap(&d.lane[lane].rx);d.lane[lane].gain=1000;
        d.lane[lane].previous_symbol=0;
        for(unsigned i=0;i<24u;++i)
            (void)p25_rx_push(&d.lane[lane].rx,p25_data_get_dibit(lane==victim?damaged:healthy,i));
    }
    for(unsigned i=24u;i<=final;++i) {
        d.decision_tick=20000u+10u*i;
        for(unsigned pass=0;pass<2u;++pass) {
            unsigned lane=neighbor_first?1u-pass:pass;
            const uint8_t *wire=lane==victim?damaged:healthy;
            symbol(&d,&d.lane[lane],levels[p25_data_get_dibit(wire,i)]);
        }
    }
    assert(d.control_tracking_flags&P25_DEMOD_CONTROL_TRACK_FALLBACK);
    assert(p25_demod_control_tracking_lanes(&d)==0x203u); // Deferred until after this tick.
    if(selected_failure) {
        assert(d.selected_lane==UINT8_MAX&&!d.selected_qualified&&!d.first_status_pending);
        assert(out.events>1u&&!(records[(out.events-1u)*8u+6u]&2u));
    } else {
        // A rejected neighboring hypothesis cannot revoke the healthy lane's
        // validated NID, status history or epoch. Full ten-lane mode already
        // retains these; falling back must not create a new timing lease.
        assert(d.selected_lane==0u&&d.selected_qualified&&d.lane_epoch==epoch);
        assert(d.selected_nac==0x293u);
        for(unsigned i=1u;i<out.events;++i)
            assert(records[i*8u+2u]==epoch&&(records[i*8u+6u]&3u)==3u);
    }
    control_tracking_resume(&d);
    assert(p25_demod_control_tracking_lanes(&d)==0x3ffu
           &&d.control_tracking_flags==P25_DEMOD_CONTROL_TRACK_REQUESTED);
    if(!selected_failure) {
        assert(d.selected_lane==0u&&d.selected_qualified&&d.lane_epoch==epoch);
        unsigned before=out.events;
        for(unsigned i=final+1u;i<180u;++i) {
            d.decision_tick=20000u+10u*i;
            symbol(&d,&d.lane[0],levels[p25_data_get_dibit(healthy,i)]);
        }
        assert(out.events>before&&d.pending_ticks&&!d.pending_errors);
        status_select(&d);
        assert(d.selected_lane==0u&&d.selected_qualified&&d.lane_epoch==epoch);
        for(unsigned i=1u;i<out.events;++i)
            assert(records[i*8u+2u]==epoch&&(records[i*8u+6u]&3u)==3u);
    }
}
unsigned p25_tracking_units(void) {
    p25_demod d;track_output out;
    assert(!p25_demod_control_tracking_lanes(NULL));p25_demod_control_tracking(NULL,true);
    seed(&d,&out,false);p25_demod_control_tracking(&d,true);
    assert(d.control_tracking_flags==P25_DEMOD_CONTROL_TRACK_REQUESTED
        &&p25_demod_control_tracking_lanes(&d)==0x3ffu);
    // Merely requesting tracking, or a non-CRC winner, cannot reduce lanes.
    d.pending_errors=1;status_select(&d);assert(p25_demod_control_tracking_lanes(&d)==0x3ffu);
    d.pending_errors=0;d.pending.duid=5;status_select(&d);assert(p25_demod_control_tracking_lanes(&d)==0x3ffu);
    seed(&d,&out,true);d.control_tracking_center=9;
    assert(p25_demod_control_tracking_lanes(&d)==0x301u);
    d.control_tracking_center=0;d.hunt_filled=240;d.hunt_index=7;d.ticks=101;
    memset(d.hunt_history,0,sizeof d.hunt_history);
    for(unsigned i=2;i<9u;++i) {
        p25_demod_lane *lane=&d.lane[i];memset(lane->history,0x7f,sizeof lane->history);
        lane->filled=24;lane->gain=90000;lane->period_q16=1;lane->next_q16=INT32_MIN;
        lane->sum=777;lane->sum_squares=1234567;lane->rx.symbols=27;lane->rx.frames=100u+i;
    }
    p25_demod_lane retained[3]={d.lane[0],d.lane[1],d.lane[9]};
    status_lost(&d);assert(d.control_tracking_flags&P25_DEMOD_CONTROL_TRACK_FALLBACK);
    assert(p25_demod_control_tracking_lanes(&d)==0x203u); // No mid-tick stale resume.
    control_tracking_resume(&d);assert(p25_demod_control_tracking_lanes(&d)==0x3ffu);
    assert(!memcmp(&retained[0],&d.lane[0],sizeof retained[0])
        &&!memcmp(&retained[1],&d.lane[1],sizeof retained[1])
        &&!memcmp(&retained[2],&d.lane[9],sizeof retained[2]));
    for(unsigned i=2;i<9u;++i) {
        p25_demod_lane *lane=&d.lane[i];assert(!lane->gain&&!lane->sum&&!lane->sum_squares
            &&!lane->rx.symbols&&lane->rx.frames==100u+i&&lane->period_q16==10*65536);
        for(unsigned j=0;j<48u;++j)assert(!lane->history[j]);
        assert(lane->next_q16>0&&lane->next_q16<=10*65536);
    }
    assert(d.control_tracking_flags==P25_DEMOD_CONTROL_TRACK_REQUESTED);
    seed(&d,&out,true);p25_demod_control_tracking(&d,false);
    assert(d.control_tracking_flags==6u&&p25_demod_control_tracking_lanes(&d)==0x203u);
    control_tracking_resume(&d);assert(!d.control_tracking_flags&&p25_demod_control_tracking_lanes(&d)==0x3ffu);
    seed(&d,&out,true);d.idle_ticks=P25_DEMOD_CONTROL_TRACK_MAX_IDLE_TICKS;
    interpolated(&d,0,12000,track_frame,NULL,&out);
    assert(d.selected_lane==UINT8_MAX&&d.control_tracking_flags==1u
        &&p25_demod_control_tracking_lanes(&d)==0x3ffu);
    seed(&d,&out,true);p25_demod_gap(&d);
    assert(!d.control_tracking_flags&&p25_demod_control_tracking_lanes(&d)==0x3ffu);
    seed(&d,&out,true);p25_demod_push(&d,0,track_frame,&out);
    assert(!d.control_tracking_flags&&p25_demod_control_tracking_lanes(&d)==0x3ffu);
    // Inheriting a selected lane outside the fresh winner's neighborhood is
    // insufficient for activation. Do not retarget the ordinary status lane.
    seed(&d,&out,false);p25_demod_control_tracking(&d,true);d.pending_lane=5;
    status_select(&d);assert(d.selected_lane==0&&p25_demod_control_tracking_lanes(&d)==0x3ffu);
    for(unsigned fault=0;fault<3u;++fault)for(unsigned order=0;order<2u;++order) {
        candidate_failure(fault,false,order!=0u);
        candidate_failure(fault,true,order!=0u);
    }
    return (unsigned)sizeof d;
}
unsigned p25_tracking_run(const int16_t *samples,unsigned count,unsigned mode,unsigned change_at,
                         unsigned char *frames,uint64_t *events,uint16_t *masks,unsigned stats[16]) {
    p25_demod d;p25_demod_init(&d);track_output out={.frame_bytes=frames,.status_events=events};
    if(mode&&mode!=6u)p25_demod_control_tracking(&d,true);
    unsigned first=UINT_MAX,last=UINT_MAX,locks=0,falls=0,discontinuities=0;test_symbol_visits=0;
    for(unsigned i=0;i<count;++i) {
        if(i==change_at&&mode==2u)p25_demod_control_tracking(&d,false);
        if(i==change_at&&mode==5u)p25_demod_gap(&d);
        if(i==change_at&&mode==6u)p25_demod_control_tracking(&d,true);
        unsigned before=p25_demod_control_tracking_lanes(&d);
        uint64_t tick=1000000u+(uint64_t)i*6u;uint32_t epoch=11;
        if(mode==3u&&i>=change_at)tick+=6u;
        if(mode==4u&&i>=change_at)++epoch;
        out.current=i;
        if(!p25_demod_push_at(&d,samples[i],tick,epoch,track_frame,track_status,&out))++discontinuities;
        unsigned after=p25_demod_control_tracking_lanes(&d);masks[i]=(uint16_t)after;
        if(before==0x3ffu&&after!=0x3ffu) {++locks;if(first==UINT_MAX)first=i;last=i;}
        if(before!=0x3ffu&&after==0x3ffu)++falls;
    }
    memset(stats,0,16u*sizeof *stats);stats[0]=out.frames;stats[1]=test_symbol_visits;
    stats[2]=d.sync_tests;stats[3]=out.events;stats[4]=discontinuities;stats[5]=locks;stats[6]=falls;
    stats[7]=first;stats[8]=last;stats[9]=d.control_tracking_flags;
    stats[10]=p25_demod_control_tracking_lanes(&d);stats[11]=(unsigned)sizeof d;
    stats[12]=d.selected_lane;return (unsigned)sizeof d;
}
