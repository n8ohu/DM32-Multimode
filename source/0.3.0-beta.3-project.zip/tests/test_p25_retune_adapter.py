# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual P25 retune and cross-protocol ownership under existing HAL mocks."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
UPSTREAM=ROOT/'external/RadioFoundry/RadioFoundry'
BUILD=ROOT/'build/test-p25-retune-adapter'
BUILD.mkdir(parents=True,exist_ok=True)
prefix=(ROOT/'tests/test_live_adapter.c').read_text().split('static void reset(void) {',1)[0]
prefix=prefix.replace('../src/firmware/','')
prefix=prefix.replace('../external/RadioFoundry/RadioFoundry/',UPSTREAM.as_posix()+'/')
prefix=prefix.replace('static void mode(radio_mode_t m) {',
    'static unsigned retune_mode_transitions;\nstatic bool retune_task_fail;\n'
    'static void mode(radio_mode_t m) {\nif(m!=frontend_mode)++retune_mode_transitions;')
marker='    (void)f;(void)n;(void)p;(void)pr;(void)h;assert(d==4096 || d==512);'
assert marker in prefix
prefix=prefix.replace(marker,'    if(retune_task_fail)return 0;\n'+marker)
source=BUILD/'actual-retune-adapter.c'
source.write_text(prefix+(ROOT/'tests/test_p25_retune_adapter.c').read_text(),encoding='utf-8',newline='\n')
includes=['-I'+str(UPSTREAM/path) for path in ('hal','core','drivers','boards/dm32',
    'platform/hrc7000','platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include')]
sources=['p25_demod.c','p25_receive_bench.c','p25_rx.c','p25_tsdu.c','p25_trunking.c',
    'p25_trunking_isp.c','p25_trunking_burst.c','p25_data.c','p25_call.c','p25_live_tx.c',
    'p25_live_frame.c','p25_test_tx.c','radio_microapps.c','same_demod.c','same_protocol.c',
    'radio_applet_store.c','radio_applet_vm.c','radio_applets.c','radio_pcm_engine.c','radio_pcm_fm_tx.c',
    'p25_trunking_backend.c','p25_trunking_search.c','p25_trunking_session.c','p25_trunking_access.c','p25_trunking_slot.c',
    'p25_rx_progress.c','p25_rx_stream.c','p25_rx_feed.c','p25_trunking_preload.c','p25_trunking_lab_exchange.c',
    'p25_trunking_lab_voice.c','p25_trunking_lab_ptt.c','p25_trunking_lab_attach.c']
for diagnostics in (0,1):
    binary=BUILD/('retune-adapter-'+str(diagnostics)+('.exe' if sys.platform=='win32' else ''))
    subprocess.run(['gcc','-std=gnu11','-O1','-g','-Wall','-Wextra','-Werror',
        '-Wno-unused-parameter','-Wno-unused-function','-Wno-unused-variable',
        '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
        '-DDM32_LAB_DIAGNOSTICS='+str(diagnostics),'-DDM32_TRUNK_SUBSCRIBER=1',
        '-DBENCH_GIT="p25-retune-test"','-DCONFIG_DMR=1',
        '-Itests/diag-stubs','-Itests','-Isrc/firmware','-Ifixtures/p25-1011',*includes,
        str(source),'tests/diag-stubs/radio_dmr_stub.c','tests/diag-stubs/radio_pcm_stub.c',
        *['src/firmware/'+name for name in sources],'-o',str(binary)],cwd=ROOT,check=True)
    subprocess.run([str(binary)],cwd=ROOT,check=True,timeout=30)
