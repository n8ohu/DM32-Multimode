"""Offline wire compatibility, explicit RF ordering, credit and restoration tests."""
from collections import deque
import importlib.util
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import wave
import zlib

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('dm32_pcm',ROOT/'scripts/dm32_pcm.py')
pcm=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=pcm;SPEC.loader.exec_module(pcm)
CLI_SPEC=importlib.util.spec_from_file_location('dm32_pcm_cli',ROOT/'scripts/dm32-pcm.py')
cli=importlib.util.module_from_spec(CLI_SPEC);CLI_SPEC.loader.exec_module(cli)

class Clock:
    def __init__(self):self.now=0
    def __call__(self):self.now+=.001;return self.now
    def sleep(self,seconds):self.now+=seconds

class FakePort:
    def __init__(self,**kwargs):
        self.options=kwargs;self.baudrate=115200;self.dtr=True;self.rts=True;self.port=None
        self.responses=bytearray();self.commands=[];self.packets=[];self.state=1;self.accepted=0
        self.queued=0;self.sent=0;self.direction=None;self.modulation=None;self.opened=False;self.closed=False
        self.rx_data=[];self.short_write=False;self.error_start=False;self.missing_ready=False
        self.interrupt_after_start=False;self.ascii_refusal=None
        self.ascii_resync=[]
        self.maximum_queued=0
    def open(self):
        assert self.dtr is False and self.rts is False;self.opened=True
    def close(self):self.closed=True
    @property
    def in_waiting(self):return len(self.responses)
    def reply(self,kind,payload=b'',sequence=0,flags=0):
        self.responses.extend(pcm.Frame(kind,123,sequence,sequence*160,payload,flags).encode())
    def status(self,kind):
        self.reply(pcm.ACK,struct.pack('<BBHIIIII',kind,self.state,7-self.queued,0,self.sent,0,0,self.accepted))
    def write(self,data):
        if self.short_write:return max(0,len(data)-1)
        if self.baudrate==115200 and data==b'\n':
            self.ascii_resync.append(data);return len(data)
        if data.startswith(b'APP '):
            assert self.baudrate==115200
            self.commands.append(data);parts=data.decode().split();self.direction=parts[5];self.modulation=parts[4]
            if self.ascii_refusal:self.responses.extend((self.ascii_refusal+'\r\n').encode())
            elif not self.missing_ready:self.responses.extend(b'APP EVENT harmless\r\nAPP PCM READY 230400 123\r\n')
        else:
            assert self.baudrate==230400
            frame=pcm.Frame.decode(data[:-1]);self.packets.append(frame)
            assert frame.session==123 and frame.flags==0
            if frame.kind==pcm.HELLO:
                self.reply(pcm.HELLO,struct.pack('<IHHHBBI',8000,160,7,320,pcm.MODULATIONS[self.modulation],3,0));self.status(pcm.HELLO)
            elif frame.kind==pcm.DATA:
                assert self.direction=='TX' and frame.sequence==self.accepted
                assert frame.sample_index==self.accepted*160
                self.accepted+=1;self.queued+=1;self.maximum_queued=max(self.maximum_queued,self.queued)
                assert self.queued<=7;self.status(pcm.DATA)
            elif frame.kind==pcm.START:
                if self.error_start:
                    self.reply(pcm.ERROR,struct.pack('<BBHIIIII',pcm.ERROR,5,0,0,0,0,0,self.accepted),flags=7)
                else:
                    if self.direction=='TX':assert self.queued>=4
                    self.state=2;self.status(pcm.START)
                    if self.direction=='RX':
                        for sequence,flags,payload in self.rx_data:self.reply(pcm.DATA,payload,sequence,flags)
            elif frame.kind==pcm.END:
                assert frame.sequence==self.accepted
                self.sent+=self.queued;self.queued=0;self.state=4;self.status(pcm.END)
            elif frame.kind==pcm.STOP:self.queued=0;self.state=4;self.status(pcm.STOP)
            elif frame.kind==pcm.STATUS:self.status(pcm.STATUS)
        return len(data)
    def read(self,length):
        if self.state==2 and self.interrupt_after_start:
            self.interrupt_after_start=False;raise KeyboardInterrupt
        if self.state==2 and self.direction=='TX' and self.queued:
            self.queued-=1;self.sent+=1;self.status(pcm.DATA)
        result=bytes(self.responses[:length]);del self.responses[:length];return result

class PcmHostTests(unittest.TestCase):
    def client(self,**changes):
        port=FakePort();clock=Clock()
        for key,value in changes.items():setattr(port,key,value)
        return pcm.PcmClient(port,clock=clock,sleep=clock.sleep),port

    def test_wire_contract_crc_and_parser_resynchronization(self):
        payload=bytes(range(256))+bytes(range(64))
        frame=pcm.Frame(pcm.DATA,0x12345678,4,640,payload)
        wire=frame.encode();decoded=pcm.cobs_decode(wire[:-1])
        self.assertEqual(len(decoded),344)
        self.assertEqual(decoded[:20],struct.pack('<2sBBHHIII',b'DP',1,3,0,320,0x12345678,4,640))
        self.assertEqual(struct.unpack_from('<I',decoded,20)[0],zlib.crc32(decoded[:20]+payload))
        self.assertEqual(pcm.Frame.decode(wire[:-1]),frame)
        parser=pcm.Decoder();self.assertEqual(parser.feed(bytes([1])*400+b'\0'),[])
        self.assertEqual(parser.bad_frames,1)
        output=[]
        for start in range(0,len(wire),7):output+=parser.feed(wire[start:start+7])
        self.assertEqual(output,[frame]);self.assertLessEqual(len(wire),347)
        corrupted=bytearray(wire);corrupted[-2]^=1
        self.assertEqual(parser.feed(corrupted),[]);self.assertEqual(parser.bad_frames,2)

    def test_python_wire_is_accepted_by_actual_c_engine(self):
        output=ROOT/'build/pcm-host-test';output.mkdir(parents=True,exist_ok=True)
        binary=output/'core.exe'
        subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-pedantic',
                        '-Isrc/firmware','tests/test_pcm_engine.c','src/firmware/radio_pcm_engine.c',
                        '-o',str(binary)],cwd=ROOT,check=True)
        session=0x12345678
        frames=[pcm.Frame(pcm.HELLO,session)]
        frames += [pcm.Frame(pcm.DATA,session,seq,seq*160,struct.pack('<h',seq-32768)*160) for seq in range(4)]
        frames += [pcm.Frame(pcm.START,session,payload=struct.pack('<BBBBI',1,2,3,0,0)),
                   pcm.Frame(pcm.END,session,4,640)]
        source=output/'host.wire';reply=output/'radio.wire'
        source.write_bytes(b''.join(frame.encode() for frame in frames))
        result=subprocess.run([str(binary),str(source),str(reply)],cwd=ROOT,check=True,capture_output=True,text=True)
        self.assertIn('accepted=4 consumed=4 state=4 errors=0',result.stdout)
        decoder=pcm.Decoder();received=decoder.feed(reply.read_bytes())
        self.assertEqual(decoder.bad_frames,0)
        self.assertTrue(any(frame.kind==pcm.HELLO and struct.unpack_from('<I',frame.payload)[0]==8000 for frame in received))
        end=next(frame for frame in received if frame.kind==pcm.ACK and pcm.Status.decode(frame.payload).ack_type==pcm.END)
        status=pcm.Status.decode(end.payload)
        self.assertEqual((end.session,end.sequence,status.state,status.tx_frames),(session,4,4,4))

    def test_config_validation_before_any_write(self):
        client,port=self.client()
        for config in [('RAW','DMR','TX',145700000),('VOICE','FM','BOTH',145700000),('VOICE','FM','RX',True)]:
            with self.assertRaises(ValueError):client.open(*config)
        self.assertEqual(port.commands,[])

    def test_open_sets_control_lines_before_port_open(self):
        port=pcm.open_port('FAKE',types.SimpleNamespace(Serial=FakePort))
        self.assertTrue(port.opened);self.assertFalse(port.dtr);self.assertFalse(port.rts)
        self.assertEqual(port.options['baudrate'],115200)

    def test_tx_prefill_credit_eof_and_stop(self):
        client,port=self.client();client.open('VOICE','DMR','TX',145700000)
        data=struct.pack('<h',1234)*160*30
        report=client.transmit(data);client.stop()
        kinds=[frame.kind for frame in port.packets]
        self.assertEqual(kinds[:6],[pcm.HELLO,pcm.DATA,pcm.DATA,pcm.DATA,pcm.DATA,pcm.START])
        self.assertLessEqual(port.maximum_queued,7);self.assertIn(pcm.END,kinds)
        self.assertEqual(kinds[-1],pcm.STOP);self.assertEqual(port.baudrate,115200)
        self.assertEqual(report.frames,30);self.assertTrue(report.stop_acknowledged)
        self.assertEqual(b''.join(frame.payload for frame in port.packets if frame.kind==pcm.DATA),data)

    def test_start_ack_is_processed_before_waiting_for_pcm_sized_buffer(self):
        clock=Clock()
        class DelayedSerial:
            baudrate=230400
            def __init__(self):
                self.responses=bytearray();self.read_sizes=[];self.started=None;self.refilled=None
            @property
            def in_waiting(self):return len(self.responses)
            def write(self,data):
                frame=pcm.Frame.decode(data[:-1])
                if frame.kind==pcm.START:
                    self.started=clock.now
                    payload=struct.pack('<BBHIIIII',pcm.START,2,4,0,1,0,0,4)
                    self.responses.extend(pcm.Frame(pcm.ACK,123,payload=payload).encode())
                elif frame.kind==pcm.DATA:
                    self.refilled=clock.now
                return len(data)
            def read(self,length):
                self.read_sizes.append(length)
                if self.responses and length>len(self.responses):
                    # A timeout-oriented serial driver can coalesce sparse
                    # control replies while the 80-ms four-frame prefill runs
                    # out. The valid START ACK and later fault then arrive in
                    # one read, before the host has had a chance to refill.
                    clock.now+=.12
                    payload=struct.pack('<BBHIIIII',pcm.ERROR,5,7,0,4,0,1,4)
                    self.responses.extend(pcm.Frame(pcm.ERROR,123,payload=payload,flags=8).encode())
                result=bytes(self.responses[:length]);del self.responses[:length];return result
        port=DelayedSerial();client=pcm.PcmClient(port,clock=clock,sleep=clock.sleep)
        client.binary=True;client.session=123;client.config=('VOICE','P25','TX',145700000)
        client.start();client.send(pcm.DATA,bytes(pcm.PAYLOAD),4)
        self.assertIsNotNone(port.refilled)
        self.assertLess(port.refilled-port.started,.08)
        self.assertEqual(port.read_sizes[0],1)
        self.assertEqual(client.status.state,2)
        self.assertEqual(client.report.radio_underruns,0)

    def test_short_tx_is_padded_and_tot_override_is_zero(self):
        client,port=self.client();client.open('RAW','NFM','TX',145700000)
        report=client.transmit(b'\x01\x02'*161);client.stop()
        self.assertEqual(report.padded_tx_samples,479)
        start=next(frame for frame in port.packets if frame.kind==pcm.START)
        self.assertEqual(struct.unpack('<BBBBI',start.payload),(0,2,1,0,0))

    def test_rx_gap_is_silence_with_explicit_loss_report(self):
        client,port=self.client(rx_data=[(0,0,b'\x11'*320),(2,1,b'\x22'*320),(2,0,b'\x33'*320)])
        client.open('VOICE','P25','RX',145700000);output=bytearray()
        report=client.receive(output.extend,.12);client.stop()
        self.assertEqual(output,b'\x11'*320+bytes(320)+b'\x22'*320)
        self.assertEqual((report.frames,report.missing_frames,report.inserted_silence_samples,report.gap_flags,report.duplicate_frames),(2,1,160,1,1))
        self.assertFalse(any(frame.kind==pcm.DATA for frame in port.packets))

    def test_start_error_can_always_stop_and_restore(self):
        client,port=self.client(error_start=True);client.open('VOICE','FM','RX',145700000)
        with self.assertRaisesRegex(pcm.PcmError,'policy'):client.start()
        client.stop();self.assertEqual(port.baudrate,115200);self.assertEqual(port.packets[-1].kind,pcm.STOP)

    def test_fault_auto_close_resynchronizes_ascii_without_claiming_stop_ack(self):
        client,port=self.client(error_start=True);client.open('RAW','NFM','RX',145700000)
        with self.assertRaisesRegex(pcm.PcmError,'policy'):client.start()
        # The radio has already returned to 115200 by the time the host sees
        # ERROR. A late binary STOP leaves an unfinished ASCII garbage prefix.
        original_write=port.write;poisoned=bytearray();resynced=[]
        def after_auto_close(data):
            if port.baudrate==230400:
                poisoned.extend(b'late-binary-stop');return len(data)
            if data==b'\n':
                self.assertGreaterEqual(client.clock.now-resynced_at,.7)
                poisoned.clear();resynced.append(data);return len(data)
            if data==b'STATUS\n':
                port.responses.extend(b'ERR unknown command\r\n' if poisoned else b'LIVE rf=0\r\n')
                return len(data)
            return original_write(data)
        port.write=after_auto_close;resynced_at=client.clock.now
        with self.assertRaises(TimeoutError):client.stop()
        self.assertEqual(resynced,[b'\n']);self.assertFalse(client.report.stop_acknowledged)
        self.assertFalse(client.binary);self.assertEqual(port.baudrate,115200)
        port.write(b'STATUS\n');self.assertIn(b'LIVE rf=0',port.read(512))

    def test_stop_ack_waits_for_native_close_before_ascii_resync(self):
        client,port=self.client();client.open('VOICE','P25','RX',145700000)
        began=client.clock.now;client.stop()
        self.assertGreaterEqual(client.clock.now-began,.7)
        self.assertTrue(client.report.stop_acknowledged)
        self.assertEqual(port.ascii_resync,[b'\n'])

    def test_missing_stop_ack_waits_for_idle_watchdog_before_ascii(self):
        client,port=self.client();client.open('RAW','NFM','RX',145700000)
        last_binary=[client.clock.now];resynced=[]
        def no_ack(data):
            if port.baudrate==230400:
                last_binary[0]=client.clock.now;return len(data)
            self.assertEqual(data,b'\n')
            self.assertGreaterEqual(client.clock.now-last_binary[0],2.7)
            resynced.append(data);return len(data)
        port.write=no_ack
        with self.assertRaises(TimeoutError):client.stop()
        self.assertEqual(resynced,[b'\n']);self.assertFalse(client.report.stop_acknowledged)
        self.assertFalse(client.binary);self.assertEqual(port.baudrate,115200)

    def test_resync_write_error_does_not_replace_original_stop_failure(self):
        client,port=self.client();client.open('RAW','NFM','RX',145700000)
        def broken(data):
            if port.baudrate==230400:raise OSError('original STOP failure')
            raise OSError('secondary resync failure')
        port.write=broken
        with self.assertRaisesRegex(OSError,'original STOP failure'):client.stop()
        self.assertFalse(client.report.stop_acknowledged);self.assertEqual(port.baudrate,115200)

    def test_ascii_endpoint_refusal_is_immediate_and_never_binary(self):
        client,port=self.client(ascii_refusal='APP PCM ERROR selected channel must be DMR')
        with self.assertRaisesRegex(pcm.PcmError,'must be DMR'):client.open('VOICE','DMR','RX',145700000)
        self.assertFalse(client.binary);self.assertEqual(port.baudrate,115200);self.assertEqual(port.packets,[])

    def test_cli_ctrl_c_stops_and_finalizes_wav_with_report(self):
        client,port=self.client(interrupt_after_start=True)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'interrupted.wav'
            with patch.object(cli,'open_port',return_value=port),patch.object(cli,'PcmClient',return_value=client):
                self.assertEqual(cli.main(['rx',str(path),'--modulation','P25','--hz','145700000']),130)
            self.assertTrue(port.closed);self.assertEqual(port.baudrate,115200)
            self.assertEqual(port.packets[-1].kind,pcm.STOP)
            self.assertTrue(Path(str(path)+'.json').exists())
            with wave.open(str(path),'rb') as wav:self.assertEqual((wav.getnchannels(),wav.getsampwidth(),wav.getframerate()),(1,2,8000))

    def test_timeout_or_partial_write_restores_default_baud(self):
        client,port=self.client(missing_ready=True)
        with self.assertRaises(TimeoutError):client.open('VOICE','DMR','RX',145700000)
        client.stop();self.assertEqual(port.baudrate,115200)
        client,port=self.client();client.open('VOICE','FM','RX',145700000);port.short_write=True
        with self.assertRaises(pcm.PcmError):client.start()
        with self.assertRaises(pcm.PcmError):client.stop()
        self.assertEqual(port.baudrate,115200)

    def test_audio_format_and_cli_reject_before_open(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'bad.wav'
            with wave.open(str(path),'wb') as wav:
                wav.setnchannels(2);wav.setsampwidth(2);wav.setframerate(8000);wav.writeframes(bytes(640))
            with self.assertRaises(ValueError):pcm.read_audio(path)
            with patch.object(cli,'open_port',side_effect=AssertionError('must not open')):
                with self.assertRaises(SystemExit):cli.main(['tx',str(path),'--mode','RAW','--modulation','P25','--hz','145700000'])

if __name__=='__main__':unittest.main()
