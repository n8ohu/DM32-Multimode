"""Finite source scheduling, explicit RF entry and cleanup under fault; no ports."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("hotspot_source_test", ROOT/"scripts/hotspot-p25-source.py")
TOOL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TOOL)
CONFIG = """[General]
Duplex=1
[Info]
TXFrequency=440075000
RXFrequency=445075000
[Modem]
Protocol=uart
UARTPort=/dev/ttyAMA0
UARTSpeed=115200
TXDelay=100
RXInvert=0
TXInvert=0
PTTInvert=0
RXOffset=0
TXOffset=0
P25TXLevel=50
[P25]
Enable=1
NAC=293
[P25 Network]
Enable=0
[DMR]
Enable=0
Beacons=0
[DMR Network]
Enable=0
[CW Id]
Enable=0
"""
DESCRIPTION = b"MMDVM_HS_Dual_Hat-v1.5.2 20201108 14.7456MHz ADF7021 GitID #89daa20"
VERSION = bytes((0xE0, len(DESCRIPTION)+4, 0, 1))+DESCRIPTION


class Clock:
    def __init__(self): self.now = 100.0
    def __call__(self): return self.now
    def sleep(self, seconds): self.now += seconds


class Modem:
    def __init__(self, clock, *, lead=0.6, space=6):
        self.clock, self.lead, self.space = clock, lead, space
        self.sent, self.first, self.tail, self.polls = [], None, clock(), 0
        self.drop_after = self.fail_after = None
        self.assert_tx = True
        self.status_delay = 0
    def status(self):
        self.polls += 1
        self.clock.sleep(self.status_delay)
        if self.fail_after is not None and len(self.sent) >= self.fail_after:
            raise RuntimeError("NAK or overflow")
        tx = bool(self.sent) and self.clock() < self.tail and self.assert_tx
        if self.drop_after is not None and len(self.sent) >= self.drop_after:
            tx = False
        return {"p25": True, "mode": 4 if self.sent else 0, "tx": tx, "space": self.space}
    def send(self, packet):
        if self.first is None:
            self.first = self.clock()+self.lead
            self.tail = self.first
        start = max(self.tail, self.clock())
        self.tail = start+(len(packet)-4)/1200
        self.sent.append((packet, self.clock(), start, self.tail))


class Services:
    def __init__(self, fail_start=False):
        self.states = {unit: unit == "mmdvmhost.service" for unit in TOOL.CC.UNITS}
        self.before = dict(self.states)
        self.fail_start = fail_start
    def loaded(self, unit): return unit == "mmdvmhost.service"
    def active(self, unit): return self.states[unit]
    def manual_hosts(self): return False
    def service(self, action, unit):
        if self.fail_start and action == "start": raise RuntimeError("restore failure")
        self.states[unit] = action == "start"


class SourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.frames, cls.metadata = TOOL.SOURCE.make_fixture()

    def fixture(self, directory):
        directory = Path(directory)
        TOOL.SOURCE.write_fixture(directory, self.frames, self.metadata)
        source = directory/"config.ini"
        source.write_text(CONFIG)
        return source, directory/"control.bin", directory/"manifest.json"

    def test_manifest_or_bytes_cannot_self_authorize_a_different_sequence(self):
        with tempfile.TemporaryDirectory() as directory:
            _, fixture, manifest = self.fixture(directory)
            self.assertEqual(TOOL.load_fixture(fixture, manifest), (tuple(self.frames), self.metadata))
            changed = bytearray(fixture.read_bytes()); changed[-1] ^= 1
            fixture.write_bytes(changed)
            metadata = copy.deepcopy(self.metadata)
            metadata["files"]["control.bin"]["sha256"] = hashlib.sha256(changed).hexdigest()
            manifest.write_text(json.dumps(metadata))
            with self.assertRaisesRegex(ValueError, "regenerated"):
                TOOL.load_fixture(fixture, manifest)
            fixture.write_bytes(b"".join(self.frames))
            for key, value in (("repetitions", 2), ("mfid", 0), ("counter_first", 0), ("rf_verified", True)):
                bad = copy.deepcopy(self.metadata); bad[key] = value
                manifest.write_text(json.dumps(bad))
                with self.subTest(key=key), self.assertRaises(ValueError): TOOL.load_fixture(fixture, manifest)
            fixture.write_bytes(b"short")
            with self.assertRaisesRegex(ValueError, "sizes"): TOOL.load_fixture(fixture, manifest)

    def test_offline_cli_never_touches_configuration_services_uart_or_stop_path(self):
        with tempfile.TemporaryDirectory() as directory:
            _, fixture, manifest = self.fixture(directory)
            with patch.object(TOOL, "configuration", side_effect=AssertionError("no config")), \
                    patch.object(TOOL.CC, "System", side_effect=AssertionError("no services")), \
                    patch.object(TOOL, "transmit", side_effect=AssertionError("no UART")), \
                    patch.object(TOOL, "stop_path", side_effect=AssertionError("no stop path")), \
                    patch.dict(sys.modules, {"serial": None}), contextlib.redirect_stdout(io.StringIO()) as stdout:
                result = TOOL.main(["--fixture", str(fixture), "--manifest", str(manifest),
                                    "--config", "/no-config", "--stop-file", "/no-stop"])
            record = json.loads(stdout.getvalue())
            self.assertEqual(result, 0)
            self.assertTrue(record["dry_run"] and record["fixture_validated"])
            self.assertEqual((record["units"], record["rf_payload_commands_sent"], record["responses_sent"]), (192, 0, 0))

    def test_profile_is_exact_existing_duplex_and_preserves_calibration_power_caps(self):
        with tempfile.TemporaryDirectory() as directory:
            source, _, _ = self.fixture(directory)
            profile = TOOL.configuration(source, 9)
            self.assertEqual(profile["lab_profile"], "LEGACY5M")
            self.assertEqual((profile["effective_tx_frequency_hz"], profile["effective_rx_frequency_hz"]), (440075000, 445075000))
            self.assertLessEqual(profile["rf_level_byte"]/255, .09)
            for text in (CONFIG.replace("RXFrequency=445075000", "RXFrequency=441075000"),
                         CONFIG.replace("Duplex=1", "Duplex=0"),
                         CONFIG.replace("[P25 Network]\nEnable=0", "[P25 Network]\nEnable=1"),
                         CONFIG.replace("TXDelay=100", "TXDelay=1000"),
                         CONFIG.replace("NAC=293", "NAC=2A3")):
                source.write_text(text)
                with self.subTest(config=text), self.assertRaises(ValueError): TOOL.configuration(source, 9)
            source.write_text(CONFIG)
            for power in (0, 11, True, 9.0):
                with self.subTest(power=power), self.assertRaises(ValueError): TOOL.configuration(source, power)

    def test_single_pass_queues_all_unique_frames_once_with_continuous_primed_readiness(self):
        clock = Clock(); modem = Modem(clock); events = []
        result = TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep, event=events.append)
        self.assertEqual([row[0][4:] for row in modem.sent], self.frames)
        self.assertEqual(len(modem.sent), 192)
        self.assertAlmostEqual(modem.tail-modem.first, 7.2)
        self.assertLessEqual(result["max_estimated_payload_queue_s"], .25+1e-9)
        for row in modem.sent:
            self.assertLessEqual(row[3]-max(row[1], modem.first), .25+1e-9)
        ready = [record for record in events if record["event"] == "cc_ready"]
        self.assertEqual(len(ready), 1)
        self.assertEqual(ready[0]["units_queued"], 6)
        self.assertTrue(ready[0]["tx_observed"])
        self.assertAlmostEqual(ready[0]["estimated_payload_queue_s"], .225)
        self.assertEqual(events[-1]["event"], "source_queued_complete")
        self.assertEqual(events[-1]["units_queued"], 192)
        self.assertEqual(result["responses_sent"], 0)
        self.assertFalse(result["rf_timing_measured"] or result["rf_decode_verified"])

    def test_tx_drop_nak_or_overflow_stop_without_retrying_or_filling_more(self):
        for mode in ("drop", "NAK"):
            clock = Clock(); modem = Modem(clock)
            if mode == "drop": modem.drop_after = 10
            else: modem.fail_after = 10
            with self.subTest(mode=mode), self.assertRaises(RuntimeError):
                TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep)
            self.assertEqual(len(modem.sent), 10)

    def test_never_asserted_tx_and_stalled_fifo_cannot_claim_ready_or_complete(self):
        clock = Clock(); modem = Modem(clock); modem.assert_tx = False; events = []
        with self.assertRaisesRegex(RuntimeError, "assert TX"):
            TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep, event=events.append)
        self.assertFalse(any(row["event"] == "cc_ready" for row in events))
        clock = Clock(); modem = Modem(clock, space=0)
        with self.assertRaises(TimeoutError): TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep)
        self.assertEqual(modem.sent, [])
        self.assertLess(clock.now, 111)

    def test_nak_after_final_write_cannot_be_reported_as_success(self):
        clock = Clock(); modem = Modem(clock); modem.fail_after = 192; events = []
        with self.assertRaisesRegex(RuntimeError, "NAK"):
            TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep, event=events.append)
        self.assertEqual(len(modem.sent), 192)
        self.assertEqual(events[-1]["event"], "source_queued_complete")
        self.assertFalse(events[-1]["rf_timing_measured"] or events[-1]["rf_decode_verified"])

    def test_stop_during_preamble_never_sends_later_identities(self):
        clock = Clock(); modem = Modem(clock)
        with self.assertRaises(InterruptedError):
            TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep,
                          stopping=lambda: len(modem.sent) >= 6)
        self.assertEqual(len(modem.sent), 6)
        self.assertLess(clock(), modem.first)

    def test_late_status_cannot_send_after_deadline_and_stop_is_cooperative(self):
        clock = Clock(); modem = Modem(clock); modem.status_delay = 20
        with self.assertRaisesRegex(TimeoutError, "status transaction"):
            TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep)
        self.assertEqual(modem.sent, [])
        clock = Clock(); modem = Modem(clock)
        with self.assertRaises(InterruptedError):
            TOOL.schedule(modem, self.frames, .6, clock=clock, sleep=clock.sleep,
                          stopping=lambda: len(modem.sent) >= 10)
        self.assertEqual(len(modem.sent), 10)

    def test_reordered_truncated_changed_or_repeated_input_is_rejected_before_link_access(self):
        for frames in (self.frames[:-1], self.frames*2, list(reversed(self.frames)),
                       [self.frames[0]]*192):
            clock = Clock(); modem = Modem(clock)
            with self.subTest(size=len(frames)), self.assertRaises(ValueError):
                TOOL.schedule(modem, frames, .6, clock=clock, sleep=clock.sleep)
            self.assertEqual(modem.polls, 0)
        for lead in (False, float("nan"), .4, 1.1):
            with self.subTest(lead=lead), self.assertRaises(ValueError): TOOL.schedule(None, self.frames, lead)

    def test_actual_link_status_refuses_overflow_or_other_mode_before_payload(self):
        good = bytes((0xE0, 13, 1, 8, 0, 0, 0, 0, 0, 0, 6, 0, 0))
        for row in (good[:5]+b"\x04"+good[6:], good[:4]+b"\x01"+good[5:]):
            link = TOOL.CC.Link(None); link.query = lambda command: row
            link.send = lambda data: self.fail("no payload on invalid status")
            clock = Clock()
            with self.subTest(row=row), self.assertRaises(RuntimeError):
                TOOL.schedule(link, self.frames, .6, clock=clock, sleep=clock.sleep)

    def test_modem_identity_precedes_any_frequency_config_or_rf_write(self):
        class Device:
            def __enter__(self): return self
            def __exit__(self, *args): return False
        class Link:
            def __init__(self, device): pass
            def query(self, cmd): return VERSION
            def status(self): return {"tx": False, "p25": True, "mode": 0}
            def command(self, wire): writes.append(wire)
        with tempfile.TemporaryDirectory() as directory:
            source, _, _ = self.fixture(directory); profile = TOOL.configuration(source, 9)
            writes = []; device = Device()
            serial = types.SimpleNamespace(Serial=lambda **kw: device)
            with patch.dict(sys.modules, {"serial": serial}), patch.object(TOOL.CC, "Link", Link), \
                    patch.object(TOOL, "schedule", return_value={"units_sent": 192}) as run:
                result = TOOL.transmit(profile, self.frames, lambda row: None)
            self.assertEqual(writes, [profile["frequency"], profile["config"]])
            self.assertEqual(result["modem"], DESCRIPTION.decode())
            self.assertEqual(run.call_count, 1)
            self.assertFalse(device.dtr or device.rts)
            writes.clear()
            with patch.dict(sys.modules, {"serial": serial}), patch.object(TOOL.CC, "Link", Link), \
                    patch.object(TOOL.CC, "identify", side_effect=RuntimeError("unknown modem")):
                with self.assertRaises(RuntimeError): TOOL.transmit(profile, self.frames, lambda row: None)
            self.assertEqual(writes, [])

    def test_stop_file_requires_absent_canonical_parent_and_detects_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory).resolve()/"stop"
            self.assertEqual(TOOL.stop_path(file), file)
            self.assertFalse(TOOL.stop_requested(file))
            file.write_text("stop")
            self.assertTrue(TOOL.stop_requested(file))
            with self.assertRaises(ValueError): TOOL.stop_path(file)
            with self.assertRaises(ValueError): TOOL.stop_path(Path("relative"))

    def test_main_restores_services_and_reports_abort_separately_from_success(self):
        original_execute = TOOL.CC.execute_session
        fake_signals = types.SimpleNamespace(SIGINT=2, SIGTERM=15, SIGHUP=1, SIGALRM=14,
            SIG_IGN=1, ITIMER_REAL=0, getsignal=lambda sig: None,
            signal=lambda sig, handler: None, setitimer=lambda *args: None)
        fake_fcntl = types.SimpleNamespace(LOCK_EX=2, LOCK_NB=4, flock=lambda *args: None)
        for fail_tx, fail_restore in ((False, False), (True, False), (False, True)):
            with self.subTest(fail_tx=fail_tx, fail_restore=fail_restore), tempfile.TemporaryDirectory() as directory:
                folder = Path(directory).resolve(); source, fixture, manifest = self.fixture(folder)
                services = Services(fail_restore); output = folder/"capture"
                def execute(system, operation, source, report, begin_cleanup):
                    return original_execute(system, operation, source, report,
                                            begin_cleanup=begin_cleanup, settle=lambda seconds: None)
                with patch.object(TOOL, "os", types.SimpleNamespace(name="posix", geteuid=lambda: 0, chmod=os.chmod)), \
                        patch.object(TOOL, "signal", fake_signals), patch.dict(sys.modules, {"fcntl": fake_fcntl}), \
                        patch.object(TOOL, "open", lambda path, mode: (folder/"lock").open(mode), create=True), \
                        patch.object(TOOL.CC, "System", return_value=services), \
                        patch.object(TOOL.CC, "execute_session", side_effect=execute), \
                        patch.object(TOOL, "transmit", side_effect=RuntimeError("TX failed") if fail_tx else None,
                                     return_value={"units_sent": 192, "responses_sent": 0}), \
                        contextlib.redirect_stdout(io.StringIO()):
                    status = TOOL.main(["--transmit", "--fixture", str(fixture), "--manifest", str(manifest),
                                        "--config", str(source), "--output", str(output)])
                report = json.loads((output/"report.json").read_text())
                self.assertEqual(status, 1 if fail_tx or fail_restore else 0)
                self.assertEqual(report["result"], "failed" if fail_tx or fail_restore else "complete")
                self.assertEqual(report["services_restored"], not fail_restore)
                self.assertTrue(report["original_config_unchanged"])
                self.assertEqual(source.read_text(), CONFIG)
                if not fail_restore: self.assertEqual(services.states, services.before)
                if fail_tx:
                    self.assertEqual(report["error_type"], "RuntimeError")
                    self.assertEqual(report["error"], "TX failed")
                self.assertFalse(report["rf_timing_measured"] or report["rf_decode_verified"])


if __name__ == "__main__":
    unittest.main()
