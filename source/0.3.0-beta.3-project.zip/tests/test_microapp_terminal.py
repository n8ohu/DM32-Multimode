"""Offline command and serial-lifecycle tests; no ports are opened."""
import importlib.util
import io
from pathlib import Path
import queue
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import patch
import zlib

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('dm32_apps_terminal',ROOT/'scripts'/'dm32-apps.py')
terminal=importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name]=terminal
SPEC.loader.exec_module(terminal)


class FakePort:
    def __init__(self,**kwargs):
        self.options=kwargs;self.dtr=True;self.rts=True;self.port=None
        self.opened=False;self.closed=False;self.writes=[];self.read_wait=threading.Event()
    def open(self):
        assert self.dtr is False and self.rts is False and self.port=='FAKE'
        self.opened=True
    def close(self):self.closed=True
    def write(self,data):self.writes.append(data);return len(data)
    def read(self,size):self.read_wait.wait(0.01);return b''


class UploadPort(FakePort):
    """Replies arrive through read(), never through the client's readline()."""
    def __init__(self):
        super().__init__();self.responses=queue.Queue();self.pending=b'';self.readers=set()
        self.image=bytearray();self.size=0;self.crc=0;self.committed=False;self.aborted=False;self.foreign=False
    def reply(self,line):self.responses.put((line+'\r\n').encode('ascii'))
    def read(self,size):
        self.readers.add(threading.current_thread().name)
        if not self.pending:
            try:self.pending=self.responses.get(timeout=0.01)
            except queue.Empty:return b''
        data=self.pending[:size];self.pending=self.pending[size:];return data
    def readline(self,size):raise AssertionError('Second port reader is forbidden')
    def write(self,data):
        self.writes.append(data);line=data.decode('ascii').rstrip('\n');words=line.split()
        if words[:3]==['APP','INSTALL','BEGIN']:
            if self.foreign:self.reply('APP ERROR foreign partition; not modified')
            else:
                self.size=int(words[4]);self.crc=int(words[5]);self.image.clear()
                self.reply('SAME asynchronous receiver line')
                self.reply('APP EVENT unrelated')
                self.reply('APP OK INSTALL BEGIN')
        elif words[:3]==['APP','INSTALL','DATA']:
            offset=int(words[3]);chunk=bytes.fromhex(words[4])
            assert offset==len(self.image);self.image.extend(chunk)
            self.reply(f'APP OK INSTALL DATA {len(self.image)}')
        elif line=='APP INSTALL COMMIT':
            assert len(self.image)==self.size and zlib.crc32(self.image)&0xFFFFFFFF==self.crc
            self.committed=True;self.reply('APP OK INSTALL COMMIT')
        elif line=='APP INSTALL ABORT':self.aborted=True;self.reply('APP OK INSTALL ABORT')
        elif line=='APP STOP':self.reply('APP STOPPED')
        elif line=='APP STORE STATUS':self.reply('APP OK STORE STATUS')
        elif line=='APP STATUS':self.reply('APP STATUS running=0')
        elif words[:2]==['APP','RUN']:self.reply('APP OK RUN '+words[2])
        elif words[:2]==['APP','REMOVE']:self.reply('APP OK REMOVE '+words[2])
        else:raise AssertionError(f'Unexpected command {line}')
        return len(data)


class MicroappTerminalTest(unittest.TestCase):
    def test_aliases_and_no_command_passthrough(self):
        aliases={'apps':'APPS','APP HELP':'APP HELP','same':'APP SAME START 162550000',
            'same 162.425':'APP SAME START 162425000','same162.550':'APP SAME START 162550000',
            'same start 162400000':'APP SAME START 162400000','status':'APP SAME STATUS',
            'last':'APP SAME LAST','watch off':'APP SAME WATCH OFF','WATCH ON':'APP SAME WATCH ON',
            'stop':'APP STOP','app same':'APP SAME STATUS','APP SAME START':'APP SAME START 162550000',
            'slots':'APP STORE STATUS','APP STORE STATUS':'APP STORE STATUS','appstatus':'APP STATUS',
            'app status':'APP STATUS','run 1':'APP RUN 1','run8':'APP RUN 8','APP RUN 3':'APP RUN 3',
            'remove 2':'APP REMOVE 2','remove8':'APP REMOVE 8','APP REMOVE 4':'APP REMOVE 4'}
        for entered,wire in aliases.items():
            with self.subTest(entered=entered):self.assertEqual(terminal.parse_command(entered).wire,wire)
        self.assertTrue(terminal.parse_command('quit').quit)
        self.assertTrue(terminal.parse_command('exit').quit)
        self.assertTrue(terminal.parse_command('help').local_help)
        self.assertIsNone(terminal.parse_command(' ').wire)
        for command in ('CPS BEGIN','STATUS EXTRA','START','TX 1','APP STOP\nTX','APPEND','APPS SAME',
                'app same watch maybe','same 162.55 extra','same 162.4125','same nan','same +162.550',
                'same -162.550','same 1625500000','same 4294967296','same 162.5500001','\033[31m','x'*96,
                'run 0','run 9','run 01','run +1','run 1 extra','run9','APP RUN 0','APP REMOVE 9',
                'APP STORE FORMAT','APP INSTALL BEGIN 1 64 0','APP INSTALL ABORT','appstatus extra'):
            with self.subTest(command=command):
                with self.assertRaises(ValueError):terminal.parse_command(command)

    def test_local_install_paths_are_bounded_and_keep_windows_syntax(self):
        paths=[r'C:\Users\Tester\My Apps\same.dappsrc',r'.\apps\same.dapp',
            'folder with spaces/app.dappsrc','weather-\u2603.dappsrc','A'*150+'.dapp']
        for path in paths:
            for quoting in ('','"',"'"):
                with self.subTest(path=path,quoting=quoting):
                    command=terminal.parse_command(f'install 2 {quoting}{path}{quoting}')
                    self.assertEqual(command.install_slot,2);self.assertEqual(command.install_path,path)
                    self.assertIsNone(command.wire)
        for line in ('install 0 file.dapp','install 9 file.dapp','install +1 file.dapp','install 1',
                'install 1 file.py','install 1 "unterminated.dapp','install 1 file.dapp\nAPP RUN 1',
                'install 1 '+'x'*1020+'.dapp','slots '+'x'*100,'\tinstall 1 file.dapp'):
            with self.subTest(line=line):
                with self.assertRaises(ValueError):terminal.parse_command(line)

    def test_all_noaa_channels_and_exact_units(self):
        for hz in terminal.NOAA_HZ:
            self.assertEqual(terminal.same_frequency(str(hz)),hz)
            self.assertEqual(terminal.same_frequency(f'{hz/1000000:.3f}'),hz)
        self.assertEqual(terminal.same_frequency('162.55'),162550000)
        with self.assertRaises(ValueError):terminal.same_frequency('162550')

    def test_serial_open_does_not_tune_or_raise_control_lines(self):
        module=types.SimpleNamespace(Serial=FakePort)
        port=terminal.open_port('FAKE',module)
        self.assertTrue(port.opened)
        self.assertEqual(port.options,{'port':None,'baudrate':115200,'timeout':0.1,'write_timeout':1})
        self.assertEqual(port.writes,[])
        terminal.send_command(port,'APP SAME START 162550000')
        self.assertEqual(port.writes,[b'APP SAME START 162550000\n'])
        for command in ('TX 1','APP STOP\nTX','same 162.550','APP SAME START'):
            with self.assertRaises(ValueError):terminal.send_command(port,command)
        self.assertEqual(len(port.writes),1)

    def test_bounded_serial_output_sanitizes_terminal_controls(self):
        decoder=terminal.LineDecoder()
        self.assertEqual(decoder.feed(b'SAME HEA'),[])
        self.assertEqual(decoder.feed(b'DER\r\n\033[31mRED\n'),['SAME HEADER','?[31mRED'])
        self.assertEqual(decoder.feed(b'X'*2048),[])
        self.assertLessEqual(len(decoder.pending),terminal.LINE_MAX)
        self.assertEqual(decoder.feed(b'\nnormal\n'),['[Oversized serial line discarded]','normal'])

    def test_quit_and_ctrl_c_send_stop_and_close(self):
        for interrupt in (False,True):
            with self.subTest(interrupt=interrupt):
                port=FakePort();entered=iter(['same 162.550','status','quit'])
                calls=0
                def read_input(prompt):
                    nonlocal calls
                    calls+=1
                    if interrupt and calls==3:raise KeyboardInterrupt
                    return next(entered)
                self.assertEqual(terminal.terminal_session(port,read_input,io.StringIO(),io.StringIO()),0)
                self.assertTrue(port.closed)
                self.assertEqual(port.writes,[b'APP SAME START 162550000\n',b'APP SAME STATUS\n',b'APP STOP\n'])

    def test_invalid_command_cannot_reach_serial(self):
        port=FakePort();entered=iter(['CPS BEGIN','TX 1','APP STOP\nTX','help','quit']);errors=io.StringIO()
        self.assertEqual(terminal.terminal_session(port,lambda prompt:next(entered),io.StringIO(),errors),0)
        self.assertEqual(port.writes,[b'APP STOP\n'])
        self.assertIn('Unknown command',errors.getvalue())

    def test_eof_and_connection_failure_cleanup(self):
        port=FakePort()
        def eof(prompt):raise EOFError
        self.assertEqual(terminal.terminal_session(port,eof,io.StringIO(),io.StringIO()),0)
        self.assertEqual(port.writes,[b'APP STOP\n'])
        class FailedPort(FakePort):
            def write(self,data):raise OSError('disconnected')
        port=FailedPort();errors=io.StringIO()
        self.assertEqual(terminal.terminal_session(port,eof,io.StringIO(),errors),1)
        self.assertTrue(port.closed)
        self.assertIn('Stop locally',errors.getvalue())

    def test_interactive_install_has_one_reader_and_prints_acks_once(self):
        with tempfile.TemporaryDirectory() as temporary:
            source=Path(temporary)/'SAME monitor.dappsrc'
            source.write_text('name "Interactive Test"\ncaps serial\nprint "Hello"\nend',encoding='utf-8')
            package=terminal._applet_module().load_package(source)
            port=UploadPort();entered=iter([f'install 2 "{source}"','run 2','appstatus','slots','remove 2','quit'])
            output=io.StringIO();errors=io.StringIO()
            self.assertEqual(terminal.terminal_session(port,lambda prompt:next(entered),output,errors),0)
            self.assertEqual(bytes(port.image),package.data);self.assertTrue(port.committed)
            self.assertEqual(port.readers,{'dm32-app-reader'});self.assertTrue(port.closed)
            self.assertEqual(output.getvalue().count('APP OK INSTALL COMMIT'),1)
            self.assertIn('SAME asynchronous receiver line',output.getvalue())
            self.assertIn('APP EVENT unrelated',output.getvalue());self.assertIn('Installed "Interactive Test"',output.getvalue())
            self.assertFalse(errors.getvalue())
            before_commit=port.writes.index(b'APP INSTALL COMMIT\n')
            self.assertFalse(any(line.startswith(b'APP RUN') for line in port.writes[:before_commit+1]))
            self.assertFalse(any(b'FORMAT' in line for line in port.writes));self.assertEqual(port.writes[-1],b'APP STOP\n')

    def test_bad_local_package_has_no_install_side_effect_and_prompt_continues(self):
        with tempfile.TemporaryDirectory() as temporary:
            source=Path(temporary)/'bad.dapp';source.write_bytes(b'DAPP invalid bytes')
            port=UploadPort();entered=iter([f'install 1 {source}','appstatus','quit']);errors=io.StringIO()
            self.assertEqual(terminal.terminal_session(port,lambda prompt:next(entered),io.StringIO(),errors),0)
            self.assertEqual(port.writes,[b'APP STATUS\n',b'APP STOP\n'])
            self.assertIn('Install failed:',errors.getvalue());self.assertFalse(port.committed)

    def test_install_rejection_aborts_and_returns_to_prompt(self):
        with tempfile.TemporaryDirectory() as temporary:
            source=Path(temporary)/'valid.dappsrc';source.write_text('name "Test"\ncaps none\nend',encoding='utf-8')
            port=UploadPort();port.foreign=True;entered=iter([f'install 1 {source}','slots','quit']);errors=io.StringIO()
            self.assertEqual(terminal.terminal_session(port,lambda prompt:next(entered),io.StringIO(),errors),0)
            self.assertIn('foreign partition',errors.getvalue());self.assertTrue(port.aborted)
            self.assertFalse(port.committed);self.assertIn(b'APP STORE STATUS\n',port.writes)
            self.assertFalse(any(line.startswith(b'APP INSTALL DATA') for line in port.writes))

    def test_reply_adapter_has_bounded_queue_and_rejects_non_upload_commands(self):
        port=FakePort();replies=queue.Queue(maxsize=terminal.REPLY_QUEUE_MAX)
        stopped=threading.Event();overflow=threading.Event()
        adapter=terminal._ReplyPort(port,replies,stopped,overflow,[])
        for line in (b'APP RUN 1\n',b'CPS BEGIN\n',b'APP INSTALL DATA 0 fff\n',
                b'APP INSTALL DATA 32768 ff\n',b'APP INSTALL BEGIN 1 1 0\n',
                b'APP INSTALL BEGIN 1 64 4294967296\n',b'APP INSTALL COMMIT\nAPP RUN 1\n'):
            with self.subTest(line=line):
                with self.assertRaises(ValueError):adapter.write(line)
        self.assertEqual(port.writes,[])
        for _ in range(terminal.REPLY_QUEUE_MAX):replies.put_nowait(b'APP EVENT queued\n')
        with self.assertRaises(queue.Full):replies.put_nowait(b'APP EVENT overflow\n')
        self.assertEqual(replies.qsize(),128)
        overflow.set()
        with self.assertRaisesRegex(OSError,'queue overflow'):adapter.readline()
        overflow.clear();self.assertEqual(adapter.readline(4),b'APP ')
        self.assertEqual(adapter.readline(),b'EVENT queued\n')

    def test_open_and_help_do_not_import_compiler_or_install(self):
        port=FakePort();entered=iter(['help','quit'])
        with patch.object(terminal,'_applet_module',side_effect=AssertionError('compiler imported')):
            self.assertEqual(terminal.terminal_session(port,lambda prompt:next(entered),io.StringIO(),io.StringIO()),0)
        self.assertEqual(port.writes,[b'APP STOP\n'])

    def test_optional_readline_completion(self):
        completions=[];bindings=[]
        module=types.SimpleNamespace(set_completer=completions.append,parse_and_bind=bindings.append)
        self.assertTrue(terminal.configure_completion(module))
        self.assertEqual(bindings,['tab: complete'])
        self.assertEqual(completions[0]('inst',0),'install ')
        self.assertIsNone(completions[0]('inst',1))
        self.assertIsNone(completions[0]('CPS',0))
        with patch.object(terminal.importlib,'import_module',side_effect=ImportError('not available')):
            self.assertFalse(terminal.configure_completion())


if __name__=='__main__':unittest.main()
