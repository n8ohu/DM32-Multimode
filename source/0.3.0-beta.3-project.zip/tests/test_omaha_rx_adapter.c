// SPDX-License-Identifier: GPL-3.0-or-later
// Appended to the actual controller's existing HAL mock prefix by the runner.
_Static_assert(DM32_OMAHA_RX_ONLY==1 && DM32_LAB_DIAGNOSTICS==0,"Field RX-only profile");
static uint8_t saved_flash[32768];
static bool test_was_down,test_dirty;
static const char *fixtures;
static void no_tx(void) {
    assert(!rf_keys && !pa_keys && !call_active && !hardware_running && !prepared && !audio_on);
    assert(!mock_pa_selected && !mock_rf_selected && !mock_dac_drive);
    assert(!digital_dmr.tx_armed && !digital_dmr.data_armed && !analog_fm.transmitting);
    assert(!trunk_subscriber_active() && !trunk_session.running && !trunk_system_subscriber);
    assert(!memcmp(saved_flash,pref_flash_mem,sizeof saved_flash));
    assert(!pref_flash_writes && !pref_flash_erases);
}
static void tick(bool down) {
    scripted_keys=down?ptt_mask:0;mock_ptt_high=!down;
    normal_tick(scripted_keys,&test_was_down,&test_dirty);advance(1000u);
    no_tx();
}
static void boot(unsigned stored_kind) {
    now=1000000u;ptt_mask=1u;display_ok=true;screen_backlight=80;
    scripted_scan=true;mock_ptt_high=true;
    __wrap_hrc_dmr_board_init(&modem,&rf_hooks);
    radio_dmr_stub_reset();
    radio_dmr_hal hal={.radio=board.radio,.modem=board.dmr,.audio=board.audio,
        .vocoder=board.vocoder,.acquire=dmr_acquire,.release=dmr_release};
    radio_dmr_init(&digital_dmr,&hal);
    assert(radio_codec_bind_dmr(&rx_storage,sizeof rx_storage));
    p25_preferences previous={145700000u,145700000u,0x293,1000,1234567,0,22,false,true};
    memset(pref_flash_mem,255,sizeof pref_flash_mem);
    if(stored_kind!=2u)pref_pack(pref_flash_mem,&previous,7);
    if(stored_kind==1u || stored_kind==3u) {
        // Fixture preparation deliberately creates an existing DMR codeplug
        // before the field application starts. These are not application writes.
        p25_cs_store stored;uint8_t global[32],channel[32];uint32_t crc;
        assert(p25_cs_open(&stored,&pref_flash));
        assert(p25_cs_read(&stored,P25_CS_GLOBAL,global));
        assert(p25_cs_read(&stored,P25_CS_VFO_A,channel));
        assert(radio_channel_set_mode(channel,stored_kind==1u?RADIO_CHANNEL_DMR:RADIO_CHANNEL_P25));
        global[28]=global[29]=0;
        assert(p25_cs_begin(&stored,stored.revision));
        assert(p25_cs_stage_write(&stored,P25_CS_GLOBAL,global));
        assert(p25_cs_stage_write(&stored,P25_CS_VFO_A,channel));
        if(stored_kind==3u) {
            uint8_t empty_list[32]={0};memcpy(empty_list,"Empty TG",8);
            empty_list[12]=P25_CS_SCAN_TG;p25_cs_put16(empty_list+14,1u);
            p25_cs_put16(empty_list+18,500u);
            assert(p25_cs_stage_write(&stored,0u,channel));
            assert(p25_cs_stage_write(&stored,p25_cs_scan_key(0u),empty_list));
        }
        assert(p25_cs_stage_crc(&stored,&crc) && p25_cs_commit(&stored,crc));
    }
    pref_flash_writes=pref_flash_erases=0;
    memcpy(saved_flash,pref_flash_mem,sizeof saved_flash);
    preferences_restore();hardware_stop();boot_policy();
    if(stored_kind==4u)tune=false;
    for(unsigned i=0;i<60;++i)tick(false);
    if(stored_kind==4u) {
        assert(omaha_receive_recovery.pending && trunk_enabled && !mon_running);
        assert(!mon_enabled && !trunk_subscriber_active());no_tx();return;
    }
    if(!trunk_enabled || !trunk_system_overlay_owned || !mon_running)
        fprintf(stderr,"boot state trunk=%u overlay=%u mon=%u reason=%s mon_reason=%s trunk_reason=%s ptt=%u checked=%u state=%u features=%u\n",
            trunk_enabled,trunk_system_overlay_owned,mon_running,reason,mon_reason,trunk_reason,
            ptt_release_required,trunk_system_boot_checked,control.state,features_ready);
    assert(trunk_enabled && trunk_system_overlay_owned && mon_running);
    assert(frequency==172287500u && receiver_frequency()==172287500u);
    assert(control.nac==0xb85 && control.talkgroup==3075u && control.source_id==1u);
    assert(trunk.group_count==1u && trunk.groups[0]==3075u && !rx_promiscuous);
    assert(trunk_search.config.wacn==0xbee00u && trunk_search.config.system==0xb8fu);
    assert(trunk_search.config.rfss==1u && trunk_search.config.site==70u && trunk_search.config.count==7u);
    assert(trunk_search.config.nac==0xb85u && strstr(trunk_system_name,"NDOT"));
    assert(!channel_store.writable && !pref_store.writable);
    no_tx();
}
static uint32_t healthy_raw_epoch,healthy_raw_due;
static unsigned healthy_raw_half;
static void healthy_ticks(uint32_t duration_us) {
    uint32_t deadline=now+duration_us;
    memset(buf+C7_FM_RX_AUDIO,0,1024);
    while((int32_t)(now-deadline)<0) {
        if(mon_running && healthy_raw_epoch!=trunk_stream_epoch) {
            healthy_raw_epoch=trunk_stream_epoch;healthy_raw_due=now;healthy_raw_half=0;
        }
        if(mon_running && (int32_t)(now-healthy_raw_due)>=0) {
            regs[C7_SYS_INTERP_LIST/4]=1u<<14;
            regs[C7_FM_ADDR_SW/4]=(healthy_raw_half++&1u)+1u;
            isr_sys();healthy_raw_due=now+32000u;
        }
        tick(false);
    }
}
static void receive_wire(const char *name) {
    char path[1024];snprintf(path,sizeof path,"%s/%s.bin",fixtures,name);
    FILE *f=fopen(path,"rb");assert(f);p25_rx unit;p25_rx_init(&unit);int byte;unsigned units=0;
    while((byte=fgetc(f))!=EOF)for(unsigned dibit=0;dibit<4u;++dibit)
        if(p25_rx_push(&unit,(uint8_t)((byte>>(6u-2u*dibit))&3u))) {
            assert(unit.duid==7u || unit.duid==12u);mon_receive(&unit,NULL);++units;
        }
    assert(!ferror(f)&&units==1u);fclose(f);trunk_poll(false);no_tx();
}
static void lock(void) {
    receive_wire("wrong-nac-site");receive_wire("wrong-site");receive_wire("grant");
    assert(trunk_search.phase!=P25_TRUNK_SEARCH_LOCKED && !trunk.grants && !trunk.pending_hz);
    // Changing site identity invalidates its earlier band map. The next real
    // identifier repeat must rebuild it before those site/network rows lock.
    receive_wire("site-0");assert(trunk_search.phase!=P25_TRUNK_SEARCH_LOCKED);
    receive_wire("site-0");assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
}
static void frame(uint8_t duid,const uint8_t *bytes) {
    p25_rx unit={.nac=(uint16_t)control.nac,.duid=duid};
    if(bytes)memcpy(unit.frame,bytes,duid==0u?99u:duid==3u?18u:216u);
    mon_receive(&unit,NULL);no_tx();
}
static void issue_rx(const char *text) {
    output_n=0;strcpy(command,text);parse_command(false);
    for(unsigned i=0;telemetry_pending();++i) {assert(i<1024u);telemetry_poll(false);}
    no_tx();
}
int main(int argc,char **argv) {
    assert(argc==3);fixtures=argv[2];
    boot(!strcmp(argv[1],"initial-setup")?4u:!strcmp(argv[1],"empty-boot")?2u:!strcmp(argv[1],"dmr-boot")?1u:!strcmp(argv[1],"scan-boot")?3u:0u);
    if(!strcmp(argv[1],"boot") || !strcmp(argv[1],"empty-boot") || !strcmp(argv[1],"dmr-boot") || !strcmp(argv[1],"scan-boot")) {
        assert(strstr(home_hint(),"RX"));
        issue_rx("PROFILE");assert(strstr(output,"OMAHA_DUALSITE_RX_ONLY_TG3075_V2"));
        for(unsigned i=0;i<100;++i)tick(true);
        for(unsigned i=0;i<60;++i)tick(false);
    } else if(!strcmp(argv[1],"search")) {
        const uint32_t cc[]={172287500u,172600000u,173762500u,154680000u,154950000u,155872500u,156142500u};
        for(unsigned i=0;i<7;++i) {
            assert(frequency==cc[i] && trunk_search.index==i);
            assert(control.nac==(i<3u?0xb85u:0xb83u));
            assert(trunk.configured_nac==control.nac && trunk.learned_nac==control.nac);
            assert(trunk_search.config.nac==control.nac && trunk_search.config.site==(i<3u?70u:83u));
            assert(!trunk.have_site && !trunk.have_network);
            char name[20];snprintf(name,sizeof name,"site-%u",i);receive_wire(name);
            assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
            now+=3100000u;monitor.last_raw_us=now;trunk_poll(false);no_tx();
        }
        assert(frequency==cc[0] && trunk_search.index==0u && !trunk.have_site && !trunk.have_network);
    } else if(!strcmp(argv[1],"follow")) {
        lock();
        receive_wire("other-group");receive_wire("wrong-nac");receive_wire("encrypted");
        assert(trunk.phase==P25_TRUNKING_CONTROL && !trunk.grants);
        receive_wire("grant");assert(trunk.phase==P25_TRUNKING_VOICE && receiver_frequency()==171437500u);
        p25_channel_frames voice;assert(p25_channel_build(&voice,0xb85,3075u,1u));
        frame(0,voice.hdu);frame(5,voice.ldu1);
        assert(monitor.voices==9u && decode_calls==9u && trunk.have_voice);
        // Neither physical PTT nor the restricted display menu interrupts RX.
        local_action(ACT_SELECT,false);assert(menu_open && mon_running);
        for(unsigned i=0;i<70;++i)tick(true);
        assert(mon_running && trunk.phase==P25_TRUNKING_VOICE && trunk.have_voice);
        tick(false);local_action(ACT_BACK,false);assert(!menu_open && mon_running);
        frame(3,NULL);trunk_poll(false);
        now+=601000u;monitor.last_raw_us=now;trunk_poll(false);
        assert(trunk_enabled && trunk.phase==P25_TRUNKING_CONTROL && receiver_frequency()==172287500u);
        assert(trunk_search.index==0u && control.nac==0xb85u && trunk_search.config.site==70u);
        no_tx();
    } else if(!strcmp(argv[1],"fallback") || !strcmp(argv[1],"wrap")) {
        uint32_t last_epoch=trunk_stream_epoch;
        for(unsigned i=0;i<3u;++i) {
            now+=3100000u;monitor.last_raw_us=now;trunk_poll(false);no_tx();
            assert(trunk_stream_epoch!=last_epoch);last_epoch=trunk_stream_epoch;
        }
        assert(frequency==154680000u && control.nac==0xb83u && trunk_search.index==3u);
        assert(trunk_search.config.nac==0xb83u && trunk_search.config.site==83u && strstr(trunk_system_name,"Hummel"));
        assert(!trunk.have_site && !trunk.have_network && !trunk.band[1].valid);
        // Previous-site control and voice grants cannot lock or retune here.
        receive_wire("site-0");receive_wire("grant");receive_wire("hummel-grant");
        assert(trunk_search.phase!=P25_TRUNK_SEARCH_LOCKED && !trunk.grants && !trunk.pending_hz);
        receive_wire("site-3");assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
        receive_wire("grant");assert(trunk.phase==P25_TRUNKING_CONTROL);
        receive_wire("hummel-grant");assert(trunk.phase==P25_TRUNKING_VOICE && receiver_frequency()==154122500u);
        p25_channel_frames voice,foreign;
        assert(p25_channel_build(&voice,0xb83,3075u,1u));
        assert(p25_channel_build(&foreign,0xb85,3075u,1u));
        p25_rx wrong={.nac=0xb85,.duid=0};memcpy(wrong.frame,foreign.hdu,99);mon_receive(&wrong,NULL);
        wrong.duid=5;memcpy(wrong.frame,foreign.ldu1,216);mon_receive(&wrong,NULL);assert(!decode_calls);
        frame(0,voice.hdu);frame(5,voice.ldu1);assert(decode_calls==9u && trunk.have_voice);
        frame(3,NULL);trunk_poll(false);now+=601000u;monitor.last_raw_us=now;trunk_poll(false);
        assert(trunk.phase==P25_TRUNKING_CONTROL && receiver_frequency()==154680000u && trunk_search.index==3u);
        assert(control.nac==0xb83u && trunk_search.config.site==83u);no_tx();
        if(!strcmp(argv[1],"wrap")) {
            // Resume acquisition on Hummel, then exhaust that site's controls.
            receive_wire("site-3");
            for(unsigned i=0;i<4u;++i) {now+=3100000u;monitor.last_raw_us=now;trunk_poll(false);no_tx();}
            assert(frequency==172287500u && control.nac==0xb85u && trunk_search.index==0u);
            assert(trunk_search.config.nac==0xb85u && trunk_search.config.site==70u);
            assert(!trunk.have_site && !trunk.have_network && !trunk.band[1].valid);
            receive_wire("site-3");receive_wire("hummel-grant");assert(!trunk.pending_hz && !trunk.have_site);
            receive_wire("site-0");assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
        }
    } else if(!strcmp(argv[1],"recover-fault") || !strcmp(argv[1],"recover-gap")) {
        lock();uint32_t epoch_before=trunk_stream_epoch;
        if(!strcmp(argv[1],"recover-fault"))mon_failed=true;else now+=201000u;
        tick(false);
        assert(omaha_receive_recovery.pending && trunk_enabled && trunk_system_overlay_owned);
        assert(!mon_running && !mon_enabled && trunk_search.phase==P25_TRUNK_SEARCH_OFF);
        healthy_ticks(499000u);assert(omaha_receive_recovery.pending && !mon_running);
        healthy_ticks(150000u);
        assert(!omaha_receive_recovery.pending && mon_running && trunk_enabled);
        assert(trunk_stream_epoch!=epoch_before && trunk_search.index==0u && frequency==172287500u);
        assert(!trunk.have_site && !trunk.have_network && !trunk.band[1].valid);
        assert(!ptt_release_required && !menu_open);receive_wire("site-0");
        assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
        // Continue receiving longafter the old reproduction silentlyfellback.
        // Real matching metadata keeps this site live throughout the interval.
        for(unsigned i=0;i<25u;++i) {healthy_ticks(1000000u);receive_wire("site-0");}
        assert(mon_running && trunk_enabled && trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
        assert(!mon_failed && !monitor.raw_overflow);no_tx();
    } else if(!strcmp(argv[1],"recover-setup")) {
        lock();mon_failed=true;tick(false);tune=false;
        healthy_ticks(501000u);
        assert(omaha_receive_recovery.pending && omaha_receive_recovery.index==0u
            && omaha_receive_recovery.attempts==2u && !mon_running);
        healthy_ticks(501000u);
        assert(omaha_receive_recovery.pending && omaha_receive_recovery.index==1u
            && !omaha_receive_recovery.attempts && !mon_running);
        healthy_ticks(1500000u);assert(omaha_receive_recovery.pending && !mon_running);
        tune=true;healthy_ticks(501000u);
        assert(!omaha_receive_recovery.pending && mon_running && trunk_enabled
            && frequency==172600000u && trunk_search.index==1u);
        assert(control.nac==0xb85u && trunk_search.config.site==70u && !trunk.have_site);
        receive_wire("site-1");assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);no_tx();
    } else if(!strcmp(argv[1],"initial-setup")) {
        tune=true;healthy_ticks(650000u);
        assert(!omaha_receive_recovery.pending && mon_running && trunk_enabled);
        assert(frequency==172287500u && trunk_search.index==0u);
        receive_wire("site-0");assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);no_tx();
    } else if(!strcmp(argv[1],"recovery-cancel") || !strcmp(argv[1],"recovery-poweroff")
           || !strcmp(argv[1],"recovery-unrelated-fault")) {
        lock();mon_failed=true;tick(false);assert(omaha_receive_recovery.pending);
        if(!strcmp(argv[1],"recovery-cancel"))trunk_stop("operator");
        else if(!strcmp(argv[1],"recovery-poweroff"))mock_power_on=false;
        else control.state=RADIO_FAULT;
        healthy_ticks(1500000u);
        assert(!omaha_receive_recovery.pending && !mon_running && !trunk_enabled);
        mock_power_on=true;healthy_ticks(1500000u);
        assert(!mon_running && !trunk_enabled);
        if(!strcmp(argv[1],"recovery-unrelated-fault"))assert(control.state==RADIO_FAULT);
        no_tx();
    } else if(!strcmp(argv[1],"activity")) {
        lock();
        for(unsigned i=0;i<6u;++i) {
            healthy_ticks(2000000u);receive_wire("activity");
            assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED && trunk_search.index==0u);
        }
        receive_wire("foreign-activity");healthy_ticks(3100000u);
        assert(trunk_search.index!=0u && trunk_enabled && mon_running);no_tx();
    } else if(!strcmp(argv[1],"ambt-activity")) {
        receive_wire("iden-only");receive_wire("ambt-site");receive_wire("ambt-network");
        assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
        for(unsigned i=0;i<6u;++i) {
            healthy_ticks(2000000u);receive_wire("ambt-other-group");
            assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED && trunk_search.index==0u);
            assert(!trunk.pending_hz && !trunk.grants);
        }
        receive_wire("ambt-wrong-nac");healthy_ticks(3100000u);
        assert(trunk_search.index!=0u && trunk_enabled && mon_running);no_tx();
    } else if(!strcmp(argv[1],"ambt")) {
        receive_wire("iden-only");assert(trunk.band[1].valid && !trunk.have_site && !trunk.have_network);
        mon_have_sync=false;uint32_t units_before=trunk_units;
        receive_wire("ambt-corrupt");receive_wire("ambt-wrong-nac");receive_wire("ambt-grant");
        assert(!mon_have_sync && trunk_units==units_before && !trunk.have_site && !trunk.have_network);
        assert(trunk_search.phase!=P25_TRUNK_SEARCH_LOCKED && !trunk.pending_hz && !trunk.grants);
        receive_wire("ambt-site");assert(trunk.have_site && !trunk.have_network);
        receive_wire("ambt-network");assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED);
        receive_wire("ambt-other-group");assert(!trunk.pending_hz && !trunk.grants);
        receive_wire("ambt-grant");assert(trunk.phase==P25_TRUNKING_VOICE && receiver_frequency()==171437500u);
        p25_channel_frames voice;assert(p25_channel_build(&voice,0xb85,3075u,1u));
        frame(0,voice.hdu);frame(5,voice.ldu1);assert(decode_calls==9u);
        frame(3,NULL);trunk_poll(false);now+=601000u;monitor.last_raw_us=now;trunk_poll(false);
        assert(trunk.phase==P25_TRUNKING_CONTROL && receiver_frequency()==172287500u);
        receive_wire("ambt-site");receive_wire("ambt-network");
        assert(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED && mon_have_sync);no_tx();
    } else if(!strcmp(argv[1],"deny")) {
        lock();
        const char *denied[]={"RADIO","STOP","TRUNK STOP","TRUNK ACCESS START","TX ENABLE",
            "ARM 154680000 ALLOW_RF","SESSION 154680000 ALLOW_RF","CHANNEL 145700000 145700000 659 1 1 22",
            "CPS HELLO","APP START 1","PCM TX VOICE","TXSOURCE MIC"};
        for(unsigned i=0;i<sizeof denied/sizeof *denied;++i) {
            issue_rx(denied[i]);assert(strstr(output,"ERR"));
            assert(trunk_enabled && mon_running && !cps_active && !cps_link);
        }
        owner_tx_inhibit=false;channel_record[12]&=(uint8_t)~P25_CS_RX_ONLY;
        control.inhibit=false;control.tx_enabled=true;session_enabled=armed=true;
        assert(!begin_capture());session_enabled=armed=false;
        normal_permission();assert(control.inhibit && !control.tx_enabled);
        assert(!ptt_start_requested(true,false));
        for(unsigned i=0;i<100;++i)tick(true);
        tick(false);
        for(unsigned action=ACT_DIGIT_0;action<=ACT_DIGIT_9;++action)local_action(action,false);
        local_action(ACT_AB,false);local_action(ACT_MONITOR,false);
        local_action(ACT_NAV_UP,false);local_action(ACT_NAV_DOWN,false);
        assert(frequency==172287500u && trunk_enabled);no_tx();
    } else assert(false);
    printf("Omaha receive %s: PASS\n",argv[1]);return 0;
}
