# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent registration fixtures and native wire checks, with no RF I/O."""
import contextlib
import ctypes as C
import importlib.util
import io
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("p25_access_fixture", ROOT/"scripts/generate-p25-access-fixture.py")
generator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(generator)


class Tsdu(C.Structure):
    _fields_ = [("nac", C.c_uint16), ("count", C.c_uint8), ("block", (C.c_uint8*12)*3)]


class AccessFixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        build = ROOT / "build/test-p25-access-fixture"
        build.mkdir(parents=True, exist_ok=True)
        library = build/("access_fixture.dll" if sys.platform == "win32" else "access_fixture.so")
        command = ["gcc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-shared"]
        if sys.platform != "win32":
            command.append("-fPIC")
        subprocess.run(command+["-Isrc/firmware", "src/firmware/p25_rx.c", "src/firmware/p25_tsdu.c",
            "src/firmware/p25_trunking_isp.c", "-o", str(library)], cwd=ROOT, check=True)
        cls.lib = C.CDLL(str(library))
        cls.lib.p25_tsdu_decode.argtypes = [C.POINTER(C.c_uint8), C.c_size_t, C.POINTER(Tsdu)]
        cls.lib.p25_tsdu_decode.restype = C.c_bool
        cls.lib.p25_tsdu_decode_block.argtypes = [C.POINTER(C.c_uint8), C.c_size_t, C.c_uint, C.POINTER(C.c_uint8)]
        cls.lib.p25_tsdu_decode_block.restype = C.c_bool
        cls.lib.p25_trunking_isp_register.argtypes = [C.POINTER(C.c_uint8), C.c_uint32, C.c_uint16, C.c_uint32]
        cls.lib.p25_trunking_isp_register.restype = C.c_bool
        cls.lib.p25_tsdu_encode.argtypes = [C.POINTER(C.c_uint8), C.c_size_t, C.c_uint16,
            C.POINTER(C.c_uint8*12), C.c_uint, C.c_uint8]
        cls.lib.p25_tsdu_encode.restype = C.c_size_t

    def test_native_decode_fields_encoder_bytes_and_prefix(self):
        rng = random.Random(0xA11CE)
        identities = [(1, 0, 1, 1), (0xFFFFFF, 0xFFF, 0xFFFFF, 0xFFF)]
        identities += [(rng.randrange(1, 1<<24), rng.randrange(4096), rng.randrange(1, 1<<20),
            rng.randrange(1, 4096)) for _ in range(30)]
        for rid, nac, wacn, system in identities:
            files, metadata = generator.make_fixture(radio_id=rid, nac=nac, wacn=wacn, system_id=system)
            wire, prefix = files[generator.FILES[0]], files[generator.FILES[1]]
            frame = (C.c_uint8*len(wire)).from_buffer_copy(wire)
            decoded = Tsdu()
            self.assertTrue(self.lib.p25_tsdu_decode(frame, len(wire), C.byref(decoded)))
            self.assertEqual((decoded.nac, decoded.count), (nac, 1))
            word = bytes(decoded.block[0]); argument = int.from_bytes(word[2:10], "big")
            self.assertEqual((word[0], word[1]), (0xAC, 0))
            self.assertEqual(((argument>>36)&0xFFFFF, (argument>>24)&0xFFF, argument&0xFFFFFF), (wacn, system, rid))
            self.assertEqual(metadata["expected"]["decoded_hex"], word.hex())
            native_block = (C.c_uint8*12)()
            self.assertTrue(self.lib.p25_trunking_isp_register(native_block, wacn, system, rid))
            self.assertEqual(bytes(native_block), word)
            blocks = ((C.c_uint8*12)*1)(native_block); native = (C.c_uint8*90)()
            self.assertEqual(self.lib.p25_tsdu_encode(native, 90, nac, blocks, 1, 2), 45)
            self.assertEqual(bytes(native[:45]), wire)
            self.assertEqual((len(prefix), metadata["prefix"]["valid_bits"]), (40, 316))
            self.assertEqual(prefix[-1]&15, 0)
            self.assertEqual(prefix[:39], wire[:39]); self.assertEqual(prefix[-1]&0xF0, wire[39]&0xF0)
            # Native block decoder needs the prefix's 158 real dibits only;
            # complete-envelope decode deliberately requires all45 padded bytes.
            recovered = (C.c_uint8*12)()
            self.assertTrue(self.lib.p25_tsdu_decode_block((C.c_uint8*40).from_buffer_copy(prefix), 40, 0, recovered))
            self.assertEqual(bytes(recovered), word)
            self.assertFalse(self.lib.p25_tsdu_decode((C.c_uint8*40).from_buffer_copy(prefix), 40, C.byref(decoded)))
            dibits = [(wire[i//4]>>(6-2*(i%4)))&3 for i in range(180)]
            self.assertEqual([dibits[i] for i in range(35, 180, 36)], [2]*5)
            self.assertFalse(metadata["rf_timing_qualified"])
            self.assertFalse(metadata["transmission_authorized"])

    def test_exact_roundtrip_loader_rejects_data_and_manifest_tampering(self):
        files, manifest = generator.make_fixture(radio_id=123456)
        with tempfile.TemporaryDirectory() as folder:
            generator.write_fixture(folder, files, manifest)
            self.assertEqual(generator.load_fixture(folder), (files, manifest))
            for name in generator.FILES:
                path = Path(folder)/name
                for bad in (b"", files[name]+b"\0", bytes((files[name][0]^1,))+files[name][1:]):
                    path.write_bytes(bad)
                    with self.assertRaisesRegex(ValueError, "data differs"):
                        generator.load_fixture(folder)
                path.write_bytes(files[name])
            path = Path(folder)/"manifest.json"
            for key, bad in (("radio_id", 123457), ("rf_timing_qualified", True), ("units", 2), ("schema", "wrong")):
                altered = dict(manifest); altered[key] = bad
                path.write_text(json.dumps(altered))
                with self.assertRaises(ValueError):
                    generator.load_fixture(folder)
            path.write_text(" "*16385)
            with self.assertRaisesRegex(ValueError, "bounded"):
                generator.load_fixture(folder)

    def test_validation_and_required_radio_id(self):
        for params in ({"radio_id": 0}, {"radio_id": 1<<24}, {"radio_id": True}, {"radio_id": 1.0},
            {"nac": -1}, {"nac": 4096}, {"wacn": 0}, {"wacn": 1<<20},
            {"system_id": 0}, {"system_id": 4096}):
            with self.subTest(params=params), self.assertRaises(ValueError):
                generator.make_fixture(**({"radio_id": 42}|params))
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            generator.main([])
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            generator.main(["--radio-id", "0"])

    def test_cli_has_only_finite_documented_artifacts_and_no_import_side_effects(self):
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()) as output:
            generator.main(["--radio-id", "0x123456", "--output", folder])
            self.assertEqual({p.name for p in Path(folder).iterdir()}, set(generator.FILES)|{"manifest.json"})
            self.assertEqual(generator.load_fixture(folder), generator.make_fixture(radio_id=0x123456))
            self.assertEqual(json.loads(output.getvalue())["valid_prefix_bits"], 316)
        with tempfile.TemporaryDirectory() as folder:
            code = ("import importlib.util; "
                f"s=importlib.util.spec_from_file_location('g',{str(ROOT/'scripts/generate-p25-access-fixture.py')!r}); "
                "g=importlib.util.module_from_spec(s); s.loader.exec_module(g); g.make_fixture(radio_id=42)")
            subprocess.run([sys.executable, "-c", code], cwd=folder, check=True, capture_output=True, text=True)
            self.assertEqual(list(Path(folder).iterdir()), [])


if __name__ == "__main__":
    unittest.main()
