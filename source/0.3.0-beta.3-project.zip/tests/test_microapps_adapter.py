"""Exercise actual radio-controller microapp integration using existing HAL mocks.

The SAME waveform comes from the independent NOAA-spec host generator; this
test sends it through the real SYS IRQ, queue, demodulator and protocol parser.
No serial port, RF hardware, firmware image or vendor executable is accessed.
"""
from array import array
import importlib.util
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build'/'microapps-adapter'
UPSTREAM=ROOT/'external'/'RadioFoundry'/'RadioFoundry'
INCLUDES=['-I'+str(UPSTREAM/path) for path in (
    'hal','core','drivers','boards/dm32','platform/hrc7000',
    'platform/hrc7000/freertos','third_party/FreeRTOS-Kernel/include')]


def run(arguments):
    result=subprocess.run([str(arg) for arg in arguments],cwd=ROOT,
        capture_output=True,text=True,timeout=45)
    if result.returncode:
        raise AssertionError(f'{arguments[0]} exited {result.returncode}\n{result.stdout}\n{result.stderr}')
    return result.stdout


class MicroappsAdapterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        BUILD.mkdir(parents=True,exist_ok=True)
        prefix=(ROOT/'tests/test_live_adapter.c').read_text().split('static void reset(void) {',1)[0]
        prefix=prefix.replace('../src/firmware/','').replace(
            '../external/RadioFoundry/RadioFoundry/',UPSTREAM.as_posix()+'/')
        start=prefix.index('static size_t write_port(')
        end=prefix.index('static bool audio_start(',start)
        prefix=prefix[:start]+WRITE_MOCK+prefix[end:]
        source=BUILD/'microapps-adapter.c'
        source.write_text(prefix+ADAPTER_MAIN,encoding='utf-8',newline='\n')
        cls.binary=BUILD/'microapps-adapter.exe'
        run(['gcc','-std=gnu11','-O1','-Wall','-Wextra','-Werror',
            '-Wno-unused-parameter','-Wno-unused-function','-Wno-unused-variable',
            '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
            '-DBENCH_GIT="microapps-test"','-DCONFIG_DMR=1',
            '-Itests/diag-stubs','-Itests','-Isrc/firmware','-Ifixtures/p25-1011',
            *INCLUDES,source,'tests/diag-stubs/radio_dmr_stub.c',
            'src/firmware/p25_demod.c','src/firmware/p25_rx.c','src/firmware/p25_tsdu.c','src/firmware/p25_trunking.c','src/firmware/p25_trunking_isp.c','src/firmware/p25_trunking_burst.c',
            'src/firmware/p25_call.c','src/firmware/p25_data.c','src/firmware/p25_live_tx.c',
            'src/firmware/p25_live_frame.c','src/firmware/p25_test_tx.c',
            'src/firmware/radio_microapps.c','src/firmware/same_demod.c',
            'src/firmware/same_protocol.c','src/firmware/radio_applet_vm.c',
            'src/firmware/radio_applet_store.c','src/firmware/radio_applets.c',
            'src/firmware/radio_pcm_engine.c','src/firmware/radio_pcm_fm_tx.c','tests/diag-stubs/radio_pcm_stub.c',
            '-o',cls.binary])
        spec=importlib.util.spec_from_file_location('microapps_same_waveform',ROOT/'tests/test_same_demod.py')
        generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
        samples=[]
        for payload in (generator.HEADER,generator.HEADER,b'NNNN',b'NNNN'):
            samples.extend(generator.waveform(payload,phase=.73,dc=3000,noise=500))
            samples.extend([3000]*8000)
        cls.fixture=BUILD/'same-headers-eom.pcm'
        with cls.fixture.open('wb') as stream:array('h',samples).tofile(stream)

    def check_case(self,case):
        report=run([self.binary,case,self.fixture])
        self.assertIn(f'microapps adapter {case}: PASS',report)

    def test_mode_ownership_and_stop_restore(self):
        for mode in ('p25','fm','dmr'):
            with self.subTest(mode=mode):self.check_case(mode)

    def test_busy_ptt_cps_and_tx_guards(self):self.check_case('guards')
    def test_failed_start_unwinds(self):self.check_case('failed')
    def test_cps_takeover_keeps_protocol_clean(self):self.check_case('cps')
    def test_back_ctrl_c_and_held_ptt_gate(self):self.check_case('stops')
    def test_irq_audio_to_confirmed_header_and_eom(self):self.check_case('waveform')
    def test_queue_overflow_gap_reset_and_recovery(self):self.check_case('gap')
    def test_missing_audio_timeout_restores_receiver(self):self.check_case('timeout')
    def test_nonblocking_partial_serial_writes_and_whole_line_overflow(self):self.check_case('serial')
    def test_cps_takeover_closes_partial_app_line(self):self.check_case('serial-cps')
    def test_invalid_pcm_halves_cannot_keep_app_alive(self):self.check_case('invalid-halves')


WRITE_MOCK=r'''
static unsigned app_write_limit=UINT32_MAX,app_write_calls,app_write_max;
static bool app_in_irq,app_in_callback;
static size_t write_port(const uint8_t *p,size_t n) {
    assert(!digital_dmr.tx_armed && !app_in_irq && !app_in_callback);
    ++app_write_calls;if(n>app_write_max)app_write_max=(unsigned)n;
    if(n>app_write_limit)n=app_write_limit;
    assert(output_n+n<sizeof output);memcpy(output+output_n,p,n);output_n+=n;output[output_n]=0;
    return n;
}
'''


ADAPTER_MAIN=r'''
static uint8_t settings_memory[32768];
static unsigned settings_writes,settings_erases;
static bool settings_read(uint32_t addr,void *data,uint32_t size) {
    assert(addr>=0x711000u && addr+size<=0x719000u);
    memcpy(data,settings_memory+addr-0x711000u,size);return true;
}
static bool settings_write(uint32_t addr,const void *data,uint32_t size) {
    assert(addr>=0x711000u && addr+size<=0x719000u);++settings_writes;
    for(unsigned i=0;i<size;++i)settings_memory[addr-0x711000u+i]&=((const uint8_t *)data)[i];
    return true;
}
static bool settings_erase(uint32_t addr) {
    assert(addr>=0x711000u && addr<0x719000u && !(addr%4096u));
    ++settings_erases;memset(settings_memory+addr-0x711000u,255,4096);return true;
}
static const hal_flash_map_t settings_map={.settings_addr=0x711000u,.settings_size=32768u};
static const hal_flash_t pref_flash={.size=0x1000000u,.erase_size=4096u,.read=settings_read,
    .write=settings_write,.erase=settings_erase,.map=&settings_map};
static bool was_down,dirty;
static uint8_t saved_channel_record[32],saved_global_record[32],saved_settings[32768];
static p25_preferences saved_profile;
static void drain_serial(void) {
    unsigned limit=0;
    while(same_running && same_rx.serial_head!=same_rx.serial_tail) {
        unsigned tail=same_rx.serial_tail;apps_output_flush();
        assert(same_rx.serial_tail!=tail && ++limit<4096u);
    }
}
static void issue_app(const char *text) {strcpy(command,text);parse_command(false);drain_serial();}
static void clear_uart(void) {output_n=0;output[0]=0;}
static void tick(bool down) {
    scripted_scan=true;scripted_keys=down ? ptt_mask : 0;mock_ptt_high=!down;
    if(same_running)same_last_pcm_us=now;
    if(mon_running)monitor.last_raw_us=now;
    normal_tick(scripted_keys,&was_down,&dirty);now+=1000u;
}
static void assert_no_rf(void) {
    assert(!rf_keys && !pa_keys && !mock_pa_selected && !mock_rf_selected);
    assert(!call_active && !hardware_running && !audio_on && !callback && !digital_dmr.tx_armed);
}
static void snapshot(void) {
    memcpy(saved_channel_record,channel_record,32);memcpy(saved_global_record,global_record,32);
    memcpy(saved_settings,settings_memory,sizeof saved_settings);saved_profile=pref_current();
    settings_writes=settings_erases=0;
}
static void assert_saved(void) {
    p25_preferences current=pref_current();
    assert(current.rx==saved_profile.rx && current.tx==saved_profile.tx);
    assert(current.nac==saved_profile.nac && current.tg==saved_profile.tg && current.id==saved_profile.id);
    assert(!memcmp(saved_channel_record,channel_record,32) && !memcmp(saved_global_record,global_record,32));
    assert(!memcmp(saved_settings,settings_memory,sizeof saved_settings) && !settings_writes && !settings_erases);
}
static void setup(radio_channel_mode_t mode_index) {
    now=1000000u;ptt_mask=1;mock_ptt_high=true;scripted_scan=true;scripted_keys=0;
    mock_dac_power=0xa5u|DAC_B_OFF;
    radio_dmr_stub_reset();assert(radio_codec_bind_dmr(&rx_storage,sizeof rx_storage));
    radio_dmr_hal dmr_hal={.radio=board.radio,.modem=board.dmr,.audio=board.audio,
        .vocoder=board.vocoder,.acquire=dmr_acquire,.release=dmr_release};
    radio_dmr_init(&digital_dmr,&dmr_hal);regs[C7_SYS_INTERP_MASK/4]=MOCK_NATIVE_SYS_MASK;
    __wrap_hrc_dmr_board_init(&modem,&rf_hooks);apps_init();
    memset(settings_memory,255,sizeof settings_memory);
    p25_preferences initial={440075000,440075000,0x293,10,1234567,0,22,false,false};
    pref_pack(settings_memory,&initial,7);preferences_restore();assert(features_ready);
    assert(radio_channel_set_mode(channel_record,mode_index));
    if(mode_index==RADIO_CHANNEL_DMR) {
        assert(radio_channel_set_destination(channel_record,98638));
        assert(radio_channel_set_timeslot(channel_record,2));
    }
    feature_apply();feature_capture();
    assert(feature_commit(feature_key(),channel_record,true));
    memcpy(channel_saved,channel_record,32);memcpy(global_saved,global_record,32);pref_saved=pref_current();
    assert(normal_resume());tick(false);snapshot();clear_uart();
    assert(mode_index==RADIO_CHANNEL_DMR ? digital_dmr.running : mode_index==RADIO_CHANNEL_FM ? analog_fm.running : mon_running);
    assert_no_rf();
}
static void start_same(void) {
    issue_app("APP SAME START 162550000");
    assert(same_running && microapps.active==RADIO_MICROAPP_SAME);
    assert(tuned_rx==162550000u && tuned_bw==RADIO_BW_25K && frontend_mode==RADIO_MODE_FM);
    assert(!analog_fm.owned && !digital_dmr.owned && !mon_running && !mon_enabled);
    assert((regs[C7_SYS_INTERP_MASK/4]&(1u<<14)) && mock_irq_enabled[IRQ_MODEM_SYS]);
    assert(control.inhibit && !control.tx_enabled && !analog_audio);
    assert(!memcmp(saved_channel_record,channel_record,32));assert_saved();assert_no_rf();
}
static void assert_restored(void) {
    assert(!same_running && microapps.active==RADIO_MICROAPP_NONE && normal_mode);
    tick(false);assert_saved();assert_no_rf();assert(tuned_rx==frequency);
    assert(feature_dmr() ? digital_dmr.running : feature_fm() ? analog_fm.running : mon_running);
}
static void test_mode(radio_channel_mode_t mode_index) {
    setup(mode_index);start_same();
    for(unsigned i=0;i<10;++i)tick(true);
    assert(same_running && ptt_release_required);assert_no_rf();
    mock_ptt_high=true;scripted_keys=0;
    issue_app("APP STOP");assert_restored();
    unsigned old_writes=settings_writes;issue_app("APP STOP");assert(settings_writes==old_writes);assert_saved();
}
static void test_guards(void) {
    setup(RADIO_CHANNEL_P25);uint32_t tuned=tuned_rx;
    const char *bad[]={"APP SAME START 162550001","APP SAME START 162.550","APP SAME START 162550000 extra","APP STOP extra"};
    for(unsigned i=0;i<sizeof bad/sizeof bad[0];++i) {issue_app(bad[i]);assert(!same_running && tuned_rx==tuned);}
    mock_ptt_high=false;issue_app("APP SAME START");assert(!same_running && mon_running);
    mock_ptt_high=true;scripted_keys=ptt_mask;issue_app("APP SAME START");assert(!same_running);
    scripted_keys=0;cps_link=true;issue_app("APP SAME START");assert(!same_running);cps_link=false;
    cps_active=true;issue_app("APP SAME START");assert(!same_running);cps_active=false;
    call_active=true;issue_app("APP SAME START");assert(!same_running);call_active=false;
    prepared=true;issue_app("APP SAME START");assert(!same_running);prepared=false;
    rx_job=true;issue_app("APP SAME START");assert(!same_running);rx_job=false;
    assert_saved();assert_no_rf();
}
static void test_failed(void) {
    setup(RADIO_CHANNEL_DMR);tune=false;
    issue_app("APP SAME START");assert(!same_running && microapps.active==RADIO_MICROAPP_NONE);
    assert(!native_irq_owned && !digital_dmr.owned && !mon_running && !analog_fm.owned);
    assert_saved();assert_no_rf();tune=true;tick(false);
    assert(digital_dmr.running && tuned_rx==frequency);assert_saved();
}
static void test_cps(void) {
    setup(RADIO_CHANNEL_P25);start_same();clear_uart();issue_app("CPS HELLO");
    assert(!same_running && microapps.active==RADIO_MICROAPP_NONE && cps_link);
    char hello[64];snprintf(hello,sizeof hello,"CPS HELLO DM32P25 %u 256 2 ",P25_CS_VERSION);
    assert(!strncmp(output,hello,strlen(hello)));
    assert(!strstr(output,"SAME") && !strstr(output,"APP "));
    assert(!mon_running && !digital_dmr.owned && !analog_fm.owned);assert_saved();assert_no_rf();
    clear_uart();issue_app("APP SAME START");assert(strstr(output,"programming session active") && !same_running);
    cps_link=false;assert(normal_resume());tick(false);assert_restored();
}
static void test_stops(void) {
    setup(RADIO_CHANNEL_P25);start_same();
    mock_ptt_high=false;scripted_keys=ptt_mask;
    local_action(ACT_BACK,true);assert(!same_running && ptt_release_required);
    tick(true);assert(!call_active);assert_no_rf();
    for(unsigned i=0;i<60;++i)tick(false);
    assert(!ptt_release_required);assert_restored();start_same();
    host_input="\003";commands(false);host_input=NULL;
    assert_restored();assert(strstr(output,"APP STOPPED"));
}
static unsigned pcm_block;
static void feed_pcm(const int16_t *samples,unsigned count,bool poll) {
    unsigned half=1u+pcm_block++%2u;
    volatile uint8_t *destination=dev->buf+C7_FM_RX_AUDIO+(half-1u)*512u;
    for(unsigned i=0;i<RADIO_APP_AUDIO_SAMPLES;++i) {
        uint16_t value=i<count ? (uint16_t)samples[i] : 0;
        // The actual FM recorder exposes high byte first, unlike host PCM files.
        destination[2u*i]=(uint8_t)(value>>8);destination[2u*i+1u]=(uint8_t)value;
    }
    now+=32000u;regs[C7_FM_ADDR_SW/4]=half;regs[C7_SYS_INTERP_LIST/4]=1u<<14;
    size_t before=output_n;app_in_irq=true;isr_sys();app_in_irq=false;assert(output_n==before);
    if(poll)apps_poll();
}
static void fixture_feed(const char *path,bool flush) {
    FILE *stream=fopen(path,"rb");assert(stream);int16_t samples[RADIO_APP_AUDIO_SAMPLES];size_t n;
    while((n=fread(samples,sizeof samples[0],RADIO_APP_AUDIO_SAMPLES,stream))!=0)feed_pcm(samples,(unsigned)n,true);
    assert(!ferror(stream));fclose(stream);if(flush)drain_serial();
}
static void fixture(const char *path) {fixture_feed(path,true);}
static void test_waveform(const char *path) {
    setup(RADIO_CHANNEL_P25);start_same();clear_uart();fixture(path);
    assert(same_rx.protocol.headers==2u && same_rx.protocol.confirmations==1u);
    assert(same_rx.protocol.eoms==2u && same_rx.protocol.eom_confirmations==1u);
    assert(strstr(output,"SAME UNCONFIRMED ZCZC-WXR-RWT-018097+0030-3171200-KZZZ/NWS-"));
    assert(strstr(output,"SAME CONFIRMED ZCZC-WXR-RWT-018097+0030-3171200-KZZZ/NWS-"));
    assert(strstr(output,"SAME EOM CONFIRMED"));
    assert(!same_rx.audio.dropped && !same_rx.audio.gaps && same_samples>0);
    issue_app("APP SAME STATUS");assert(strstr(output,"SAME AUDIO blocks=") && strstr(output,"valid=2 confirmed=1"));
    assert_saved();assert_no_rf();issue_app("APP STOP");assert_restored();
}
static void test_gap(const char *path) {
    setup(RADIO_CHANNEL_DMR);start_same();int16_t silent[RADIO_APP_AUDIO_SAMPLES]={0};
    same_rx.demod.locked=1;same_rx.demod.byte_bits=5;
    same_protocol_feed_byte(&same_rx.protocol,0xabu,1);same_protocol_feed_byte(&same_rx.protocol,0xabu,2);
    for(unsigned i=0;i<RADIO_APP_AUDIO_BLOCKS+2u;++i)feed_pcm(silent,RADIO_APP_AUDIO_SAMPLES,false);
    assert(same_rx.audio.dropped>=1u && same_rx.audio.pending_gap);
    apps_poll();apps_poll();assert(same_running);
    // First block after loss owns the gap marker; queued pre-loss data cannot
    // be concatenated with the next burst to manufacture a SAME header.
    feed_pcm(silent,RADIO_APP_AUDIO_SAMPLES,true);
    assert(!same_rx.demod.locked && !same_rx.demod.byte_bits && !same_rx.protocol.headers);
    clear_uart();fixture(path);assert(same_rx.protocol.headers==2u && same_rx.protocol.confirmations==1u);
    assert(strstr(output,"SAME CONFIRMED "));assert_saved();assert_no_rf();
    issue_app("APP STOP");assert_restored();
}
static void test_timeout(void) {
    setup(RADIO_CHANNEL_FM);start_same();clear_uart();now+=1000001u;apps_poll();
    assert(strstr(output,"audio stalled"));assert_restored();
}
static void test_serial(const char *path) {
    setup(RADIO_CHANNEL_P25);start_same();clear_uart();
    // Even the complete-header callback only enqueues lines. No HAL write is
    // allowed while a decoder callback or SYS IRQ is on the call stack.
    const char *header="ZCZC-WXR-RWT-018097+0030-3171200-KZZZ/NWS-";
    unsigned before=app_write_calls;app_in_callback=true;
    for(unsigned i=0;i<16u;++i)apps_same_byte(NULL,0xabu);
    for(unsigned i=0;header[i];++i)apps_same_byte(NULL,(uint8_t)header[i]);
    app_in_callback=false;assert(app_write_calls==before && !output_n && same_rx.protocol.headers==1u);
    drain_serial();assert(strstr(output,"SAME UNCONFIRMED "));clear_uart();
    app_write_limit=0;apps_emit(NULL,"SAME ZERO-WRITE CONTROL");
    unsigned tail=same_rx.serial_tail;apps_output_flush();
    assert(same_rx.serial_tail==tail && !output_n);
    app_write_limit=7;app_write_max=0;drain_serial();
    assert(!strcmp(output,"SAME ZERO-WRITE CONTROL\r\n") && app_write_max<=48u);clear_uart();
    // Fill beyond the complete-line reservation capacity. Accepted entries
    // must emerge intact and in order despite 7-byte partial HAL writes.
    char line[202];memset(line,'X',200);line[200]=0;
    unsigned dropped=same_rx.serial_dropped;
    for(unsigned i=0;i<20u;++i)apps_emit(NULL,line);
    unsigned rejected=same_rx.serial_dropped-dropped;
    assert(rejected>0u && rejected<20u && !output_n);
    drain_serial();assert(output_n==(20u-rejected)*202u);
    for(unsigned position=0;position<output_n;position+=202u) {
        assert(!memcmp(output+position,line,200) && output[position+200u]=='\r' && output[position+201u]=='\n');
    }
    // A host that accepts no bytes must not stall the audio consumer or DSP.
    // Start with a saturated text queue and decode full RF-audio fixtures.
    clear_uart();app_write_limit=0;
    for(unsigned i=0;i<20u;++i)apps_emit(NULL,line);
    dropped=same_rx.serial_dropped;fixture_feed(path,false);
    assert(same_running && same_rx.protocol.headers==3u && same_rx.protocol.eoms==2u);
    assert(same_rx.serial_dropped>dropped && !output_n && same_rx.audio.head==same_rx.audio.tail);
    assert(!same_rx.audio.dropped && !same_rx.audio.gaps);
    app_write_limit=7;drain_serial();
    // Exercise a wrap after drain; every byte must still match the source.
    clear_uart();const char *wrapped="SAME queue wrap preserves complete lines";
    for(unsigned i=0;i<30u;++i) {apps_emit(NULL,wrapped);drain_serial();}
    size_t length=strlen(wrapped);
    assert(output_n==30u*(length+2u));
    for(unsigned i=0;i<30u;++i)assert(!memcmp(output+i*(length+2u),wrapped,length));
    app_write_limit=UINT32_MAX;assert_saved();assert_no_rf();issue_app("APP STOP");assert_restored();
}
static void test_serial_cps(void) {
    setup(RADIO_CHANNEL_DMR);start_same();clear_uart();
    apps_emit(NULL,"SAME INTERRUPTED HEADER TO DISCARD");
    app_write_limit=5;apps_output_flush();
    assert(!strcmp(output,"SAME ") && same_rx.serial_partial);
    // CPS resumes its normal full-write HAL contract after an app queue write
    // was partial. The queue tail is discarded, and CPS begins a fresh line.
    app_write_limit=UINT32_MAX;strcpy(command,"CPS HELLO");parse_command(false);
    assert(!same_running && cps_link && microapps.active==RADIO_MICROAPP_NONE);
    char hello[64];snprintf(hello,sizeof hello,"SAME \r\nCPS HELLO DM32P25 %u 256 2 ",P25_CS_VERSION);
    assert(!strncmp(output,hello,strlen(hello)));
    assert(!strstr(output,"INTERRUPTED") && !strstr(output,"TO DISCARD"));
    assert(!same_rx.serial_head && !same_rx.serial_tail && !same_rx.serial_partial);
    assert_saved();assert_no_rf();
}
static void test_invalid_halves(void) {
    setup(RADIO_CHANNEL_FM);start_same();clear_uart();
    uint32_t initial=same_last_pcm_us;unsigned iterations=0;
    while(same_running) {
        now+=32000u;regs[C7_FM_ADDR_SW/4]=iterations%2u ? 3u : 0u;
        regs[C7_SYS_INTERP_LIST/4]=1u<<14;
        size_t before=output_n;app_in_irq=true;isr_sys();app_in_irq=false;
        assert(output_n==before && same_last_pcm_us==initial);
        apps_poll();assert(++iterations<40u);
    }
    assert(iterations>=31u && strstr(output,"audio stalled"));assert_restored();
}
int main(int argc,char **argv) {
    assert(argc==3);
    if(!strcmp(argv[1],"p25"))test_mode(RADIO_CHANNEL_P25);
    else if(!strcmp(argv[1],"fm"))test_mode(RADIO_CHANNEL_FM);
    else if(!strcmp(argv[1],"dmr"))test_mode(RADIO_CHANNEL_DMR);
    else if(!strcmp(argv[1],"guards"))test_guards();
    else if(!strcmp(argv[1],"failed"))test_failed();
    else if(!strcmp(argv[1],"cps"))test_cps();
    else if(!strcmp(argv[1],"stops"))test_stops();
    else if(!strcmp(argv[1],"waveform"))test_waveform(argv[2]);
    else if(!strcmp(argv[1],"gap"))test_gap(argv[2]);
    else if(!strcmp(argv[1],"timeout"))test_timeout();
    else if(!strcmp(argv[1],"serial"))test_serial(argv[2]);
    else if(!strcmp(argv[1],"serial-cps"))test_serial_cps();
    else if(!strcmp(argv[1],"invalid-halves"))test_invalid_halves();else assert(0);
    printf("microapps adapter %s: PASS\n",argv[1]);return 0;
}
'''


if __name__=='__main__':unittest.main(verbosity=2)
