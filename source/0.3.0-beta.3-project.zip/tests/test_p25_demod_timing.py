# SPDX-License-Identifier: GPL-3.0-or-later
"""Sample-origin status timing through real demod/FEC, using pinned OP25 C4FM.

No radio or CPU/task timestamp anchor. Run with numpy and GCC available.
"""
import ast
import ctypes as C
import hashlib
import importlib.util
import math
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build/test-p25-demod-timing'
BUILD.mkdir(parents=True, exist_ok=True)
REF = ROOT / 'external/boatbod/op25/op25/gr-op25_repeater/apps/tx'
PINS = {'p25craft.py': '27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9',
        'op25_c4fm_mod.py': 'b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef'}


def pinned(name):
    data = (REF/name).read_bytes().replace(b'\r\n', b'\n')
    assert hashlib.sha256(data).hexdigest() == PINS[name], name
    return data


pinned('p25craft.py')
spec = importlib.util.spec_from_file_location('timing_op25', REF/'p25craft.py')
op = importlib.util.module_from_spec(spec)
old_cwd = Path.cwd()
os.chdir(BUILD)
try:
    spec.loader.exec_module(op)
finally:
    os.chdir(old_cwd)
op.outfile.close()
op.text_out = lambda *_: None
generated = []
op.print_spec = lambda dibits: generated.append(list(dibits))
tree = ast.parse(pinned('op25_c4fm_mod.py'))
nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
         and n.name in {'transfer_function_tx', 'c4fm_taps'}]
assert len(nodes) == 2
scope = dict(np=np, pi=math.pi, sin=math.sin, cos=math.cos,
             _def_symbol_rate=4800, _def_output_sample_rate=48000, _def_span=13)
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'pinned-op25-c4fm', 'exec'), scope)
taps = scope['c4fm_taps']().generate()
assert len(taps) % 2 == 1
assert np.allclose(taps, taps[::-1], atol=1e-13)
tx_delay = (len(taps)-1)//2


def wire(status=3, bad_nid=False, bad_crc=False, parity_error=False):
    generated.clear()
    op.construct_tsdu3(0x293, 2, 1, 0, [0x3b], [0x000abcde12300001])
    dibits = generated[0]
    assert len(dibits) == 180
    if bad_crc:
        block = op.construct_tsbk(1, 0, 0x3b, 0, 0x000abcde12300001) ^ 1
        encoded = op.data_interleave(op.trellis_1_2_encode(op.split_dibits(block, 48)))
        for i, value in enumerate(encoded):
            logical = 56+i
            dibits[logical+logical//35] = value
    for index in range(35, 180, 36):
        dibits[index] = status if index == 35 else 2
    if bad_nid:
        dibits[24] ^= 3
        dibits[25] ^= 3
        dibits[56] ^= 1  # four BCH errors plus parity exceed the SAME total4 budget.
    elif parity_error:
        dibits[56] ^= 1  # one counted correction, without altering status timing.
    return bytes(sum(dibits[i+j] << (6-2*j) for j in range(4))
                 for i in range(0, 180, 4))


library = BUILD/('timing.dll' if sys.platform == 'win32' else 'timing.so')
cmd = ['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wshadow', '-shared']
if sys.platform != 'win32':
    cmd += ['-fPIC']
cmd += ['-Isrc/firmware', 'tests/test_p25_demod_timing.c', 'src/firmware/p25_rx.c',
        'src/firmware/p25_tsdu.c', 'src/firmware/p25_trunking_slot.c', '-o', str(library)]
subprocess.run(cmd, cwd=ROOT, check=True, timeout=120)
lib = C.CDLL(str(library))
U8 = C.c_uint8
U32 = C.c_uint
U64 = C.c_uint64
lib.p25_timing_unit.argtypes = [C.POINTER(U8), U32]
lib.p25_timing_unit.restype = U32
lib.p25_timing_run.argtypes = [C.POINTER(C.c_int16), U32, U64, U32, U32,
                             C.POINTER(U64), U32, C.POINTER(U32)]
lib.p25_timing_run.restype = U32
clean = wire()
state_bytes = lib.p25_timing_unit((U8*len(clean)).from_buffer_copy(clean), len(clean))
LEAD_DIBITS = 72*4
ORIGIN = 1000000


def waveform(frames, phase=0, polarity=1):
    air = b'\x77'*72 + b''.join(frames)
    dibits = np.array([(v >> shift) & 3 for v in air for shift in (6, 4, 2, 0)])
    impulses = np.zeros(len(dibits)*10)
    impulses[::10] = np.array([1, 3, -1, -3])[dibits]
    high = np.convolve(impulses, taps)*60000*polarity
    pcm = np.clip(np.rint(high[phase::6]), -32768, 32767).astype(np.int16)
    return np.concatenate((pcm, np.zeros(32, dtype=np.int16)))


def run(pcm, phase=0, mode=1, change_at=0):
    records = (U64*(7*256))()
    stats = (U32*6)()
    count = lib.p25_timing_run(pcm.ctypes.data_as(C.POINTER(C.c_int16)), len(pcm),
                              ORIGIN+phase, mode, change_at, records, 256, stats)
    assert count <= 256
    events = [tuple(records[i*7:(i+1)*7]) for i in range(count)]
    return events, tuple(stats)


def qualified(events):
    return [e for e in events if e[6] & 3 == 3 and e[4] > 0]


expected = [(ORIGIN+(LEAD_DIBITS+180*frame+pos)*10+tx_delay+5,
             3 if pos == 35 else 2)
            for frame in range(1, 12) for pos in range(35, 180, 36)]
for phase in range(6):
    for polarity in (1, -1):
        pcm = waveform([clean]*12, phase, polarity)
        events, stats = run(pcm, phase)
        conventional_events, conventional = run(pcm, phase, mode=0)
        assert stats[:2] == conventional[:2] and stats[0] == 12, (phase, polarity, stats)
        assert not conventional_events
        observed = qualified(events)
        assert len(observed) == len(expected), (phase, polarity, len(observed))
        for actual, (tick, status) in zip(observed, expected):
            assert actual[3] == 0x293 and actual[4] == status and actual[6] >> 8 == 7
            assert actual[1] == 11 and actual[2] == observed[0][2]
            assert abs(actual[0]-tick) <= 3, (phase, polarity, actual, tick)
        assert stats[2] == 0 and stats[4] > 0
print('PASS: 12 OP25 phase/polarity cases, exact conventional CAI parity, 55 sample-timed statuses each, <=3-tick waveform-origin residual')

pcm = waveform([clean]*12)
change_at = (LEAD_DIBITS*10+6*1800+tx_delay)//6
for mode in (2, 3):
    events, stats = run(pcm, mode=mode, change_at=change_at)
    assert stats[2] == 1, (mode, stats)
    assert any(not e[6] & 2 and e[4] == 0 for e in events)
    later = [e for e in qualified(events) if e[0] > ORIGIN+change_at*6]
    earlier = [e for e in qualified(events) if e[0] < ORIGIN+change_at*6]
    assert earlier and later and later[0][2] > earlier[-1][2]
    assert all(e[1] == (12 if mode == 3 else 11) for e in later)
print('PASS: sample omission and stream-epoch retune revoke phase, flush partial units and reacquire with a new lane epoch')

events, stats = run(waveform([clean]*6+[wire(parity_error=True)]+[clean]*5))
assert stats[0] == 12 and stats[4] > 0, stats
assert len(set(e[2] for e in qualified(events))) == 1
for bad in (wire(bad_nid=True), wire(bad_crc=True)):
    events, stats = run(waveform([clean]*6+[bad]+[clean]*5))
    assert stats[0] == 11 and stats[4] > 0, stats
    low = ORIGIN+(LEAD_DIBITS+6*180)*10+tx_delay
    high = low+1800
    assert any(low <= e[0] <= high and e[4] == 0 and not e[6] & 2 for e in events)
    assert len(set(e[2] for e in qualified(events))) > 1
for status in (0, 1):
    events, stats = run(waveform([wire(status=status)]*12))
    assert stats[0] == 12 and stats[4] == 0
    assert any(e[4] == status for e in events)
events, stats = run(waveform([clean]))
assert stats[0] == 1 and not qualified(events), 'No timing authority from an unselected first frame'
print(f'PASS: counted parity recovery preserves first-status timing; excess NID errors/CRC loss, busy/unknown rejection, no first-frame timing authority; demod state {state_bytes} bytes')
