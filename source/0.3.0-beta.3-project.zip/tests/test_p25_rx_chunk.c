// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx_progress.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

static unsigned checks;
#define CHECK(x) do {++checks;assert(x);} while(0)
typedef struct {
    p25_rx_chunk state;
    unsigned char bytes[P25_RX_CHUNK_STORAGE_BYTES+2],ram[1024];
    uint32_t now,duration;
    unsigned reads,clocks,irq_at,mutate_at,mutation_offset,max_reads;
    bool mutate_high,pending;
    unsigned pending_after_reads;
} fixture;
static void sample(fixture *f,unsigned half,unsigned index,unsigned value) {
    unsigned offset=(half-1u)*512u+index*2u;f->ram[offset]=(unsigned char)(value>>8);f->ram[offset+1]=(unsigned char)value;
}
static void prefix(fixture *f,unsigned half,unsigned count,unsigned generation) {
    for(unsigned i=0;i<count;++i)sample(f,half,i,generation+i);
}
static uint8_t byte_read(void *context,unsigned offset) {
    fixture *f=context;CHECK(offset<1024u);++f->reads;
    if(f->reads==f->mutate_at) {
        if(f->mutate_high)f->ram[f->mutation_offset]^=1u;
        else {f->ram[f->mutation_offset]=0x12;f->ram[f->mutation_offset+1u]=0x34;}
    }
    if(f->reads==f->irq_at)CHECK(p25_rx_chunk_irq(&f->state,3u-f->state.base.completed_half,f->now+1u));
    return f->ram[offset];
}
static uint32_t clock_read(void *context) {fixture *f=context;return f->now+((f->clocks++&1u) ? f->duration : 0u);}
static bool half_pending(void *context) {
    fixture *f=context;return f->pending || (f->pending_after_reads && f->reads>=f->pending_after_reads);
}
static bool poll(fixture *f,uint32_t now) {
    f->now=now;unsigned before=f->reads;
    p25_rx_progress_io io={f,byte_read,clock_read,half_pending};bool result=p25_rx_chunk_poll(&f->state,&io,now);
    unsigned count=f->reads-before;CHECK(count<=96u);if(count>f->max_reads)f->max_reads=count;return result;
}
static void setup(fixture *f,unsigned rows,unsigned guard,uint32_t start) {
    memset(f,0,sizeof *f);memset(f->bytes,0xa5,sizeof f->bytes);
    prefix(f,1,256,1000);prefix(f,2,256,2000);
    p25_rx_chunk_config c={(uint16_t)rows,(uint16_t)guard};
    CHECK(p25_rx_chunk_start(&f->state,f->bytes+1,sizeof f->bytes-2,&c,start));
}
static void complete(fixture *f,uint32_t time,unsigned generation) {
    prefix(f,2,256,generation);CHECK(p25_rx_chunk_irq(&f->state,2,time));CHECK(poll(f,time));
}
static p25_rx_chunk_row row(fixture *f,unsigned index) {
    p25_rx_chunk_row result;CHECK(p25_rx_chunk_read(&f->state,index,&result));return result;
}
static void refusal_and_ownership(void) {
    fixture f;memset(&f,0,sizeof f);p25_rx_chunk original=f.state;
    p25_rx_chunk_config c={1,0};
    CHECK(!p25_rx_chunk_start(NULL,f.bytes,sizeof f.bytes,&c,0));
    CHECK(!p25_rx_chunk_start(&f.state,NULL,sizeof f.bytes,&c,0));
    CHECK(!p25_rx_chunk_start(&f.state,f.bytes,sizeof f.bytes,NULL,0));
    for(unsigned failure=0;failure<6;++failure) {
        p25_rx_chunk_config invalid=c;void *storage=f.bytes;size_t bytes=sizeof f.bytes;
        if(failure==0)invalid.rows=0;
        if(failure==1)invalid.rows=97;
        if(failure==2)invalid.guard_us=16001;
        if(failure==3)bytes=143;
        if(failure==4)storage=&f.state;
        if(failure==5)storage=(unsigned char *)&f.state+sizeof f.state-1u;
        CHECK(!p25_rx_chunk_start(&f.state,storage,bytes,&invalid,0));CHECK(!memcmp(&f.state,&original,sizeof original));
    }
    setup(&f,1,2000,0);original=f.state;
    CHECK(!p25_rx_chunk_start(&f.state,f.bytes,sizeof f.bytes,&c,0));CHECK(!memcmp(&f.state,&original,sizeof original));
    CHECK(!poll(&f,100) && !f.reads && !f.clocks);
    CHECK(!p25_rx_chunk_irq(&f.state,0,100));CHECK(f.state.base.invalid_irqs==1 && !f.reads);
    p25_rx_chunk_cancel(&f.state);CHECK(f.state.base.state==P25_RX_PROGRESS_CANCELLED);
    CHECK(!poll(&f,200) && !f.reads && !f.clocks);
}
static void progressive_writer_and_stale_equality(void) {
    const unsigned guards[]={0,1000,2000,4000};
    for(unsigned g=0;g<sizeof guards/sizeof *guards;++g) {
        fixture f;setup(&f,1,guards[g],0);CHECK(p25_rx_chunk_irq(&f.state,1,100));
        CHECK(!poll(&f,2099u+guards[g]));
        // Simulated writer lags the nominal clock by2ms. Equal double reads of
        // stale bytes must fail later comparison rather than imply readiness.
        prefix(&f,2,guards[g]/125u,4000);
        CHECK(poll(&f,2100u+guards[g]));CHECK(f.reads==96u && f.state.base.count==1u);
        CHECK(p25_rx_chunk_active(&f.state));
        p25_rx_chunk_row blocked;memset(&blocked,0x5a,sizeof blocked);p25_rx_chunk_row old=blocked;
        CHECK(!p25_rx_chunk_read(&f.state,0,&blocked) && !memcmp(&blocked,&old,sizeof old));
        CHECK(!poll(&f,10000) && f.reads==96u); // Candidate limit drains, never silently finishes.
        complete(&f,32100,4000);CHECK(f.reads==144 && f.state.base.state==P25_RX_PROGRESS_DONE);
        p25_rx_chunk_row out=row(&f,0);
        CHECK(out.target_half==2 && out.sample_offset==0 && out.origin_irq_count==1 && out.completion_irq_count==2);
        CHECK(out.origin_irq_us==100 && out.completion_irq_us==32100 && out.cpu_begin_us==2100+guards[g]);
        CHECK(!out.changed_mask && !out.torn_mask && !out.completed_torn_mask && f.state.compared==1);
        if(guards[g]<2000)CHECK(out.mismatch_mask && (out.flags&P25_RX_CHUNK_MISMATCH) && f.state.mismatches==1);
        else CHECK(!out.mismatch_mask && out.flags==P25_RX_CHUNK_COMPARED && !f.state.mismatches);
        for(unsigned i=0;i<16;++i)CHECK(out.completed[i]==4000+(int)i);
        CHECK(f.bytes[0]==0xa5 && f.bytes[145]==0xa5);
        const unsigned char *wire=f.bytes+1;
        CHECK(wire[120]==1 && wire[124]==2 && wire[140]==2 && !wire[141] && !wire[142] && !wire[143]);
    }
}
static void mutations_and_epoch_races(void) {
    for(unsigned mode=0;mode<8;++mode) {
        fixture f;setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));prefix(&f,2,256,4000);
        if(mode==0) {f.mutate_at=49;f.mutation_offset=512;}
        if(mode==1) {f.mutate_at=2;f.mutation_offset=512;f.mutate_high=true;}
        if(mode==2)f.irq_at=24;
        if(mode==3)f.state.base.irq_serial|=1u;
        if(mode==4)CHECK(p25_rx_chunk_irq(&f.state,1,101));
        CHECK(poll(&f,4101));
        if(mode!=2)CHECK(p25_rx_chunk_irq(&f.state,2,32100));
        if(mode==5)f.irq_at=f.reads+24u;
        if(mode==6) {f.mutate_at=f.reads+2u;f.mutation_offset=512;f.mutate_high=true;}
        if(mode==7) {f.state.base.irq_serial|=1u;}
        CHECK(poll(&f,32101));CHECK(!p25_rx_chunk_active(&f.state));p25_rx_chunk_row out=row(&f,0);
        if(mode==0)CHECK(out.changed_mask==1 && (out.flags&P25_RX_CHUNK_VALUES_CHANGED));
        if(mode==1)CHECK(out.torn_mask==1 && (out.flags&P25_RX_CHUNK_WORD_TORN));
        if(mode==2)CHECK(out.flags&P25_RX_CHUNK_IRQ_DURING_READ);
        if(mode==3)CHECK(out.flags&P25_RX_CHUNK_META_UNSTABLE);
        if(mode==4)CHECK(out.flags&P25_RX_CHUNK_IRQ_SEQUENCE);
        if(mode==5)CHECK((out.flags&P25_RX_CHUNK_COMPARE_IRQ_DURING_READ) && (out.flags&P25_RX_CHUNK_OVERWRITTEN));
        if(mode==6)CHECK(out.completed_torn_mask==1 && (out.flags&P25_RX_CHUNK_COMPARE_WORD_TORN));
        if(mode==7)CHECK(out.flags&P25_RX_CHUNK_COMPARE_META_UNSTABLE);
    }
}
static void overwrite_timeout_and_wrap(void) {
    fixture f;setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));CHECK(p25_rx_chunk_irq(&f.state,1,64100));
    unsigned reads=f.reads;CHECK(poll(&f,64100));CHECK(f.reads==reads && !f.state.compared);
    CHECK(row(&f,0).flags==(P25_RX_CHUNK_OVERWRITTEN|P25_RX_CHUNK_UNPAIRED));
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));reads=f.reads;
    CHECK(poll(&f,64100));CHECK(f.reads==reads && (row(&f,0).flags&P25_RX_CHUNK_OVERWRITTEN));
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(!poll(&f,2000000) && f.state.base.state==P25_RX_PROGRESS_TIMEOUT);CHECK(row(&f,0).flags&P25_RX_CHUNK_UNPAIRED);
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(!p25_rx_chunk_irq(&f.state,2,2000000)); // ISR cannot touch row storage.
    CHECK(!(f.bytes[139]&8u));CHECK(!poll(&f,2000000));CHECK(row(&f,0).flags&P25_RX_CHUNK_UNPAIRED);
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    p25_rx_chunk_cancel(&f.state);CHECK(row(&f,0).flags&P25_RX_CHUNK_UNPAIRED);
    setup(&f,1,2000,UINT32_MAX-10000u);CHECK(p25_rx_chunk_irq(&f.state,1,UINT32_MAX-9000u));
    CHECK(poll(&f,UINT32_MAX-5000u));CHECK(p25_rx_chunk_irq(&f.state,2,22999));CHECK(poll(&f,22999));
    CHECK(row(&f,0).flags==P25_RX_CHUNK_COMPARED);
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(!poll(&f,4099) && f.state.base.state==P25_RX_PROGRESS_CLOCK_ERROR);CHECK(row(&f,0).flags&P25_RX_CHUNK_UNPAIRED);
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));f.duration=UINT32_MAX;
    CHECK(poll(&f,4100) && f.state.base.state==P25_RX_PROGRESS_CLOCK_ERROR);
    CHECK((row(&f,0).flags&P25_RX_CHUNK_CLOCK_ANOMALY) && (row(&f,0).flags&P25_RX_CHUNK_UNPAIRED));
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));f.duration=UINT32_MAX;
    CHECK(poll(&f,32100) && f.state.base.state==P25_RX_PROGRESS_CLOCK_ERROR);
    CHECK((row(&f,0).flags&P25_RX_CHUNK_CLOCK_ANOMALY) && (row(&f,0).flags&P25_RX_CHUNK_OVERWRITTEN));
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));f.duration=32000;
    CHECK(poll(&f,32100) && (row(&f,0).flags&P25_RX_CHUNK_OVERWRITTEN));
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));f.duration=2000000u-32100u;
    CHECK(poll(&f,32100) && f.state.base.state==P25_RX_PROGRESS_TIMEOUT);
    CHECK(row(&f,0).flags&P25_RX_CHUNK_UNPAIRED); // Completion cannot overwrite a timeout with DONE.
}
static void skips_bounds_and_full_capture(void) {
    fixture f;setup(&f,96,2000,0);uint32_t time=100;
    for(unsigned cycle=0;cycle<20 && p25_rx_chunk_active(&f.state);++cycle) {
        unsigned half=(cycle&1u)+1u;CHECK(p25_rx_chunk_irq(&f.state,half,time));
        // Drain previous half without a catch-up sample-read loop in the core.
        while(f.state.next_verify<f.state.base.count)CHECK(poll(&f,time));
        for(unsigned step=4000;step<32000 && p25_rx_chunk_active(&f.state);step+=2000) {
            unsigned target=3u-half;prefix(&f,target,step/125u,3000+cycle*1000);
            (void)poll(&f,time+step);
        }
        time+=32000;
    }
    CHECK(f.state.base.state==P25_RX_PROGRESS_DONE && f.state.base.count==96 && f.state.compared==96);
    CHECK(f.bytes[0]==0xa5 && f.bytes[P25_RX_CHUNK_STORAGE_BYTES+1]==0xa5 && f.max_reads==96);
    for(unsigned i=0;i<96;++i)CHECK((row(&f,i).flags&P25_RX_CHUNK_COMPARED) && row(&f,i).sample_offset<=240);
    setup(&f,2,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,10100));
    CHECK(f.state.skipped_chunks==3 && f.state.next_sample==64 && f.state.base.count==1);
    CHECK(!poll(&f,10100) && f.state.base.count==1);p25_rx_chunk_cancel(&f.state);
    CHECK(row(&f,0).sample_offset==48);
}
static void bounded_isr_step_and_pending_halves(void) {
    fixture f;setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));f.pending=true;
    CHECK(!poll(&f,4100) && !f.reads && !f.state.base.count);f.pending=false;
    f.pending_after_reads=96;CHECK(poll(&f,4100));f.pending_after_reads=0;
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));CHECK(poll(&f,32100));
    CHECK(row(&f,0).flags&P25_RX_CHUNK_IRQ_DURING_READ);
    setup(&f,1,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));CHECK(poll(&f,4100));
    CHECK(p25_rx_chunk_irq(&f.state,2,32100));f.pending=true;CHECK(!poll(&f,32100) && f.reads==96);
    f.pending=false;f.pending_after_reads=144;CHECK(poll(&f,32100));
    CHECK((row(&f,0).flags&P25_RX_CHUNK_COMPARE_IRQ_DURING_READ) && (row(&f,0).flags&P25_RX_CHUNK_OVERWRITTEN));
    // Inject a maximum pending trace to exercise the ISR/task boundary under
    // the full storage bound. A terminal step may change state, never96rows.
    setup(&f,96,2000,0);CHECK(p25_rx_chunk_irq(&f.state,1,100));
    memset(f.bytes+1,0,P25_RX_CHUNK_STORAGE_BYTES);f.state.base.count=96;
    f.now=2000000;p25_rx_progress_io io={&f,byte_read,clock_read,half_pending};
    CHECK(!p25_rx_chunk_step(&f.state,&io,f.now) && f.state.base.state==P25_RX_PROGRESS_TIMEOUT);
    CHECK(!f.state.finalized && !f.reads && !f.clocks);
    for(unsigned i=0;i<P25_RX_CHUNK_STORAGE_BYTES;++i)CHECK(f.bytes[i+1u]==0);
    CHECK(!p25_rx_chunk_poll(&f.state,NULL,f.now) && f.state.finalized);
    for(unsigned i=0;i<96;++i)CHECK(row(&f,i).flags==P25_RX_CHUNK_UNPAIRED);
}
int main(void) {
    CHECK(sizeof(p25_rx_chunk_row)==144 && sizeof(p25_rx_chunk)<=160);
    refusal_and_ownership();progressive_writer_and_stale_equality();mutations_and_epoch_races();
    overwrite_timeout_and_wrap();skips_bounds_and_full_capture();bounded_isr_step_and_pending_halves();
    printf("RX early contiguous chunks: PASS (%u checks; state %uB; rows %uB; storage %uB)\n",
        checks,(unsigned)sizeof(p25_rx_chunk),(unsigned)sizeof(p25_rx_chunk_row),(unsigned)P25_RX_CHUNK_STORAGE_BYTES);
    return 0;
}
