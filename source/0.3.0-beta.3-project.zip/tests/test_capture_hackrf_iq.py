"""No hardware: native ABI, signed data, finite counts and cleanup on failures."""
import ast
import contextlib
import ctypes as C
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('hackrf_recorder', ROOT/'scripts/capture-hackrf-iq.py')
TOOL = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(TOOL)


class Function:
    def __init__(self, lib, name, call): self.lib, self.name, self.call = lib, name, call
    def __call__(self, *args):
        self.lib.calls.append(self.name)
        if self.name in self.lib.errors: return self.lib.errors[self.name]
        return self.call(*args)


class Native:
    def __init__(self, *, api=0x108, packets=None, shortfalls=0, pre_shortfalls=0, stall=False, stall_error=0):
        self.calls, self.errors, self.api, self.shortfalls, self.stall = [], {}, api, shortfalls, stall
        self.settings = {}
        self.packets = [b'\x80\xff\0\x7f\x81\xfe\1\x7e'] if packets is None else list(packets)
        self.started = self.stopped = False
        self.pre_shortfalls, self.inside_callback = pre_shortfalls, False
        self.stall_error = stall_error
        self.serials = (C.c_char_p*1)(b'00000001000000020000000300000004')
        self.listing = TOOL.DeviceList(self.serials, None, None, 1, None, 1)
        def assign(pointer, kind, value): C.cast(pointer, C.POINTER(kind))[0] = value; return 0
        def open_device(listing, index, pointer): return assign(pointer, C.c_void_p, C.c_void_p(1234))
        def version(device, buffer, size):
            for i, value in enumerate(b'v1.9.1'): buffer[i] = bytes((value,))
            return 0
        def parts(device, pointer):
            target = C.cast(pointer, C.POINTER(TOOL.PartSerial)).contents
            target.part_id[:] = [5, 6]; target.serial_no[:] = [1, 2, 3, 4]
            return 0
        def m0(device, pointer):
            if self.stopped and 'post_m0' in self.errors: return self.errors['post_m0']
            target = C.cast(pointer, C.POINTER(TOOL.M0State)).contents
            target.num_shortfalls = self.shortfalls if self.stopped else self.pre_shortfalls
            target.m0_count = target.m4_count = 8 if self.stopped else 0
            target.error = self.stall_error if self.started else 0
            return 0
        def start(device, callback, context):
            self.callback, self.context, self.started = callback, context, True
            return 0
        def streaming(device):
            if self.packets:
                data = self.packets.pop(0)
                buffer = (C.c_uint8*len(data)).from_buffer_copy(data)
                transfer = TOOL.Transfer(C.c_void_p(1234), buffer, len(data), len(data), self.context, None)
                self.inside_callback = True
                try: result = self.callback(C.pointer(transfer))
                finally: self.inside_callback = False
                return -1003 if result else 1
            return 1 if self.stall else -1002
        def stop(device): self.stopped = True; return 0
        functions = dict(hackrf_init=lambda: 0, hackrf_exit=lambda: 0,
            hackrf_library_version=lambda: b'local-test', hackrf_library_release=lambda: b'test-release',
            hackrf_device_list=lambda: C.pointer(self.listing), hackrf_device_list_free=lambda value: None,
            hackrf_device_list_open=open_device, hackrf_close=lambda dev: 0,
            hackrf_board_id_read=lambda dev, ptr: assign(ptr, C.c_uint8, 2),
            hackrf_board_id_name=lambda value: b'HackRF One', hackrf_board_partid_serialno_read=parts,
            hackrf_version_string_read=version,
            hackrf_usb_api_version_read=lambda dev, ptr: assign(ptr, C.c_uint16, self.api),
            hackrf_start_rx=start, hackrf_is_streaming=streaming, hackrf_stop_rx=stop,
            hackrf_get_m0_state=m0, hackrf_set_rx_overrun_limit=lambda dev, limit: 0)
        for name in ('sample_rate', 'freq', 'baseband_filter_bandwidth', 'lna_gain', 'vga_gain', 'amp_enable', 'antenna_enable'):
            def setting(device, value, key=name): self.settings[key] = value; return 0
            functions['hackrf_set_'+name] = setting
        for name, call in functions.items(): setattr(self, name, Function(self, name, call))


class Clock:
    def __init__(self): self.now = 100
    def __call__(self): return self.now
    def sleep(self, seconds): self.now += seconds


class NativeCollectorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.native, cls.metadata = TOOL.load_buffer_library()

    def setUp(self):
        self.storage = (C.c_uint8*48)(*([0xA5]*48))
        self.destination = C.cast(C.byref(self.storage, 8), C.POINTER(C.c_uint8))
        self.context = self.native.hrx_create(self.destination, 16, 4)
        self.assertTrue(self.context)

    def tearDown(self): self.native.hrx_destroy(self.context)

    def stats(self):
        result = TOOL.BufferStats()
        self.assertEqual(self.native.hrx_snapshot(self.context, C.byref(result)), 0)
        return result

    def deliver(self, data, *, valid=None, capacity=None, null=False):
        buffer = (C.c_uint8*len(data)).from_buffer_copy(data)
        transfer = TOOL.Transfer(None, None if null else buffer,
            len(data) if capacity is None else capacity, len(data) if valid is None else valid,
            self.context, None)
        return self.native.hrx_callback(C.pointer(transfer))

    def test_compiled_abi_and_snapshot_arguments(self):
        self.assertEqual(self.native.hrx_transfer_size(), C.sizeof(TOOL.Transfer))
        self.assertEqual(self.native.hrx_stats_size(), C.sizeof(TOOL.BufferStats))
        self.assertEqual(self.native.hrx_snapshot(None, C.byref(TOOL.BufferStats())), -1)
        self.assertEqual(self.native.hrx_snapshot(self.context, None), -1)

    def test_native_discard_trim_and_canaries(self):
        self.assertEqual(self.deliver(bytes(range(8))), 0)
        self.assertEqual(self.deliver(bytes(range(8, 32))), 1)
        self.assertEqual(bytes(self.storage[:8]), b'\xa5'*8)
        self.assertEqual(bytes(self.storage[8:24]), bytes(range(4, 20)))
        self.assertEqual(bytes(self.storage[24:]), b'\xa5'*24)
        stats = self.stats()
        self.assertEqual((stats.callbacks, stats.callback_bytes, stats.copied_bytes, stats.discarded_bytes), (2, 32, 16, 4))
        self.assertEqual((stats.done, stats.fault, stats.size_count), (1, 0, 2))
        self.assertEqual(self.deliver(bytes(range(16))), 1)
        self.assertEqual(self.stats().callbacks, 2)

    def test_allocation_bounds_rejected_before_use(self):
        for capacity, discard in ((0, 0), (3, 0), (576_000_002, 0), (2, 3), (2, 4_800_002)):
            with self.subTest(capacity=capacity, discard=discard):
                self.assertFalse(self.native.hrx_create(self.destination, capacity, discard))
        self.assertFalse(self.native.hrx_create(None, 2, 0))

    def test_callback_bounds_and_null_context_are_contained_without_writes(self):
        for options in ({'valid': 0}, {'valid': -2}, {'valid': 3}, {'valid': 10},
                        {'capacity': 4*1024*1024+1}, {'null': True}):
            self.native.hrx_destroy(self.context)
            self.context = self.native.hrx_create(self.destination, 16, 4)
            with self.subTest(options=options):
                self.assertEqual(self.deliver(b'abcdefgh', **options), 1)
                self.assertEqual(self.stats().fault, 1)
                self.assertEqual(self.stats().copied_bytes, 0)
                self.assertEqual(bytes(self.storage), b'\xa5'*48)
        self.assertEqual(self.native.hrx_callback(None), 1)
        self.assertEqual(self.native.hrx_callback(C.byref(TOOL.Transfer())), 1)

    def test_callback_size_histogram_is_bounded(self):
        self.native.hrx_destroy(self.context)
        storage = (C.c_uint8*8192)()
        self.context = self.native.hrx_create(storage, len(storage), 0)
        for length in range(2, 66, 2): self.assertEqual(self.deliver(b'x'*length), 0)
        self.assertEqual(self.deliver(b'x'*66), 1)
        stats = self.stats()
        self.assertEqual((stats.fault, stats.size_count, stats.callbacks), (2, 32, 32))
        self.assertEqual(list(stats.sizes), list(range(2, 66, 2)))
        self.assertEqual(list(stats.counts), [1]*32)


class RecorderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.collector, cls.collector_meta = TOOL.load_buffer_library()

    def run_capture(self, lib, *, probe=False, discard=0, count=4, event=lambda row: None, profile=None):
        record = {}; clock = Clock()
        args = types.SimpleNamespace(serial=None, probe=probe, seconds=count/TOOL.RATE, lna=0, vga=0)
        if profile is not None: args.profile = profile
        with patch.object(TOOL, 'DISCARD_SECONDS', discard), \
                patch.object(TOOL, 'load_buffer_library', return_value=(self.collector, self.collector_meta)):
            storage = TOOL.capture(lib, args, record, clock=clock, sleep=clock.sleep, event=event)
        return storage, record, clock

    def test_ctypes_abi_layout_and_all_pointer_return_types(self):
        ptr = C.sizeof(C.c_void_p)
        self.assertEqual(C.sizeof(TOOL.Transfer), 40 if ptr == 8 else 24)
        self.assertEqual(TOOL.Transfer.valid_length.offset, 2*ptr+4)
        self.assertEqual(TOOL.Transfer.rx_ctx.offset, 24 if ptr == 8 else 16)
        self.assertEqual(C.sizeof(TOOL.DeviceList), 48 if ptr == 8 else 24)
        self.assertEqual(C.sizeof(TOOL.PartSerial), 24)
        self.assertEqual(C.sizeof(TOOL.M0State), 40)
        self.assertEqual(TOOL.M0State.num_shortfalls.offset, 16)
        lib = Native(); TOOL.configure_library(lib)
        self.assertEqual(lib.hackrf_device_list.restype, C.POINTER(TOOL.DeviceList))
        self.assertEqual(lib.hackrf_start_rx.argtypes, [C.c_void_p, TOOL.CALLBACK, C.c_void_p])
        self.assertEqual(lib.hackrf_set_freq.argtypes, [C.c_void_p, C.c_uint64])
        self.assertEqual(lib.hackrf_get_m0_state.argtypes, [C.c_void_p, C.POINTER(TOOL.M0State)])
        self.assertIsNone(lib.hackrf_device_list_free.restype)

    def test_default_plan_never_loads_a_library_or_allocates_capture_memory(self):
        with patch.object(TOOL.C, 'CDLL', side_effect=AssertionError('No native load')), \
                patch.object(TOOL, 'capture', side_effect=AssertionError('No capture')), \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(TOOL.main(['--seconds', '30', '--library', '/nonexistent']), 0)
        value = json.loads(output.getvalue())
        self.assertEqual(value['requested_memory_bytes'], 576_000_000)
        self.assertEqual(value['format'], 'cs8')
        self.assertTrue(value['dry_run']); self.assertFalse(value['receive_started'])
        self.assertEqual((value['capture_profile'], value['center_hz']), ('hackrf-legacy5m', 442575000))

    def test_offset_profile_plan_and_native_readiness_use_exact_fixed_center(self):
        with patch.object(TOOL.C, 'CDLL', side_effect=AssertionError('No native load')), \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(TOOL.main(['--profile', 'hackrf-legacy5m-offset']), 0)
        value = json.loads(output.getvalue())
        self.assertEqual(value['capture_profile'], 'hackrf-legacy5m-offset')
        self.assertEqual(value['center_hz'], 442325000)
        self.assertEqual(value['requested_settings']['center_hz'], 442325000)
        self.assertEqual(value['sample_rate'], 9600000)
        lib, events = Native(), []
        _, record, _ = self.run_capture(lib, profile='hackrf-legacy5m-offset', event=events.append)
        self.assertTrue(record['complete'])
        self.assertEqual(lib.settings['freq'], 442325000)
        self.assertEqual(events[0]['capture_profile'], value['capture_profile'])
        self.assertEqual(events[0]['center_hz'], value['center_hz'])

    def test_common1m_offset_preserves_settings_and_binds_plan_readiness_and_saved_metadata(self):
        profile = 'hackrf-common1m-offset'
        with patch.object(TOOL.C, 'CDLL', side_effect=AssertionError('No native load')), \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(TOOL.main(['--profile', profile]), 0)
        value = json.loads(output.getvalue())
        self.assertEqual((value['capture_profile'], value['center_hz'], value['sample_rate']),
                         (profile, 442325000, 9600000))
        self.assertEqual(value['requested_settings']['filter_bandwidth_hz'], 7000000)
        lib, events = Native(), []
        _, record, _ = self.run_capture(lib, profile=profile, event=events.append)
        self.assertTrue(record['complete'])
        self.assertEqual(lib.settings['freq'], 442325000)
        self.assertEqual(events[0]['capture_profile'], profile)
        self.assertEqual(events[0]['center_hz'], 442325000)
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory); library = folder/'library.dll'; library.write_bytes(b'offline library')
            capture = folder/'iq.cs8'; lib = Native()
            with patch.object(TOOL.C, 'CDLL', return_value=lib), patch.object(TOOL, 'DISCARD_SECONDS', 0), \
                    patch.object(TOOL, 'load_buffer_library', return_value=(self.collector, self.collector_meta)), \
                    contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(TOOL.main(['--receive', '--profile', profile, '--seconds', str(4/TOOL.RATE),
                    '--library', str(library), '--output', str(capture)]), 0)
            saved = json.loads(capture.with_suffix('.cs8.json').read_text())
            self.assertEqual((saved['capture_profile'], saved['center_hz']), (profile, 442325000))
            self.assertTrue(saved['complete'] and saved['count_complete'])
            self.assertFalse(saved['usb_continuity_qualified'] or saved['access_slot_qualified'])

    def test_probe_only_enumerates_reads_identity_and_closes(self):
        lib = Native(); storage, record, _ = self.run_capture(lib, probe=True)
        self.assertIsNone(storage); self.assertEqual(record['result'], 'complete')
        self.assertEqual(record['device']['usb_api'], 0x108)
        self.assertEqual(record['device']['firmware'], 'v1.9.1')
        self.assertEqual(record['device']['serial'], lib.serials[0].decode())
        self.assertFalse(any(name.startswith('hackrf_set_') or name == 'hackrf_start_rx' for name in lib.calls))
        self.assertEqual(lib.calls[-2:], ['hackrf_close', 'hackrf_exit'])

    def test_signed_iq_bytes_remain_exact_and_m0_counts_are_retained(self):
        lib = Native(); storage, record, _ = self.run_capture(lib)
        self.assertEqual(bytes(storage), b'\x80\xff\0\x7f\x81\xfe\1\x7e')
        self.assertEqual((record['bytes'], record['samples'], record['callbacks']), (8, 4, 1))
        self.assertEqual(record['callback_lengths'], {'8': 1})
        self.assertTrue(record['complete'] and record['count_complete'] and record['overrun_visibility'])
        self.assertFalse(record['overrun_observed'])
        self.assertEqual(record['m0_pre']['num_shortfalls'], 0)
        self.assertEqual(record['m0_post']['m0_count'], 8)
        self.assertEqual(lib.calls[-4:], ['hackrf_stop_rx', 'hackrf_get_m0_state', 'hackrf_close', 'hackrf_exit'])

    def test_discard_and_last_callback_trimming_have_exact_counts(self):
        storage, record, _ = self.run_capture(Native(packets=[bytes(range(16))]), discard=2/TOOL.RATE)
        self.assertEqual(bytes(storage), bytes(range(4, 12)))
        self.assertEqual((record['callback_bytes'], record['discarded_bytes'], record['bytes']), (16, 4, 8))

    def test_readiness_occurs_once_on_main_thread_after_first_retained_post_discard_data(self):
        lib = Native(packets=[b'1234', b'abcdefgh']); events = []
        def event(row):
            self.assertFalse(lib.inside_callback)
            events.append(row)
        _, record, _ = self.run_capture(lib, discard=2/TOOL.RATE, event=event)
        self.assertEqual(record['callbacks'], 2)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]['event'], 'rx_ready')
        self.assertEqual(events[0]['retained_samples'], 4)
        self.assertEqual(events[0]['sample_rate'], 9600000)
        self.assertFalse(events[0]['sample_clock_qualified'] or events[0]['rf_origin_qualified'])

    def test_preexisting_m0_shortfalls_are_context_and_not_subtracted_from_fresh_rx_epoch(self):
        _, record, _ = self.run_capture(Native(pre_shortfalls=9))
        self.assertEqual(record['m0_pre']['num_shortfalls'], 9)
        self.assertEqual(record['m0_post']['num_shortfalls'], 0)
        self.assertTrue(record['complete'])
        self.assertFalse(record['overrun_observed'])

    def test_old_device_api_or_missing_exports_never_calls_m0_functions(self):
        for missing in (False, True):
            lib = Native(api=0x105 if not missing else 0x108)
            if missing:
                del lib.hackrf_get_m0_state; del lib.hackrf_set_rx_overrun_limit
            _, record, _ = self.run_capture(lib)
            self.assertTrue(record['complete'])
            self.assertFalse(record['overrun_visibility'])
            self.assertIsNone(record['overrun_observed'])
            self.assertNotIn('hackrf_get_m0_state', lib.calls)
            self.assertNotIn('hackrf_set_rx_overrun_limit', lib.calls)

    def test_incomplete_stream_deadline_callback_fault_and_overrun_never_claim_complete(self):
        cases = [Native(packets=[b'1234']), Native(packets=[], stall=True), Native(packets=[b'123']), Native(shortfalls=1)]
        for lib in cases:
            with self.subTest(lib=lib):
                _, record, clock = self.run_capture(lib)
                self.assertEqual(record['result'], 'failed'); self.assertFalse(record['complete'])
                self.assertIn('hackrf_stop_rx', lib.calls)
                self.assertEqual(lib.calls[-2:], ['hackrf_close', 'hackrf_exit'])
                self.assertLess(clock(), 106)
        self.assertTrue(self.run_capture(Native(shortfalls=1))[1]['overrun_observed'])

    def test_native_callback_uses_no_python_memory_copy(self):
        lib = Native()
        with patch.object(TOOL.C, 'memmove', side_effect=AssertionError('No Python callback copy')):
            _, record, _ = self.run_capture(lib)
        self.assertTrue(record['complete'])
        self.assertEqual(record['collector']['mode'], 'native_memcpy_atomic_no_python_callback')
        self.assertEqual(lib.calls[-2:], ['hackrf_close', 'hackrf_exit'])

    def test_no_progress_watchdog_records_m0_and_stops_within_one_second(self):
        lib = Native(packets=[b'1234'], stall=True, stall_error=1)
        _, record, clock = self.run_capture(lib)
        self.assertEqual(record['bytes'], 4)
        self.assertEqual(record['m0_stall']['error'], 1)
        self.assertEqual(record['error_type'], 'TimeoutError')
        self.assertIn('No RX callback progress', record['error'])
        self.assertLess(clock(), 101.1)
        self.assertFalse(record['complete'] or record['count_complete'])
        self.assertEqual(lib.calls[-4:], ['hackrf_stop_rx', 'hackrf_get_m0_state', 'hackrf_close', 'hackrf_exit'])

    def test_setup_start_stop_close_and_m0_failures_always_have_honest_cleanup_receipts(self):
        for operation in ('hackrf_set_freq', 'hackrf_start_rx', 'hackrf_stop_rx', 'hackrf_close', 'post_m0'):
            lib = Native(); lib.errors[operation] = -99
            with self.subTest(operation=operation):
                _, record, _ = self.run_capture(lib)
                self.assertFalse(record['complete'])
                self.assertEqual(record['result'], 'failed')
                self.assertIn('hackrf_close', lib.calls)
                self.assertEqual(lib.calls[-1], 'hackrf_exit')
                if operation != 'hackrf_set_freq': self.assertIn('hackrf_stop_rx', lib.calls)

    def test_main_saves_exact_file_hash_and_incomplete_partial_capture_metadata(self):
        for packets, complete in ((None, True), ([b'1234'], False)):
            with self.subTest(complete=complete), tempfile.TemporaryDirectory() as directory:
                folder = Path(directory); library = folder/'library.dll'; library.write_bytes(b'offline library identity')
                output = folder/'iq.cs8'; lib = Native(packets=packets)
                with patch.object(TOOL.C, 'CDLL', return_value=lib), patch.object(TOOL, 'DISCARD_SECONDS', 0), \
                        patch.object(TOOL, 'load_buffer_library', return_value=(self.collector, self.collector_meta)), \
                        contextlib.redirect_stdout(io.StringIO()):
                    status = TOOL.main(['--receive', '--seconds', str(4/TOOL.RATE), '--library', str(library), '--output', str(output)])
                record = json.loads(output.with_suffix('.cs8.json').read_text())
                self.assertEqual(status, 0 if complete else 1)
                self.assertIs(record['complete'], complete)
                self.assertEqual(record['bytes'], output.stat().st_size)
                self.assertEqual(record['sha256'], hashlib.sha256(output.read_bytes()).hexdigest())
                self.assertEqual(record['library_sha256'], hashlib.sha256(library.read_bytes()).hexdigest())
                self.assertFalse(record['test_counter'] or record['usb_continuity_qualified'] or record['access_slot_qualified'])
                self.assertEqual(record['capture_profile'], 'hackrf-legacy5m')

    def test_invalid_bounds_and_existing_outputs_fail_before_native_load(self):
        for options in (['--seconds', '31'], ['--seconds', 'nan'], ['--seconds', '0'], ['--lna', '1'],
                        ['--vga', '63'], ['--receive'], ['--profile', 'unreviewed']):
            with self.subTest(options=options), patch.object(TOOL.C, 'CDLL', side_effect=AssertionError('no native')), \
                    contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit): TOOL.main(options)
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)/'exists.cs8'; output.write_bytes(b'preserve')
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                TOOL.main(['--receive', '--output', str(output)])
            self.assertEqual(output.read_bytes(), b'preserve')

    def test_source_has_no_transmit_or_programming_native_entrypoint(self):
        tree = ast.parse((ROOT/'scripts/capture-hackrf-iq.py').read_text())
        names = [node.attr for node in ast.walk(tree) if isinstance(node, ast.Attribute) and node.attr.startswith('hackrf_')]
        self.assertFalse(any('tx' in name or 'spiflash' in name or 'cpld' in name for name in names))


if __name__ == '__main__':
    unittest.main()
