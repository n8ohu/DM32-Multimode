# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent AMBT waveforms and real completed-lane CRC arbitration; no RF.

Uses the pinned OP25 frequency response, with a small direct inverse DFT for
its 131 transmit taps. No numpy/scipy or production transmitter is required.
"""
import ctypes as C
import math
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tests'))
from p25_ambt_fixture import ambt, ambt_blocks, wire_blocks


def transmit_taps():
    # OP25 transfer_function_tx at 3f44d43eb449bb4753247ce848bb42a403823dea:
    # apps/tx/op25_c4fm_mod.py, normalized LF SHA256
    # b658a324dc9ed3af1ffaec7737dba871ca81b1cb1e8c675783092552ff53b3ef.
    # Keep this independent TX response local so target CI needs no GNU Radio
    # checkout, numerical packages, network download or production TX code.
    spectrum = []
    for f in range(2881):
        hf = 1.0 if f < 1920 else .5+.5*math.cos(2*math.pi*f/1920)
        t = math.pi*f/4800
        spectrum.append(hf*(1 if t < 1e-6 else t/math.sin(t)))
    # Exactly the center 131 samples of OP25's length-48000 real inverse FFT.
    taps = [(spectrum[0]+2*sum(value*math.cos(2*math.pi*f*k/48000)
             for f, value in enumerate(spectrum[1:], 1)))/48000 for k in range(-65, 66)]
    gain = sum(taps)
    return [value/gain for value in taps]


def waveform(wire, taps, phase=0, polarity=1, gain=1, dc=0, noise=0, ppm=0):
    raw = b'\x77'*240+wire+b'\x77'*36
    symbols = [(byte >> shift)&3 for byte in raw for shift in (6, 4, 2, 0)]
    shaped = [0.0]*(phase+len(symbols)*10+len(taps)-1)
    levels = (1, 3, -1, -3)
    for i, symbol in enumerate(symbols):
        start = phase+i*10
        value = levels[symbol]*60000
        for j, tap in enumerate(taps):
            shaped[start+j] += value*tap
    rng = random.Random(250075+phase)
    result = []
    ratio = 1+ppm/1e6
    for i in range(0, math.ceil(len(shaped)*ratio), 6):
        position = i/ratio
        left = min(int(position), len(shaped)-1)
        fraction = position-left
        value = shaped[left]*(1-fraction)+shaped[min(left+1, len(shaped)-1)]*fraction
        value = value*polarity*gain+dc+(rng.gauss(0, noise) if noise else 0)
        result.append(max(-32768, min(32767, round(value))))
    return result


def main():
    build = ROOT/'build/test-p25-ambt-demod'
    build.mkdir(parents=True, exist_ok=True)
    library = build/('ambt_demod.dll' if sys.platform == 'win32' else 'ambt_demod.so')
    flags = ['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wshadow', '-shared']
    if sys.platform != 'win32':
        flags.append('-fPIC')
    subprocess.run(flags+['-Isrc/firmware', 'tests/test_p25_tsdu_demod_bridge.c',
        'src/firmware/p25_rx.c', 'src/firmware/p25_tsdu.c', '-o', str(library)],
        cwd=ROOT, check=True, timeout=120)
    lib = C.CDLL(str(library))
    byte = C.c_uint8
    pointer = C.POINTER(byte)
    lib.p25_tsdu_test_demod.argtypes = [C.POINTER(C.c_int16), C.c_uint, pointer, C.c_uint]
    lib.p25_tsdu_test_demod.restype = C.c_uint
    lib.p25_ambt_test_rank.argtypes = [pointer, C.c_uint, C.c_uint,
        pointer, C.c_uint, C.c_uint, pointer, C.POINTER(C.c_uint)]
    lib.p25_ambt_test_rank.restype = C.c_uint

    def buffer(data):
        return (byte*len(data)).from_buffer_copy(data)

    def receive(samples):
        packed = (C.c_int16*len(samples))(*samples)
        out = (byte*65536)()
        count = lib.p25_tsdu_test_demod(packed, len(samples), out, len(out))
        assert count != 0xffffffff
        data = bytes(out[:count])
        records = []
        while data:
            assert len(data) >= 5
            length = int.from_bytes(data[3:5], 'big')
            assert length and len(data) >= length+5
            records.append((int.from_bytes(data[:2], 'big'), data[2], data[5:5+length]))
            data = data[5+length:]
        return records

    def rank(first, q1, second, q2, expected, score):
        out = (byte*512)()
        scores = (C.c_uint*4)()
        length = lib.p25_ambt_test_rank(buffer(first), len(first), q1,
            buffer(second), len(second), q2, out, scores)
        assert bytes(out[:length]) == expected
        assert scores[0] == score, tuple(scores)

    good = ambt(0x3b)
    header, blocks = ambt_blocks(0x3b)
    damaged = bytearray(blocks[0]); damaged[-1] ^= 1
    bad = wire_blocks(header, [bytes(damaged)])  # Exact trellis with bad packet CRC.
    rank(bad, 1000, good, 900, good, 0)
    rank(good, 900, bad, 1000, good, 0)
    rank(good, 1000, bad, 900, good, 0)
    rank(bad, 900, bad, 1000, bad, 1)
    alternate = ambt(0x3b, wacn=0xbee01)
    rank(good, 900, alternate, 1000, alternate, 0)

    taps = transmit_taps()
    cases = 0
    for opcode in (0x3a, 0x3b, 0):
        wire = ambt(opcode)
        for phase in (0, 3, 6, 9):
            for params in ({}, dict(polarity=-1, gain=.25, dc=300, noise=25),
                           dict(noise=50, ppm=500)):
                records = receive(waveform(wire, taps, phase=phase, **params))
                assert records == [(0xb85, 12, wire)], (opcode, phase, params, records)
                cases += 1
    sequence = [ambt(opcode) for _ in range(4) for opcode in (0x3a, 0x3b, 0)]
    records = receive(waveform(b''.join(sequence), taps, phase=7, noise=45, ppm=-500))
    assert records == [(0xb85, 12, wire) for wire in sequence]
    print(f'AMBT demod: {cases} independent 8-kHz waveforms, '
          f'{len(sequence)} continuous packets and five lane-CRC arbitration cases passed; no RF')


if __name__ == '__main__':
    main()
