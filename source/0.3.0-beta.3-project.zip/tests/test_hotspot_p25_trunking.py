"""Finite control-channel scheduling, profile refusal and service recovery mocks."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("hotspot_trunking", ROOT/"scripts/hotspot-p25-trunking.py")
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
CONFIG = """[General]
Duplex=1
[Info]
TXFrequency=440075000
RXFrequency=445075000
[Modem]
Protocol=uart
UARTPort=/dev/ttyAMA0
UARTSpeed=115200
TXDelay=100
RXInvert=1
TXInvert=0
PTTInvert=1
RXOffset=125
TXOffset=-250
P25TXLevel=50
[P25]
Enable=1
NAC=293
[P25 Network]
Enable=0
[DMR]
Enable=0
Beacons=0
[DMR Network]
Enable=0
[CW Id]
Enable=0
"""
VERSION_TEXT = b"MMDVM_HS_Dual_Hat-v1.5.2 20201108 14.7456MHz ADF7021 GitID #89daa20"
VERSION = bytes((0xE0, len(VERSION_TEXT)+4, 0, 1))+VERSION_TEXT


def fixture(repetitions=1):
    return tool.GENERATOR.make_fixture(control_frequency=440075000, voice_frequency=440087500,
                                       repetitions=repetitions)


class Clock:
    def __init__(self):
        self.now = 100.0

    def __call__(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


class Modem:
    def __init__(self, clock, *, space=6, lead=0.6):
        self.clock, self.space, self.lead = clock, space, lead
        self.sent = []
        self.first_payload = None
        self.tail = clock()
        self.max_payload = 0
        self.polls = 0

    def status(self):
        self.polls += 1
        return {"p25": True, "mode": 4 if self.sent else 0,
                "tx": bool(self.sent) and self.clock() < self.tail, "space": self.space}

    def send(self, packet):
        if not self.sent:
            self.first_payload = self.clock()+self.lead
            self.tail = self.first_payload
        start = max(self.clock(), self.tail)
        self.tail = start+(len(packet)-4)/1200
        self.max_payload = max(self.max_payload, self.tail-max(self.clock(), self.first_payload))
        self.sent.append({"packet": packet, "queued": self.clock(), "start": start, "end": self.tail})


class Services:
    def __init__(self):
        self.states = {unit: unit in ("mmdvmhost.service", "mmdvmhost.timer",
                                      "pistar-watchdog.service") for unit in tool.UNITS}
        self.before = self.states.copy()
        self.calls = []
        self.fail_stop = None
        self.fail_start = None
        self.owner = False

    def loaded(self, unit):
        return unit in ("mmdvmhost.service", "mmdvmhost.timer", "pistar-watchdog.service")

    def active(self, unit):
        return self.states[unit]

    def manual_hosts(self):
        return self.owner

    def service(self, action, unit):
        self.calls.append((action, unit))
        if action == "stop" and self.fail_stop == unit:
            self.fail_stop = None
            raise RuntimeError("stop failed")
        if action == "start" and self.fail_start == unit:
            raise RuntimeError("start failed")
        self.states[unit] = action == "start"


class FixtureAndProfileTests(unittest.TestCase):
    def files(self, directory, *, config=CONFIG):
        directory = Path(directory)
        frames, metadata = fixture()
        tool.GENERATOR.write_fixture(directory, frames, metadata)
        source = directory/"modem.ini"
        source.write_text(config)
        return source, directory/"control.bin", directory/"manifest.json", frames, metadata

    def test_reproduces_full_fixture_before_using_one_cycle(self):
        with tempfile.TemporaryDirectory() as directory:
            _, source, manifest, frames, metadata = self.files(directory)
            self.assertEqual(tool.load_fixture(source, manifest), (frames, metadata))
            bad = bytearray(source.read_bytes())
            bad[-1] ^= 1
            source.write_bytes(bad)
            # Updating the self-described SHA cannot authorize changed RF.
            metadata["files"]["control.bin"]["sha256"] = hashlib.sha256(bad).hexdigest()
            manifest.write_text(json.dumps(metadata))
            with self.assertRaises(ValueError):
                tool.load_fixture(source, manifest)

    def test_metadata_semantics_and_counts_cannot_be_silently_changed(self):
        with tempfile.TemporaryDirectory() as directory:
            _, source, manifest, _, metadata = self.files(directory)
            for path, value in ((["talkgroup"], 1000), (["repetitions"], 0),
                                (["bandplan", "voice_channel"], 999),
                                (["frames", 0, "blocks", 0, "mfid"], 0x90)):
                changed = copy.deepcopy(metadata)
                target = changed
                for key in path[:-1]:
                    target = target[key]
                target[path[-1]] = value
                manifest.write_text(json.dumps(changed))
                with self.subTest(path=path), self.assertRaises(ValueError):
                    tool.load_fixture(source, manifest)

    def test_exact_duplex_profile_keeps_offsets_and_power_cap(self):
        with tempfile.TemporaryDirectory() as directory:
            source, _, _, _, metadata = self.files(directory)
            profile = tool.configuration(source, metadata, 10)
        self.assertEqual((profile["port"], profile["baud"]), ("/dev/ttyAMA0", 115200))
        self.assertEqual(struct.unpack("<II", profile["frequency"][4:12]), (445075125, 440074750))
        self.assertEqual(profile["rf_level_byte"], 25)
        self.assertLessEqual(profile["rf_level_byte"]/255, 0.1)
        self.assertEqual(len(profile["config"]), 26)
        payload = profile["config"][3:]
        self.assertEqual(payload[:4], bytes((5, 8, 10, 0)))
        self.assertEqual(payload[12], 128)
        self.assertEqual(payload[13:], bytes(10))
        self.assertFalse(payload[0] & 0x80)
        self.assertAlmostEqual(profile["lead_seconds"], 0.6)

    def test_common_iq_profile_is_explicit_exact_and_keeps_calibration_caps(self):
        with tempfile.TemporaryDirectory() as directory:
            source, _, _, _, metadata = self.files(directory)
            source.write_text(CONFIG.replace('RXFrequency=445075000','RXFrequency=441075000'))
            with self.assertRaises(ValueError):tool.configuration(source,metadata,9)
            lab=tool.LAB.COMMONIQ1M
            profile=tool.configuration(source,metadata,10,lab_profile=lab)
            self.assertEqual(profile['lab_profile'],'COMMONIQ1M')
            self.assertEqual(struct.unpack('<II',profile['frequency'][4:12]),(441075125,440074750))
            self.assertEqual(profile['rf_level_byte'],25)
            self.assertEqual((tool.TX_FREQUENCY,tool.RX_FREQUENCY),(440075000,445075000))
            source.write_text(CONFIG)
            with self.assertRaises(ValueError):tool.configuration(source,metadata,9,lab_profile=lab)
            for field,value in (('voice_frequency_hz',440100000),('nac',0x294),
                                ('wacn',0xABCDE+1),('system_id',0x124)):
                wrong=copy.deepcopy(metadata);wrong[field]=value
                with self.subTest(field=field),self.assertRaises(ValueError):
                    tool.configuration(source,wrong,9,lab_profile=tool.LAB.LEGACY5M)

    def test_refuses_profiles_requiring_retune_network_or_mode_changes(self):
        invalid = (
            CONFIG.replace("Duplex=1", "Duplex=0"),
            CONFIG.replace("TXFrequency=440075000", "TXFrequency=440087500"),
            CONFIG.replace("RXFrequency=445075000", "RXFrequency=440075000"),
            CONFIG.replace("[DMR]\nEnable=0", "[DMR]\nEnable=1"),
            CONFIG.replace("Beacons=0", "Beacons=1"),
            CONFIG.replace("[P25 Network]\nEnable=0", "[P25 Network]\nEnable=1"),
            CONFIG.replace("[CW Id]\nEnable=0", "[CW Id]\nEnable=1"),
            CONFIG.replace("P25TXLevel=50", "P25TXLevel=nan"),
            CONFIG.replace("P25TXLevel=50", "P25TXLevel=101"),
            CONFIG.replace("RXOffset=125", "RXOffset=20000"),
            CONFIG.replace("Protocol=uart", "Protocol=udp"),
            CONFIG.replace("UARTSpeed=115200", "UARTSpeed=9600"),
            CONFIG.replace("NAC=293", "NAC=2A3"),
            CONFIG.replace("TXInvert=0", "TXInvert=0\ntxinvert=1"),
        )
        with tempfile.TemporaryDirectory() as directory:
            source, _, _, _, metadata = self.files(directory)
            for text in invalid:
                source.write_text(text)
                with self.subTest(config=text), self.assertRaises((ValueError, tool.configparser.Error)):
                    tool.configuration(source, metadata, 9)
            source.write_text(CONFIG)
            for power in (0, 11, True, 9.0):
                with self.subTest(power=power), self.assertRaises(ValueError):
                    tool.configuration(source, metadata, power)

    def test_offline_default_never_reads_config_queries_services_or_opens_serial(self):
        with tempfile.TemporaryDirectory() as directory:
            _, source, manifest, _, _ = self.files(directory)
            with patch.object(tool, "configuration", side_effect=AssertionError("no profile access")), \
                    patch.object(tool, "System", side_effect=AssertionError("no services")), \
                    patch.object(tool, "transmit", side_effect=AssertionError("no RF")), \
                    patch.dict(sys.modules, {"serial": None}), contextlib.redirect_stdout(io.StringIO()) as output:
                result = tool.main(["--fixture", str(source), "--manifest", str(manifest),
                                    "--config", "/no-access", "--duration", "3", "--grant-delay", "1"])
            self.assertEqual(result, 0)
            record = json.loads(output.getvalue())
            self.assertTrue(record["dry_run"])
            self.assertEqual(record["rf_payload_commands_sent"], 0)


class ModemTests(unittest.TestCase):
    def test_identity_is_strict_and_optional_udid_is_not_reported(self):
        self.assertEqual(tool.identify(VERSION), VERSION_TEXT.decode())
        with_udid = VERSION_TEXT+b"\0PRIVATE-UDID"
        self.assertEqual(tool.identify(bytes((0xE0, len(with_udid)+4, 0, 1))+with_udid), VERSION_TEXT.decode())
        for version in (b"", VERSION[:3], VERSION.replace(b"#89daa20", b"#7e16099"),
                        VERSION[:3]+b"\x02"+VERSION[4:]):
            with self.subTest(version=version), self.assertRaises(RuntimeError):
                tool.identify(version)

    def test_status_uses_only_identified_thirteen_byte_layout(self):
        link = tool.Link(None)
        good = bytes((0xE0, 13, 1, 8, 4, 1, 0, 0, 0, 0, 6, 0, 0))
        link.query = lambda command: good
        self.assertEqual(link.status(), {"p25": True, "mode": 4, "tx": True, "space": 6})
        for value in (good[:-1], bytes((0xE0, 14))+good[2:]+b"\0",
                      good[:5]+b"\x04"+good[6:]):
            link.query = lambda command, value=value: value
            with self.subTest(value=value), self.assertRaises(RuntimeError):
                link.status()

    def test_version_gates_every_mutating_command(self):
        class Device:
            def __enter__(self): return self
            def __exit__(self, *args): return False
        device = Device()
        commands = []
        class SetupLink:
            def __init__(self, device): self.status_count = 0
            def query(self, command): return VERSION
            def command(self, command): commands.append(command)
            def status(self):
                self.status_count += 1
                return {"p25": self.status_count > 1, "mode": 0, "tx": False, "space": 6}
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)/"config.ini"; source.write_text(CONFIG)
            frames, metadata = fixture(); profile = tool.configuration(source, metadata, 9)
            serial = types.SimpleNamespace(Serial=lambda **kwargs: device)
            with patch.dict(sys.modules, {"serial": serial}), patch.object(tool, "Link", SetupLink), \
                    patch.object(tool, "schedule", return_value={"units_sent": 3}) as schedule:
                result = tool.transmit(profile, frames, 3, 1, lambda event: None)
            self.assertEqual(commands, [profile["frequency"], profile["config"]])
            self.assertEqual(schedule.call_count, 1)
            self.assertIn("89daa20", result["modem"])
            self.assertFalse(device.dtr); self.assertFalse(device.rts)
            commands.clear()
            with patch.dict(sys.modules, {"serial": serial}), patch.object(tool, "Link", SetupLink), \
                    patch.object(tool, "identify", side_effect=RuntimeError("unknown")):
                with self.assertRaises(RuntimeError):
                    tool.transmit(profile, frames, 3, 1, lambda event: None)
            self.assertEqual(commands, [])


class SchedulerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames = fixture()[0]

    def test_fresh_fifo_bounded_queue_delayed_grant_and_clean_drain(self):
        clock = Clock(); link = Modem(clock); events = []
        result = tool.schedule(link, self.frames, 4, 1, 0.6,
                               clock=clock, sleep=clock.sleep, event=events.append)
        self.assertTrue(result["tx_observed"])
        self.assertTrue(result["grant_queued"])
        self.assertGreater(link.polls, len(link.sent))
        self.assertLessEqual(link.max_payload, 0.250000001)
        self.assertLessEqual(result["max_estimated_payload_queue_s"], 0.250000001)
        self.assertLessEqual(link.sent[-1]["end"], 104.000000001)
        self.assertLess(clock(), 104.2)
        self.assertEqual([event["event"] for event in events], ["cc_ready", "grant_queued"])
        self.assertFalse(events[1]["rf_timing_measured"])
        self.assertGreaterEqual(events[1]["estimated_rf_start_s"], 1.6)
        self.assertLess(events[1]["estimated_rf_start_s"], 1.675000001)
        grant = next(entry for entry in link.sent if len(entry["packet"]) == 49)
        self.assertAlmostEqual(grant["start"]-100, events[1]["estimated_rf_start_s"])
        for entry in link.sent:
            if entry is grant:
                break
            self.assertEqual(len(entry["packet"]), 94)
        self.assertFalse(result["rf_decode_verified"])

    def test_finite_grant_window_ends_with_site_information_only(self):
        clock = Clock(); link = Modem(clock); events = []
        result = tool.schedule(link, self.frames, 5, .5, .6, grant_duration=1,
                               clock=clock, sleep=clock.sleep, event=events.append)
        window_end = 100+.6+.5+1
        grants = [entry for entry in link.sent if len(entry["packet"]) != 94]
        self.assertTrue(grants)
        self.assertTrue(all(entry["end"] <= window_end+1e-9 for entry in grants))
        final = [entry for entry in link.sent if entry["start"] >= window_end]
        self.assertGreater(len(final), 3)
        self.assertTrue(all(len(entry["packet"]) == 94 for entry in final))
        self.assertEqual([event["event"] for event in events],
                         ["cc_ready", "grant_queued", "grant_window_closed"])
        self.assertTrue(result["grant_window_closed"])
        self.assertEqual(result["grant_duration_s"], 1)

    def test_invalid_or_nonfitting_grant_windows_send_nothing(self):
        for window in (0, .1, True, float("nan"), float("inf"), 10, 4):
            clock = Clock(); link = Modem(clock)
            with self.subTest(window=window), self.assertRaises(ValueError):
                tool.schedule(link, self.frames, 5, .5, .6, grant_duration=window,
                              clock=clock, sleep=clock.sleep)
            self.assertEqual(link.sent, [])

    def test_fifo_reserve_and_absolute_no_space_deadline(self):
        clock = Clock(); link = Modem(clock, space=1)
        with self.assertRaises(TimeoutError):
            tool.schedule(link, self.frames, 2, 0, .6, clock=clock, sleep=clock.sleep)
        self.assertEqual(link.sent, [])
        self.assertLessEqual(clock(), 105.01)

    def test_unknown_mode_tx_drop_or_delayed_status_never_rekeys(self):
        clock = Clock(); link = Modem(clock)
        link.status = lambda: {"p25": False, "mode": 2, "tx": False, "space": 6}
        with self.assertRaises(RuntimeError):
            tool.schedule(link, self.frames, 2, 0, .6, clock=clock, sleep=clock.sleep)
        self.assertFalse(link.sent)
        clock = Clock(); link = Modem(clock); normal = link.status
        def dropped():
            state = normal()
            if clock() > 100.2: state["tx"] = False
            return state
        link.status = dropped
        with self.assertRaisesRegex(RuntimeError, "lost TX"):
            tool.schedule(link, self.frames, 2, 0, .6, clock=clock, sleep=clock.sleep)
        self.assertLess(clock(), 100.25)
        clock = Clock(); link = Modem(clock)
        def late():
            clock.sleep(10)
            return {"p25": True, "mode": 0, "tx": False, "space": 6}
        link.status = late
        with self.assertRaises(TimeoutError):
            tool.schedule(link, self.frames, 2, 0, .6, clock=clock, sleep=clock.sleep)
        self.assertFalse(link.sent)

    def test_stuck_tx_and_transport_fault_remain_bounded(self):
        clock = Clock(); link = Modem(clock); normal = link.status
        def stuck():
            state = normal(); state["tx"] = bool(link.sent); return state
        link.status = stuck
        with self.assertRaises(TimeoutError):
            tool.schedule(link, self.frames, 2, 0, .6, clock=clock, sleep=clock.sleep)
        self.assertLessEqual(clock(), 105.01)
        clock = Clock(); link = Modem(clock)
        def failed(packet): raise RuntimeError("NAK/FIFO fault")
        link.send = failed
        with self.assertRaisesRegex(RuntimeError, "NAK"):
            tool.schedule(link, self.frames, 2, 0, .6, clock=clock, sleep=clock.sleep)
        self.assertEqual(link.sent, [])

    def test_invalid_duration_delay_and_preamble_rejected_before_status(self):
        for duration, delay in ((0, 0), (31, 1), (3, -1), (3, 3), (float("nan"), 0),
                                (3, float("inf")), (True, 0), (0.7, 0)):
            clock = Clock(); link = Modem(clock)
            with self.subTest(duration=duration, delay=delay), self.assertRaises(ValueError):
                tool.schedule(link, self.frames, duration, delay, .6, clock=clock, sleep=clock.sleep)
            self.assertEqual(link.polls, 0)
            self.assertEqual(link.sent, [])


class RecoveryTests(unittest.TestCase):
    def setup_session(self, directory):
        source = Path(directory)/"config.ini"; source.write_text(CONFIG)
        return source, {"original_config_sha256": tool.digest(source)}

    def test_success_and_operation_failure_restore_exact_services(self):
        for fails in (False, True):
            with self.subTest(fails=fails), tempfile.TemporaryDirectory() as directory:
                source, report = self.setup_session(directory); services = Services(); settles = []
                def operation():
                    self.assertFalse(any(services.states.values()))
                    if fails: raise RuntimeError("RF worker failed")
                    return {"units_sent": 7}
                if fails:
                    with self.assertRaises(RuntimeError):
                        tool.execute_session(services, operation, source, report, settle=settles.append)
                else:
                    tool.execute_session(services, operation, source, report, settle=settles.append)
                self.assertEqual(services.states, services.before)
                self.assertEqual(settles, [3, 3])
                self.assertTrue(report["services_restored"])
                self.assertTrue(report["original_config_unchanged"])
                self.assertEqual(report["cleanup_errors"], [])

    def test_profile_revalidation_failure_restores_services_for_both_catalog_entries(self):
        for lab in tool.LAB.PROFILES:
            with self.subTest(profile=lab.name),tempfile.TemporaryDirectory() as directory:
                source,report=self.setup_session(directory);services=Services()
                source.write_text(CONFIG.replace('RXFrequency=445075000',f'RXFrequency={lab.control_tx_hz}'))
                report['original_config_sha256']=tool.digest(source)
                metadata=fixture()[1]
                tool.configuration(source,metadata,9,lab_profile=lab)
                other=tool.LAB.PROFILES[1-lab.profile_id]
                def operation():
                    tool.configuration(source,metadata,9,lab_profile=other)
                    self.fail('mixed profile must stop before modem access')
                with self.assertRaises(ValueError):
                    tool.execute_session(services,operation,source,report,settle=lambda _:None)
                self.assertEqual(services.states,services.before)
                self.assertTrue(report['services_restored'] and report['original_config_unchanged'])
                self.assertEqual(report['cleanup_errors'],[])

    def test_partial_stop_and_unmanaged_owner_refuse_operation_then_recover(self):
        for failure in ("stop", "owner"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory:
                source, report = self.setup_session(directory); services = Services()
                if failure == "stop": services.fail_stop = "mmdvmhost.service"
                else: services.owner = True
                with self.assertRaises(RuntimeError):
                    tool.execute_session(services, lambda: self.fail("worker must not start"),
                                         source, report, settle=lambda seconds: None)
                self.assertEqual(services.states, services.before)
                self.assertTrue(report["services_restored"])

    def test_restore_failure_is_recorded_without_false_success(self):
        with tempfile.TemporaryDirectory() as directory:
            source, report = self.setup_session(directory); services = Services()
            services.fail_start = "mmdvmhost.service"
            tool.execute_session(services, lambda: {"units_sent": 1}, source, report,
                                 settle=lambda seconds: None)
            self.assertFalse(report["services_restored"])
            self.assertTrue(report["cleanup_errors"])
            self.assertTrue(services.states["pistar-watchdog.service"])

    def test_external_config_mutation_is_detected_and_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            source, report = self.setup_session(directory); services = Services()
            def operation():
                source.write_text("external change")
                return {}
            tool.execute_session(services, operation, source, report, settle=lambda seconds: None)
            self.assertEqual(source.read_text(), "external change")
            self.assertFalse(report["original_config_unchanged"])
            self.assertTrue(report["services_restored"])


class UnitDiscoveryTests(unittest.TestCase):
    def test_loaded_and_optional_missing_units(self):
        for value, code, expected in (("loaded\n", 0, True), ("not-found\n", 0, False),
                                      ("not-found\n", 1, False), ("not-found\n", 4, False)):
            with self.subTest(value=value, code=code), patch.object(
                    tool.subprocess, "run", return_value=types.SimpleNamespace(stdout=value, returncode=code)):
                self.assertEqual(tool.System().loaded("optional.service"), expected)

    def test_discovery_errors_are_not_hidden(self):
        for value, code in (("", 1), ("loaded\n", 1), ("not-found\n", 2), ("error\n", 0)):
            with self.subTest(value=value, code=code), patch.object(
                    tool.subprocess, "run", return_value=types.SimpleNamespace(stdout=value, returncode=code)):
                with self.assertRaises(RuntimeError):
                    tool.System().loaded("optional.service")


if __name__ == "__main__":
    unittest.main()
