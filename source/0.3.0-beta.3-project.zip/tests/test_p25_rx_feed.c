// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx_feed.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    p25_rx_feed feed;
    unsigned char storage[P25_RX_FEED_STORAGE_BYTES+1u],window[1024];
    uint32_t now,origin;
    unsigned reads,pending_after,torn_after,irq_after,stop_after;
    bool pending;
} fixture;
static int16_t sample_value(uint32_t ordinal) {return (int16_t)(ordinal*173u+0x1213u);}
static void word(fixture *f,unsigned half,unsigned offset,int16_t value) {
    unsigned n=(half-1u)*512u+offset*2u;
    f->window[n]=(unsigned char)((uint16_t)value>>8);f->window[n+1]=(unsigned char)value;
}
static void fill(fixture *f,unsigned index,unsigned count) {
    unsigned half=index%2u?1u:2u;
    for(unsigned i=0;i<count;++i)word(f,half,i,sample_value(index*256u+i));
}
static uint8_t read_byte(void *opaque,unsigned offset) {
    fixture *f=opaque;assert(offset<1024u);++f->reads;++f->now;
    if(f->pending_after&&f->reads==f->pending_after)f->pending=true;
    if(f->torn_after&&f->reads==f->torn_after)f->window[offset]^=0x55u;
    if(f->irq_after&&f->reads==f->irq_after)
        (void)p25_rx_feed_irq(&f->feed,2u,f->origin+32000u);
    if(f->stop_after&&f->reads==f->stop_after)p25_rx_feed_stop(&f->feed);
    return f->window[offset];
}
static uint32_t clock_us(void *opaque) {return ((fixture *)opaque)->now;}
static bool half_pending(void *opaque) {return ((fixture *)opaque)->pending;}
static p25_rx_feed_io io_for(fixture *f) {
    p25_rx_feed_io io={f,read_byte,clock_us,half_pending};return io;
}
static void start(fixture *f,uint32_t limit,uint32_t now) {
    memset(f,0,sizeof *f);f->now=f->origin=now;
    p25_rx_feed_config config={2000u,16000u,limit};
    // Deliberately unaligned character storage remains supported.
    assert(p25_rx_feed_start(&f->feed,f->storage+1,P25_RX_FEED_STORAGE_BYTES,&config,17u,now));
}
static void first_irq(fixture *f) {assert(p25_rx_feed_irq(&f->feed,1u,f->now));}
static void consume(fixture *f) {
    p25_rx_feed_chunk chunk;
    while(p25_rx_feed_pop(&f->feed,&chunk,f->now)) {
        assert(chunk.first_sample+16u==f->feed.consumed);
        assert(chunk.sample_offset==chunk.first_sample%256u);
        assert(chunk.origin_irq_count==chunk.first_sample/256u+1u);
        assert(chunk.origin_irq_us==f->origin+(chunk.first_sample/256u)*32000u);
        assert(chunk.target_half==(chunk.first_sample/256u%2u?1u:2u));
        assert(chunk.read_end_us-chunk.read_begin_us==48u&&!chunk.reserved);
        for(unsigned i=0;i<16u;++i)assert(chunk.samples[i]==sample_value(chunk.first_sample+i));
    }
}
static void continuous_and_finite(uint32_t limit,uint32_t origin,bool deadline_timer) {
    fixture f;start(&f,limit,origin);first_irq(&f);p25_rx_feed_io io=io_for(&f);
    unsigned completed=0;uint32_t tick=500u,target=limit?limit:16384u;
    while(f.feed.consumed<target&&p25_rx_feed_active(&f.feed)) {
        assert(tick<2200000u);f.now=origin+tick;
        unsigned next_completed=tick/32000u;
        if(next_completed>completed) {
            assert(next_completed==completed+1u);fill(&f,completed,256u);completed=next_completed;
            assert(p25_rx_feed_irq(&f.feed,completed%2u?2u:1u,origin+completed*32000u));
        }
        fill(&f,completed,tick%32000u/125u);
        unsigned before=f.reads;
        p25_rx_feed_step_result result=p25_rx_feed_step(&f.feed,&io,f.now);
        assert(result!=P25_RX_FEED_REVOKED);
        assert(f.reads-before==(result==P25_RX_FEED_PUBLISHED?48u:0u));
        consume(&f);
        uint32_t delay=deadline_timer?p25_rx_feed_next_delay(&f.feed,f.now):500u;
        if(!delay)break;
        assert(delay<=4000u);tick=(f.now-origin)+delay;
    }
    assert(!f.feed.faults&&f.feed.produced==target&&f.feed.consumed==target);
    assert(f.reads==target*3u); // One H/L/H pass, no double read or later verification.
    assert(f.feed.read_calls==target/16u&&f.feed.read_bytes==target*3u);
    assert(f.feed.max_read_us==48u&&f.feed.max_queue_us<=500u);
    if(limit) {
        assert(f.feed.state==P25_RX_FEED_COMPLETE&&!p25_rx_feed_active(&f.feed));
        assert(!p25_rx_feed_next_delay(&f.feed,f.now));
    } else {assert(p25_rx_feed_producing(&f.feed));p25_rx_feed_stop(&f.feed);assert(f.feed.state==P25_RX_FEED_STOPPED);}
}
static void admission_and_restart(void) {
    fixture f;memset(&f,0,sizeof f);p25_rx_feed_config c={2000u,16000u,0u};
    assert(!p25_rx_feed_start(NULL,f.storage,sizeof f.storage,&c,1u,0u));
    assert(!p25_rx_feed_start(&f.feed,NULL,1024u,&c,1u,0u));
    assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,NULL,1u,0u));
    assert(!p25_rx_feed_start(&f.feed,f.storage,895u,&c,1u,0u));
    assert(!p25_rx_feed_start(&f.feed,&f.feed,1024u,&c,1u,0u));
    assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,0u,0u));
    c.guard_us=1999u;assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    c.guard_us=8001u;assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    c.guard_us=2000u;c.max_age_us=16001u;assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    c.max_age_us=999u;assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    c.max_age_us=16000u;
    const uint32_t bad_limits[]={1u,255u,257u,8193u,UINT32_MAX};
    for(unsigned i=0;i<sizeof bad_limits/sizeof bad_limits[0];++i) {
        c.sample_limit=bad_limits[i];assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    }
    c.sample_limit=0u;memset(f.storage,0x5a,sizeof f.storage);
    assert(p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    for(unsigned i=0;i<sizeof f.storage;++i)assert(f.storage[i]==0x5a);
    p25_rx_feed copy=f.feed;
    assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,2u,0u));
    assert(!memcmp(&copy,&f.feed,sizeof copy));
    p25_rx_feed_stop(&f.feed);assert(!p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,1u,0u));
    assert(p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,2u,0u));
    p25_rx_feed_stop(&f.feed);c.guard_us=8000u;c.max_age_us=1000u;c.sample_limit=8192u;
    assert(p25_rx_feed_start(&f.feed,f.storage,sizeof f.storage,&c,3u,0u));
}
static void pending_torn_and_boundary(void) {
    fixture f;start(&f,0u,0u);first_irq(&f);fill(&f,0u,64u);f.now=8000u;
    p25_rx_feed_io io=io_for(&f);f.pending=true;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_WAIT&&!f.reads&&!f.feed.faults);
    assert(p25_rx_feed_next_delay(&f.feed,f.now)==500u);
    f.pending=false;f.pending_after=48u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED);
    assert(f.feed.faults&P25_RX_FEED_IRQ_READ);assert(!f.feed.produced);
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,64u);f.now=8000u;io=io_for(&f);f.torn_after=3u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED);
    assert(f.feed.faults&P25_RX_FEED_TORN);
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,256u);f.now=31980u;io=io_for(&f);f.irq_after=20u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED);
    assert(f.feed.faults&P25_RX_FEED_IRQ_READ);
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,256u);f.now=31980u;io=io_for(&f);
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED);
    assert(f.feed.faults&P25_RX_FEED_OVERWRITTEN);
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,64u);f.now=8000u;io=io_for(&f);f.stop_after=5u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED);
    assert(f.feed.state==P25_RX_FEED_STOPPED&&!f.feed.produced);
}
static void irq_and_clock_faults(void) {
    fixture f;start(&f,0u,0u);
    assert(!p25_rx_feed_irq(&f.feed,0u,0u)&&(f.feed.faults&P25_RX_FEED_BAD_IRQ));
    start(&f,0u,0u);first_irq(&f);
    assert(!p25_rx_feed_irq(&f.feed,1u,32000u)&&(f.feed.faults&P25_RX_FEED_IRQ_SEQUENCE));
    start(&f,0u,0u);first_irq(&f);
    assert(!p25_rx_feed_irq(&f.feed,2u,29999u)&&(f.feed.faults&P25_RX_FEED_IRQ_CLOCK));
    start(&f,0u,0u);first_irq(&f);
    assert(!p25_rx_feed_irq(&f.feed,2u,34001u)&&(f.feed.faults&P25_RX_FEED_IRQ_CLOCK));
    start(&f,0u,0u);first_irq(&f);assert(p25_rx_feed_irq(&f.feed,2u,32000u));
    assert(!p25_rx_feed_irq(&f.feed,1u,64000u)&&(f.feed.faults&P25_RX_FEED_OVERWRITTEN));
    start(&f,0u,0u);p25_rx_feed_io io=io_for(&f);f.now=200001u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_MISSING_IRQ));
    start(&f,0u,0u);assert(!p25_rx_feed_irq(&f.feed,1u,200001u)&&(f.feed.faults&P25_RX_FEED_MISSING_IRQ));
    start(&f,0u,0u);first_irq(&f);io=io_for(&f);f.now=34001u;f.pending=true;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_MISSING_IRQ));
    start(&f,0u,100u);first_irq(&f);io=io_for(&f);f.now=99u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_CLOCK));
    start(&f,0u,0u);first_irq(&f);io=io_for(&f);f.feed.irq_serial|=1u;f.now=8000u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_META));
    start(&f,0u,0u);first_irq(&f);f.feed.irq_serial=UINT32_MAX-1u;
    assert(!p25_rx_feed_irq(&f.feed,2u,32000u)&&(f.feed.faults&P25_RX_FEED_COUNTER));
    start(&f,0u,0u);first_irq(&f);f.feed.irq_count=UINT32_MAX/256u+1u;
    assert(!p25_rx_feed_irq(&f.feed,2u,32000u)&&(f.feed.faults&P25_RX_FEED_COUNTER));
    start(&f,0u,0u);first_irq(&f);io=io_for(&f);f.feed.produced=f.feed.consumed=UINT32_MAX-15u;
    f.feed.irq_count=UINT32_MAX/256u+1u;f.now=31900u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_COUNTER));
}
static void stale_full_and_output(void) {
    fixture f;start(&f,0u,0u);first_irq(&f);fill(&f,0u,64u);p25_rx_feed_io io=io_for(&f);f.now=8000u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);
    p25_rx_feed_chunk out,before;memset(&out,0x5a,sizeof out);before=out;f.now+=16001u;
    assert(!p25_rx_feed_pop(&f.feed,&out,f.now)&&(f.feed.faults&P25_RX_FEED_STALE));
    assert(!memcmp(&out,&before,sizeof out));
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,64u);io=io_for(&f);f.now=8000u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);f.now+=16001u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_STALE));
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,256u);assert(p25_rx_feed_irq(&f.feed,2u,32000u));
    io=io_for(&f);f.now=32000u;
    for(unsigned i=0;i<16u;++i)assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);
    f.now=36000u;fill(&f,1u,64u);
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_RING_FULL));
    assert(f.feed.produced==256u&&!f.feed.consumed);
    start(&f,0u,0u);first_irq(&f);fill(&f,0u,64u);io=io_for(&f);f.now=8000u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);
    assert(!p25_rx_feed_pop(&f.feed,(p25_rx_feed_chunk *)(void *)f.storage,f.now));
    assert(!f.feed.consumed&&p25_rx_feed_active(&f.feed));
    f.feed.storage[(f.feed.consumed/16u%16u)*56u+32u]^=1u;
    assert(!p25_rx_feed_pop(&f.feed,&out,f.now)&&(f.feed.faults&P25_RX_FEED_META));
}
static void missing_io_and_terminal(void) {
    fixture f;start(&f,0u,0u);p25_rx_feed_io io=io_for(&f);io.half_pending=NULL;
    assert(p25_rx_feed_step(&f.feed,&io,0u)==P25_RX_FEED_REVOKED&&(f.feed.faults&P25_RX_FEED_BAD_IO));
    unsigned faults=f.feed.faults;assert(!p25_rx_feed_irq(&f.feed,0u,0u));p25_rx_feed_stop(&f.feed);
    assert(f.feed.state==P25_RX_FEED_FAULT&&f.feed.faults==faults);
    assert(!p25_rx_feed_next_delay(&f.feed,0u));
    start(&f,256u,0u);first_irq(&f);fill(&f,0u,256u);assert(p25_rx_feed_irq(&f.feed,2u,32000u));
    io=io_for(&f);f.now=32000u;
    for(unsigned i=0;i<16u;++i)assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);
    assert(f.feed.state==P25_RX_FEED_DRAINING&&!p25_rx_feed_producing(&f.feed)&&p25_rx_feed_active(&f.feed));
    assert(!p25_rx_feed_next_delay(&f.feed,f.now));unsigned reads=f.reads;
    assert(!p25_rx_feed_irq(&f.feed,1u,64000u));
    assert(p25_rx_feed_step(&f.feed,NULL,f.now)==P25_RX_FEED_WAIT&&f.reads==reads);
    consume(&f);assert(f.feed.state==P25_RX_FEED_COMPLETE);
}
static void guard_deadline_and_metric_bounds(void) {
    fixture f;start(&f,0u,100u);p25_rx_feed_io io=io_for(&f);
    assert(p25_rx_feed_next_delay(&f.feed,100u)==500u);first_irq(&f);
    fill(&f,0u,64u);f.now=4099u;
    assert(p25_rx_feed_next_delay(&f.feed,f.now)==1u);
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_WAIT&&!f.reads);
    f.now=4100u;assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);
    assert(p25_rx_feed_next_delay(&f.feed,f.now)==1952u);
    consume(&f);f.feed.read_bytes=UINT32_MAX-1u;f.now=6100u;
    assert(p25_rx_feed_step(&f.feed,&io,f.now)==P25_RX_FEED_PUBLISHED);
    assert(f.feed.read_bytes==UINT32_MAX);consume(&f);
    // After stop/fault a newer epoch is required and old buffered rows vanish.
    p25_rx_feed_stop(&f.feed);p25_rx_feed_config config={2000u,16000u,0u};
    assert(p25_rx_feed_start(&f.feed,f.storage+1,P25_RX_FEED_STORAGE_BYTES,&config,18u,f.now));
    assert(!f.feed.produced&&!f.feed.consumed&&!f.feed.read_calls&&!f.feed.faults);
}
int main(void) {
    admission_and_restart();pending_torn_and_boundary();irq_and_clock_faults();
    stale_full_and_output();missing_io_and_terminal();guard_deadline_and_metric_bounds();
    continuous_and_finite(0u,0u,false);continuous_and_finite(0u,UINT32_MAX-10000u,true);
    continuous_and_finite(256u,0u,true);continuous_and_finite(4096u,UINT32_MAX-10000u,false);
    continuous_and_finite(8192u,0u,true);
    puts("Lean RX feed: continuity, finite drain, exact3-read pass and fail-closed deadlines PASS");return 0;
}
