// SPDX-License-Identifier: GPL-3.0-or-later
// Pure canonical encoding and borrowed-ledger storage. No radio or RF calls.
#define main borrowed_stream_test_main
#include "test_p25_rx_stream.c"
#undef main
#include "p25_rx_origin.h"
_Static_assert(P25_RX_STREAM_ORIGIN_MARK_BYTES==P25_RX_ORIGIN_EVENT_BYTES
    &&P25_RX_STREAM_ORIGIN_MAX_SAMPLES==P25_RX_ORIGIN_MAX_SAMPLES,"Origin encoder/storage bounds differ");

static p25_rx_origin_event status_event(void) {
    p25_rx_origin_event e={.event_tick=0x1234u,.cpu_us=0x10203040u,
        .stream_epoch=0x50607080u,.lane_epoch=0x90abcdefu,
        .read_begin_us=0x10202ff0u,.read_end_us=0x10203000u,
        .origin_irq_us=0x101fb000u,.origin_irq_count=4u,
        .delivery_input_ordinal=798u,.chunk_first_sample=784u,.nac=0x293u,
        .type=P25_RX_ORIGIN_STATUS,.duid=7u,.status=3u,.lane=9u,
        .evidence=P25_RX_ORIGIN_SELECTED|P25_RX_ORIGIN_QUALIFIED};return e;
}
static p25_rx_origin_event unit_event(void) {
    p25_rx_origin_event e=status_event();e.type=P25_RX_ORIGIN_UNIT;
    e.event_tick=(uint64_t)e.delivery_input_ordinal*6u;e.status=0u;e.lane=255u;
    e.evidence=P25_RX_ORIGIN_NATIVE_CRC;e.block_descriptor=0x10u;
    const unsigned char block[12]={0xac,0x00,0x00,0xab,0xcd,0xe1,0x23,0x30,0x50,0x99,0x5f,0xae};
    memcpy(e.data,block,sizeof block);return e;
}
static p25_rx_origin_event fault_event(void) {
    p25_rx_origin_event e={.type=P25_RX_ORIGIN_FAULT,.cpu_us=0x10203040u,
        .stream_epoch=0x50607080u,.lane_epoch=0x90abcdefu,.lane=255u,
        .data={P25_RX_ORIGIN_LANE_LOSS}};return e;
}
static void refused(p25_rx_origin_event e) {
    unsigned char out[64],before[64];memset(out,0xa5,sizeof out);memcpy(before,out,sizeof out);
    assert(!p25_rx_origin_encode(out,&e)&&!memcmp(before,out,sizeof out));
}
static void encoding(void) {
    const unsigned char expected[64]={
        0x34,0x12,0,0,0,0,0,0, 0x40,0x30,0x20,0x10, 0x80,0x70,0x60,0x50,
        0xef,0xcd,0xab,0x90, 0xf0,0x2f,0x20,0x10, 0,0x30,0x20,0x10, 0,0xb0,0x1f,0x10,
        4,0,0,0, 0x10,3,0x93,2, 1,7,3,9, 0,0,3,0,
        0,0,0,0,0,0,0,0,0,0,0,0, 0x1e,3,0,0};
    unsigned char out[64],want[64];p25_rx_origin_event e=status_event();
    assert(p25_rx_origin_encode(out,&e)&&!memcmp(out,expected,64));
    union {p25_rx_origin_event event;unsigned char bytes[sizeof(p25_rx_origin_event)];} alias;
    alias.event=e;assert(p25_rx_origin_encode(alias.bytes,&alias.event)&&!memcmp(alias.bytes,expected,64));
    assert(!p25_rx_origin_encode(NULL,&e)&&!p25_rx_origin_encode(out,NULL));
    e=unit_event();memcpy(want,expected,64);want[0]=0xb4;want[40]=2;want[42]=0;
    want[43]=255;want[46]=4;want[47]=0x10;memcpy(want+48,e.data,12);
    assert(p25_rx_origin_encode(out,&e)&&!memcmp(out,want,64));
    for(unsigned count=1;count<=3u;++count)for(unsigned index=0;index<count;++index) {
        e.block_descriptor=(uint8_t)(count<<4|index);assert(p25_rx_origin_encode(out,&e));
        assert(out[47]==e.block_descriptor&&!memcmp(out+48,e.data,12));
    }
    e=fault_event();memset(want,0,64);memcpy(want+8,expected+8,12);
    want[40]=3;want[43]=255;want[48]=1;
    assert(p25_rx_origin_encode(out,&e)&&!memcmp(out,want,64));
    for(unsigned reason=P25_RX_ORIGIN_LANE_LOSS;reason<=P25_RX_ORIGIN_CONTEXT_LOST;++reason) {
        e.data[0]=(uint8_t)reason;assert(p25_rx_origin_encode(out,&e)&&out[48]==reason);
    }
    // Forward CPU-time wrap is valid; it does not alter event sample ordinals.
    e=status_event();e.read_begin_us=UINT32_MAX-7u;e.read_end_us=2;e.cpu_us=19;
    assert(p25_rx_origin_encode(out,&e)&&out[20]==248u&&out[24]==2u&&out[8]==19u);
    e=status_event();e.evidence=1u;assert(p25_rx_origin_encode(out,&e));
    e.evidence=0u;e.lane=255u;assert(p25_rx_origin_encode(out,&e));
    e=status_event();e.chunk_first_sample=8176u;e.delivery_input_ordinal=8191u;
    e.origin_irq_count=32u;e.event_tick=8191u*6u;assert(p25_rx_origin_encode(out,&e));
}
static void encoding_refusals(void) {
    p25_rx_origin_event e;
#define BAD(member,value) do {e=status_event();e.member=(value);refused(e);} while(0)
    BAD(type,0);BAD(type,4);BAD(duid,3);BAD(nac,0x1000);BAD(source_flags,1);
    BAD(chunk_first_sample,785);BAD(chunk_first_sample,8192);BAD(delivery_input_ordinal,783);
    BAD(delivery_input_ordinal,800);BAD(origin_irq_count,3);BAD(read_end_us,0x10202fefu);
    BAD(cpu_us,0x10202fffu);BAD(status,0);BAD(status,4);BAD(evidence,4);BAD(evidence,2);
    BAD(lane,10);BAD(event_tick,798u*6u+1u);BAD(block_descriptor,0x10);BAD(data[0],1);
    e=status_event();e.evidence=0;e.lane=0;refused(e);
#undef BAD
#define BAD(member,value) do {e=unit_event();e.member=(value);refused(e);} while(0)
    BAD(evidence,0);BAD(evidence,5);BAD(lane,0);BAD(status,1);BAD(event_tick,1);
    BAD(block_descriptor,0);BAD(block_descriptor,0x11);BAD(block_descriptor,0x40);BAD(block_descriptor,0x23);
#undef BAD
#define BAD(member,value) do {e=fault_event();e.member=(value);refused(e);} while(0)
    BAD(event_tick,1);BAD(read_begin_us,1);BAD(read_end_us,1);BAD(origin_irq_us,1);BAD(origin_irq_count,1);
    BAD(chunk_first_sample,16);BAD(delivery_input_ordinal,1);BAD(nac,1);BAD(source_flags,1);
    BAD(duid,7);BAD(status,1);BAD(lane,0);BAD(evidence,4);BAD(block_descriptor,0x10);
    BAD(data[0],0);BAD(data[0],7);BAD(data[11],1);
#undef BAD
}
static void storage(void) {
    struct {unsigned char before[16],ring[8192],middle[16],ledger[15360],after[16];} memory;
    p25_rx_stream s={0};memset(&memory,0xa5,sizeof memory);
    assert(p25_rx_stream_origin_start(&s,memory.ring,8192,memory.ledger,15360,8192,2000,17,UINT32_MAX-7u));
    assert(s.marker_bytes==64u&&s.marker_schema==1u&&s.limit_halves==32u);
    unsigned char bytes[64],old[32]={0};p25_rx_origin_event e=unit_event();
    assert(p25_rx_origin_encode(bytes,&e));
    assert(!p25_rx_stream_origin_marker(&s,bytes)); // WAIT is not a published sample epoch.
    p25_rx_stream_irq(&s,1u,UINT32_MAX-7u);
    unsigned char halves[3072];memcpy(halves,memory.ledger,sizeof halves);
    assert(!p25_rx_stream_marker(&s,old)&&!s.markers);
    for(unsigned i=0;i<192u;++i) {
        bytes[8]=(unsigned char)i; // Distinct valid CPU times; source/data remain canonical.
        assert(p25_rx_stream_origin_marker(&s,bytes));
        assert(!memcmp(memory.ledger+3072u+i*64u,bytes,64u));
    }
    assert(s.markers==192u&&!memcmp(halves,memory.ledger,sizeof halves));
    unsigned char retained[12288];memcpy(retained,memory.ledger+3072u,sizeof retained);
    s.state=P25_RX_STREAM_DRAINING;
    assert(!p25_rx_stream_origin_marker(&s,bytes));
    assert(s.state==P25_RX_STREAM_FAULT&&(s.faults&P25_RX_STREAM_RING_FULL)&&s.markers==192u);
    assert(!memcmp(retained,memory.ledger+3072u,sizeof retained));
    assert(!p25_rx_stream_origin_marker(&s,bytes));p25_rx_stream_finalize(&s);assert(s.finalized);
    assert(memory.before[0]==0xa5&&memory.middle[15]==0xa5&&memory.after[0]==0xa5);
    assert(p25_rx_stream_start(&s,memory.ring,8192,memory.ledger,15360,16384,2000,19,0));
    assert(s.marker_bytes==32u&&!s.marker_schema);p25_rx_stream_irq(&s,1u,0);
    assert(!p25_rx_stream_origin_marker(&s,bytes)&&!s.markers);
    for(unsigned i=0;i<384u;++i) {old[0]=(unsigned char)i;assert(p25_rx_stream_marker(&s,old));
        assert(!memcmp(memory.ledger+3072u+i*32u,old,32u));}
    assert(!p25_rx_stream_marker(&s,old)&&s.state==P25_RX_STREAM_FAULT&&s.markers==384u);
    // A refused mode/start switch cannot change either stream or arena.
    p25_rx_stream before=s;memcpy(retained,memory.ledger+3072u,sizeof retained);
    assert(!p25_rx_stream_origin_start(&s,memory.ring,8192,memory.ledger,15360,8448,2000,17,0));
    assert(!memcmp(&before,&s,sizeof s)&&!memcmp(retained,memory.ledger+3072u,sizeof retained));
}
static void origin_clock_wrap(void) {
    fixture f;memset(&f,0,sizeof f);uint32_t origin=UINT32_MAX-10000u;
    f.now=f.origin=origin;
    assert(p25_rx_stream_origin_start(&f.stream,f.ring,8192,f.ledger,15360,8192,2000,17,origin));
    p25_rx_stream_irq(&f.stream,1u,origin);p25_rx_progress_io io=io_for(&f);unsigned completed=0;
    for(unsigned tick=500;p25_rx_stream_active(&f.stream);tick+=500u) {
        assert(tick<1100000u);f.now=origin+tick;
        if(tick/32000u>completed) {fill(&f,completed,256u);completed=tick/32000u;
            p25_rx_stream_irq(&f.stream,completed%2u?2u:1u,f.now);}
        if(completed<32u)fill(&f,completed,tick%32000u/125u);
        (void)p25_rx_stream_step(&f.stream,&io,f.now);consume(&f);
    }
    assert(f.stream.state==P25_RX_STREAM_DRAINING);consume(&f);p25_rx_stream_finalize(&f.stream);
    assert(f.stream.state==P25_RX_STREAM_COMPLETE&&f.stream.verified==8192u&&!f.stream.faults);
    assert(f.stream.marker_bytes==64u&&f.stream.marker_schema==1u);
    for(unsigned index=0;index<32u;++index) {p25_rx_stream_half half;
        assert(p25_rx_stream_half_read(&f.stream,index,&half));
        assert(half.origin_irq_us==origin+index*32000u&&half.verified_chunks==16u);}
}
int main(void) {
    encoding();encoding_refusals();storage();origin_clock_wrap();
    puts("RX origin canonical64 encoding and bounded borrowed-ledger storage: PASS");return 0;
}
