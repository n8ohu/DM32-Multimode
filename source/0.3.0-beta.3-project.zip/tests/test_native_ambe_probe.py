"""AMBE fixture/protocol and fake-transport safety tests; no device/private PCM."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest import mock
import wave
import zlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('ambe_under_test', ROOT/'scripts/native-ambe-probe.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def fixture(frames=4):
    return probe.fixture_module.make_blob(probe.fixture_module.synthetic_pcm(frames))


def make_elf(image):
    section = (0x100+len(image)+63)&~63
    data = bytearray(section+80)
    data[:52] = struct.pack('<16sHHIIIIIHHHHHH', b'\x7fELF\x01\x01\x01'+bytes(9),
                           2,252,1,probe.ENTRY,52,section,0,52,32,1,40,2,0)
    data[52:84] = struct.pack('<8I',1,0x100,probe.ENTRY,probe.ENTRY,len(image),len(image),5,4)
    data[0x100:0x100+len(image)] = image
    data[section+40:section+80] = struct.pack('<10I',0,1,6,probe.ENTRY,0x100,len(image),0,0,4,0)
    return bytes(data)


def output(frames=4):
    return bytes.fromhex('123456789abc80')*frames+bytes(256-frames*7)


def timings(frames=4):
    arrays = [[(base+step*i if i<frames else 0) for i in range(32)]
              for base,step in ((100,1),(200,1),(300,2),(400,2))]
    return struct.pack('<256I', *(v for a in arrays for v in a), *([0]*128))


def records(mode, blob=None, packed=None, ticks=None):
    values = [(1,0x23456789,0)]
    if mode:
        info = probe.fixture_info(blob or fixture());n=info['frames']
        packed = output(n) if packed is None else packed
        ticks = timings(n) if ticks is None else ticks
        a=struct.unpack('<256I',ticks)
        values += [(20,n,info['payload_crc32']),(21,12000,1),(22,n,49),
                   (24,sum(a[64:96]),max(a[64:96])),(25,60000000,2),
                   (26,zlib.crc32(packed[:n*7]),n*7),(28,zlib.crc32(ticks),1024),
                   (29,sum(a[96:128]),max(a[96:128])),(30,2048,8176)]
    return [dict(id=i,status=0,value=v,aux=a,vector=0,epc=0,epsr=0,reserved=0) for i,v,a in values]


def packet(nonce=123, mode=0, recs=None, header=None):
    recs=records(mode) if recs is None else recs
    h=dict(nonce=nonce,build_id=probe.BUILD_ID,mode=mode,total_bytes=56+32*len(recs),
           record_count=len(recs),fatal=0,guard_mask=31,initial_psr=0x80000100,
           initial_vbr=0,initial_sp=0x37c34,cpuid_words=0)
    h.update(header or {})
    raw=probe.HEADER.pack(probe.MAGIC,*(h[k] for k in probe.transport.HEADER_NAMES))
    raw+=b''.join(probe.RECORD.pack(*(r[k] for k in probe.transport.RECORD_NAMES)) for r in recs)
    return raw+struct.pack('<I',zlib.crc32(raw))


class Port:
    def __init__(self):self.buffer=bytearray();self.timeout=.02;self.closed=False
    def read(self,count):
        count=min(count,17);raw=bytes(self.buffer[:count]);del self.buffer[:count];return raw
    def close(self):self.closed=True


class Radio:
    def __init__(self,port):
        self.port=port;self.ops=[];self.memory={};self.configured=None;self.hello_count=0
        self.v6={k:v for k,v in probe.clock.MONITOR.items() if k not in ('protocol','max_payload')}
        self.v6['stack_used']=164
        self.registers={**probe.clock.COLD_CLOCKS,'UART_LCR':3,'UART_IER':128,'UART_MCR':0,
                        'CACHE_REGION':0,'TIMER2_LOAD':0xffffffff,'TIMER2_CTRL':5,'APLL':0x85040eb2}
        self.samples=[24000000]*24;self.bad_readback=False;self.fail_return=False
        self.modify_raw=lambda x:x;self.modify_records=lambda x:x;self.after_call=lambda:None
        self.fixture=fixture();self.packed=output();self.ticks=timings()
    def hello(self,retries):
        self.ops.append(('hello',retries));self.hello_count+=1
        if self.fail_return:raise OSError('No monitor return')
        return 7,1032
    def configure(self,board):
        self.ops.append(('configure',board))
        if board is not None:raise AssertionError('CONFIG writes forbidden')
        self.configured={'id':1}
    def timer_hz(self,span):self.ops.append(('timer_hz',span));return self.samples.pop(0)
    def peek(self,address,count):
        self.ops.append(('peek',address,count))
        if count>512:raise AssertionError('Oversized read')
        for key,a in {**probe.clock.CLOCK_REGISTERS,**probe.clock.UART_REGISTERS,**probe.clock.OTHER_REGISTERS}.items():
            if address==a:
                if count!=4:raise AssertionError('Consuming/ambiguous MMIO read')
                return self.registers[key].to_bytes(4,'little')
        raw=bytes(self.memory[address+i] for i in range(count))
        return bytes([raw[0]^1])+raw[1:] if self.bad_readback else raw
    def poke(self,address,raw):
        if len(raw)>512:raise AssertionError('Oversized write')
        self.ops.append(('poke',address,bytes(raw)));self.setmem(address,raw)
    def setmem(self,address,raw):self.memory.update({address+i:b for i,b in enumerate(raw)})
    def jump(self,address):
        self.ops.append(('call',address));args=bytes(self.memory[probe.ARGS+i] for i in range(64))
        nonce,mode=struct.unpack_from('<2I',args,8)
        if mode:
            self.setmem(probe.COOKIE,bytes(4))
            self.setmem(probe.AMBE['output'][0],self.packed)
            self.setmem(probe.AMBE['frame_ticks'][0],self.ticks)
        else:self.setmem(probe.COOKIE,struct.pack('<3I',probe.COOKIE_MAGIC,nonce,probe.BUILD_ID))
        recs=records(mode,self.fixture,self.packed,self.ticks)
        self.port.buffer.extend(self.modify_raw(packet(nonce,mode,self.modify_records(recs))))
        self.after_call()


class AmbeProbeTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);self.directory=Path(tmp.name)
        native=copy.deepcopy(probe.NATIVE);backup=bytes(0x100000);native['program_sha256']=probe.digest(backup)
        for key in ('code','tables'):native[key]['sha256']=probe.digest(bytes(native[key]['bytes']))
        patch=mock.patch.object(probe,'NATIVE',native);patch.start();self.addCleanup(patch.stop)
        self.image=b'\x00\x50'*600;elf=make_elf(self.image)
        self.manifest=dict(schema=probe.SCHEMA,build_id=probe.BUILD_ID,entry=probe.ENTRY,ram_start=probe.ENTRY,
            ram_end=probe.RAM_END,args_address=probe.ARGS,allowed_modes=[0,1],source_commit='a'*40,
            stub_source_sha256=probe.transport.STUB_SHA256,native=native,ambe=copy.deepcopy(probe.AMBE),
            ranges={**copy.deepcopy(probe.FIXED),'image':[probe.ENTRY,probe.ENTRY+len(self.image)],'bss':[0x45000,0x45100]},
            image=dict(file='probe.bin',bytes=len(self.image),sha256=probe.digest(self.image)),
            elf=dict(file='probe.elf',bytes=len(elf),sha256=probe.digest(elf)))
        (self.directory/'probe.bin').write_bytes(self.image);(self.directory/'probe.elf').write_bytes(elf)
        self.backup=self.directory/'original.bin';self.backup.write_bytes(backup)
        self.path=self.directory/'manifest.json';self.save();self.bundle=probe.load_bundle(self.path,self.backup)
    def save(self):self.path.write_text(json.dumps(self.manifest))
    def run_fake(self,mode=0,radio=None,port=None,**kwargs):
        port=port or Port();radio=radio or Radio(port)
        result=probe.execute(self.bundle,mode,'FAKE',123,resume=True,radio_factory=lambda _:radio,
                             port_factory=lambda _:port,log=lambda _:None,**kwargs)
        return result,radio,port
    def smoke(self):
        result,radio,port=self.run_fake()
        return dict(schema=probe.SCHEMA,dry_run=False,manifest=self.bundle['manifest'],**result),radio,port
    def encode(self,change=None,**kwargs):
        proof,radio,_=self.smoke();port=Port();radio.port=port
        if change:change(radio)
        result,radio,port=self.run_fake(1,radio,port,proof=proof,fixture=radio.fixture,**kwargs)
        return result,radio,port

    def test_manifest_layout_and_sealed_native_buffers(self):
        self.assertEqual(self.bundle['ranges']['ambe_encoder_state'],(0x48000,0x49c40))
        self.assertEqual(self.bundle['ranges']['ambe_decoder_state'],(0x4b3e0,0x4cc20))
        self.assertEqual(len(self.bundle['blobs']['code']),0x14600)
    def test_manifest_layout_version_and_unknown_fields_refused(self):
        for key,value in [('entry',0x38000),('allowed_modes',[0,1,2]),('schema','other'),('extra',1)]:
            with self.subTest(key=key):
                old=copy.deepcopy(self.manifest);self.manifest[key]=value;self.save()
                with self.assertRaises(probe.ProbeError):probe.load_bundle(self.path,self.backup)
                self.manifest=old
    def test_artifact_or_backup_corruption_refused(self):
        (self.directory/'probe.bin').write_bytes(bytes(len(self.image)))
        with self.assertRaisesRegex(probe.ProbeError,'SHA256'):probe.load_bundle(self.path,self.backup)
        (self.directory/'probe.bin').write_bytes(self.image);self.backup.write_bytes(b'X'+bytes(0xfffff))
        with self.assertRaisesRegex(probe.ProbeError,'backup SHA'):probe.load_bundle(self.path,self.backup)
    def test_elf_wrong_entry_or_load_refused(self):
        for offset,value in [(24,0x38000),(60,0x30000)]:
            raw=bytearray(make_elf(self.image));struct.pack_into('<I',raw,offset,value)
            with self.assertRaises(probe.ProbeError):probe.transport.validate_elf(bytes(raw),self.image,self.manifest['ranges'])
    def test_fixture_is_deterministic_and_initial_four_are_silence_then_tone(self):
        a=fixture();b=fixture();self.assertEqual(a,b);self.assertEqual(a[64:704],bytes(640))
        self.assertTrue(any(a[704:]));self.assertEqual(probe.fixture_info(a)['frames'],4)
        self.assertEqual(probe.fixture_info(fixture(32))['payload_bytes'],10240)
    def test_fixture_rejects_bad_crc_count_stride_reserved_and_tail(self):
        for offset,value in [(12,0),(12,33),(16,319),(32,1)]:
            raw=bytearray(fixture());struct.pack_into('<I',raw,offset,value);struct.pack_into('<I',raw,60,zlib.crc32(raw[:60]))
            with self.assertRaises(probe.ProbeError):probe.fixture_info(bytes(raw))
        raw=bytearray(fixture());raw[-1]^=1
        with self.assertRaises(probe.ProbeError):probe.fixture_info(bytes(raw))
        with self.assertRaises(probe.ProbeError):probe.fixture_info(fixture()+b'\0')
    def test_wav_requires_existing_mono_8k16_format_no_resampling(self):
        path=self.directory/'source.wav'
        for rate in (16000,8000):
            with wave.open(str(path),'wb') as out:
                out.setparams((1,2,rate,0,'NONE','not compressed'));out.writeframes(bytes(640))
            if rate==16000:
                with self.assertRaises(ValueError):probe.fixture_module.source_pcm(path,0,2,True)
            else:self.assertEqual(probe.fixture_module.source_pcm(path,0,2,True),bytes(640))
    def test_args_bind_nonzero_prior_smoke_nonce(self):
        raw=probe.make_args(123,1,456);self.assertEqual(len(raw),64)
        self.assertEqual(struct.unpack_from('<I',raw,28)[0],456)
        self.assertEqual(zlib.crc32(raw[:60]),int.from_bytes(raw[60:],'little'))
        for args in [(0,0,0),(True,0,0),(123,True,456),(123,1,0),(123,0,1)]:
            with self.assertRaises(probe.ProbeError):probe.make_args(*args)
    def test_smoke_one_call_no_native_fixture_upload_and_exact_return(self):
        result,radio,port=self.run_fake();self.assertTrue(port.closed)
        self.assertTrue(result['monitor_returned'] and result['clock_restored'])
        self.assertEqual(sum(x[0]=='call' for x in radio.ops),1)
        writes=[(x[1],len(x[2])) for x in radio.ops if x[0]=='poke']
        self.assertTrue(all(probe.ENTRY<=a<a+n<=probe.ENTRY+len(self.image) or a==probe.ARGS for a,n in writes))
    def test_encode_outputs_timing_and_clock_restoration(self):
        result,radio,port=self.encode();self.assertTrue(port.closed)
        self.assertEqual(len(result['encoded_parameters_hex']),4)
        self.assertEqual(result['benchmark']['native_sum']['ticks'],[300,302,304,306])
        self.assertFalse(result['production_audio_deadline_measured'])
        self.assertEqual(sum(x[0]=='call' for x in radio.ops),2)
        self.assertTrue(all(x[1] is None for x in radio.ops if x[0]=='configure'))
        for op in radio.ops:
            if op[0]=='poke':
                table=probe.NATIVE['tables']
                table_write=table['address']<=op[1] and op[1]+len(op[2])<=table['address']+table['bytes']
                self.assertFalse(0x14000000<=op[1]<0x20000000 and not table_write)
    def test_zero_parameters_are_observations_not_invalid_voice_claim(self):
        result,_,_=self.encode(lambda r:setattr(r,'packed',bytes(256)))
        self.assertEqual(result['all_zero_parameter_frames'],4)
        self.assertFalse(result['speech_quality_qualified'])
    def test_missing_or_changed_live_smoke_cookie_refused_before_call(self):
        proof,radio,_=self.smoke();port=Port();radio.port=port
        radio.setmem(probe.COOKIE,bytes(12));before=len([x for x in radio.ops if x[0]=='call'])
        with self.assertRaisesRegex(probe.ProbeError,'cookie'):
            self.run_fake(1,radio,port,proof=proof,fixture=radio.fixture)
        self.assertEqual(len([x for x in radio.ops if x[0]=='call']),before);self.assertTrue(port.closed)
    def test_proof_different_manifest_refused_before_open(self):
        proof,_,_=self.smoke();proof['manifest']=dict(proof['manifest'],source_commit='b'*40)
        factory=mock.Mock(side_effect=AssertionError('must not open'))
        with self.assertRaises(probe.ProbeError):
            probe.execute(self.bundle,1,'FAKE',123,True,proof,fixture(),port_factory=factory,radio_factory=lambda _:None)
        factory.assert_not_called()
    def test_cold_clock_or_dlab_or_monitor_identity_refused_without_call(self):
        for change in [lambda r:r.registers.update(BPLL=0),lambda r:r.registers.update(UART_LCR=0x83),
                       lambda r:r.v6.update(image=1)]:
            port=Port();radio=Radio(port);change(radio)
            with self.assertRaises(probe.ProbeError):self.run_fake(radio=radio,port=port)
            self.assertFalse(any(x[0]=='call' for x in radio.ops));self.assertTrue(port.closed)
    def test_stage_readback_failure_never_calls(self):
        port=Port();radio=Radio(port);radio.bad_readback=True
        with self.assertRaises(probe.ProbeError):self.run_fake(radio=radio,port=port)
        self.assertFalse(any(x[0]=='call' for x in radio.ops))
    def test_fault_aborts_and_preserves_evidence_after_monitor_return(self):
        def change(radio):
            def fail(recs):
                recs=recs[:4];recs[-1].update(status=3,value=1,aux=0x47000,vector=4,epc=0x16f3c,epsr=0x80000000)
                return recs
            radio.modify_records=fail
            radio.modify_raw=lambda raw:packet(123,1,fail(records(1)),{'fatal':2})
        with self.assertRaises(probe.ProbeError) as caught:self.encode(change)
        error=caught.exception;self.assertTrue(error.monitor_returned and error.clock_restored)
        self.assertEqual(error.target_result['records'][-1]['epc'],0x16f3c)
        self.assertEqual(error.call_operations_requested,1)
    def test_post_return_output_corruption_retains_restoration_evidence(self):
        def change(radio):radio.after_call=lambda:radio.setmem(probe.AMBE['output'][0],b'\xff')
        with self.assertRaisesRegex(probe.ProbeError,'CRC') as caught:self.encode(change)
        self.assertTrue(caught.exception.monitor_returned and caught.exception.clock_restored)
    def test_bad_packing_unused_output_and_timing_entries_refused(self):
        for kind in ('pad','output-tail','timing-unused','timing-tail','sum'):
            def change(radio,kind=kind):
                if kind.startswith('timing') or kind=='sum':
                    data=bytearray(radio.ticks);offset={'timing-unused':4*4,'timing-tail':512,'sum':64*4}[kind]
                    struct.pack_into('<I',data,offset,1);radio.ticks=bytes(data)
                else:
                    data=bytearray(radio.packed);data[6 if kind=='pad' else 40]|=1;radio.packed=bytes(data)
            with self.subTest(kind=kind),self.assertRaises(probe.ProbeError):self.encode(change)
    def test_clock_restoration_mismatch_is_fatal_and_no_recall(self):
        def change(radio):radio.after_call=lambda:radio.registers.update(CTRL=0xc0000004)
        with self.assertRaises(probe.ProbeError) as caught:self.encode(change)
        self.assertFalse(caught.exception.clock_restored);self.assertEqual(caught.exception.call_operations_requested,1)
    def test_truncated_packet_times_out_once_and_checks_return(self):
        port=Port();radio=Radio(port);radio.modify_raw=lambda raw:raw[:51]
        with self.assertRaises(Exception) as caught:self.run_fake(radio=radio,port=port,timeout=.1)
        self.assertEqual(sum(x[0]=='call' for x in radio.ops),1)
        self.assertTrue(caught.exception.monitor_returned and port.closed)
    def test_packet_crc_nonce_count_order_and_guard_refusals(self):
        for raw in [packet(nonce=124),packet(header={'guard_mask':30}),packet(header={'record_count':13,'total_bytes':472}),
                    packet(recs=[dict(records(0)[0],id=20)])]:
            with self.assertRaises(probe.ProbeError):probe.parse_packet(raw,123,0)
        raw=bytearray(packet());raw[-1]^=1
        with self.assertRaises(probe.ProbeError):probe.parse_packet(bytes(raw),123,0)
    def test_write_allowlist_is_exact_whole_region_not_subspan(self):
        radio=Radio(Port())
        with self.assertRaises(probe.ProbeError):probe.write_verified(radio,probe.ENTRY,b'x',{(probe.ENTRY,probe.ENTRY+4)})
        self.assertFalse(any(x[0]=='poke' for x in radio.ops))
    def test_cli_dry_run_never_loads_serial(self):
        report=self.directory/'dry.json'
        args=['native-ambe-probe.py','--manifest',str(self.path),'--backup',str(self.backup),'--output',str(report)]
        with mock.patch.object(sys,'argv',args),mock.patch.object(probe.transport,'load_stub',side_effect=AssertionError('serial forbidden')),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(probe.main(),0)
        data=json.loads(report.read_text());self.assertTrue(data['dry_run']);self.assertFalse(data['serial_opened'])


if __name__ == '__main__':
    unittest.main()
