# SPDX-License-Identifier: GPL-3.0-or-later
"""Execute the dedicated passive field image against HAL mocks; no devices."""
import importlib.util
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build/omaha-rx-adapter'
UPSTREAM = ROOT / 'external/RadioFoundry/RadioFoundry'


def run(args):
    result = subprocess.run([str(a) for a in args], cwd=ROOT, capture_output=True,
                            text=True, timeout=120)
    if result.returncode:
        raise AssertionError(f'{args[0]} exited {result.returncode}\n{result.stdout}\n{result.stderr}')
    return result.stdout


class OmahaReceiveAdapter(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        BUILD.mkdir(parents=True, exist_ok=True)
        harness = (ROOT/'tests/test_live_adapter.c').read_text()
        prefix = harness.split('static void reset(void) {', 1)[0]
        flash = harness.split('static uint8_t pref_flash_mem[32768];', 1)[1].split(
            'static void check_stored_profile(', 1)[0]
        prefix = prefix.replace('../src/firmware/', '').replace(
            '../external/RadioFoundry/RadioFoundry/', UPSTREAM.as_posix()+'/')
        # The general UHF lab harness omits VHF. Match the real DM32 board's
        # supported136..174MHz receive band for this VHF field profile.
        prefix = prefix.replace('bands[]={{400000000,480000000,true}',
            'bands[]={{136000000,174000000,true},{400000000,480000000,true}')
        prefix = prefix.replace('.band_count=3,', '.band_count=4,')
        source = BUILD/'omaha-adapter.c'
        source.write_text(prefix+'\nstatic uint8_t pref_flash_mem[32768];'+flash+
                          (ROOT/'tests/test_omaha_rx_adapter.c').read_text(), newline='\n')
        includes = ['-I'+str(UPSTREAM/p) for p in ('hal', 'core', 'drivers', 'boards/dm32',
                    'platform/hrc7000', 'platform/hrc7000/freertos',
                    'third_party/FreeRTOS-Kernel/include')]
        sources = ['p25_demod', 'p25_rx', 'p25_tsdu', 'p25_trunking', 'p25_trunking_search',
            'p25_trunking_isp', 'p25_trunking_burst', 'p25_trunking_backend', 'p25_trunking_session',
            'p25_trunking_access', 'p25_trunking_slot', 'p25_rx_progress', 'p25_rx_stream',
            'p25_rx_feed', 'p25_trunking_preload', 'p25_trunking_lab_exchange',
            'p25_trunking_lab_voice', 'p25_trunking_lab_ptt', 'p25_trunking_lab_attach',
            'p25_data', 'p25_call', 'p25_live_tx', 'p25_live_frame', 'p25_test_tx',
            'radio_microapps', 'same_demod', 'same_protocol', 'radio_applet_store',
            'radio_applet_vm', 'radio_applets', 'radio_pcm_engine', 'radio_pcm_fm_tx']
        cls.binary = BUILD/'omaha-adapter.exe'
        flags = ['-DDM32_OMAHA_RX_ONLY=1', '-DDM32_LAB_DIAGNOSTICS=0',
                 '-DDM32_TRUNK_SUBSCRIBER=1', '-DCONFIG_DMR=1', '-DBENCH_GIT="omaha-test"']
        run(['gcc', '-std=gnu11', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
             '-Wno-unused-parameter', '-Wno-unused-function', '-Wno-unused-variable',
             '-ffunction-sections', '-fdata-sections', '-Wl,--gc-sections', *flags,
             '-Itests/diag-stubs', '-Itests', '-Isrc/firmware', '-Ifixtures/p25-1011',
             *includes, source, 'tests/diag-stubs/radio_dmr_stub.c',
             'tests/diag-stubs/radio_pcm_stub.c',
             *['src/firmware/'+s+'.c' for s in sources], '-o', cls.binary])
        # The pinned OP25 encoder supplies independent CRC/BCH/trellis/interleave.
        spec = importlib.util.spec_from_file_location('omaha_oracle', ROOT/'scripts/generate-p25-trunking-fixture.py')
        oracle = importlib.util.module_from_spec(spec); spec.loader.exec_module(oracle)
        ref = oracle.load_reference()
        controls = [172287500, 172600000, 173762500, 154680000, 154950000, 155872500, 156142500]
        spacing = 2500
        for i, hz in enumerate(controls):
            base, nac, site = (171437500, 0xb85, 70) if i < 3 else (154122500, 0xb83, 83)
            channel = 0x1000 | ((hz-base)//spacing)
            blocks = [(0x34, 1 << 60 | 5 << 56 | (spacing//125) << 32 | base//5),
                ref['format_rfss_status_broadcast'](0, 1, 1, 0xb8f, 1, site, channel, 0x70),
                ref['format_network_status_broadcast'](0, 0xbee00, 0xb8f, channel, 0x70)]
            (BUILD/f'site-{i}.bin').write_bytes(oracle.encode_tsdu(ref, nac, blocks)[0])
            if not i:
                bad = list(blocks)
                bad[1] = ref['format_rfss_status_broadcast'](0, 1, 1, 0xb8f, 1, 83, channel, 0x70)
                (BUILD/'wrong-site.bin').write_bytes(oracle.encode_tsdu(ref, nac, bad)[0])
                (BUILD/'wrong-nac-site.bin').write_bytes(oracle.encode_tsdu(ref, 0xb83, blocks)[0])
        ambt_spec = importlib.util.spec_from_file_location('omaha_ambt_oracle', ROOT/'tests/p25_ambt_fixture.py')
        ambt_ref = importlib.util.module_from_spec(ambt_spec); ambt_spec.loader.exec_module(ambt_ref)
        (BUILD/'iden-only.bin').write_bytes(ambt_ref.tsbk(0x34,
            1 << 60 | 5 << 56 | (spacing//125) << 32 | 171437500//5))
        control_channel = 0x1000 | ((172287500-171437500)//spacing)
        for name, opcode, fields in [
                ('ambt-site', 0x3a, {'downlink': control_channel}),
                ('ambt-network', 0x3b, {'downlink': control_channel}),
                ('ambt-grant', 0, {}), ('ambt-other-group', 0, {'group': 3076}),
                ('ambt-wrong-nac', 0x3a, {'nac': 0xb83, 'downlink': control_channel})]:
            (BUILD/(name+'.bin')).write_bytes(ambt_ref.ambt(opcode, **fields))
        header, blocks = ambt_ref.ambt_blocks(0x3a, downlink=control_channel)
        damaged = bytearray(blocks[0]); damaged[0] ^= 1
        (BUILD/'ambt-corrupt.bin').write_bytes(ambt_ref.wire_blocks(header, [bytes(damaged)]))
        for name, nac in [('activity', 0xb85), ('foreign-activity', 0xb83)]:
            (BUILD/(name+'.bin')).write_bytes(oracle.encode_tsdu(ref, nac, [(0x20, 0)])[0])
        for name, nac, group, options in [('grant', 0xb85, 3075, 0),
                ('other-group', 0xb85, 3076, 0), ('wrong-nac', 0xb83, 3075, 0),
                ('encrypted', 0xb85, 3075, 0x40), ('hummel-grant', 0xb83, 3075, 0)]:
            arg = options << 56 | 0x1000 << 40 | group << 24 | 1
            (BUILD/(name+'.bin')).write_bytes(oracle.encode_tsdu(ref, nac, [(0, arg)])[0])

    def case(self, name):
        self.assertIn('Omaha receive '+name+': PASS', run([self.binary, name, BUILD]))

    def test_boot_ignores_saved_tx_profile_and_preserves_all_settings_bytes(self): self.case('boot')
    def test_boot_overrides_saved_dmr_and_disabled_system_start_without_writing(self): self.case('dmr-boot')
    def test_blank_codeplug_still_starts_fixed_passive_receiver_without_writing(self): self.case('empty-boot')
    def test_saved_empty_talkgroup_scan_list_does_not_block_fixed_receiver(self): self.case('scan-boot')
    def test_all_control_candidates_require_exact_site_and_fresh_metadata(self): self.case('search')
    def test_only_clear_tg3075_follows_and_returns_to_control(self): self.case('follow')
    def test_ptt_commands_menu_and_mutated_inhibit_cannot_arm_tx(self): self.case('deny')
    def test_fallback_uses_its_own_nac_identity_and_returns_to_that_site(self): self.case('fallback')
    def test_lost_fallback_wraps_to_ndot_without_accepting_previous_site_state(self): self.case('wrap')
    def test_recorder_fault_recovers_same_control_with_fresh_map_and_stays_trunked(self): self.case('recover-fault')
    def test_recorder_gap_recovers_same_control_with_fresh_map_and_stays_trunked(self): self.case('recover-gap')
    def test_repeated_receiver_setup_failure_advances_only_after_bounded_cooldowns(self): self.case('recover-setup')
    def test_initial_receiver_setup_failure_gets_delayed_passive_retry(self): self.case('initial-setup')
    def test_operator_stop_cancels_pending_receive_recovery(self): self.case('recovery-cancel')
    def test_power_off_cancels_pending_receive_recovery(self): self.case('recovery-poweroff')
    def test_unrelated_radio_fault_cannot_be_revived_by_receive_recovery(self): self.case('recovery-unrelated-fault')
    def test_valid_control_activity_keeps_lock_but_wrong_nac_cannot_refresh(self): self.case('activity')
    def test_native_ambt_metadata_acquires_and_passively_follows_only_selected_group(self): self.case('ambt')
    def test_filtered_ambt_grants_keep_control_lock_without_authorizing_voice(self): self.case('ambt-activity')


if __name__ == '__main__':
    unittest.main(verbosity=2)
