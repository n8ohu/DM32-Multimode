# SPDX-License-Identifier: GPL-3.0-or-later
"""Versioned origin events without changing the ordinary RXSTREAM32 ABI."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-rx-origin'
BUILD.mkdir(parents=True,exist_ok=True)
BINARY=BUILD/('origin.exe' if sys.platform=='win32' else 'origin')
subprocess.run(['gcc','-std=c11','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror',
    '-Wshadow','-Wstrict-aliasing=2','-pedantic','-Isrc/firmware','tests/test_p25_rx_origin.c',
    'src/firmware/p25_rx_stream.c','-o',str(BINARY)],cwd=ROOT,check=True)
subprocess.run([str(BINARY)],cwd=ROOT,check=True,timeout=20)
