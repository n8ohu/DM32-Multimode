"""Actual serial controller + bytecode VM + two-bank flash store; no hardware."""
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]


class AppletControllerTest(unittest.TestCase):
    def test_install_run_restore_failures_and_flash_ownership(self):
        binary=ROOT/'build'/'applets'/'applet-controller-test.exe'
        binary.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Wshadow','-Werror','-pedantic',
                        '-Isrc/firmware','tests/test_applets_controller.c',
                        'src/firmware/radio_applets.c','src/firmware/radio_applet_vm.c',
                        'src/firmware/radio_applet_store.c','-o',str(binary)],cwd=ROOT,check=True)
        result=subprocess.run([str(binary)],cwd=ROOT,check=True,capture_output=True,text=True)
        self.assertIn('integration passed',result.stdout)


if __name__=='__main__':unittest.main()
