# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent OP25 wire factory; no production firmware encoder is imported.

AMBT fields follow Viavi/Aeroflex figures 5, 6 and 19. In particular, an
explicit group grant has ONE data block and its options are HEADER octet 8.
The pinned OP25 factory supplies BCH, trellis/interleave and native CRCs.
"""
import ast
import hashlib
from pathlib import Path
import struct
import sys
from types import ModuleType

ROOT = Path(__file__).resolve().parents[1]
_op = None


def reference():
    global _op
    if _op is None:
        # This tracked, reviewed reference is present in target CI without an
        # optional full OP25 checkout. Skip its top-level default-file open.
        path=ROOT / "research/references/boatbod/op25/op25/gr-op25_repeater/apps/tx/p25craft.py"
        source=path.read_text(encoding="utf-8")
        if hashlib.sha256(source.encode()).hexdigest() != "27079a321f75bda5db8d3ef6dd30d65992dbf8b6c73a2c608b43f3f745e9e2d9":
            raise ValueError("OP25 p25craft source differs from the reviewed pin")
        functions=[node for node in ast.parse(source,filename=str(path)).body if isinstance(node,ast.FunctionDef)]
        module=ModuleType("p25craft_ambt_fixture")
        module.__dict__.update(sys=sys,struct=struct,quiet=True,flip=0,outfile=None)
        exec(compile(ast.Module(body=functions,type_ignores=[]),str(path),"exec"),module.__dict__)
        module.text_out = lambda *_: None
        _op = module
    return _op


def packed(symbols):
    return bytes(sum(symbols[i+j] << (6-2*j) for j in range(4))
                 for i in range(0, len(symbols), 4))


def wire_blocks(header, blocks, *, nac=0xB85, status=2):
    """Encode supplied native blocks, retaining even deliberately bad CRCs."""
    op = reference()
    symbols = op.start_packet(nac, 12)
    for block in [header, *blocks]:
        assert len(block) == 12
        symbols.extend(op.data_interleave(op.trellis_1_2_encode(
            op.split_dibits(int.from_bytes(block, "big"), 48))))
    statuses = (status,) * ((56 + (len(blocks)+1)*98 + 34)//35)
    return packed(op.insert_status(symbols, statuses))


def ambt_blocks(opcode, *, wacn=0xBEE00, system=0xB8F, rfss=1, site=70,
                downlink=0x1000, uplink=0x2000, group=3075, source=1,
                options=0, io=1, sap=61, mfid=0, data=None):
    """Return independent header/data blocks for the bounded supported forms."""
    op = reference()
    if data is None:
        if opcode == 0x3B:
            data = ((wacn << 44) | (downlink << 24) | (uplink << 8) | 0xF0).to_bytes(8, "big")
        elif opcode == 0x3A:
            data = ((rfss << 56) | (site << 48) | (downlink << 32)
                    | (uplink << 16) | (0xF0 << 8)).to_bytes(8, "big")
        else:
            data = ((downlink << 32) | (uplink << 16) | group).to_bytes(8, "big")
    assert (len(data)+4) % 12 == 0
    count = (len(data)+4)//12
    llid = source if opcode == 0 else system
    dbtm = options << 8 if opcode == 0 else 0
    header = op.construct_ambth(io, sap, mfid, llid, count, opcode, dbtm).to_bytes(12, "big")
    packet = data + op.crc_32(int.from_bytes(data, "big"), len(data)*8).to_bytes(4, "big")
    return header, [packet[i:i+12] for i in range(0, len(packet), 12)]


def ambt(opcode, *, nac=0xB85, status=2, **fields):
    header, blocks = ambt_blocks(opcode, **fields)
    return wire_blocks(header, blocks, nac=nac, status=status)


def repair_header(header):
    op = reference()
    return bytes(header[:10]) + op.crc_ccitt(int.from_bytes(header[:10], "big")).to_bytes(2, "big")


def tsbk(opcode, argument, *, nac=0xB85):
    op = reference()
    frames = []
    previous = op.print_spec
    op.print_spec = lambda symbols: frames.append(packed(symbols))
    try:
        op.construct_tsdu(nac, 2, 1, 0, opcode, argument)
    finally:
        op.print_spec = previous
    return frames[0]
