// SPDX-License-Identifier: GPL-3.0-or-later
// Separate, unqualified pre-NID witness; real native parser and CRC selection.
#include <assert.h>
#include <limits.h>
#include <string.h>
#include "../src/firmware/p25_demod.c"

#define EARLY_CAPACITY 256u
typedef struct {
    uint64_t ordinary[EARLY_CAPACITY][9],early[EARLY_CAPACITY][9];
    unsigned ordinary_count,early_count,frames,hash,discontinuities,current;
    uint64_t input_tick;
} early_output;
static void record(uint64_t out[9],const p25_demod_status *event,const early_output *context) {
    out[0]=event->sample_tick;out[1]=event->stream_epoch;out[2]=event->lane_epoch;
    out[3]=event->nac;out[4]=event->status;out[5]=event->lane;
    out[6]=(event->selected?1u:0u)|(event->qualified?2u:0u)|((unsigned)event->duid<<8);
    out[7]=context->current;out[8]=context->input_tick;
}
static void ordinary(const p25_demod_status *event,void *context) {
    early_output *out=context;assert(out->ordinary_count<EARLY_CAPACITY);
    record(out->ordinary[out->ordinary_count++],event,out);
}
static void early(const p25_demod_status *event,void *context) {
    early_output *out=context;assert(out->early_count<EARLY_CAPACITY);
    assert(event->selected&&!event->qualified&&event->duid==7u&&event->lane<10u);
    record(out->early[out->early_count++],event,out);
}
static void frame(const p25_rx *received,void *context) {
    early_output *out=context;++out->frames;
    for(unsigned i=0;i<received->frame_bytes;++i) {out->hash^=received->frame[i];out->hash*=16777619u;}
}
static void begin_unit(p25_demod *d,const unsigned char *wire) {
    p25_rx_gap(&d->lane[0].rx);d->lane[0].gain=1000;
    d->selected_qualified=false;d->first_status_pending=false;
    for(unsigned i=0;i<24u;++i)(void)p25_rx_push(&d->lane[0].rx,
        (wire[i/4u]>>(6u-2u*(i%4u)))&3u);
}
static void feed_unit(p25_demod *d,early_output *out,const unsigned char *wire,
                     unsigned end,bool observe) {
    static const int16_t level[4]={1000,3000,-1000,-3000};
    begin_unit(d,wire);
    for(unsigned i=24u;i<end;++i) {
        out->current=i;out->input_tick=10000u+10u*i;
        d->input_tick=out->input_tick;d->decision_valid=true;d->decision_tick=out->input_tick;
        int16_t value=level[(wire[i/4u]>>(6u-2u*(i%4u)))&3u];
        if(observe)symbol_observed(d,&d->lane[0],value,early,out);
        else symbol(d,&d->lane[0],value);
    }
}
static void seed(p25_demod *d,early_output *out,const unsigned char *wire) {
    p25_demod_init(d);memset(out,0,sizeof *out);
    d->status_emit=ordinary;d->status_context=out;d->have_input_time=true;d->stream_epoch=11u;
    feed_unit(d,out,wire,180u,true);
    assert(!out->early_count&&d->selected_lane==UINT8_MAX&&d->pending_ticks&&!d->pending_errors);
    status_select(d);d->pending_ticks=0;
    assert(d->selected_lane==0u&&d->selected_nac==0x293u&&d->lane_epoch==1u);
    out->ordinary_count=0;
}
static void equal_state(p25_demod left,p25_demod right) {
    left.status_context=right.status_context=NULL;
    assert(!memcmp(&left,&right,sizeof left));
}
unsigned p25_early_units(const unsigned char clean[45],const unsigned char foreign[45],
                         const unsigned char *voice,unsigned voice_bytes) {
    assert(voice_bytes>=15u);p25_demod d;early_output out;
    seed(&d,&out,clean);
    p25_demod ordinary_d=d;early_output ordinary_out=out;ordinary_d.status_context=&ordinary_out;
    feed_unit(&d,&out,clean,180u,true);feed_unit(&ordinary_d,&ordinary_out,clean,180u,false);
    assert(out.early_count==1u&&out.ordinary_count==5u);
    assert(!memcmp(out.ordinary,ordinary_out.ordinary,sizeof out.ordinary));
    equal_state(d,ordinary_d);
    assert(out.early[0][0]==10350u&&out.early[0][7]==35u&&out.early[0][6]==0x701u);
    assert(out.ordinary[0][0]==out.early[0][0]&&out.ordinary[0][7]==56u
        &&out.ordinary[0][6]==0x703u&&out.ordinary[0][8]-out.early[0][8]==210u);

    unsigned char bad[45];memcpy(bad,clean,sizeof bad);
    bad[6]^=0xf0u;bad[14]^=0x40u; // Four BCH errors plus parity exceed total4.
    const unsigned char *rejected[3]={foreign,voice,bad};
    for(unsigned n=0;n<3u;++n) {
        seed(&d,&out,clean);feed_unit(&d,&out,rejected[n],57u,true);
        assert(out.early_count==1u&&out.early[0][3]==0x293u&&out.early[0][6]==0x701u);
        assert(out.ordinary_count==1u&&out.ordinary[0][4]==0u&&!(out.ordinary[0][6]&2u));
        assert(d.selected_lane==UINT8_MAX&&!d.first_status_pending);
    }
    // Corrected NID parity preserves the later qualified event, never upgrading
    // or mutating the already delivered early record.
    memcpy(bad,clean,sizeof bad);bad[14]^=0x40u;
    seed(&d,&out,clean);feed_unit(&d,&out,bad,57u,true);
    assert(out.early_count==1u&&out.ordinary_count==1u&&out.early[0][6]==0x701u
        &&out.ordinary[0][6]==0x703u&&d.lane[0].rx.nid_corrected==1u);

    // Explicit lane loss, mixed conventional input, sample gap, epoch change,
    // reset and timestamp overflow cannot carry the previous selection onward.
    for(unsigned loss=0;loss<6u;++loss) {
        seed(&d,&out,clean);
        if(loss==0u)status_lost(&d);
        else if(loss==1u)p25_demod_push(&d,0,frame,&out);
        else if(loss==2u)assert(!p25_demod_push_at_observed(&d,0,d.input_tick+12u,11u,frame,ordinary,early,&out));
        else if(loss==3u)assert(!p25_demod_push_at_observed(&d,0,d.input_tick+6u,12u,frame,ordinary,early,&out));
        else if(loss==4u)p25_demod_gap(&d);
        else assert(!p25_demod_push_at_observed(&d,0,UINT64_MAX,11u,frame,ordinary,early,&out));
        assert(d.selected_lane==UINT8_MAX);
        d.status_emit=ordinary;d.status_context=&out;d.have_input_time=true;
        feed_unit(&d,&out,clean,57u,true);assert(!out.early_count);
    }
    seed(&d,&out,clean);d.status_emit=NULL;feed_unit(&d,&out,clean,57u,true);assert(!out.early_count);
    assert(!p25_demod_push_at_observed(NULL,0,0,1,frame,ordinary,early,&out));
    assert(!p25_demod_push_at_observed(&d,0,0,1,NULL,ordinary,early,&out));
    return (unsigned)sizeof d;
}

// Public API tests use shaped, independently generated OP25 samples. Every
// callback sees this exact push's context; no early callback is stored in d.
unsigned p25_early_run(const int16_t *samples,unsigned count,uint64_t origin,
                       unsigned mode,unsigned change_at,uint64_t *ordinary_events,
                       uint64_t *early_events,unsigned stats[7]) {
    p25_demod d;p25_demod_init(&d);early_output out={.hash=2166136261u};
    for(unsigned i=0;i<count;++i) {
        out.current=i;out.input_tick=origin+(uint64_t)i*6u;
        uint32_t epoch=11u;
        if(mode==5u&&i>=change_at)out.input_tick+=6u;
        if(mode==6u&&i>=change_at)++epoch;
        bool continuous;
        if(mode==0u)continuous=p25_demod_push_at(&d,samples[i],out.input_tick,epoch,frame,ordinary,&out);
        else continuous=p25_demod_push_at_observed(&d,samples[i],out.input_tick,epoch,frame,
            mode==4u?NULL:ordinary,(mode!=2u&&(mode!=3u||i==change_at))?early:NULL,&out);
        if(!continuous)++out.discontinuities;
    }
    memcpy(ordinary_events,out.ordinary,sizeof out.ordinary);memcpy(early_events,out.early,sizeof out.early);
    stats[0]=out.frames;stats[1]=out.hash;stats[2]=out.discontinuities;stats[3]=out.ordinary_count;
    stats[4]=out.early_count;stats[5]=d.selected_lane;
    d.status_context=NULL;unsigned hash=2166136261u;
    for(unsigned i=0;i<sizeof d;++i) {hash^=((const unsigned char *)&d)[i];hash*=16777619u;}
    stats[6]=hash;return (unsigned)sizeof d;
}
