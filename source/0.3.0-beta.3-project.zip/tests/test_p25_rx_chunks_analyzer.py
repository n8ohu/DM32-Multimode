"""Corrupted telemetry and independent completed-half comparisons; no device."""
from contextlib import redirect_stderr, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("p25_rx_chunks_analyzer", ROOT / "scripts/analyze-p25-rx-chunks.py")
analysis = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(analysis)

U32 = 0xFFFFFFFF


def row(*, offset=0, epoch=1, half=2, origin=100000, guard=1000, flags=8192,
        first=None, second=None, completed=None, changed=0, torn=0,
        mismatch=0, completed_torn=0, completion_epoch=None, completion_age=100,
        late=30, read_us=40):
    """Independent raw ABI construction, preserving signed sample values."""
    first = first if first is not None else tuple(-32768 + 4096 * n for n in range(16))
    second = second if second is not None else first
    completed = completed if completed is not None else second
    begin = (origin + (offset + 16) * 125 + guard + late) & U32
    end = (begin + read_us) & U32
    completion = (origin + 32000) & U32
    compare_begin = (completion + completion_age) & U32
    compare_end = (compare_begin + 24) & U32
    completion_epoch = (epoch + 1) & U32 if completion_epoch is None else completion_epoch
    if not flags & 8192:
        completed = [0] * 16
        completion = compare_begin = compare_end = completion_epoch = 0
    return struct.pack("<48h8I6HB3x", *first, *second, *completed,
                       begin, end, origin, compare_begin, compare_end, completion,
                       epoch, completion_epoch, offset, changed, torn, mismatch,
                       completed_torn, flags, half)


def capture(rows=None, *, guard=1000, state="complete", invalid=0, sequence=0, skipped=0, dump=1, service=None):
    rows = rows if rows is not None else [row(guard=guard)]
    flags = [struct.unpack_from("<H", data, 138)[0] for data in rows]
    mismatches = [struct.unpack_from("<H", data, 134)[0] for data in rows]
    count = len(rows)
    limit = count if state == "complete" else max(count, 1)
    service_text = f" service={service}" if service is not None else ""
    header = (f"RXCHUNK state={state} records={count} limit={limit} guard_us={guard} owned=1 dump={dump}{service_text} "
              f"valid_irqs=3 invalid_irqs={invalid} sequence_errors={sequence} skipped_chunks={skipped} "
              f"compared={sum(bool(f & 8192) for f in flags)} "
              f"mismatches={sum(bool(m) for m in mismatches)} row_bytes=144 samples=16 "
              "nominal_sample_us=125 clock=cpu_unqualified")
    return "\r\n".join([header] + ([f"RXCHUNK_ROW index={i} data={data.hex()}" for i, data in enumerate(rows)] if dump else [])
                         + [f"RXCHUNK_END records={count} state={state}"]) + "\r\n"


class ChunkAnalysisTests(unittest.TestCase):
    def test_completed_comparison_preserves_signed_samples_and_only_cpu_observations(self):
        result = analysis.parse_trace(capture())
        observed = result["captures"][0]["rows"][0]
        self.assertTrue(result["all_rows_coherent_matched"])
        self.assertEqual(observed["first_samples"][0], -32768)
        self.assertEqual(observed["first_samples"][-1], 28672)
        self.assertEqual(observed["observations"]["candidate_read_us"], 40)
        self.assertEqual(observed["observations"]["comparison_read_us"], 24)
        self.assertEqual(observed["observations"]["nominal_schedule_lateness_us"], 30)
        self.assertFalse(result["sample_clock_qualified"])
        self.assertFalse(result["rf_timing_qualified"])
        self.assertIn("byte atomicity", result["limitations"])

    def test_uint32_time_and_irq_wrap_with_alternating_halves(self):
        rows = [row(origin=U32 - 20000, epoch=U32, half=2),
                row(origin=(U32 - 20000 + 32000) & U32, epoch=0, half=1)]
        result = analysis.parse_trace(capture(rows))
        self.assertEqual(result["captures"][0]["coherent_matched_rows"], 2)
        self.assertEqual(result["by_service_guard"][0]["observations"]["irq_interval_us"]["median"], 32000)

    def test_multiple_guards_and_cpu_log_prefixes(self):
        first = capture(guard=0)
        second = capture([row(guard=3000, read_us=52)], guard=3000, skipped=4)
        text = "OK COMMAND\r\n" + "\n".join("[12:34] " + line for line in first.splitlines()) + "\n" + second
        result = analysis.parse_trace(text)
        self.assertEqual([entry["guard_us"] for entry in result["by_service_guard"]], [0, 3000])
        self.assertEqual(result["by_service_guard"][1]["observations"]["candidate_read_us"]["max"], 52)
        self.assertEqual(result["by_service_guard"][1]["skipped_chunks"], 4)

    def test_mixed_status_and_dump_sessions_keep_dump_rows_strict(self):
        result = analysis.parse_trace(capture(dump=0, state="recording") + capture(dump=0) + capture())
        self.assertEqual(len(result["status_snapshots"]), 2)
        self.assertEqual(len(result["captures"]), 1)
        self.assertTrue(result["all_rows_coherent_matched"])
        for bad in (capture(dump=0), capture(dump=0) + capture().replace("dump=1", "dump=0"),
                    capture().replace(" dump=1", "")):
            with self.subTest(bad=bad[:120]), self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(bad)

    def test_timer_and_task_services_have_separate_guard_distributions(self):
        result = analysis.parse_trace(capture() + capture(service="task")
                                      + capture([row(read_us=60)], service="timer500"))
        groups = result["by_service_guard"]
        self.assertEqual([(g["service"], g["guard_us"], g["captures"]) for g in groups],
                         [("task", 1000, 2), ("timer500", 1000, 1)])
        self.assertEqual(groups[0]["observations"]["candidate_read_us"]["max"], 40)
        self.assertEqual(groups[1]["observations"]["candidate_read_us"]["max"], 60)
        self.assertFalse(result["sample_clock_qualified"])
        for service in ("timer250", "", "TASK"):
            with self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(capture(service=service))

    def test_reject_missing_tail_missing_row_and_short_hex(self):
        text = capture()
        for bad in (text[:text.index("RXCHUNK_END")],
                    "\n".join(line for line in text.splitlines() if "_ROW" not in line),
                    text.replace("data=", "data=00", 1)):
            with self.subTest(bad=bad[-100:]), self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(bad)

    def test_reject_duplicate_or_reordered_serial_row_indices(self):
        text = capture([row(offset=0), row(offset=16)])
        for replacement in ("index=0", "index=2"):
            with self.assertRaisesRegex(analysis.ChunkError, "duplicate/reordered"):
                analysis.parse_trace(text.replace("index=1", replacement))

    def test_reject_duplicate_reordered_chunk_offsets_and_irq_epochs(self):
        cases = ([row(offset=16), row(offset=16)], [row(offset=16), row(offset=0)],
                 [row(epoch=4), row(epoch=3, origin=68000)])
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(capture(rows))

    def test_same_epoch_requires_same_origin_and_target_half(self):
        for second in (row(offset=16, origin=100001), row(offset=16, half=1)):
            with self.assertRaisesRegex(analysis.ChunkError, "same-epoch"):
                analysis.parse_trace(capture([row(), second]))

    def test_irq_count_requires_alternating_half_unless_sequence_fault_recorded(self):
        with self.assertRaisesRegex(analysis.ChunkError, "target-half"):
            analysis.parse_trace(capture([row(), row(epoch=2, origin=132000, half=2)]))
        result = analysis.parse_trace(capture([row(), row(epoch=2, origin=132000, half=2, flags=8192 | 16)]))
        self.assertFalse(result["all_rows_coherent_matched"])
        self.assertEqual(result["captures"][0]["rejection_counts"], {"irq_sequence": 1})

    def test_mismatch_is_independently_computed_from_second_pass(self):
        values = tuple(range(16))
        first = list(values)
        first[1] = -1
        completed = list(values)
        completed[3] = -10
        data = row(first=first, second=values, completed=completed, changed=2, mismatch=8, flags=8192 | 8 | 512)
        result = analysis.parse_trace(capture([data]))
        self.assertFalse(result["all_rows_coherent_matched"])
        self.assertEqual(result["captures"][0]["rejection_counts"], {"values_changed": 1, "mismatch": 1})
        self.assertEqual(result["captures"][0]["header"]["mismatches"], 1)

    def test_reject_fabricated_masks_and_flags(self):
        for arguments in ({"changed": 1}, {"torn": 1}, {"mismatch": 1}, {"completed_torn": 1},
                          {"flags": 8192 | 8}, {"flags": 8192 | 512}, {"flags": 8192 | 4}, {"flags": 8192 | 256}):
            with self.subTest(arguments=arguments), self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(capture([row(**arguments)]))

    def test_race_torn_and_schedule_flags_are_excluded_from_matched_evidence(self):
        for flag in (1, 2, 16, 32, 64, 128, 1024, 4096):
            with self.subTest(flag=flag):
                result = analysis.parse_trace(capture([row(flags=8192 | flag)]))
                self.assertFalse(result["all_rows_coherent_matched"])
                self.assertEqual(result["captures"][0]["coherent_matched_rows"], 0)
                self.assertIsNone(result["by_service_guard"][0]["observations"]["candidate_read_us"])
                if flag != 1024:
                    self.assertEqual(result["by_service_guard"][0]["all_row_cpu_observations"]["candidate_read_us"]["max"], 40)
        result = analysis.parse_trace(capture([row(flags=8192 | 4 | 256, torn=1, completed_torn=1)]))
        self.assertEqual(result["captures"][0]["rejected_rows"], 1)

    def test_unpaired_and_overwritten_rows_cannot_supply_comparison_evidence(self):
        result = analysis.parse_trace(capture([row(flags=2048 | 128)]))
        observed = result["captures"][0]["rows"][0]
        self.assertFalse(observed["compared"])
        self.assertFalse(observed["coherent_matched"])
        self.assertNotIn("comparison_read_us", observed["observations"])
        result = analysis.parse_trace(capture([row(flags=8192 | 2048)], state="timeout"))
        observed = result["captures"][0]["rows"][0]
        self.assertTrue(observed["compared"])
        self.assertIn("unpaired", observed["rejected_reasons"])
        self.assertFalse(result["all_rows_coherent_matched"])

    def test_wrong_completion_epoch_is_not_accepted_as_matched(self):
        result = analysis.parse_trace(capture([row(completion_epoch=3)]))
        self.assertIn("comparison_wrong_irq_epoch", result["captures"][0]["rows"][0]["rejected_reasons"])
        self.assertFalse(result["all_rows_coherent_matched"])

    def test_comparison_before_overwrite_checks_entire_read_not_only_begin(self):
        for age in (32000, 31990):
            result = analysis.parse_trace(capture([row(completion_age=age)]))
            self.assertIn("comparison_not_before_nominal_overwrite",
                          result["captures"][0]["rows"][0]["rejected_reasons"])

    def test_candidate_before_nominal_guard_not_admitted(self):
        result = analysis.parse_trace(capture([row(late=-1)]))
        self.assertIn("candidate_outside_nominal_guard_window", result["captures"][0]["rows"][0]["rejected_reasons"])

    def test_omitted_late_flag_cannot_hide_a_full_missed_chunk_period(self):
        result = analysis.parse_trace(capture([row(late=2000)]))
        self.assertIn("nominal_schedule_late_unflagged", result["captures"][0]["rows"][0]["rejected_reasons"])
        self.assertFalse(result["all_rows_coherent_matched"])

    def test_candidate_read_spanning_completion_is_rejected_even_with_race_flag(self):
        result = analysis.parse_trace(capture([row(offset=224, guard=1000, read_us=1100,
                                                       completion_age=200, flags=8192 | 2)]))
        observed = result["captures"][0]["rows"][0]
        self.assertIn("candidate_read_crosses_nominal_completion", observed["rejected_reasons"])
        self.assertFalse(observed["coherent_matched"])

    def test_reversed_candidate_read_requires_explicit_clock_anomaly(self):
        with self.assertRaisesRegex(analysis.ChunkError, "reversed/ambiguous"):
            analysis.parse_trace(capture([row(read_us=-1)]))
        result = analysis.parse_trace(capture([row(read_us=-1, flags=8192 | 1024)]))
        self.assertEqual(result["captures"][0]["rows"][0]["observations"], {})

    def test_header_must_match_counters_state_tail_and_abi(self):
        text = capture()
        for old, new in (("compared=1", "compared=0"), ("mismatches=0", "mismatches=1"),
                         ("row_bytes=144", "row_bytes=96"), ("samples=16", "samples=8"),
                         ("records=1 state=complete", "records=0 state=complete"),
                         ("clock=cpu_unqualified", "clock=qualified"), ("guard_us=1000", "guard_us=16001"),
                         ("limit=1", "limit=97"), ("owned=1", "owned=2"),
                         ("state=complete", "state=recording")):
            with self.subTest(new=new), self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(text.replace(old, new))

    def test_partial_and_irq_fault_captures_remain_explicitly_unsuccessful(self):
        for kwargs in ({"state": "cancelled"}, {"invalid": 1}, {"sequence": 1}):
            result = analysis.parse_trace(capture(**kwargs))
            self.assertFalse(result["all_rows_coherent_matched"])
            self.assertTrue(result["captures"][0]["capture_issues"])

    def test_reject_reserved_unknown_flags_bad_half_offset_and_nonhex(self):
        data = bytearray(row())
        data[141] = 1
        cases = [bytes(data), row(flags=8192 | 16384), row(half=0), row(offset=1), row(offset=256)]
        for bad in cases:
            with self.subTest(bad=bad[-16:]), self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(capture([bad]))
        with self.assertRaises(analysis.ChunkError):
            analysis.parse_trace(capture().replace("data=", "data=z", 1))

    def test_reject_duplicate_fields_nested_capture_and_unknown_records(self):
        text = capture()
        header = text.splitlines()[0]
        for bad in (text.replace("owned=1", "owned=1 owned=1"), header + "\n" + text,
                    text.replace("RXCHUNK_ROW", "RXCHUNK_BOGUS")):
            with self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(bad)

    def test_bounded_input_and_missing_capture(self):
        for text in ("just normal status", capture() + "\0", "x" * (analysis.MAX_INPUT_BYTES + 1)):
            with self.assertRaises(analysis.ChunkError):
                analysis.parse_trace(text)

    def test_cli_statuses_and_json_output(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "capture.log", Path(folder) / "report.json"
            source.write_text(capture(), encoding="utf-8")
            self.assertEqual(analysis.main([str(source), "--output", str(output)]), 0)
            self.assertFalse(json.loads(output.read_text())["sample_clock_qualified"])
            source.write_text(capture([row(flags=8192 | 2)]), encoding="utf-8")
            with redirect_stdout(io.StringIO()):
                self.assertEqual(analysis.main([str(source)]), 1)
            source.write_text("RXCHUNK", encoding="utf-8")
            with redirect_stderr(io.StringIO()) as errors:
                self.assertEqual(analysis.main([str(source)]), 2)
            self.assertIn("failed", errors.getvalue())


if __name__ == "__main__":
    unittest.main()
