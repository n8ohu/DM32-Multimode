"""Offline duplex capture, native decode/map and finite transport regressions."""
import copy
import contextlib
import ctypes
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("hotspot_access_test", ROOT / "scripts/hotspot-p25-access.py")
TOOL = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = TOOL
SPEC.loader.exec_module(TOOL)
VERSION = (b"MMDVM_HS_Dual_Hat-v1.5.2 20201108 14.7456MHz dual "
           b"ADF7021 FW by CA6JAU GitID #89daa20")
CONFIG = """[General]
Duplex=1
[Info]
TXFrequency=440075000
RXFrequency=445075000
[Modem]
Protocol=uart
UARTPort=/dev/ttyAMA0
UARTSpeed=115200
TXDelay=100
RXInvert=1
TXInvert=0
PTTInvert=1
RXOffset=125
TXOffset=-250
P25TXLevel=50
[P25]
Enable=1
NAC=293
[P25 Network]
Enable=0
[DMR]
Enable=0
Beacons=0
[DMR Network]
Enable=0
[CW Id]
Enable=0
"""


class Clock:
    def __init__(self):
        self.value = 100.0

    def __call__(self):
        return self.value

    def sleep(self, duration):
        self.value += duration


class Serial:
    def __init__(self, clock, inbound=b"", *, flags=0, mode=None, space=6, drop_at=None):
        self.clock, self.inbound = clock, inbound
        self.flags, self.mode, self.space, self.drop_at = flags, mode, space, drop_at
        self.reads, self.writes, self.sent = bytearray(), [], []
        self.queries, self.first, self.tail = 0, None, clock()

    def write(self, packet):
        self.writes.append(packet)
        kind = packet[2]
        if kind == 0:
            self.reads.extend(TOOL.MODEM.packet(0, b"\1" + VERSION))
        elif kind in (2, 3, 4):
            self.reads.extend(TOOL.MODEM.packet(0x70, bytes((kind,))))
        elif kind == 1:
            self.queries += 1
            if self.queries == 4:
                self.reads.extend(self.inbound)
            now = self.clock()
            tx = bool(self.sent) and now < self.tail
            if self.drop_at is not None and now >= self.drop_at:
                tx = False
            mode = self.mode if self.mode is not None else (4 if self.sent else 0)
            self.reads.extend(bytes((0xE0, 13, 1, 8, mode, self.flags | int(tx), 0, 0, 0, 0, self.space, 0, 0)))
        elif kind == 0x31:
            if self.first is None:
                self.first = self.clock() + 0.6
                self.tail = self.first
            self.tail = max(self.tail, self.clock()) + (len(packet) - 4) / 1200
            self.sent.append(packet)
        else:
            raise AssertionError("Unexpected command: " + packet.hex())
        return len(packet)

    def read(self, count):
        self.clock.value += 0.001
        result = bytes(self.reads[:count])
        del self.reads[:count]
        return result


class AccessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames, cls.metadata = TOOL.CC.GENERATOR.make_fixture(
            control_frequency=440075000, voice_frequency=440087500, repetitions=1)
        cls.site = TOOL.site_only_frame(cls.frames, cls.metadata)
        reference = TOOL.CC.GENERATOR.load_reference()
        cls.request, _ = TOOL.CC.GENERATOR.encode_tsdu(reference, 0x293,
            [(0x2C, (0xABCDE << 36) | (0x123 << 24) | 0x123456)])
        cls.rx = TOOL.MODEM.packet(0x30, b"\1" + cls.request)
        build = ROOT / "build/test-hotspot-p25-access"
        build.mkdir(parents=True, exist_ok=True)
        bridge = build / "pair_bridge.c"
        bridge.write_text('''#include "p25_tsdu.h"
#include "p25_trunking.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
bool access_test_pair(const uint8_t *wire,size_t size,uint16_t channel,uint32_t *rx,uint32_t *tx) {
    p25_tsdu unit;p25_trunking state;
    if(!p25_tsdu_decode(wire,size,&unit) || unit.count!=3 ||
       !p25_trunking_init(&state,440075000u,400000000u,480000000u,0x293u))return false;
    for(unsigned i=0;i<unit.count;++i)p25_trunking_consume(&state,unit.nac,unit.block[i],1u);
    return p25_trunking_channel_pair(&state,channel,0,false,rx,tx);
}
''', encoding="utf-8")
        cls.library = build / ("access_decode.dll" if sys.platform == "win32" else "access_decode.so")
        command = ["gcc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-shared"]
        if sys.platform != "win32":
            command.append("-fPIC")
        subprocess.run(command + ["-Isrc/firmware", str(bridge), "src/firmware/p25_tsdu.c",
            "src/firmware/p25_rx.c", "src/firmware/p25_trunking.c", "-o", str(cls.library)],
            cwd=ROOT, check=True)
        cls.decoder = TOOL.NativeDecoder(cls.library)
        cls.decoder.lib.access_test_pair.argtypes = [ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t,
            ctypes.c_uint16, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32)]
        cls.decoder.lib.access_test_pair.restype = ctypes.c_bool

    def record(self, wire=None, sequence=1, stamp=100.0):
        return {"schema": TOOL.SCHEMA, "sequence": sequence,
                "received_at_monotonic": stamp, "wire_hex": (wire or self.rx).hex()}

    def test_site_has_only_site_blocks_and_preserves_original_fixture(self):
        frames, metadata = copy.deepcopy(self.frames), copy.deepcopy(self.metadata)
        output = TOOL.site_only_frame(frames, metadata)
        self.assertEqual(frames, self.frames)
        self.assertEqual(metadata, self.metadata)
        nac, blocks = self.decoder(output)
        self.assertEqual(nac, 0x293)
        self.assertEqual([block[0] & 0x3F for block in blocks], [0x34, 0x3A, 0x3B])
        self.assertEqual(len(output), 90)
        self.assertEqual(blocks[1:], self.decoder(self.frames[0])[1][1:])

    def test_global_five_microslot_lab_marker_pattern(self):
        symbols = []
        for _ in range(3):
            symbols.extend((self.site[index // 4] >> (6 - 2 * (index % 4))) & 3
                           for index in range(35, 360, 36))
        self.assertEqual(symbols, [3 if index % 5 == 0 else 2 for index in range(30)])

    def test_native_mapping_checks_control_and_voice_inputs(self):
        source = (ctypes.c_uint8 * len(self.site)).from_buffer_copy(self.site)
        for channel, expected in ((0x1000, (440075000, 445075000)),
                                  (0x1001, (440087500, 445087500))):
            rx, tx = ctypes.c_uint32(), ctypes.c_uint32()
            self.assertTrue(self.decoder.lib.access_test_pair(source, len(self.site), channel,
                                                             ctypes.byref(rx), ctypes.byref(tx)))
            self.assertEqual((rx.value, tx.value), expected)

    def test_common_iq_site_uses_exact_one_mhz_bandplan_without_global_mutation(self):
        for lab,raw in ((TOOL.CC.LAB.LEGACY5M,0x2190),(TOOL.CC.LAB.COMMONIQ1M,0x2050)):
            site=TOOL.site_only_frame(self.frames,self.metadata,lab_profile=lab)
            nac,blocks=self.decoder(site)
            self.assertEqual(nac,0x293)
            argument=int.from_bytes(blocks[0][2:10],'big')
            self.assertEqual((argument>>42)&0x3FFF,raw)
            source=(ctypes.c_uint8*len(site)).from_buffer_copy(site)
            for channel,pair in ((0x1000,(lab.control_rx_hz,lab.control_tx_hz)),
                                 (0x1001,(lab.voice_rx_hz,lab.voice_tx_hz))):
                rx,tx=ctypes.c_uint32(),ctypes.c_uint32()
                self.assertTrue(self.decoder.lib.access_test_pair(source,len(site),channel,
                    ctypes.byref(rx),ctypes.byref(tx)))
                self.assertEqual((rx.value,tx.value),pair)
        self.assertEqual((TOOL.CC.TX_FREQUENCY,TOOL.CC.RX_FREQUENCY),(440075000,445075000))
        self.assertEqual(TOOL.site_only_frame(self.frames,self.metadata),self.site)

    def test_common_iq_cli_dry_run_names_profile_and_keeps_responses_explicit(self):
        with tempfile.TemporaryDirectory() as directory:
            TOOL.CC.GENERATOR.write_fixture(Path(directory),self.frames,self.metadata)
            for active in (False,True):
                args=['--fixture',str(Path(directory)/'control.bin'),'--manifest',
                      str(Path(directory)/'manifest.json'),'--lab-profile','COMMONIQ1M',
                      '--config','/must-not-be-read']
                if active:args+=['--active-responses','--radio-id','0x123456','--talkgroup','10']
                with contextlib.redirect_stdout(io.StringIO()) as stdout:
                    self.assertEqual(TOOL.main(args),0)
                result=json.loads(stdout.getvalue())
                self.assertEqual(result['lab_profile'],'COMMONIQ1M')
                self.assertEqual(result['receiver_frequency_hz'],441075000)
                self.assertEqual(result['advertised_input_offset_hz'],1000000)
                self.assertEqual(result['active_responses'],active)
                self.assertEqual(result['rf_payload_commands_sent'],0)

    def test_repeated_site_capture_preserves_rx_through_status_polls(self):
        clock, records, events = Clock(), [], []
        serial = Serial(clock, self.rx + TOOL.MODEM.packet(0x32))
        link = TOOL.CaptureLink(serial, self.site, records.append, clock=clock, sleep=clock.sleep)
        self.assertTrue(link.version().endswith("#89daa20"))
        started = clock()
        result = TOOL.schedule(link, 2, 0.6, clock=clock, sleep=clock.sleep, event=events.append)
        self.assertGreater(result["site_units_sent"], 5)
        self.assertEqual(result["responses_sent"], 0)
        self.assertEqual(result["grants_sent"], 0)
        self.assertLessEqual(result["max_estimated_payload_queue_s"], 0.25000001)
        self.assertGreaterEqual(result["elapsed_s"], 2 + TOOL.POSTROLL_SECONDS)
        self.assertEqual([bytes.fromhex(item["wire_hex"])[2] for item in records], [0x30, 0x32])
        self.assertTrue(all(packet == TOOL.CC.GENERATOR.modem_packet(self.site) for packet in serial.sent))
        self.assertEqual(events[0]["idle_markers"], "lab_advertised_only")
        self.assertEqual(events[0]["request_send_deadline_monotonic"], started + 1)
        decoded = TOOL.analyse(records, self.decoder)
        self.assertEqual(decoded["candidate_isp_count"], 1)
        self.assertEqual(decoded["events"][0]["candidate_isp"],
            {"opcode": 0x2C, "radio_id": 0x123456, "kind": "registration", "wacn": 0xABCDE, "system_id": 0x123})

    def test_overflow_and_mode_faults_abort_without_payload(self):
        for options in ({"flags": 4}, {"flags": 8}, {"flags": 2}, {"mode": 2}):
            with self.subTest(options=options):
                clock = Clock()
                serial = Serial(clock, **options)
                link = TOOL.CaptureLink(serial, self.site, lambda value: None, clock=clock, sleep=clock.sleep)
                with self.assertRaises(RuntimeError):
                    TOOL.schedule(link, 2, 0.6, clock=clock, sleep=clock.sleep)
                self.assertEqual(serial.sent, [])

    def test_fifo_stall_and_early_tx_drop_are_bounded_failures(self):
        for options in ({"space": 0}, {"drop_at": 100.9}):
            with self.subTest(options=options):
                clock = Clock()
                serial = Serial(clock, **options)
                link = TOOL.CaptureLink(serial, self.site, lambda value: None, clock=clock, sleep=clock.sleep)
                with self.assertRaises((RuntimeError, TimeoutError)):
                    TOOL.schedule(link, 2, 0.6, clock=clock, sleep=clock.sleep)
                self.assertLessEqual(clock(), 106)

    def test_native_crc_refusal_and_non_tsdu_rx_remain_records(self):
        damaged = bytearray(self.rx)
        for index in range(18, 35):
            damaged[index] ^= 0xFF
        records = [self.record(bytes(damaged)),
                   self.record(TOOL.MODEM.packet(0x31, b"\0" + bytes(216)), 2, 101)]
        result = TOOL.analyse(records, self.decoder)
        self.assertEqual(result["records"], 2)
        self.assertEqual(result["qualified_single_tsdu"], 0)
        self.assertEqual(result["candidate_isp_count"], 0)

    def test_analysis_rejects_bad_capture_envelope_order_and_schema(self):
        for change in ({"schema": "other"}, {"sequence": True}, {"sequence": 0},
                       {"received_at_monotonic": float("nan")}, {"wire_hex": "zz"},
                       {"wire_hex": "e00130"}):
            value = self.record()
            value.update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                TOOL.analyse([value], self.decoder)
        with self.assertRaises(ValueError):
            TOOL.analyse([self.record(), self.record()], self.decoder)
        with self.assertRaises(ValueError):
            TOOL.analyse([self.record(stamp=101), self.record(sequence=2, stamp=100)], self.decoder)

    def test_no_unsupported_or_malformed_isp_is_reported_as_supported(self):
        reference = TOOL.CC.GENERATOR.load_reference()
        arguments = ((0x28, 0x123 << 40 | 10 << 24 | 0x123456, "affiliation"),
                     (0, 10 << 24 | 0x123456, "group_voice_request"),
                     (0x2B, 0xABCDE << 36 | 0x123 << 24 | 0x123456, "deregistration"))
        for opcode, argument, kind in arguments:
            frame, _ = TOOL.CC.GENERATOR.encode_tsdu(reference, 0x293, [(opcode, argument)])
            result = TOOL.analyse([self.record(TOOL.MODEM.packet(0x30, b"\1" + frame))], self.decoder)
            self.assertEqual(result["events"][0]["candidate_isp"]["kind"], kind)
        for opcode, argument in ((0, 0x40 << 56 | 10 << 24 | 1), (0, 8 << 56 | 10 << 24 | 1),
                                 (0, 1 << 40 | 10 << 24 | 1), (0x31, 0), (0x28, 1 << 63),
                                 (0x2C, 1), (0x2C, 0xF << 60 | 1), (0x28, 0x123 << 40 | 1),
                                 (0, 10 << 24 | 0xFFFFFF)):
            frame, _ = TOOL.CC.GENERATOR.encode_tsdu(reference, 0x293, [(opcode, argument)])
            result = TOOL.analyse([self.record(TOOL.MODEM.packet(0x30, b"\1" + frame))], self.decoder)
            self.assertEqual(result["qualified_single_tsdu"], 1)
            self.assertEqual(result["candidate_isp_count"], 0)

    def test_duration_refusal_and_bad_site_shape(self):
        for duration in (0, 1, -1, 31, True, float("inf"), float("nan")):
            with self.subTest(duration=duration), self.assertRaises(ValueError):
                TOOL.finite_duration(duration)
        with self.assertRaises(ValueError):
            TOOL.site_only_frame(self.frames[:1], self.metadata)
        changed = copy.deepcopy(self.metadata)
        changed["bandplan"]["spacing_hz"] = 127
        with self.assertRaises(ValueError):
            TOOL.site_only_frame(self.frames, changed)

    def test_reuses_exact_reviewed_profile_gates(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "mmdvmhost"
            path.write_text(CONFIG)
            profile = TOOL.CC.configuration(path, self.metadata, 9)
            self.assertEqual(profile["effective_rx_frequency_hz"], 445075125)
            self.assertEqual(profile["effective_tx_frequency_hz"], 440074750)
            for changed in (CONFIG.replace("Duplex=1", "Duplex=0"),
                            CONFIG.replace("RXFrequency=445075000", "RXFrequency=145700000"),
                            CONFIG.replace("[P25 Network]\nEnable=0", "[P25 Network]\nEnable=1")):
                path.write_text(changed)
                with self.assertRaises(ValueError):
                    TOOL.CC.configuration(path, self.metadata, 9)

    def test_offline_cli_does_not_import_serial_or_transmit(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            TOOL.CC.GENERATOR.write_fixture(output, self.frames, self.metadata)
            result = subprocess.run([sys.executable, str(ROOT / "scripts/hotspot-p25-access.py"),
                "--fixture", str(output / "control.bin"), "--manifest", str(output / "manifest.json")],
                capture_output=True, text=True, check=True, cwd=ROOT)
            value = json.loads(result.stdout)
            self.assertTrue(value["dry_run"])
            self.assertEqual(value["rf_payload_commands_sent"], 0)
            self.assertEqual(value["responses_sent"], 0)
            self.assertEqual(value["advertised_input_offset_hz"], 5000000)
            self.assertEqual(value["site_sha256"], hashlib.sha256(self.site).hexdigest())

    def test_stop_path_is_only_inspected_for_explicit_capture(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary).resolve()
            TOOL.CC.GENERATOR.write_fixture(folder, self.frames, self.metadata)
            with mock.patch.object(TOOL, 'stop_path', side_effect=AssertionError('offline path inspection')), \
                    contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(TOOL.main(['--fixture', str(folder/'control.bin'),
                    '--manifest', str(folder/'manifest.json'), '--stop-file', 'relative-no-access']), 0)
            self.assertTrue(json.loads(output.getvalue())['dry_run'])
            file = folder/'stop'
            self.assertEqual(TOOL.stop_path(file), file)
            self.assertFalse(TOOL.stop_requested(file))
            file.write_text('stop')
            self.assertTrue(TOOL.stop_requested(file))
            with self.assertRaises(ValueError): TOOL.stop_path(file)
            with self.assertRaises(ValueError): TOOL.stop_path(Path('relative'))

    def test_owner_stop_transport_completion_remains_incomplete_and_restores_services(self):
        class Services:
            def __init__(self):
                self.states = {unit: unit == 'mmdvmhost.service' for unit in TOOL.CC.UNITS}
            def loaded(self, unit): return unit == 'mmdvmhost.service'
            def active(self, unit): return self.states[unit]
            def service(self, action, unit): self.states[unit] = action == 'start'
            def manual_hosts(self): return False
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary).resolve(); source = folder/'mmdvmhost'; source.write_text(CONFIG)
            TOOL.CC.GENERATOR.write_fixture(folder, self.frames, self.metadata)
            stop, output = folder/'stop', folder/'capture'
            services = Services(); before = dict(services.states)
            signals = SimpleNamespace(SIGINT=2, SIGTERM=15, SIGHUP=1, SIGALRM=14, ITIMER_REAL=0,
                SIG_IGN=1, getsignal=lambda sig: None, signal=lambda *args: None, setitimer=lambda *args: None)
            fcntl = SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None)
            real_open = open
            def local_lock(path, *args, **kwargs):
                return real_open(folder/'session.lock' if path == '/run/lock/dm32-p25-session.lock' else path, *args, **kwargs)
            execute = TOOL.CC.execute_session
            def isolated(system, operation, profile, report, **kwargs):
                return execute(system, operation, profile, report, settle=lambda seconds: None, **kwargs)
            def transport(profile, site, duration, sink, emit, *, responder, stopping):
                self.assertFalse(stopping()); stop.write_text('stop'); self.assertTrue(stopping())
                emit(dict(event='responder_summary', responses_sent=0, grants_sent=0, exchange_complete=False))
                return dict(stopped=True, exchange_complete=False)
            with mock.patch.object(TOOL, 'os', SimpleNamespace(name='posix', geteuid=lambda: 0, chmod=TOOL.os.chmod)), \
                    mock.patch.object(TOOL, 'signal', signals), mock.patch.dict(sys.modules, {'fcntl': fcntl}), \
                    mock.patch.object(TOOL.CC, 'System', return_value=services), \
                    mock.patch.object(TOOL.CC, 'execute_session', side_effect=isolated), \
                    mock.patch.object(TOOL, 'transmit_capture', side_effect=transport), \
                    mock.patch('builtins.open', side_effect=local_lock), contextlib.redirect_stdout(io.StringIO()):
                status = TOOL.main(['--capture', '--duration', '2', '--fixture', str(folder/'control.bin'),
                    '--manifest', str(folder/'manifest.json'), '--config', str(source),
                    '--output', str(output), '--stop-file', str(stop)])
            report = json.loads((output/'report.json').read_text())
            self.assertEqual(status, 0)
            self.assertEqual(report['result'], 'complete')
            self.assertTrue(report['stopped'])
            self.assertFalse(report['exchange_complete'])
            self.assertTrue(report['services_restored'] and report['original_config_unchanged'])
            self.assertEqual(services.states, before)
            self.assertEqual(source.read_text(), CONFIG)

    def test_local_analysis_cli_uses_native_library_without_pi_compiler(self):
        with tempfile.TemporaryDirectory() as temporary:
            capture = Path(temporary) / "rx-events.jsonl"
            capture.write_text(json.dumps(self.record()) + "\n", encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "scripts/hotspot-p25-access.py"),
                "--analyse", str(capture), "--decoder", str(self.library)],
                capture_output=True, text=True, check=True, cwd=ROOT)
            value = json.loads(result.stdout)
            self.assertEqual(value["candidate_isp_count"], 1)
            self.assertEqual(value["events"][0]["candidate_isp"]["radio_id"], 0x123456)
            self.assertFalse(value["rf_slot_timing_verified"])

    def test_capture_event_limit_fails_without_silently_discarding_rx(self):
        clock, records = Clock(), []
        serial = Serial(clock)
        link = TOOL.CaptureLink(serial, self.site, records.append, clock=clock, sleep=clock.sleep)
        link.records = TOOL.MAX_RECORDS - 1
        link.dispatcher.feed(self.rx + TOOL.MODEM.packet(0x32))
        with self.assertRaisesRegex(RuntimeError, "record limit"):
            link.drain()
        self.assertEqual(len(records), 1)
        self.assertEqual(link.dispatcher.received[0].command, 0x32)
        self.assertEqual(serial.writes, [])

    def test_service_hash_restoration_on_capture_failure(self):
        class Services:
            def __init__(self):
                self.states = {unit: unit in ("mmdvmhost.service", "pistar-watchdog.timer")
                               for unit in TOOL.CC.UNITS}
            def loaded(self, unit):
                return True
            def active(self, unit):
                return self.states[unit]
            def service(self, action, unit):
                self.states[unit] = action == "start"
            def manual_hosts(self):
                return False
        with tempfile.TemporaryDirectory() as temporary:
            profile = Path(temporary) / "mmdvmhost"
            profile.write_text(CONFIG)
            before = profile.read_bytes()
            services = Services()
            states_before = copy.deepcopy(services.states)
            report = {"original_config_sha256": hashlib.sha256(before).hexdigest()}
            def broken_capture():
                self.assertFalse(any(services.states.values()))
                raise RuntimeError("capture fault")
            with self.assertRaisesRegex(RuntimeError, "capture fault"):
                TOOL.CC.execute_session(services, broken_capture, profile, report,
                                        settle=lambda duration: None)
            self.assertEqual(services.states, states_before)
            self.assertEqual(profile.read_bytes(), before)
            self.assertTrue(report["services_restored"])
            self.assertTrue(report["original_config_unchanged"])

    def test_wrapped_signal_during_serial_read_retains_cause_and_restores_services(self):
        # Model pyserial's POSIX read wrapper: an OSError raised by a Python
        # signal handler becomes SerialException. Exercise the installed handler
        # through the production CLI, capture link, dispatcher and cleanup.
        try:
            from serial import SerialException
        except ImportError:
            class SerialException(OSError):
                pass  # Optional pyserial is unnecessary for offline CI.

        class Services:
            def __init__(self):
                self.states={unit:unit in ("mmdvmhost.service","pistar-watchdog.timer")
                             for unit in TOOL.CC.UNITS}
            def loaded(self,unit):return True
            def active(self,unit):return self.states[unit]
            def service(self,action,unit):self.states[unit]=action=="start"
            def manual_hosts(self):return False

        for signum in (15,None):
            with self.subTest(signal=signum),tempfile.TemporaryDirectory() as temporary:
                folder=Path(temporary).resolve();source=folder/'mmdvmhost'
                secret='never-include-config-password-in-error'
                source.write_text(CONFIG.replace('[P25 Network]\nEnable=0',
                    '[P25 Network]\nEnable=0\nPassword='+secret))
                original=source.read_bytes();services=Services();before=dict(services.states)
                TOOL.CC.GENERATOR.write_fixture(folder,self.frames,self.metadata)
                handlers={value:'original-'+str(value) for value in (2,15,1,14)}
                original_handlers=dict(handlers);timers=[]
                def install(sig,handler):
                    previous=handlers[sig];handlers[sig]=handler;return previous
                signals=SimpleNamespace(SIGINT=2,SIGTERM=15,SIGHUP=1,SIGALRM=14,
                    ITIMER_REAL=0,SIG_IGN=object(),getsignal=handlers.__getitem__,signal=install,
                    setitimer=lambda kind,seconds:timers.append(seconds))
                class FailingRead(Serial):
                    closed=False;interrupted=False
                    def __enter__(self):return self
                    def __exit__(self,*args):self.closed=True
                    def read(self,count):
                        if self.queries>=4 and not self.interrupted:
                            self.interrupted=True
                            try:
                                if signum is not None:handlers[signum](signum,None)
                                raise OSError('test I/O fault')
                            except OSError as error:
                                raise SerialException('read failed: '+str(error)) from error
                        return super().read(count)
                device=FailingRead(Clock())
                fake_serial=SimpleNamespace(Serial=lambda **kwargs:device,SerialException=SerialException)
                fcntl=SimpleNamespace(LOCK_EX=1,LOCK_NB=2,flock=lambda *args:None)
                real_open=open
                def local_lock(path,*args,**kwargs):
                    if path=='/run/lock/dm32-p25-session.lock':path=folder/'session.lock'
                    return real_open(path,*args,**kwargs)
                execute=TOOL.CC.execute_session
                def isolated(system,operation,profile,report,**kwargs):
                    return execute(system,operation,profile,report,settle=lambda seconds:None,**kwargs)
                operating_system=SimpleNamespace(name='posix',geteuid=lambda:0,chmod=TOOL.os.chmod)
                output=folder/'capture'
                with mock.patch.object(TOOL,'os',operating_system),mock.patch.object(TOOL,'signal',signals), \
                     mock.patch.object(TOOL.CC,'System',return_value=services), \
                     mock.patch.object(TOOL.CC,'execute_session',side_effect=isolated), \
                     mock.patch.dict(sys.modules,{'serial':fake_serial,'fcntl':fcntl}), \
                     mock.patch('builtins.open',side_effect=local_lock), \
                     contextlib.redirect_stdout(io.StringIO()):
                    result=TOOL.main(['--capture','--duration','2','--config',str(source),
                        '--fixture',str(folder/'control.bin'),'--manifest',str(folder/'manifest.json'),
                        '--output',str(output)])
                report=json.loads((output/'report.json').read_text())
                self.assertEqual(result,1)
                self.assertTrue(device.interrupted);self.assertTrue(device.closed)
                self.assertTrue(device.sent)  # The read fails during the finite scheduler.
                self.assertEqual(report['error_type'],'SerialException')
                self.assertEqual(report['interrupted_signal'],signum)
                expected='Interrupted finite access capture' if signum is not None else 'test I/O fault'
                self.assertEqual(report['error_message'],'read failed: '+expected)
                self.assertNotIn(secret,report['error_message'])
                self.assertEqual(services.states,before)
                self.assertEqual(report['active_before'],report['active_after'])
                self.assertTrue(report['services_restored']);self.assertTrue(report['original_config_unchanged'])
                self.assertEqual(source.read_bytes(),original)
                self.assertEqual(handlers,original_handlers)
                self.assertEqual(timers[-1],0)


if __name__ == "__main__":
    unittest.main()
