# SPDX-License-Identifier: GPL-3.0-or-later
"""Rare block decoder scopes without hardware or per-symbol profiling."""
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-demod-profile'
BUILD.mkdir(parents=True,exist_ok=True)
BINARY=BUILD/('profile.exe' if sys.platform=='win32' else 'profile')
subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-pedantic',
    '-Isrc/firmware','tests/test_p25_demod_profile.c','src/firmware/p25_rx.c','src/firmware/p25_tsdu.c',
    '-o',str(BINARY)],cwd=ROOT,check=True,timeout=120)
subprocess.run([str(BINARY)],cwd=ROOT,check=True,timeout=30)
