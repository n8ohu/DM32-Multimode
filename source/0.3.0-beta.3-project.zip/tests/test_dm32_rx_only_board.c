/* Exercise the real generated board/FD6818 against the existing recorded-I/O
 * fixture. Deliberately corrupt the software TX flags to test the independent
 * compile-time interlock, including callbacks invoked by the P25 RF IRQ. */
#if !DM32_RF_B_EXPERIMENTAL
char dm32_rf_compat_setup(void) { return 'A'; }
#endif
#define main rf_reference_main
#include "test_rf_board.c"
#undef main
#include "radio_dm32_generated.c"

static unsigned route_calls;
void hrc7000_codec_mute(hrc7000_t *m, bool mic, bool line)
{
    (void)m; (void)mic; (void)line;
    ++route_calls;
}

static void assert_no_tx(void)
{
    assert(pa_keys == 0 && test_dac_b == 0);
    assert(!pins[PIN_VHF_PA] && !pins[PIN_UHF_PA]);
    for (size_t i = 0; i < event_n; ++i) {
        assert(events[i].kind != 'T'); /* Native FM transmitter never enabled. */
        assert(!(events[i].kind == 'W' && events[i].reg == FD6818_REG_STATE
                 && events[i].value == FD6818_STATE_TX));
    }
}

static void native_denial(void)
{
    boot(true, true);
    const uint32_t frequencies[] = {154680000u, 154950000u, 155872500u, 156142500u, 445075000u};
    for (unsigned digital = 0; digital < 2; ++digital) {
        dm32_radio.set_mode(digital ? RADIO_MODE_DMR : RADIO_MODE_FM);
        for (unsigned i = 0; i < sizeof(frequencies) / sizeof(frequencies[0]); ++i) {
            assert(dm32_radio.rx(frequencies[i], RADIO_BW_12K5, NULL));
            clear_events();
            for (unsigned power = 0; power < 4; ++power) {
                assert(!dm32_radio.tx(frequencies[i], RADIO_BW_12K5, power, NULL));
                assert(!dm32_radio.tx(frequencies[i], RADIO_BW_25K, power, NULL));
            }
            assert(!transmitting && !dmr_keyed && !pcm_prepared);
            /* Denial must not take the working receiver off its channel. */
            for (size_t j = 0; j < event_n; ++j) assert(events[j].kind != 'W');
            assert_no_tx();
        }
    }
}

static void stale_callback_denial(void)
{
    boot(true, true);
    dm32_radio.set_mode(RADIO_MODE_DMR);
    assert(dm32_radio.rx(154680000u, RADIO_BW_12K5, NULL));
    /* Simulate a stale/errant controller granting every mutable TX flag. */
    dmr_keyed = transmitting = true;
    tx_hz = 445075000u;
    tx_drive = 65535;
    for (unsigned uhf = 0; uhf < 2; ++uhf) {
        tx_uhf = uhf;
        clear_events();
        run_callback(true);
        run_pa();
        pa_key();
        assert_no_tx();
        for (size_t j = 0; j < event_n; ++j) assert(events[j].kind != 'W');
    }
    /* Off/return hooks still restore a usable receiver and LNA. */
    run_callback(false);
    assert(rf_regs[FD6818_REG_STATE] == FD6818_STATE_RX && pins[PIN_VHF_LNA]);
    assert_no_tx();
    dm32_radio.tx_off();
    assert(!transmitting && !dmr_keyed);
}

static void pcm_and_tone_denial(void)
{
    boot(true, true);
    assert(dm32_radio.rx(154950000u, RADIO_BW_12K5, NULL));
    clear_events();
    assert(!dm32_pcm_fm_prepare(154950000u, false, 3));
    /* Even prepared/keyed state corruption cannot activate PCM or tones. */
    pcm_prepared = transmitting = afsk_tx = true;
    pcm_preparing = false;
    modem.tone_on = true;
    assert(!dm32_pcm_fm_key());
    assert(!dm32_pcm_fm_route(true) && route_calls == 0);
    assert(!dm32_radio.tx_tail(true));
    assert(!dm32_radio.tx_tone(1750));
    assert(!dm32_radio.tx_tone_key(true));
    assert_no_tx();
    assert(dm32_pcm_fm_route(false) && route_calls == 1); /* Cleanup survives. */
    dm32_radio.tx_off();
    dm32_speaker_pcm(true); /* Speaker playback is still allowed. */
    assert(modem.audio_ctl & C7_AUDIO_RING_PLAY);
    dm32_speaker_pcm(false);
    assert_no_tx();
    dm32_radio.rx_sleep(true);
    dm32_radio.rx_sleep(false);
    assert(rf_regs[FD6818_REG_STATE] == FD6818_STATE_RX);
    assert_no_tx();
}

int main(void)
{
    assert(dm32_omaha_tx_blocked == 1u);
    native_denial();
    stale_callback_denial();
    pcm_and_tone_denial();
    puts("fixed RX-only board interlock checks passed");
    return 0;
}
