# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact FIRphase3 pairing against frozen and explicit121-tap references.

Exhaust signed16 impulses, sign/full-scale cases, exact truncation/saturation
threshold sums and seeded random windows, including a trapped-overflow build.
No radio, codec, application state or hardware is involved.
"""
import ctypes as C
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-filter-symmetry';BUILD.mkdir(parents=True,exist_ok=True)
FROZEN=ROOT/'tests/reference/p25_filter_before_phase3.h'
assert hashlib.sha256(FROZEN.read_bytes().replace(b'\r\n',b'\n')).hexdigest()==(
    'b7c2e7f35fbbb757de95facae7f4fe655faa3d9d39ebfecb0db424596163697c')
results=[]
for trapped in (False,True):
    name='filter-trap' if trapped else 'filter'
    library=BUILD/(name+('.dll' if sys.platform=='win32' else '.so'))
    command=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-shared']
    if sys.platform!='win32':command+=['-fPIC']
    if trapped:command+=['-ftrapv','-static-libgcc']
    command+=['-Isrc/firmware','tests/test_p25_filter_symmetry.c','-o',str(library)]
    subprocess.run(command,cwd=ROOT,check=True,timeout=120)
    lib=C.CDLL(str(library));lib.p25_filter_symmetry_test.restype=C.c_uint64
    count=lib.p25_filter_symmetry_test();assert count>2000000
    results.append(dict(trapped_overflow=trapped,cases=count,compiler=command))
assert results[0]['cases']==results[1]['cases']
current=ROOT/'src/firmware/p25_demod_filter.h'
report=dict(cases_per_build=results[0]['cases'],builds=results,
    normalized_filter_sha256=hashlib.sha256(current.read_bytes().replace(b'\r\n',b'\n')).hexdigest(),
    phase1_to5_multiplies_before=100,phase1_to5_multiplies_after=90,
    phase0_center_unchanged=True,added_static_ram_bytes=0,
    phase3_first9_partial_abs_bound=15966*65536,
    phase3_final_product_abs_bound=20758*65536,
    hardware_access=False,target_performance_measured=False)
(BUILD/'result.private.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
