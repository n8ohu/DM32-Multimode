// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_rx.h"
#include "p25_data.h"
#include "p25_demod.h"
#include <string.h>
unsigned p25_data_test_rx(const uint8_t *frame,unsigned bytes,uint8_t *out,unsigned capacity) {
    p25_rx rx;p25_rx_init(&rx);unsigned complete=0;
    for(unsigned i=0;i<bytes*4u;++i)if(p25_rx_push(&rx,(uint8_t)((frame[i/4u]>>(6u-2u*(i%4u)))&3u))) {
        if(rx.duid!=12u || rx.frame_bytes>capacity)return 0;
        memcpy(out,rx.frame,rx.frame_bytes);complete=rx.frame_bytes;
    }
    return complete;
}
typedef struct {uint8_t *out;unsigned capacity,length,count;} data_demod_output;
static void data_demod_frame(const p25_rx *frame,void *context) {
    data_demod_output *p=context;
    if(frame->duid!=12u || frame->frame_bytes>p->capacity)return;
    ++p->count;p->length=frame->frame_bytes;memcpy(p->out,frame->frame,p->length);
}
unsigned p25_data_test_demod(const int16_t *samples,unsigned count,uint8_t *out,unsigned capacity) {
    p25_demod demod;p25_demod_init(&demod);data_demod_output result={out,capacity,0,0};
    for(unsigned i=0;i<count;++i)p25_demod_push(&demod,samples[i],data_demod_frame,&result);
    for(unsigned i=0;i<32u;++i)p25_demod_push(&demod,0,data_demod_frame,&result);
    return result.count==1u?result.length:0;
}
