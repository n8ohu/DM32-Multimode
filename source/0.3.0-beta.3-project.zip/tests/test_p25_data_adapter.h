// SPDX-License-Identifier: GPL-3.0-or-later
// Exercises the actual monitor callback and shared inbox, with no RF request.
static void test_p25_data_adapter(void) {
    reset();memset(&mailbox,0,sizeof mailbox);normal_mode=true;
    control.source_id=123456;control.nac=0x293;rx_promiscuous=false;
    p25_rx packet={.duid=12,.nac=0x293};
    size_t size=p25_data_build_tms(packet.frame,sizeof packet.frame,packet.nac,7654321,
        control.source_id,7,"MEET AT NORTH GATE");
    assert(size);packet.frame_bytes=(uint16_t)size;
    monitor.call=(p25_receive_policy){.active=true,.lc_valid=true,.source=91,.group=10,.state=P25_RX_CLEAR};
    p25_receive_policy before=monitor.call;unsigned codec_before=codec_inits,decode_before=decode_calls;
    mon_receive(&packet,NULL);
    assert(mailbox.count==1 && mailbox.items[0].unread && mailbox.items[0].state==RADIO_MAIL_RECEIVED);
    assert(mailbox.items[0].message.protocol==RADIO_PROTOCOL_P25 && mailbox.items[0].message.kind==RADIO_CALL_INDIVIDUAL);
    assert(mailbox.items[0].message.source==7654321 && mailbox.items[0].message.destination==123456);
    assert(!strcmp(mailbox.items[0].message.text,"MEET AT NORTH GATE"));
    assert(feature_u16(mailbox.items[0].channel+8)==0x293);
    assert(!memcmp(&before,&monitor.call,sizeof before) && !heard_calls.count);
    assert(codec_inits==codec_before && decode_calls==decode_before && !rf_keys && !pa_keys);
    uint32_t serial=mailbox.serial;mon_receive(&packet,NULL);
    assert(mailbox.count==1 && mailbox.serial==serial); // One RF duplicate only once.
    // Identical text with a different sequence is an intentional new message.
    size=p25_data_build_tms(packet.frame,sizeof packet.frame,packet.nac,7654321,
        control.source_id,8,"MEET AT NORTH GATE");packet.frame_bytes=(uint16_t)size;
    mon_receive(&packet,NULL);assert(mailbox.count==2);
    // NAC filtering precedes the app path. PROM bypasses NAC but never unit ID.
    control.nac=0x2a3;
    size=p25_data_build_tms(packet.frame,sizeof packet.frame,packet.nac,7654321,
        control.source_id,9,"SECOND MESSAGE");packet.frame_bytes=(uint16_t)size;
    mon_receive(&packet,NULL);assert(mailbox.count==2);
    rx_promiscuous=true;mon_receive(&packet,NULL);assert(mailbox.count==3);
    size=p25_data_build_tms(packet.frame,sizeof packet.frame,packet.nac,7654321,
        control.source_id+1u,10,"NOT FOR THIS RADIO");packet.frame_bytes=(uint16_t)size;
    mon_receive(&packet,NULL);assert(mailbox.count==3);
    // Corruption that exceeds the trellis bound never becomes an inbox event.
    size=p25_data_build_tms(packet.frame,sizeof packet.frame,packet.nac,7654321,
        control.source_id,11,"DAMAGED MESSAGE");packet.frame_bytes=(uint16_t)size;
    memset(packet.frame+50,0xff,32);mon_receive(&packet,NULL);assert(mailbox.count==3);
    packet.frame_bytes=39;mon_receive(&packet,NULL);assert(mailbox.count==3);
    assert(!rf_keys && !pa_keys && codec_inits==codec_before && decode_calls==decode_before);
    reset();
}
