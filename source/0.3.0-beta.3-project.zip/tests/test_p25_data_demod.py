# SPDX-License-Identifier: GPL-3.0-or-later
"""P25 text through the actual 8-kHz production demodulator; no RF or vocoder."""
import ast
import ctypes as C
import math
from pathlib import Path
import runpy
import sys
import numpy as np
from scipy import signal

ROOT=Path(__file__).resolve().parents[1]
# Build and validate the packet library with the independent factory first.
common=runpy.run_path(str(ROOT/'tests/test_p25_data.py'))
lib=common['lib'];Byte=common['Byte'];Buffer=common['Buffer'];Message=common['Message']
lib.p25_data_test_demod.argtypes=[C.POINTER(C.c_int16),C.c_uint,C.POINTER(Byte),C.c_uint]
lib.p25_data_test_demod.restype=C.c_uint
source=ROOT/'external/boatbod/op25/op25/gr-op25_repeater/apps/tx/op25_c4fm_mod.py'
tree=ast.parse(source.read_text())
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in {'transfer_function_tx','c4fm_taps'}]
assert len(nodes)==2
scope=dict(np=np,pi=math.pi,sin=math.sin,cos=math.cos,_def_symbol_rate=4800,_def_output_sample_rate=48000,_def_span=13)
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),scope)
taps=scope['c4fm_taps']().generate()
for chars in (1,40,80):
 text=(b'P25 MESSAGE '+b'X'*80)[:chars]
 packed=Buffer();length=lib.p25_data_build_tms(packed,512,0x293,7654321,123456,13,text)
 wire=bytes(packed[:length])
 raw=b'\x77'*240+wire+b'\x77'*36
 symbols=np.array([(v>>shift)&3 for v in raw for shift in (6,4,2,0)])
 impulse=np.zeros(len(symbols)*10);impulse[::10]=np.array([1,3,-1,-3])[symbols]
 wave=signal.fftconvolve(impulse,taps)*60000
 for name,polarity,gain,dc,ppm in (('clean',1,1,0,0),('inverted',-1,.8,300,0),('low_gain',1,.2,-200,0),('clock_plus500',1,1,0,500),('clock_minus500',1,1,0,-500)):
  shaped=wave*polarity*gain+dc
  if ppm:
   t=np.arange(math.ceil(len(shaped)*(1+ppm/1e6)))/(1+ppm/1e6)
   shaped=np.interp(t,np.arange(len(shaped)),shaped)
  samples=np.clip(np.rint(signal.resample_poly(shaped,1,6)),-32768,32767).astype(np.int16)
  output=Buffer();found=lib.p25_data_test_demod(samples.ctypes.data_as(C.POINTER(C.c_int16)),len(samples),output,512)
  assert found==length,(chars,name,found,length)
  assert bytes(output[:found])==wire,(chars,name,'wire mismatch')
  message=Message();assert lib.p25_data_parse_tms(output,found,C.byref(message)) and message.text==text
print('P25 messaging demod: 15 complete packet waveforms passed, including inversion/DC, low gain and +/-500-ppm clocks')
