"""SHA-pinned generated display core, real panel contents and bounded steps."""
import hashlib
import importlib.util
from pathlib import Path
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'external/RadioFoundry/RadioFoundry/core/ui/gfx.c'
BUILD=ROOT/'build/test-cooperative-gfx'
spec=importlib.util.spec_from_file_location('cooperative_generator',ROOT/'scripts/generate-cooperative-gfx.py')
generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)


class CooperativeGraphics(unittest.TestCase):
    def test_pin_drift_and_deterministic_generation(self):
        original=SOURCE.read_text()
        self.assertEqual(hashlib.sha256(original.replace('\r\n','\n').encode()).hexdigest(),generator.PINNED_SOURCE_SHA256)
        self.assertEqual(generator.generate(original),generator.generate(original.replace('\n','\r\n')))
        with self.assertRaisesRegex(ValueError,'upstream pin'):generator.generate(original+'\n')
        with self.assertRaisesRegex(ValueError,'structure'):generator.replace_once('x x','x','y')

    def test_actual_generated_core_all_depths_palette_and_budget_semantics(self):
        BUILD.mkdir(parents=True,exist_ok=True)
        original=SOURCE.read_bytes();generated=generator.generate(original.decode())
        (BUILD/'cooperative-gfx.c').write_text(generated,encoding='utf-8',newline='\n')
        (BUILD/'config.h').write_text('// Host display feature switches are compiler arguments.\n')
        for indexed,web in ((1,1),(1,0),(0,1),(0,0)):
            binary=BUILD/(f'gfx-{indexed}-{web}'+('.exe' if sys.platform=='win32' else ''))
            command=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-pedantic',
                '-DGFX_FB_BYTES=4096','-DGFX_MAX_ROWS=48',f'-DGFX_INDEXED={indexed}',
                f'-DCONFIG_NET_WEBCTL={web}','-DCONFIG_FONT_AA=0','-DCONFIG_FONT_XL=0',
                '-I'+str(BUILD),'-Iexternal/RadioFoundry/RadioFoundry/core',
                '-Iexternal/RadioFoundry/RadioFoundry/hal','-Isrc/firmware',
                'tests/test_cooperative_gfx.c','-o',str(binary)]
            subprocess.run(command,cwd=ROOT,check=True,timeout=120)
            subprocess.run([str(binary)],cwd=ROOT,check=True,timeout=20)
        self.assertEqual(SOURCE.read_bytes(),original)

    def test_real_indexed_aa_edges_and_clipped_ui_match_original_bytes(self):
        BUILD.mkdir(parents=True,exist_ok=True)
        original=SOURCE.read_bytes()
        generated=BUILD/'cooperative-real-gfx.c'
        generated.write_text(generator.generate(original.decode()),encoding='utf-8',newline='\n')
        (BUILD/'config.h').write_text('// Host display feature switches are compiler arguments.\n')
        outputs=[]
        for name,source in (('original',SOURCE),('generated',generated)):
            binary=BUILD/(f'gfx-real-{name}'+('.exe' if sys.platform=='win32' else ''))
            command=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wshadow','-pedantic',
                '-DGFX_FB_BYTES=38400','-DGFX_MAX_ROWS=320','-DGFX_INDEXED=1',
                '-DCONFIG_NET_WEBCTL=1','-DCONFIG_FONT_AA=1','-DCONFIG_FONT_BIG=0','-DCONFIG_FONT_XL=0',
                '-I'+str(BUILD),'-Iexternal/RadioFoundry/RadioFoundry/core',
                '-Iexternal/RadioFoundry/RadioFoundry/core/ui',
                '-Iexternal/RadioFoundry/RadioFoundry/hal','-Isrc/firmware']
            if name=='generated':command+=['-DTEST_COOPERATIVE=1']
            command+=['tests/test_cooperative_gfx_real.c',str(source),
                'external/RadioFoundry/RadioFoundry/core/ui/fonts.c','-o',str(binary)]
            subprocess.run(command,cwd=ROOT,check=True,timeout=120)
            result=subprocess.run([str(binary)],cwd=ROOT,check=True,capture_output=True,timeout=90)
            self.assertIn(b'real indexed AA PASS:',result.stderr)
            outputs.append(result.stdout)
        self.assertEqual(len(outputs[0]),44*(38400+32+240*320*2))
        self.assertEqual(outputs[0],outputs[1],
            'Packed indexes, palette or physical RGB565 differs from untouched upstream')
        self.assertEqual(SOURCE.read_bytes(),original)


if __name__=='__main__':unittest.main(verbosity=2)
