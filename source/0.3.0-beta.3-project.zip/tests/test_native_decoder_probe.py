"""Full decoder host protocol/transport refusal tests; no device or private data."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest import mock
import zlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('native_decoder_under_test', ROOT/'scripts/native-decoder-probe.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def fixture():
    payload = bytes(i % 251 for i in range(1144))
    body = struct.pack('<8s13I', b'NVDFLv1\0', 1, 40, 64, 11, 1144, zlib.crc32(payload), 0, *([0]*6))
    return body+struct.pack('<I', zlib.crc32(body))+payload


def make_elf(image):
    section = (0x100+len(image)+63)&~63
    header = struct.pack('<16sHHIIIIIHHHHHH', b'\x7fELF\x01\x01\x01'+bytes(9),
                         2, 252, 1, probe.ENTRY, 52, section, 0, 52, 32, 1, 40, 2, 0)
    data = bytearray(section+80)
    data[:52] = header
    data[52:84] = struct.pack('<8I', 1, 0x100, probe.ENTRY, probe.ENTRY, len(image), len(image), 5, 4)
    data[0x100:0x100+len(image)] = image
    data[section+40:section+80] = struct.pack('<10I', 0, 1, 6, probe.ENTRY, 0x100, len(image), 0, 0, 4, 0)
    return bytes(data)


def timings():
    arrays = [[base+step*i for i in range(64)] for base, step in ((10, 1), (100, 1), (200, 2), (20, 1), (150, 1), (300, 2))]
    return struct.pack('<384I', *(v for a in arrays for v in a))


def records(mode, payload_crc=0, canonical_crc=0, pcm=None):
    pcm = bytes(20480) if pcm is None else pcm
    values = [(1, 0x23456789, 0)]
    if mode:
        a = struct.unpack('<384I', timings());samples = struct.unpack('<10240h', pcm)
        peak, nonzero = max(abs(x) for x in samples), sum(x != 0 for x in samples)
        clips, zeros = sum(x in (-32768, 32767) for x in samples), sum(x == 0 for x in samples)
        values += [(10, 64, payload_crc), (11, 40, 104), (20, 64, 10240), (21, canonical_crc, 15872),
                   (22, peak, nonzero), (23, clips, zeros), (24, sum(a[128:192]), max(a[128:192])),
                   (25, 60000000, 2), (26, 0xabcdef01, 10240), (30, 64, 10240), (31, canonical_crc, 15872),
                   (32, peak, nonzero), (33, clips, zeros), (34, sum(a[320:384]), max(a[320:384])),
                   (35, zlib.crc32(pcm), 10240), (36, zlib.crc32(timings()), 1536)]
    return [dict(id=i, status=0, value=v, aux=a, vector=0, epc=0, epsr=0, reserved=0) for i, v, a in values]


def packet(nonce=123, mode=0, recs=None, header=None):
    recs = records(mode) if recs is None else recs
    fields = dict(nonce=nonce, build_id=probe.BUILD_ID, mode=mode, total_bytes=56+32*len(recs),
                  record_count=len(recs), fatal=0, guard_mask=31, initial_psr=0x80000100,
                  initial_vbr=0, initial_sp=0x37c34, cpuid_words=0)
    fields.update(header or {})
    raw = probe.HEADER.pack(probe.MAGIC, *(fields[k] for k in probe.transport.HEADER_NAMES))
    raw += b''.join(probe.RECORD.pack(*(r[k] for k in probe.transport.RECORD_NAMES)) for r in recs)
    return raw+struct.pack('<I', zlib.crc32(raw))


class Port:
    def __init__(self):self.buffer=bytearray();self.timeout=.02;self.closed=False
    def read(self, count):
        count=min(count,19);out=bytes(self.buffer[:count]);del self.buffer[:count];return out
    def close(self):self.closed=True


class Radio:
    def __init__(self, port):
        self.port=port;self.ops=[];self.memory={};self.configured=None;self.hello_count=0
        self.v6={k:v for k,v in probe.clock.MONITOR.items() if k not in ('protocol','max_payload')}
        self.v6['stack_used']=164
        self.registers={**probe.clock.COLD_CLOCKS, 'UART_LCR':3, 'UART_IER':128, 'UART_MCR':0,
                        'CACHE_REGION':0,'TIMER2_LOAD':0xffffffff,'TIMER2_CTRL':5,'APLL':0x85040eb2}
        self.samples=[24000000]*12;self.bad_readback=False;self.fail_return=False
        self.modify_raw=lambda x:x;self.modify_records=lambda x:x;self.after_call=lambda:None
        self.fixture=fixture();self.canonical_crc=zlib.crc32(bytes(15872));self.pcm=bytes(20480)
    def hello(self,retries):
        self.ops.append(('hello',retries));self.hello_count+=1
        if self.hello_count>1 and self.fail_return:raise OSError('No monitor return')
        return 7,1032
    def configure(self,board):
        self.ops.append(('configure',board))
        if board is not None:raise AssertionError('CONFIG writes forbidden')
        self.configured={'id':1}
    def timer_hz(self,span):self.ops.append(('timer_hz',span));return self.samples.pop(0)
    def peek(self,address,count):
        self.ops.append(('peek',address,count))
        if count>512:raise AssertionError('Oversized read')
        for k,a in {**probe.clock.CLOCK_REGISTERS,**probe.clock.UART_REGISTERS,**probe.clock.OTHER_REGISTERS}.items():
            if address==a:
                if count!=4:raise AssertionError('Consuming/ambiguous MMIO read')
                return self.registers[k].to_bytes(4,'little')
        out=bytes(self.memory[address+i] for i in range(count))
        return bytes([out[0]^1])+out[1:] if self.bad_readback else out
    def poke(self,address,raw):
        if len(raw)>512:raise AssertionError('Oversized write')
        self.ops.append(('poke',address,bytes(raw)));self.memory.update({address+i:v for i,v in enumerate(raw)})
    def jump(self,address):
        self.ops.append(('call',address));args=bytes(self.memory[probe.ARGS+i] for i in range(64))
        nonce,mode=struct.unpack_from('<2I',args,8)
        if mode:
            self.memory.update({probe.DECODER['pcm'][0]+i:v for i,v in enumerate(self.pcm)})
            self.memory.update({probe.DECODER['frame_ticks'][0]+i:v for i,v in enumerate(timings())})
        recs=records(mode,probe.fixture_info(self.fixture)['payload_crc32'],self.canonical_crc,self.pcm)
        self.port.buffer.extend(self.modify_raw(packet(nonce,mode,self.modify_records(recs))))
        self.after_call()


class DecoderProbeTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup);self.directory=Path(temporary.name)
        native=copy.deepcopy(probe.NATIVE);backup=bytes(0x100000);native['program_sha256']=probe.digest(backup)
        for key in ('code','tables'):
            x=native[key];x['sha256']=probe.digest(bytes(x['bytes']))
        patch=mock.patch.object(probe,'NATIVE',native);patch.start();self.addCleanup(patch.stop)
        self.image=b'\x00\x50'*600;elf=make_elf(self.image)
        self.manifest=dict(schema=probe.SCHEMA,build_id=probe.BUILD_ID,entry=probe.ENTRY,ram_start=probe.ENTRY,
            ram_end=probe.RAM_END,args_address=probe.ARGS,allowed_modes=[0,1],source_commit='a'*40,
            stub_source_sha256=probe.transport.STUB_SHA256,native=native,decoder=copy.deepcopy(probe.DECODER),
            ranges={**copy.deepcopy(probe.FIXED),'image':[probe.ENTRY,probe.ENTRY+len(self.image)],'bss':[0x45000,0x45100]},
            image=dict(file='probe.bin',bytes=len(self.image),sha256=probe.digest(self.image)),
            elf=dict(file='probe.elf',bytes=len(elf),sha256=probe.digest(elf)))
        (self.directory/'probe.bin').write_bytes(self.image);(self.directory/'probe.elf').write_bytes(elf)
        self.backup=self.directory/'original.bin';self.backup.write_bytes(backup)
        self.path=self.directory/'manifest.json';self.save()
        self.bundle=probe.load_bundle(self.path,self.backup)
        self.fixture=fixture();self.info=probe.fixture_info(self.fixture)
        self.oracle={'software_pcm':bytes(20480),'canonical_crc32':zlib.crc32(bytes(15872)),'fixture_sha256':probe.digest(self.fixture)}
    def save(self):self.path.write_text(json.dumps(self.manifest))
    def run_fake(self,mode=0,radio=None,port=None,**kwargs):
        port=port or Port();radio=radio or Radio(port)
        result=probe.execute(self.bundle,mode,'FAKE',123,resume=True,
            radio_factory=lambda _:radio,port_factory=lambda _:port,log=lambda _:None,**kwargs)
        return result,radio,port
    def smoke(self):
        result,radio,port=self.run_fake()
        proof=dict(schema=probe.SCHEMA,dry_run=False,manifest=self.bundle['manifest'],**result)
        return proof,radio,port
    def compare(self,change=None,**kwargs):
        proof,radio,_=self.smoke();port=Port();radio.port=port
        if change:change(radio)
        result,radio,port=self.run_fake(1,radio,port,proof=proof,fixture=self.fixture,oracle=self.oracle,**kwargs)
        return result,radio,port
    def assert_no_call(self,radio):self.assertFalse(any(x[0]=='call' for x in radio.ops))

    def test_bundle_exact_layout_and_large_image_elf(self):
        self.assertEqual(self.bundle['ranges']['image'][0],0x38000)
        self.assertEqual(self.bundle['manifest']['decoder']['timing_arrays'],6)
        self.assertEqual(len(self.bundle['blobs']['code']),83456)
    def test_manifest_identity_layout_and_overlap_refused(self):
        for key,value in (('entry',0x40000),('allowed_modes',[0,1,5]),('schema','other')):
            with self.subTest(key=key):
                original=copy.deepcopy(self.manifest);self.manifest[key]=value;self.save()
                with self.assertRaises(probe.ProbeError):probe.load_bundle(self.path,self.backup)
                self.manifest=original
        self.manifest['ranges']['image']=[0x37c80,0x38000];self.save()
        with self.assertRaises(probe.ProbeError):probe.load_bundle(self.path,self.backup)
    def test_artifact_hash_and_sealed_backup_refused(self):
        (self.directory/'probe.bin').write_bytes(bytes(len(self.image)))
        with self.assertRaisesRegex(probe.ProbeError,'SHA256'):probe.load_bundle(self.path,self.backup)
        (self.directory/'probe.bin').write_bytes(self.image);self.backup.write_bytes(b'X'+bytes(0x100000-1))
        with self.assertRaisesRegex(probe.ProbeError,'backup SHA'):probe.load_bundle(self.path,self.backup)
    def test_elf_wrong_entry_or_load_address_refused(self):
        for offset,value in ((24,0x40000),(60,0x30000)):
            raw=bytearray(make_elf(self.image));struct.pack_into('<I',raw,offset,value)
            with self.assertRaises(probe.ProbeError):probe.validate_elf(bytes(raw),self.image,self.bundle['manifest']['ranges'])
    def test_fixture_initial_shape_and_crc_are_bounded(self):
        self.assertEqual(self.info['total_frames'],104)
        raw=bytearray(self.fixture);raw[-1]^=1
        with self.assertRaises(ValueError):probe.fixture_info(bytes(raw))
        raw=bytearray(self.fixture);struct.pack_into('<I',raw,12,39);struct.pack_into('<I',raw,60,zlib.crc32(raw[:60]))
        with self.assertRaises(ValueError):probe.fixture_info(bytes(raw))
    def test_args_crc_nonce_mode_and_cold_context(self):
        raw=probe.make_args(123,1);self.assertEqual(len(raw),64);self.assertEqual(raw[:8],probe.ARG_MAGIC)
        self.assertEqual(zlib.crc32(raw[:60]),int.from_bytes(raw[60:],'little'))
        for nonce,mode in ((0,1),(True,1),(123,True),(123,2)):
            with self.assertRaises(probe.ProbeError):probe.make_args(nonce,mode)
    def test_smoke_never_uploads_native_or_fixture(self):
        result,radio,port=self.run_fake();self.assertTrue(port.closed);self.assertTrue(result['clock_restored'])
        self.assertEqual(sum(x[0]=='call' for x in radio.ops),1)
        for op in radio.ops:
            if op[0]=='poke':self.assertTrue(probe.ENTRY<=op[1]<probe.ENTRY+len(self.image) or probe.ARGS<=op[1]<probe.ARGS+64)
    def test_compare_one_call_golden_params_timing_and_restoration(self):
        result,radio,port=self.compare();self.assertTrue(port.closed)
        self.assertTrue(result['software_reference_match']);self.assertTrue(result['canonical_reference_match'])
        self.assertEqual(result['native_pcm_crc32'],0xabcdef01);self.assertFalse(result['audio_qualified'])
        self.assertEqual(sum(x[0]=='call' for x in radio.ops),2) # prior smoke plus one compare invocation
        self.assertEqual(result['clock_before'],result['clock_after'])
        self.assertEqual(result['benchmark']['native_total']['frames'],64)
    def test_resume_timeout_mode_refused_before_open(self):
        for changes in ({'resume':False},{'timeout':float('nan')},{'timeout':31},{'mode':True}):
            options=dict(mode=0,name='FAKE',nonce=123,resume=True);options.update(changes);factory=mock.Mock()
            with self.assertRaises(probe.ProbeError):probe.execute(self.bundle,**options,radio_factory=mock.Mock(),port_factory=factory)
            factory.assert_not_called()
    def test_wrong_monitor_refused_before_configure_or_writes(self):
        for key,value in (('board',0),('run',0x31000),('load',0x44000),('stack_used',4096)):
            p=Port();r=Radio(p);r.v6[key]=value
            with self.assertRaises(probe.ProbeError):self.run_fake(radio=r,port=p)
            self.assertFalse(any(x[0] in ('configure','poke','call') for x in r.ops));self.assertTrue(p.closed)
    def test_clock_and_uart_preflight_refuse_before_poke(self):
        for key in (*probe.clock.COLD_CLOCKS,'UART_LCR','UART_IER','TIMER2_LOAD','TIMER2_CTRL'):
            p=Port();r=Radio(p);r.registers[key]^=1
            with self.assertRaises(probe.ProbeError):self.run_fake(radio=r,port=p)
            self.assert_no_call(r);self.assertFalse(any(x[0]=='poke' for x in r.ops))
    def test_dlab_prevents_ambiguous_ier_read(self):
        p=Port();r=Radio(p);r.registers['UART_LCR']|=128
        with self.assertRaises(probe.ProbeError):self.run_fake(radio=r,port=p)
        self.assertFalse(any(x[:2]==('peek',0x14030004) for x in r.ops))
    def test_bad_readback_prevents_call(self):
        p=Port();r=Radio(p);r.bad_readback=True
        with self.assertRaisesRegex(probe.ProbeError,'readback'):self.run_fake(radio=r,port=p)
        self.assert_no_call(r);self.assertTrue(p.closed)
    def test_missing_or_forged_smoke_proof_refused_before_open(self):
        proof,_,_=self.smoke()
        for key,value in (('manifest',{}),('clock_restored',False),('raw_sha256','0'*64),('monitor_returned',False)):
            bad=copy.deepcopy(proof);bad[key]=value;factory=mock.Mock()
            with self.assertRaises(probe.ProbeError):
                probe.execute(self.bundle,1,'FAKE',456,resume=True,proof=bad,fixture=self.fixture,oracle=self.oracle,
                              radio_factory=mock.Mock(),port_factory=factory)
            factory.assert_not_called()
    def test_missing_live_smoke_cookie_or_image_refused_before_new_writes(self):
        for address in (probe.ARGS,probe.ENTRY):
            proof,r,_=self.smoke();p=Port();r.port=p;r.memory[address]^=1;old=sum(x[0]=='poke' for x in r.ops)
            with self.assertRaisesRegex(probe.ProbeError,'cookie/image'):
                self.run_fake(1,r,p,proof=proof,fixture=self.fixture,oracle=self.oracle)
            self.assertEqual(sum(x[0]=='poke' for x in r.ops),old)
            self.assertEqual(sum(x[0]=='call' for x in r.ops),1)
    def test_packet_crc_identity_count_guards_and_oracle_refusals(self):
        rec=records(1,self.info['payload_crc32'],self.oracle['canonical_crc32'])
        raw=packet(123,1,rec);probe.parse_packet(raw,123,1,self.info,self.oracle['canonical_crc32'])
        bad=bytearray(raw);bad[-1]^=1
        variants=[bytes(bad),packet(123,1,rec,{'nonce':124}),packet(123,1,rec,{'fatal':2}),
                  packet(123,1,rec,{'guard_mask':30}),packet(123,1,rec,{'cpuid_words':1})]
        for identifier,key in ((21,'value'),(25,'value'),(31,'value'),(36,'aux'),(20,'aux'),(23,'aux')):
            rr=copy.deepcopy(rec);next(x for x in rr if x['id']==identifier)[key]^=1;variants.append(packet(123,1,rr))
        for raw in variants:
            with self.assertRaises(probe.ProbeError):probe.parse_packet(raw,123,1,self.info,self.oracle['canonical_crc32'])
    def test_impossible_native_pcm_observations_refused(self):
        for identifier,key,value in ((23,'value',10240),(22,'value',1),(22,'aux',1)):
            rec=records(1,self.info['payload_crc32'],self.oracle['canonical_crc32'])
            next(r for r in rec if r['id']==identifier)[key]=value
            with self.assertRaisesRegex(probe.ProbeError,'PCM observations'):
                probe.parse_packet(packet(123,1,rec),123,1,self.info,self.oracle['canonical_crc32'])
    def test_partial_fatal_abort_retains_validated_target_diagnostics(self):
        rec=records(1,self.info['payload_crc32'],self.oracle['canonical_crc32'])[:4]
        rec[-1]['status']=4
        with self.assertRaisesRegex(probe.ProbeError,'Decoder failure') as context:
            probe.parse_packet(packet(123,1,rec,{'fatal':4}),123,1,self.info,self.oracle['canonical_crc32'])
        self.assertEqual(context.exception.target_result['header']['fatal'],4)
        self.assertEqual(context.exception.target_result['records'][-1]['id'],20)
    def test_partial_exception_diagnostics_preserved_and_never_recalled(self):
        p=Port();r=Radio(p)
        def failure(raw):
            rec=records(0);rec[-1].update(status=3,vector=4,epc=probe.ENTRY+256,epsr=0x80000100,aux=0x47f00)
            return packet(123,0,rec,{'fatal':2})
        r.modify_raw=failure
        with self.assertRaises(probe.ProbeError) as context:self.run_fake(radio=r,port=p)
        self.assertEqual(context.exception.target_result['records'][-1]['epc'],probe.ENTRY+256)
        self.assertTrue(context.exception.monitor_returned);self.assertTrue(context.exception.clock_restored)
        self.assertEqual(sum(x[0]=='call' for x in r.ops),1);self.assertTrue(p.closed)
    def test_unknown_fatal_and_out_of_range_exception_refused_with_evidence(self):
        rec=records(0)
        with self.assertRaisesRegex(probe.ProbeError,'Unknown decoder fatal') as context:
            probe.parse_packet(packet(123,0,rec,{'fatal':5}),123,0)
        self.assertEqual(context.exception.target_result['header']['fatal'],5)
        rec[-1].update(status=3,vector=4,epc=0x11000000,epsr=0x80000100)
        with self.assertRaisesRegex(probe.ProbeError,'executable ranges'):
            probe.parse_packet(packet(123,0,rec,{'fatal':2}),123,0)
    def test_timing_crc_totals_and_full_stage_relationship_refused(self):
        rec=records(1,self.info['payload_crc32'],self.oracle['canonical_crc32'])
        parsed=probe.parse_packet(packet(123,1,rec),123,1,self.info,self.oracle['canonical_crc32'])
        probe.timing_metrics(timings(),parsed)
        for index,value in ((0,0),(128,1),(320,1)):
            raw=bytearray(timings());struct.pack_into('<I',raw,index*4,value)
            changed=copy.deepcopy(parsed);changed['records'][-1]['value']=zlib.crc32(raw)
            with self.assertRaises(probe.ProbeError):probe.timing_metrics(bytes(raw),changed)
    def test_golden_mismatch_is_fatal_after_monitor_recovery_without_recall(self):
        with self.assertRaisesRegex(probe.ProbeError,'golden') as context:
            self.compare(lambda r:setattr(r,'pcm',bytes([1])*20480))
        self.assertTrue(context.exception.monitor_returned);self.assertTrue(context.exception.clock_restored)
        self.assertEqual(context.exception.call_operations_requested,1)
    def test_bad_result_no_call_retry_and_partial_evidence_retained(self):
        p=Port();r=Radio(p);r.modify_raw=lambda raw:raw[:-1]+bytes([raw[-1]^1])
        with self.assertRaises(probe.ProbeError) as context:self.run_fake(radio=r,port=p)
        self.assertTrue(context.exception.raw_hex);self.assertEqual(sum(x[0]=='call' for x in r.ops),1)
        self.assertTrue(context.exception.monitor_returned);self.assertTrue(p.closed)
    def test_no_monitor_return_or_restoration_drift_has_no_recovery_write(self):
        for failure in ('monitor','clock','uart'):
            p=Port();r=Radio(p)
            if failure=='monitor':r.after_call=lambda:setattr(r,'fail_return',True)
            elif failure=='clock':r.after_call=lambda:r.registers.update(CTRL=0xc0000004)
            else:r.after_call=lambda:r.registers.update(UART_MCR=1)
            with self.assertRaises((probe.ProbeError,OSError)):self.run_fake(radio=r,port=p)
            self.assertEqual(sum(x[0]=='call' for x in r.ops),1);self.assertEqual(sum(x[0]=='poke' for x in r.ops),4)
            self.assertTrue(p.closed)
    def test_whitelist_cannot_write_mmio_or_partial_objects(self):
        r=Radio(Port());allowed={(probe.ENTRY,probe.ENTRY+len(self.image)),(probe.ARGS,probe.ARGS+64)}
        for addr,raw in ((0x11000004,bytes(4)),(probe.ENTRY+4,self.image[4:]),(probe.ARGS,bytes(65)),(probe.ARGS,b'')):
            with self.assertRaises(probe.ProbeError):probe.write_verified(r,addr,raw,allowed)
        self.assertFalse(r.ops)
    def test_cli_dry_run_never_imports_serial_or_monitor_loader(self):
        with mock.patch.object(sys,'argv',['native-decoder-probe.py','--manifest',str(self.path),'--backup',str(self.backup)]), \
             mock.patch.object(probe.transport,'load_stub') as loader,contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(probe.main(),0)
        loader.assert_not_called();self.assertFalse(json.loads(output.getvalue())['serial_opened'])
    def test_oracle_files_are_hashed_and_path_bounded(self):
        canonical=bytes(15872);pcm=bytes(20480)
        def desc(name,raw):
            (self.directory/name).write_bytes(raw)
            return dict(file=name,bytes=len(raw),sha256=probe.digest(raw),crc32=zlib.crc32(raw))
        data=dict(schema='c7-native-decoder-oracle-v1',warmup_frames=40,frames=64,
                  fixture=desc('fixture.bin',self.fixture),software_pcm=desc('software.pcm',pcm),canonical=desc('canonical.bin',canonical))
        path=self.directory/'oracle.json';path.write_text(json.dumps(data));probe.load_oracle(path,self.fixture)
        data['software_pcm']['file']='../software.pcm';path.write_text(json.dumps(data))
        with self.assertRaises(probe.ProbeError):probe.load_oracle(path,self.fixture)
    def test_oracle_fixture_metadata_must_match_entire_fixture(self):
        pcm=bytes(20480);canonical=bytes(15872)
        def desc(name,raw):
            (self.directory/name).write_bytes(raw)
            return dict(file=name,bytes=len(raw),sha256=probe.digest(raw),crc32=zlib.crc32(raw))
        data=dict(schema='c7-native-decoder-oracle-v1',warmup_frames=40,frames=64,
                  fixture=desc('fixture.bin',self.fixture),software_pcm=desc('software.pcm',pcm),canonical=desc('canonical.bin',canonical))
        path=self.directory/'oracle.json'
        for key in ('bytes','crc32','sha256'):
            changed=copy.deepcopy(data);changed['fixture'][key]=0;path.write_text(json.dumps(changed))
            with self.assertRaisesRegex(probe.ProbeError,'fixture identity'):probe.load_oracle(path,self.fixture)


class DecoderPackageTests(unittest.TestCase):
    def setUp(self):
        self.package=probe.module('decoder_package_under_test',ROOT/'scripts/package-native-decoder-probe.py')
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup);self.directory=Path(temporary.name)
        self.image=bytes.fromhex('00c4209c00c4809c00c4409c00c4009d')+bytes(1200-16)
        (self.directory/'probe.bin').write_bytes(self.image)
        (self.directory/'probe.elf').write_bytes(make_elf(self.image))
        self.symbols='00038000 T nvd_entry\n00044900 B nvd_monitor_frame\n000384b0 T __image_end\n00045000 B __bss_start\n00045100 B __bss_end\n'
        (self.directory/'symbols.txt').write_text(self.symbols)
        (self.directory/'disassembly.txt').write_text('00038000: nop\n')
    def test_package_exact_layout_and_opcode_requirements(self):
        with mock.patch.object(self.package.subprocess,'check_output',return_value='a'*40):
            result=self.package.package(self.directory)
        self.assertEqual(result['entry'],0x38000);self.assertEqual(result['ranges']['image'],[0x38000,0x384b0])
        self.assertEqual(result['decoder'],probe.DECODER)
        self.assertTrue((self.directory/'manifest.json').is_file())
    def test_package_rejects_unresolved_symbols_high_registers_and_missing_dsp_save(self):
        for filename,value,message in (
            ('symbols.txt',self.symbols+'         U missing\n','Unresolved'),
            ('disassembly.txt','00038000: mov r16, r0\n','high general'),
            ('probe.bin',bytes(len(self.image)),'HI/LO')):
            with self.subTest(filename=filename):
                path=self.directory/filename;original=path.read_bytes()
                path.write_bytes(value.encode() if isinstance(value,str) else value)
                with self.assertRaisesRegex(ValueError,message):self.package.package(self.directory)
                path.write_bytes(original)
    def test_package_refuses_old_entry_before_emitting_manifest(self):
        (self.directory/'symbols.txt').write_text(self.symbols.replace('00038000 T nvd_entry','00040000 T nvd_entry'))
        with self.assertRaisesRegex(ValueError,'assembly layout'):self.package.package(self.directory)
        self.assertFalse((self.directory/'manifest.json').exists())


if __name__=='__main__':unittest.main()
