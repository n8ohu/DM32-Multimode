"""Offline primary voice trigger, nonce, profile and restoration checks."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("triggered_p25_voice", ROOT/"scripts/hotspot-p25-voice-session.py")
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
TOKEN = "a1"*32
FIXTURE = ROOT/"fixtures/p25-1011/call.bin"
CONFIG = """[General]
Duplex=0
[Info]
RXFrequency=145700000
TXFrequency=145700000
[Modem]
Protocol=uart
UARTPort=/dev/ttyAMA0
UARTSpeed=115200
TXDelay=100
RXOffset=125
TXOffset=-250
RXInvert=1
TXInvert=0
PTTInvert=1
P25TXLevel=50
[DMR]
Enable=1
[DMR Network]
Enable=1
[P25 Network]
Enable=1
"""
DESCRIPTION = b"MMDVM_HS-v1.6.1 20231115_WPSD 14.7456MHz ADF7021 GitID #7e16099"
VERSION = bytes((0xE0, len(DESCRIPTION)+4, 0, 1))+DESCRIPTION


class Clock:
    def __init__(self): self.now = 100.0
    def __call__(self): return self.now
    def sleep(self, seconds): self.now += seconds


class IdleLink:
    def __init__(self): self.statuses = 0; self.sent = []
    def status(self):
        self.statuses += 1
        return {"p25": True, "mode": 0, "tx": False, "space": 6}
    def send(self, packet): self.sent.append(packet)


class Services:
    def __init__(self):
        self.before = {unit: unit in ("mmdvmhost.service", "mmdvmhost.timer", "p25gateway.service")
                       for unit in tool.CC.UNITS}
        self.states = self.before.copy()
        self.fail_start = None
    def loaded(self, unit): return self.before[unit]
    def active(self, unit): return self.states[unit]
    def manual_hosts(self): return False
    def service(self, action, unit):
        if action == "start" and unit == self.fail_start: raise RuntimeError("restart failed")
        self.states[unit] = action == "start"


class VoiceProfileTests(unittest.TestCase):
    def source(self, directory, text=CONFIG):
        source = Path(directory)/"modem.ini"; source.write_text(text); return source

    def test_preserved_vhf_profile_creates_only_temporary_uhf_simplex_words(self):
        with tempfile.TemporaryDirectory() as directory:
            source = self.source(directory)
            original = source.read_bytes()
            profile = tool.configuration(source, 440087500, 10)
            self.assertEqual(source.read_bytes(), original)
        self.assertEqual(struct.unpack("<II", profile["frequency_packet"][4:12]), (440087625, 440087250))
        self.assertEqual(profile["rf_level_byte"], 25)
        self.assertLessEqual(profile["rf_level_byte"]/255, 0.1)
        payload = profile["config_packet"][3:]
        self.assertEqual(len(payload), 23)
        self.assertEqual(payload[:4], bytes((0x85, 8, 10, 0)))
        self.assertEqual(payload[5], 0)
        self.assertEqual(payload[9:12], bytes(3))
        self.assertEqual(payload[12], 128)
        self.assertLess(profile["lead_seconds"], 1.5)

    def test_invalid_profile_frequency_levels_and_unknown_version_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            source = self.source(directory)
            for frequency, power in ((None, 9), (145700000, 9), (440100000, 9),
                                     (440087500, 0), (440087500, 11), (440087500, True)):
                with self.subTest(frequency=frequency, power=power), self.assertRaises(ValueError):
                    tool.configuration(source, frequency, power)
            for text in (CONFIG.replace("Duplex=0", "Duplex=1"),
                         CONFIG.replace("TXFrequency=145700000", "TXFrequency=440087500"),
                         CONFIG.replace("Protocol=uart", "Protocol=udp"),
                         CONFIG.replace("P25TXLevel=50", "P25TXLevel=nan"),
                         CONFIG.replace("RXOffset=125", "RXOffset=50000")):
                source.write_text(text)
                with self.subTest(text=text), self.assertRaises(ValueError):
                    tool.configuration(source, 440087500, 9)
        self.assertEqual(tool.identify(VERSION), DESCRIPTION.decode())
        for value in (VERSION.replace(b"#7e16099", b"#89daa20"), VERSION[:3]+b"\x02"+VERSION[4:], b""):
            with self.subTest(value=value), self.assertRaises(RuntimeError): tool.identify(value)

    def test_fixed_known_clear_fixture_and_no_rf_default(self):
        with patch.object(tool, "configuration", side_effect=AssertionError("no config access")), \
                patch.object(tool, "System", side_effect=AssertionError("no services")), \
                patch.object(tool, "transmit", side_effect=AssertionError("no RF")), \
                patch.dict(sys.modules, {"serial": None}), contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(tool.main(["--fixture", str(FIXTURE)]), 0)
        report = json.loads(output.getvalue())
        self.assertEqual((report["units"], report["voice_frames"], report["voice_seconds"]), (30, 252, 5.04))
        self.assertTrue(report["dry_run"])
        self.assertEqual(report["rf_payload_commands_sent"], 0)
        self.assertEqual(report["trigger_wait_limit_s"], 45)
        self.assertNotIn(TOKEN, output.getvalue())
        with tempfile.TemporaryDirectory() as directory:
            bad = Path(directory)/"bad.bin"; bad.write_bytes(FIXTURE.read_bytes()[:-1])
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                tool.main(["--fixture", str(bad)])


class TriggerTests(unittest.TestCase):
    def test_absent_trigger_expires_after_only_idle_status_polls(self):
        with tempfile.TemporaryDirectory() as directory:
            clock = Clock(); link = IdleLink()
            with self.assertRaisesRegex(TimeoutError, "zero RF"):
                tool.wait_for_trigger(link, Path(directory)/"start.trigger", TOKEN, .25,
                                      clock=clock, sleep=clock.sleep)
            self.assertEqual(link.sent, [])
            self.assertGreater(link.statuses, 1)
            self.assertLessEqual(clock(), 100.250001)

    def test_new_correct_nonce_matches_before_deadline_and_is_not_echoed(self):
        with tempfile.TemporaryDirectory() as directory:
            clock = Clock(); link = IdleLink(); trigger = Path(directory)/"start.trigger"
            def sleep(seconds):
                clock.sleep(seconds)
                if clock() >= 100.1: trigger.write_text(json.dumps({"nonce": TOKEN}))
            result = tool.wait_for_trigger(link, trigger, TOKEN, 1, clock=clock, sleep=sleep)
            self.assertTrue(result["trigger_verified"])
            self.assertLess(result["wait_elapsed_s"], 1)
            self.assertNotIn(TOKEN, json.dumps(result))
            self.assertEqual(link.sent, [])

    def test_bad_nonce_malformed_and_oversized_triggers_fail_with_zero_payload(self):
        invalid = (json.dumps({"nonce": "b2"*32}), "{", json.dumps({"nonce": TOKEN, "extra": 1}),
                   json.dumps({"nonce": 1}), "x"*1025)
        with tempfile.TemporaryDirectory() as directory:
            trigger = Path(directory)/"start.trigger"
            for data in invalid:
                trigger.write_text(data); clock = Clock(); link = IdleLink()
                with self.subTest(data=data[:50]), self.assertRaises(RuntimeError):
                    tool.wait_for_trigger(link, trigger, TOKEN, 1, clock=clock, sleep=clock.sleep)
                self.assertEqual(link.sent, [])

    def test_status_delayed_beyond_deadline_cannot_authorize_existing_nonce(self):
        with tempfile.TemporaryDirectory() as directory:
            trigger = Path(directory)/"start.trigger"; trigger.write_text(json.dumps({"nonce": TOKEN}))
            clock = Clock(); link = IdleLink(); normal = link.status
            def delayed(): clock.sleep(2); return normal()
            link.status = delayed
            with self.assertRaises(TimeoutError):
                tool.wait_for_trigger(link, trigger, TOKEN, 1, clock=clock, sleep=clock.sleep)
            self.assertEqual(link.sent, [])

    def test_extended_wait_accepts_a_late_prepared_secondary_without_rf_while_waiting(self):
        with tempfile.TemporaryDirectory() as directory:
            trigger = Path(directory)/"start.trigger"; clock = Clock(); link = IdleLink()
            def sleep(seconds):
                clock.sleep(seconds)
                if clock() >= 140:
                    trigger.write_text(json.dumps({"nonce": TOKEN}))
            result = tool.wait_for_trigger(link, trigger, TOKEN, 45, clock=clock, sleep=sleep)
            self.assertGreaterEqual(result["wait_elapsed_s"], 40)
            self.assertLess(result["wait_elapsed_s"], 45)
            self.assertTrue(result["trigger_verified"])
            self.assertEqual(link.sent, [])

    def test_extended_wait_still_rejects_a_trigger_after_its_deadline(self):
        with tempfile.TemporaryDirectory() as directory:
            trigger = Path(directory)/"start.trigger"; clock = Clock(); link = IdleLink()
            normal = link.status
            def delayed():
                clock.sleep(45.01)
                trigger.write_text(json.dumps({"nonce": TOKEN}))
                return normal()
            link.status = delayed
            with self.assertRaises(TimeoutError):
                tool.wait_for_trigger(link, trigger, TOKEN, 45, clock=clock, sleep=clock.sleep)
            self.assertEqual(link.sent, [])

    def test_tx_mode_and_pending_fifo_refused_before_trigger(self):
        with tempfile.TemporaryDirectory() as directory:
            trigger = Path(directory)/"start.trigger"; trigger.write_text(json.dumps({"nonce": TOKEN}))
            for changed in ({"tx": True}, {"p25": False}, {"mode": 4}, {"space": 5}):
                clock = Clock(); link = IdleLink(); good = link.status()
                link.status = lambda changed=changed: dict(good, **changed)
                with self.subTest(changed=changed), self.assertRaises(RuntimeError):
                    tool.wait_for_trigger(link, trigger, TOKEN, 1, clock=clock, sleep=clock.sleep)
                self.assertEqual(link.sent, [])

    def test_nonce_and_wait_limits_fail_before_modem_queries(self):
        link = IdleLink()
        for token in (None, "a"*63, "z"*64, "a"*65):
            with self.subTest(token=token), self.assertRaises(ValueError):
                tool.wait_for_trigger(link, Path("unused"), token, 1)
        for seconds in (0, -1, 46, float("nan"), float("inf"), True):
            with self.subTest(seconds=seconds), self.assertRaises(ValueError):
                tool.operation_limit(seconds)
        self.assertEqual(link.statuses, 0)
        self.assertAlmostEqual(tool.operation_limit(15), 28.04)
        self.assertAlmostEqual(tool.operation_limit(45), 58.04)


class HardwareBoundaryTests(unittest.TestCase):
    def setup(self, directory):
        source = Path(directory)/"modem.ini"; source.write_text(CONFIG)
        profile = tool.configuration(source, 440087500, 9)
        frames = tool.BASE.load_frames(FIXTURE, 14, "clear")
        return profile, frames, Path(directory)/"start.trigger"

    def test_ready_precedes_trigger_and_replay_occurs_only_after_match(self):
        with tempfile.TemporaryDirectory() as directory:
            profile, frames, trigger = self.setup(directory); commands = []; events = []
            class Device:
                def __enter__(self): return self
                def __exit__(self, *args): return False
            device = Device()
            class SetupLink(IdleLink):
                def __init__(self, device): super().__init__()
                def query(self, command): return VERSION
                def command(self, packet): commands.append(packet)
            def emit(record):
                events.append(record)
                if record["event"] == "voice_ready":
                    self.assertFalse(trigger.exists())
                    trigger.write_text(json.dumps({"nonce": TOKEN}))
            def replay(link, packets, lead):
                self.assertEqual([record["event"] for record in events], ["voice_ready", "voice_triggered"])
                self.assertEqual(packets, frames)
                self.assertEqual(link.sent, [])
                return {"units_sent": 30, "tx_observed": True}
            with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=lambda **kwargs: device)}), \
                    patch.object(tool, "Link", SetupLink), patch.object(tool.BASE, "replay", side_effect=replay):
                result = tool.transmit(profile, frames, trigger, TOKEN, emit)
            self.assertEqual(commands, [profile["frequency_packet"], profile["config_packet"]])
            self.assertTrue(result["trigger_verified"])
            self.assertEqual(result["voice_frames"], 252)
            self.assertNotIn(TOKEN, json.dumps(events))

    def test_missing_trigger_bad_nonce_and_init_failure_never_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            profile, frames, trigger = self.setup(directory)
            class Device:
                def __enter__(self): return self
                def __exit__(self, *args): return False
            class SetupLink(IdleLink):
                def __init__(self, device): super().__init__()
                def query(self, command): return VERSION
                def command(self, packet): pass
            for failure in (TimeoutError("expired"), RuntimeError("nonce mismatch")):
                with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=lambda **kwargs: Device())}), \
                        patch.object(tool, "Link", SetupLink), \
                        patch.object(tool, "wait_for_trigger", side_effect=failure), \
                        patch.object(tool.BASE, "replay", side_effect=AssertionError("no RF")) as replay:
                    with self.assertRaises(type(failure)):
                        tool.transmit(profile, frames, trigger, TOKEN, lambda record: None)
                    replay.assert_not_called()
            with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=lambda **kwargs: Device())}), \
                    patch.object(tool, "Link", SetupLink), \
                    patch.object(tool, "identify", side_effect=RuntimeError("wrong modem")), \
                    patch.object(tool.BASE, "replay", side_effect=AssertionError("no RF")) as replay:
                with self.assertRaises(RuntimeError):
                    tool.transmit(profile, frames, trigger, TOKEN, lambda record: self.fail("not ready"))
                replay.assert_not_called()
            trigger.write_text(json.dumps({"nonce": TOKEN}))
            with patch.dict(sys.modules, {"serial": None}), self.assertRaisesRegex(RuntimeError, "already exists"):
                tool.transmit(profile, frames, trigger, TOKEN, lambda record: None)


class CleanupTests(unittest.TestCase):
    def test_trigger_expiration_and_initialization_fault_restore_original_services(self):
        for failure in (TimeoutError("trigger expired"), RuntimeError("initialization failed")):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory:
                source = Path(directory)/"modem.ini"; source.write_text(CONFIG)
                before = source.read_bytes(); services = Services()
                report = {"original_config_sha256": hashlib.sha256(before).hexdigest()}
                def operation():
                    self.assertFalse(any(services.states.values()))
                    raise failure
                with self.assertRaises(type(failure)):
                    tool.execute_session(services, operation, source, report, settle=lambda seconds: None)
                self.assertEqual(services.states, services.before)
                self.assertEqual(source.read_bytes(), before)
                self.assertTrue(report["services_restored"])
                self.assertTrue(report["original_config_unchanged"])

    def test_failed_restore_is_reported_without_false_success(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)/"modem.ini"; source.write_text(CONFIG)
            services = Services(); services.fail_start = "mmdvmhost.service"
            report = {"original_config_sha256": tool.CC.digest(source)}
            tool.execute_session(services, lambda: {}, source, report, settle=lambda seconds: None)
            self.assertFalse(report["services_restored"])
            self.assertTrue(report["cleanup_errors"])


if __name__ == "__main__":
    unittest.main()
