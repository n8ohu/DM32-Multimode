// SPDX-License-Identifier: GPL-3.0-or-later
static void test_message_adapter(void) {
    normal_model model=normal_boot(false,false);
    radio_message msg={.protocol=RADIO_PROTOCOL_P25,.kind=RADIO_CALL_INDIVIDUAL,
        .source=control.source_id,.destination=42,.token=700,.text="PACKET TEST"};
    radio_mail_item *m=message_enqueue(&msg,0,false,channel_record);assert(m && m->state==RADIO_MAIL_QUEUED);
    uint32_t id=m->id;assert(message_enqueue(&msg,0,false,channel_record)->id==id && mailbox.count==1);
    msg.text[0]='X';assert(!message_enqueue(&msg,0,false,channel_record));msg.text[0]='P';
    normal_step(&model,false);assert(message_packet_tx && call_active && hardware_running && !audio_on && !encode_calls);
    unsigned cycles=0;while(message_active_id) {normal_step(&model,false);assert(++cycles<4000u);}
    m=radio_mail_find(&mailbox,id);assert(m && m->state==RADIO_MAIL_SENT && !message_packet_tx);
    assert_rf_safe();assert(!encode_calls && !pcmq.captured);
    p25_rx parser;p25_rx_init(&parser);p25_data_message decoded;unsigned packets=0;
    for(unsigned i=0;i<wire_n*4u;++i)if(p25_rx_push(&parser,(wire[i/4u]>>(6u-2u*(i%4u)))&3u)) {
        assert(parser.duid==12 && p25_data_parse_tms(parser.frame,parser.frame_bytes,&decoded));
        assert(decoded.source==msg.source && decoded.destination==42 && !strcmp(decoded.text,msg.text));++packets;
    }
    assert(packets==1 && !parser.bad_nid);
    // Permission, profile and TTL are rechecked at dispatch, never inherited
    // from the channel that was selected when a message was queued.
    msg.token=701;m=message_enqueue(&msg,0,false,channel_record);assert(m);id=m->id;
    owner_tx_inhibit=true;message_radio_poll(false);assert(radio_mail_find(&mailbox,id)->state==RADIO_MAIL_FAILED && !message_active_id);
    owner_tx_inhibit=false;normal_permission();msg.token=702;m=message_enqueue(&msg,0,false,channel_record);assert(m);id=m->id;
    ++channel_record[8];message_radio_poll(false);assert(radio_mail_find(&mailbox,id)->error==RADIO_MAIL_ERROR_CHANNEL);--channel_record[8];
    msg.token=703;m=message_enqueue(&msg,0,false,channel_record);assert(m);id=m->id;m->stamp=hal_millis()-RADIO_MAIL_QUEUE_MS;
    message_radio_poll(false);assert(radio_mail_find(&mailbox,id)->error==RADIO_MAIL_ERROR_TIMEOUT);
    // A physical held PTT cannot trigger a machine-originated transmission.
    mock_ptt_high=false;msg.token=704;assert(!message_enqueue(&msg,0,false,channel_record));mock_ptt_high=true;
    // Same firmware UI composes text without touching voice destination/ID.
    menu_open=true;menu_page=MENU_MESSAGES;menu_item=2;uint32_t old_source=control.source_id,old_group=control.talkgroup;
    local_action(ACT_SELECT,false);assert(menu_page==MENU_MESSAGE_COMPOSE);
    menu_item=3;local_action(ACT_SELECT,false);assert(message_text_edit);
    local_action(ACT_DIGIT_4,false);local_action(ACT_DIGIT_4,false);local_action(ACT_NAV_RIGHT,false);
    local_action(ACT_DIGIT_4,false);local_action(ACT_DIGIT_4,false);local_action(ACT_DIGIT_4,false);
    assert(!strcmp(message_input.text,"HI"));local_action(ACT_SELECT,false);assert(!message_text_edit);
    assert(control.source_id==old_source && control.talkgroup==old_group);
    menu_item=5;unsigned before=mailbox.count;local_action(ACT_SELECT,false);assert(message_send_review && mailbox.count==before);
    local_action(ACT_BACK,false);assert(!message_send_review && mailbox.count==before);
    // Native DMR async completion is not a PTT voice call or implicit delivery.
    model=normal_boot(false,false);feature_pause();assert(radio_channel_set_mode(channel_record,RADIO_CHANNEL_DMR));
    (void)radio_channel_set_color_code(channel_record,1);(void)radio_channel_set_timeslot(channel_record,2);feature_apply();
    normal_step(&model,false);assert(digital_dmr.running);
    msg.protocol=RADIO_PROTOCOL_DMR;msg.source=control.source_id;msg.token=800;
    m=message_enqueue(&msg,2,false,channel_record);assert(m);id=m->id;message_radio_poll(false);
    assert(message_active_id==id && radio_dmr_stub.message_sends==1 && radio_dmr_stub.message_format==2);
    assert(!digital_dmr.tx_armed && !encode_calls);
    digital_dmr.message_state=RADIO_DMR_MESSAGE_SENT;message_radio_poll(false);
    assert(!message_active_id && radio_mail_find(&mailbox,id)->state==RADIO_MAIL_SENT);
    msg.token=801;m=message_enqueue(&msg,0,true,channel_record);assert(m);id=m->id;message_radio_poll(false);
    digital_dmr.message_state=RADIO_DMR_MESSAGE_DELIVERED;message_radio_poll(false);
    assert(!message_active_id && radio_mail_find(&mailbox,id)->state==RADIO_MAIL_DELIVERED);
    // A data-critical serial refusal stays in the messaging protocol, so a
    // refresh cannot taint an otherwise healthy CPS connection.
    digital_dmr.data_armed=true;output_n=0;issue("CPS MSG HELLO",false);
    assert(!output_n && (command_deferred&COMMAND_DEFER_MESSAGE));
    digital_dmr.data_armed=false;call_active=hardware_running=prepared=false;command_deferred_flush(false);
    assert(strstr(output,"CPS MSG ERR BUSY"));
    menu_open=true;menu_page=MENU_MESSAGES;digital_dmr.data_armed=true;digital_dmr.message_state=RADIO_DMR_MESSAGE_SENDING;
    mock_ptt_high=false;feature_dmr_tick(true);
    assert(!digital_dmr.data_armed && digital_dmr.message_state==RADIO_DMR_MESSAGE_FAILED && !digital_dmr.tx_armed);
    mock_ptt_high=true;
    puts("Messaging adapter: exact packet RF bytes, independent cutoffs, channel/permission/TTL guards, keypad review and truthful DMR delivery passed");
}
