#ifndef TEST_RF_BOARD_REF_TRIM_H
#define TEST_RF_BOARD_REF_TRIM_H
#include <stdint.h>
static inline uint32_t ref_trim_tune_hz(uint32_t hz, int32_t ppb)
{
    int32_t n = (int32_t)(hz / 10000u) * ppb;
    return hz + (uint32_t)((n + (n < 0 ? -50000 : 50000)) / 100000);
}
#endif
