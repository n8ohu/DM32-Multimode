#ifndef TEST_RF_BOARD_HAL_TIME_H
#define TEST_RF_BOARD_HAL_TIME_H
#include <stdint.h>
void hal_delay_ms(uint32_t ms);
void hal_delay_us(uint32_t us);
#endif
