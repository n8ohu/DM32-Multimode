#ifndef TEST_RF_BOARD_FM_RX_AUDIO_H
#define TEST_RF_BOARD_FM_RX_AUDIO_H
#include "modem/hrc7000/hrc7000.h"
void hrc_fm_rx_attach(hrc7000_t *modem);
#endif
