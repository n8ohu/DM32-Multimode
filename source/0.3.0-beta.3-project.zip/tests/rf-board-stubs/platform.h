#ifndef TEST_RF_BOARD_PLATFORM_H
#define TEST_RF_BOARD_PLATFORM_H
#include <stdint.h>
#include <stdbool.h>
extern uint32_t test_dac_b;
#define DAC_DATA_B test_dac_b
void hrc_pin_write(unsigned pin, bool level);
void hrc_pin_out(unsigned pin, bool level);
void hrc_pin_in(unsigned pin);
bool hrc_pin_read(unsigned pin);
uint32_t hrc_irq_save(void);
void hrc_irq_restore(uint32_t state);
void hrc_modem_analog_init(uint16_t dac);
void hrc_dac_b_power(bool on);
#endif
