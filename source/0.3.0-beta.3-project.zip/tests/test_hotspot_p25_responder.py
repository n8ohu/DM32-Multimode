"""Native/primary-source packet and finite isolated responder tests; no RF."""
import ast
import contextlib
import copy
import ctypes as C
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from test_hotspot_p25_access import Clock, Serial

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("p25_responder_under_test", ROOT / "scripts/hotspot-p25-access.py")
TOOL = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = TOOL
spec.loader.exec_module(TOOL)
RID, TG = 0x123456, 10
DESCRIPTION = ("MMDVM_HS_Dual_Hat-v1.5.2 20201108 14.7456MHz dual "
               "ADF7021 FW by CA6JAU GitID #89daa20")

BRIDGE = r'''
#include "p25_trunking_access.h"
#include "p25_tsdu.h"
#include <stddef.h>
static p25_trunking_access core;
static unsigned last_action;
static const p25_trunking_access_site site={.wacn=0xabcde,.system=0x123,.nac=0x293,
    .rfss=1,.site=1,.fdma=true,.control_pair_valid=true,.control_rx_hz=440075000,.control_tx_hz=445075000};
bool responder_core_start(void) {
    p25_trunking_access_config config={.wacn=0xabcde,.system=0x123,.nac=0x293,
        .radio_id=0x123456,.group=10,.rfss=1,.site=1,.min_hz=400000000,.max_hz=480000000,.tot_ms=5000};
    p25_trunking_access_init(&core);last_action=0;
    return p25_trunking_access_start(&core,&config,0);
}
void responder_core_poll(uint32_t now,bool down) {
    p25_trunking_access_site_update(&core,&site,now);
    p25_trunking_access_poll(&core,now,down,true,true);
}
uint32_t responder_core_action(uint32_t now,bool down,uint8_t out[12]) {
    responder_core_poll(now,down);
    p25_trunking_access_action action;
    if(!p25_trunking_access_take(&core,&action,now))return 0;
    last_action=action.type;
    bool ok=true;
    switch(action.type) {
    case P25_TRUNK_ACTION_REGISTER:ok=p25_trunking_isp_register(out,0xabcde,0x123,action.radio_id);break;
    case P25_TRUNK_ACTION_AFFILIATE:ok=p25_trunking_isp_affiliate(out,0x123,action.group,action.radio_id);break;
    case P25_TRUNK_ACTION_GROUP_REQUEST:ok=p25_trunking_isp_group_request(out,action.group,action.radio_id,4);break;
    default:break;
    }
    return ok?action.id:0;
}
bool responder_core_result(uint32_t id,uint32_t now) {
    return p25_trunking_access_result(&core,id,true,now);
}
bool responder_core_receive(const uint8_t *wire,size_t length,uint32_t now,bool down) {
    p25_tsdu tsdu;p25_trunking_osp osp;
    responder_core_poll(now,down);
    if(!p25_tsdu_decode(wire,length,&tsdu) || tsdu.count!=1 || !p25_trunking_osp_parse(tsdu.block[0],&osp))return false;
    const p25_trunking_access_pair pair={.rx_hz=440087500,.tx_hz=445087500,.valid=true};
    return p25_trunking_access_consume(&core,&osp,tsdu.nac,440075000,&pair,now);
}
unsigned responder_core_last(void) {return last_action;}
bool responder_core_denied(void) {return core.reason==P25_TRUNK_ACCESS_DENIED;}
bool responder_core_granted(void) {return core.phase==P25_TRUNK_ACCESS_GRANTED;}
'''


class ResponderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames, cls.metadata = TOOL.CC.GENERATOR.make_fixture(
            control_frequency=440075000, voice_frequency=440087500, repetitions=1)
        cls.site = TOOL.site_only_frame(cls.frames, cls.metadata)
        build = ROOT / "build/test-p25-lab-responder"
        build.mkdir(parents=True, exist_ok=True)
        bridge = build / "responder_bridge.c"
        bridge.write_text(BRIDGE)
        library = build / ("responder.dll" if sys.platform == "win32" else "responder.so")
        command = ["gcc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-shared"]
        if sys.platform != "win32":
            command.append("-fPIC")
        subprocess.run(command + ["-Isrc/firmware", str(bridge), "src/firmware/p25_rx.c",
            "src/firmware/p25_tsdu.c", "src/firmware/p25_trunking_isp.c", "src/firmware/p25_trunking_access.c",
            "tests/test_p25_trunking_isp_bridge.c", "-o", str(library)], cwd=ROOT, check=True)
        cls.decoder = TOOL.NativeDecoder(library)
        cls.lib, cls.library = cls.decoder.lib, library
        cls.lib.p25_osp_test_frame.argtypes = [C.POINTER(C.c_uint8), C.c_size_t, C.POINTER(C.c_uint32)]
        cls.lib.p25_osp_test_frame.restype = C.c_bool
        cls.lib.responder_core_start.restype = C.c_bool
        cls.lib.responder_core_action.argtypes = [C.c_uint32, C.c_bool, C.POINTER(C.c_uint8)]
        cls.lib.responder_core_action.restype = C.c_uint32
        cls.lib.responder_core_result.argtypes = [C.c_uint32, C.c_uint32]
        cls.lib.responder_core_result.restype = C.c_bool
        cls.lib.responder_core_receive.argtypes = [C.POINTER(C.c_uint8), C.c_size_t, C.c_uint32, C.c_bool]
        cls.lib.responder_core_receive.restype = C.c_bool
        cls.lib.responder_core_poll.argtypes = [C.c_uint32, C.c_bool]
        cls.lib.responder_core_last.restype = C.c_uint
        cls.lib.responder_core_denied.restype = C.c_bool
        cls.lib.responder_core_granted.restype = C.c_bool
        # Load the actual pinned primary parser's assignment expressions. No
        # hand-transcribed shift formula supplies the registration/affiliation
        # or group-grant field oracle, and no upstream code is copied to files.
        primary = subprocess.check_output(["git", "-C", str(ROOT / "external/boatbod/op25"), "show",
            TOOL.CC.GENERATOR.OP25_COMMIT + ":op25/gr-op25_repeater/apps/tk_p25.py"], text=True)
        tree = ast.parse(primary)
        functions = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == "decode_tsbk"]
        if len(functions) != 1:
            raise AssertionError("Pinned primary parser's decode_tsbk changed")
        cls.primary = functions[0]
        cls.primary_response_fields = json.loads((ROOT / "tests/fixtures/p25-access-response-fields.json").read_text())

    def setUp(self):
        self.sequence = 0
        self.reference = TOOL.CC.GENERATOR.load_reference()

    def responder(self, **kwargs):
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG, **kwargs)
        actor.arm(0)
        return actor

    def acceptance_only(self, **kwargs):
        options = dict(registration_acceptance_only=True, registration='accept',
                       affiliation='timeout', voice='timeout', max_responses=1)
        options.update(kwargs)
        return self.responder(**options)

    def affiliation_only(self, **kwargs):
        options = dict(affiliation_acceptance_only=True, registration='timeout',
                       affiliation='accept', voice='timeout', max_responses=1)
        options.update(kwargs)
        return self.responder(**options)

    def affiliation_wire(self, *, rid=RID, group=TG, system=0x123, nac=0x293):
        return self.wire(0x28,system<<40|group<<24|rid,nac)

    def voice_only(self, **kwargs):
        options = dict(voice_grant_only=True, registration='timeout',
                       affiliation='timeout', voice='accept', max_responses=1)
        options.update(kwargs)
        return self.responder(**options)

    def voice_wire(self, *, options=4, rid=RID, group=TG, nac=0x293, reserved=0):
        return self.wire(0,options<<56|reserved<<40|group<<24|rid,nac)

    def attach(self, **kwargs):
        options = dict(attach_call=True, max_responses=3)
        options.update(kwargs)
        return self.responder(**options)

    def attach_leg(self, actor, wire, stamp, *, reset=False):
        header = self.event(wire, stamp=stamp)
        actor.observe(header)
        self.assertIsNone(actor.next_response(stamp + .05, stamp + .05))
        ending = self.reset_event(stamp=stamp + .1) if reset else self.event(stamp=stamp + .1, command=0x32)
        actor.observe(ending)
        response = actor.next_response(stamp + .15, stamp + .15)
        self.assertIsNotNone(response)
        self.assertEqual(actor.allowed_frames, frozenset((response.wire,)))
        actor.sent(response, stamp + .15)
        return header, ending, response

    def event(self, wire=None, *, stamp=0.1, command=0x30):
        self.sequence += 1
        packet = TOOL.MODEM.packet(command, b"\1" + wire) if wire is not None else TOOL.MODEM.packet(command)
        return TOOL.MODEM.Event(self.sequence, stamp, packet)

    def wire(self, opcode=0x2C, argument=None, nac=0x293):
        if argument is None:
            argument = 0xABCDE << 36 | 0x123 << 24 | RID
        return TOOL.CC.GENERATOR.encode_tsdu(self.reference, nac, [(opcode, argument)])[0]

    def reset_event(self,*,stamp=.27,duid=3,flag=1,rssi=True):
        self.sequence+=1
        rf=bytearray(b'\x77'*216);rf[7]=0xA0|duid
        wire=TOOL.MODEM.packet(0x31,bytes((flag,))+rf+(b'\x12\x34' if rssi else b''))
        return TOOL.MODEM.Event(self.sequence,stamp,wire)

    def parse(self, wire):
        out = (C.c_uint32 * 20)()
        source = (C.c_uint8 * len(wire)).from_buffer_copy(wire)
        self.assertTrue(self.lib.p25_osp_test_frame(source, len(wire), out))
        return list(out)

    def primary_fields(self, opcode, block, names):
        branch = next(n for n in ast.walk(self.primary) if isinstance(n, ast.If)
            and isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name)
            and n.test.left.id == "opcode" and len(n.test.comparators) == 1
            and isinstance(n.test.comparators[0], ast.Constant) and n.test.comparators[0].value == opcode)
        assignments = [n for n in ast.walk(ast.Module(body=branch.body, type_ignores=[])) if isinstance(n, ast.Assign)
            and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id in names]
        self.assertEqual({n.targets[0].id for n in assignments}, set(names))
        namespace = {"tsbk": int.from_bytes(block, "big")}
        exec(compile(ast.Module(body=assignments, type_ignores=[]), "pinned_OP25_field_oracle", "exec"), namespace)
        return {name: namespace[name] for name in names}

    def test_exchange_osp_native_decode_matches_actual_pinned_primary_parser(self):
        files, manifest = TOOL.EXCHANGE.make_exchange_fixture(radio_id=RID, talkgroup=TG)
        expectations = {
            "registration-accepted": (0x2C, {"rv": 0, "syid": 0x123, "sid": RID, "sa": RID}),
            "affiliation-accepted": (0x28, {"lg": 0, "gav": 0, "aga": 0, "ga": TG, "ta": RID}),
            "voice-grant": (0, {"opts": 4, "ch": 0x1001, "ga": TG, "sa": RID}),
        }
        for label, (opcode, expected) in expectations.items():
            with self.subTest(label=label):
                wire = files[manifest["frames"][label]["file"]]
                nac, blocks = self.decoder(wire)
                self.assertEqual(nac, 0x293)
                self.assertEqual(self.primary_fields(opcode, blocks[0], expected), expected)
                fields = self.parse(wire)
                self.assertEqual(fields[1], opcode)
                self.assertEqual(blocks[0].hex(), manifest["frames"][label]["decoded_hex"])
        # Queue/deny primary source field positions are MSB-first over80 data
        # bits including LB/P/opcode/MFID. The service is the inbound opcode.
        for stage, service in (("registration", 0x2C), ("affiliation", 0x28), ("voice", 0)):
            for kind, expected_reason, expected_type in (("queued", 0x40, 5), ("denied", 0x11, 6)):
                wire = files[stage + "-" + kind + ".bin"]
                _, blocks = self.decoder(wire)
                data = int.from_bytes(blocks[0][:10], "big")
                def field(name):
                    start, width = self.primary_response_fields["fields"][name]
                    return (data >> (80 - start - width)) & ((1 << width) - 1)
                self.assertEqual(tuple(field(name) for name in ("additional_valid", "service", "reason", "additional", "target")),
                                 (0, service, expected_reason, 0, RID))
                fields = self.parse(wire)
                self.assertEqual((fields[0], fields[2], fields[4], fields[10]),
                                 (expected_type, service, expected_reason, RID))

    def test_response_requires_native_crc_exact_identity_and_registration_first(self):
        candidates = [self.wire(nac=0x294), self.wire(argument=0xABCDE << 36 | 0x123 << 24 | RID + 1),
            self.wire(argument=0xABCDF << 36 | 0x123 << 24 | RID),
            self.wire(argument=0xABCDE << 36 | 0x124 << 24 | RID),
            self.wire(0x28, 0x123 << 40 | TG << 24 | RID), self.wire(0, TG << 24 | RID)]
        damaged = bytearray(self.wire())
        for index in range(18, 35):
            damaged[index] ^= 0xFF
        candidates.append(bytes(damaged))
        for wire in candidates:
            with self.subTest(wire=wire.hex()[:24]):
                actor = self.responder()
                actor.observe(self.event(wire))
                actor.observe(self.event(stamp=0.8, command=0x32))
                self.assertIsNone(actor.next_response(0.9, 0.9))
                self.assertEqual(actor.responses_sent, 0)
                self.assertEqual(actor.rejected, 1)

    def exchange_stage(self, actor, base, *, down=False):
        block = (C.c_uint8 * 12)()
        action_id = self.lib.responder_core_action(round(base * 1000), down, block)
        self.assertNotEqual(action_id, 0)
        self.assertTrue(self.lib.responder_core_result(action_id, round((base + 0.04) * 1000)))
        opcode, argument = block[0] & 0x3F, int.from_bytes(bytes(block)[2:10], "big")
        actor.observe(self.event(self.wire(opcode, argument), stamp=base + 0.05))
        self.assertIsNone(actor.next_response(base + 0.5, base + 0.5))
        actor.observe(self.event(stamp=base + 0.77, command=0x32))
        now = base + 0.8
        while True:
            response = actor.next_response(now, now)
            if response is None:
                return now
            actor.sent(response, now)
            source = (C.c_uint8 * len(response.wire)).from_buffer_copy(response.wire)
            self.assertTrue(self.lib.responder_core_receive(source, len(response.wire), round((now + 0.05) * 1000), down))
            if response.kind != "queued":
                return now + 0.05
            now += actor.queue_delay + 0.01

    def test_registration_affiliation_voice_grant_drive_the_actual_subscriber_core(self):
        actor = self.responder()
        self.assertTrue(self.lib.responder_core_start())
        now = self.exchange_stage(actor, 0)
        self.assertEqual(actor.phase, "affiliation")
        now = self.exchange_stage(actor, now + 0.2)
        self.assertEqual(actor.phase, "voice")
        now = self.exchange_stage(actor, now + 0.2, down=True)
        self.assertEqual(actor.phase, "granted")
        self.assertTrue(self.lib.responder_core_granted())
        self.assertEqual((actor.responses_sent, actor.grants_sent), (3, 1))
        out = (C.c_uint8 * 12)()
        self.assertNotEqual(self.lib.responder_core_action(round((now + 0.01) * 1000), True, out), 0)
        self.assertEqual(self.lib.responder_core_last(), 4)  # VOICE_START action, not RF.

    def test_queued_then_accepted_each_stage_matches_core_without_premature_grant(self):
        actor = self.responder(registration="queue", affiliation="queue", voice="queue")
        self.assertTrue(self.lib.responder_core_start())
        now = self.exchange_stage(actor, 0)
        self.assertFalse(self.lib.responder_core_granted())
        now = self.exchange_stage(actor, now + 0.2)
        self.assertFalse(self.lib.responder_core_granted())
        self.exchange_stage(actor, now + 0.2, down=True)
        self.assertTrue(self.lib.responder_core_granted())
        self.assertEqual((actor.responses_sent, actor.grants_sent), (6, 1))

    def test_deny_and_timeout_at_each_stage_never_grant_voice(self):
        for stage in ("registration", "affiliation", "voice"):
            for policy in ("deny", "timeout"):
                with self.subTest(stage=stage, policy=policy):
                    actor = self.responder(**{stage: policy})
                    self.assertTrue(self.lib.responder_core_start())
                    now = 0
                    for current in ("registration", "affiliation", "voice"):
                        now = self.exchange_stage(actor, now, down=current == "voice")
                        if current == stage:
                            break
                        now += 0.2
                    self.assertEqual(actor.phase, "denied" if policy == "deny" else "timeout")
                    self.assertEqual(actor.grants_sent, 0)
                    self.assertFalse(self.lib.responder_core_granted())
                    if policy == "deny":
                        self.assertTrue(self.lib.responder_core_denied())

    def test_all_safe_service_options_preserved_in_source_addressed_grants(self):
        actor = self.responder()
        for options, wire in actor.grants.items():
            fields = self.parse(wire)
            self.assertEqual((fields[3], fields[6], fields[8], fields[9]), (options, TG, 0x1001, RID))
            self.assertFalse(fields[15])
        self.assertEqual(set(actor.grants), set(range(8)) | set(range(0x80, 0x88)))

    def test_response_cannot_precede_loss_or_be_reused_and_limits_precede_wire_write(self):
        actor = self.responder(max_responses=1)
        actor.observe(self.event(self.wire()))
        self.assertIsNone(actor.next_response(0.8, 0.8))
        actor.observe(self.event(stamp=0.81, command=0x32))
        response = actor.next_response(0.82, 0.82)
        clock = Clock()
        clock.value = 0.82
        serial = Serial(clock)
        link = TOOL.CaptureLink(serial, self.site, lambda _: None, responder=actor, clock=clock, sleep=clock.sleep)
        link.send_response(response)
        actor.sent(response, 0.82)
        before = len(serial.sent)
        with self.assertRaises(RuntimeError):
            link.send_response(response)
        self.assertEqual(len(serial.sent), before)
        actor.observe(self.event(self.wire(0x28, 0x123 << 40 | TG << 24 | RID), stamp=1.0))
        actor.observe(self.event(stamp=1.72, command=0x32))
        with self.assertRaisesRegex(RuntimeError, "response limit"):
            actor.next_response(1.8, 1.8)
        self.assertEqual(len(serial.sent), before)

    def test_missing_loss_stale_response_or_reordered_events_fail_closed(self):
        actor = self.responder()
        actor.observe(self.event(self.wire()))
        with self.assertRaisesRegex(TimeoutError, "rearm"):
            actor.next_response(1.11, 1.11)
        actor.observe(self.event(stamp=1.12, command=0x32))
        with self.assertRaisesRegex(TimeoutError, "response window"):
            actor.next_response(1.36, 1.36)
        event = self.event(stamp=1.2, command=0x32)
        actor.observe(event)
        with self.assertRaisesRegex(RuntimeError, "reordered"):
            actor.observe(event)

    def test_bound_silent_reset_releases_only_modem_framing_after_qualified_request(self):
        for duid in (3,15):
            with self.subTest(duid=duid):
                emitted=[];actor=self.responder(emit=emitted.append);actor.bind_modem(DESCRIPTION)
                actor.observe(self.event(self.wire()));self.assertIsNone(actor.next_response(.2,.2))
                end=self.reset_event(duid=duid);before=end.wire;actor.observe(end)
                response=actor.next_response(.28,.28)
                self.assertIsNotNone(response);self.assertEqual(response.stage,'registration')
                self.assertFalse(actor.rx_busy);self.assertEqual(end.wire,before)
                record=emitted[-1]
                self.assertEqual(record['event'],'modem_framing_reset')
                self.assertEqual(record['sequence'],end.sequence)
                self.assertFalse(record['air_validated']);self.assertFalse(record['rf_timing_measured'])
                self.assertFalse(actor.summary()['rf_timing_measured'])
                self.assertEqual((actor.responses_sent,actor.grants_sent),(0,0))
                with self.assertRaisesRegex(RuntimeError,'reordered'):actor.observe(end)

    def test_reset_cannot_bypass_binding_crc_identity_initial_request_or_deadline(self):
        unbound=self.responder();unbound.observe(self.event(self.wire()))
        with self.assertRaises(ValueError):unbound.bind_modem(DESCRIPTION.replace('#89daa20','#1234567'))
        unbound.observe(self.reset_event());self.assertTrue(unbound.rx_busy)
        self.assertIsNone(unbound.next_response(.3,.3))
        for duid,flag in ((5,1),(3,2)):
            actor=self.responder();actor.bind_modem(DESCRIPTION);actor.observe(self.event(self.wire()))
            actor.observe(self.reset_event(duid=duid,flag=flag))
            self.assertTrue(actor.rx_busy);self.assertIsNone(actor.next_response(.3,.3))
        damaged=bytearray(self.wire())
        for index in range(18,35):damaged[index]^=0xFF
        self.assertIsNone(self.decoder(bytes(damaged)))
        candidates=[None,self.wire(nac=0x294),
            self.wire(argument=0xABCDE<<36|0x123<<24|RID+1),bytes(damaged)]
        for candidate in candidates:
            actor=self.responder();actor.bind_modem(DESCRIPTION)
            if candidate is not None:actor.observe(self.event(candidate))
            actor.observe(self.reset_event());self.assertIsNone(actor.next_response(.3,.3))
            self.assertEqual(actor.requests_matched,0)
        actor=self.responder();actor.bind_modem(DESCRIPTION);actor.observe(self.event(self.wire()))
        actor.observe(self.reset_event(stamp=1.36))
        with self.assertRaisesRegex(TimeoutError,'response window'):actor.next_response(1.36,1.36)

    def test_reset_preserves_queued_response_delay_and_policy(self):
        actor=self.responder(registration='queue');actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.wire()));actor.observe(self.reset_event())
        queued=actor.next_response(.3,.3);self.assertEqual(queued.kind,'queued')
        actor.sent(queued,.3)
        self.assertIsNone(actor.next_response(1.29,1.29))
        self.assertEqual(actor.next_response(1.31,1.31).kind,'accepted')
        self.assertEqual(actor.responses_sent,1);self.assertEqual(actor.grants_sent,0)

    def test_acceptance_only_requires_real_loss_and_never_releases_on_bound_reset(self):
        for duid in (3,15):
            for flag in (0,1):
                for rssi in (False,True):
                    with self.subTest(duid=duid,flag=flag,rssi=rssi):
                        emitted=[];actor=self.acceptance_only(emit=emitted.append);actor.bind_modem(DESCRIPTION)
                        actor.observe(self.event(self.wire()))
                        reset=self.reset_event(duid=duid,flag=flag,rssi=rssi);wire=reset.wire
                        self.assertIsNotNone(TOOL.MODEM.receiver_framing_reset(reset,DESCRIPTION))
                        actor.observe(reset);self.assertEqual(reset.wire,wire)
                        self.assertTrue(actor.rx_busy);self.assertIsNone(actor.next_response(.3,.3))
                        self.assertEqual(emitted[-1]['event'],'modem_framing_reset_ignored')
                        self.assertFalse(emitted[-1]['air_validated']);self.assertTrue(emitted[-1]['real_rx_loss_required'])
                        loss=self.event(stamp=.77,command=0x32);actor.observe(loss)
                        response=actor.next_response(.8,.8)
                        self.assertEqual((response.stage,response.kind),('registration','accepted'))
                        self.assertEqual(actor.real_rx_loss_sequence,loss.sequence)
                        self.assertEqual(actor.allowed_frames,frozenset((response.wire,)))
                        fields=self.parse(response.wire)
                        self.assertEqual((fields[0],fields[4],fields[5],fields[10],fields[11]),(2,0,0x123,RID,RID))
                        self.assertEqual(emitted[-1]['event'],'modem_rx_loss')
                        self.assertFalse(emitted[-1]['air_validated'])

    def test_acceptance_only_one_native_write_completes_without_affiliation_or_grant(self):
        actor=self.acceptance_only();actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.wire()));actor.observe(self.event(stamp=.77,command=0x32))
        response=actor.next_response(.8,.8);clock=Clock();clock.value=.8;serial=Serial(clock)
        link=TOOL.CaptureLink(serial,self.site,lambda _:None,responder=actor,clock=clock,sleep=clock.sleep)
        link.send_response(response);actor.sent(response,.8)
        self.assertEqual(len(serial.sent),1);self.assertEqual(actor.phase,'complete')
        with self.assertRaises(RuntimeError):link.send_response(response)
        affiliation=self.wire(0x28,0x123<<40|TG<<24|RID)
        actor.observe(self.event(affiliation,stamp=1.0));actor.observe(self.event(stamp=1.7,command=0x32))
        self.assertIsNone(actor.next_response(1.8,1.8));self.assertEqual(len(serial.sent),1)
        summary=actor.summary();self.assertEqual((summary['responses_sent'],summary['grants_sent']),(1,0))
        self.assertTrue(summary['registration_acceptance_only']);self.assertFalse(summary['pending_response'])
        self.assertFalse(summary['rf_timing_measured'])
        self.assertIsNotNone(summary['real_rx_loss_sequence'])  # Later ignored headers cannot erase the used token.
        self.assertEqual(summary['rearm_evidence_type'],'loss')

    def test_optional_reviewed_reset_rearms_only_one_bound_acceptance_with_original_source_evidence(self):
        for duid in (3,15):
            for flag in (0,1):
                for rssi in (False,True):
                    with self.subTest(duid=duid,flag=flag,rssi=rssi):
                        emitted=[];actor=self.acceptance_only(registration_rearm='reviewed-reset-or-loss',emit=emitted.append)
                        actor.bind_modem(DESCRIPTION);request=self.event(self.wire());actor.observe(request)
                        end=self.reset_event(duid=duid,flag=flag,rssi=rssi);before=end.wire;actor.observe(end)
                        response=actor.next_response(.3,.3);self.assertEqual(response.stage,'registration')
                        self.assertEqual(end.wire,before);self.assertFalse(actor.rx_busy)
                        record=emitted[-1];self.assertEqual(record['event'],'modem_framing_reset')
                        self.assertEqual((record['sequence'],record['request_sequence']),(end.sequence,request.sequence))
                        original=TOOL.MODEM.receiver_framing_reset(end,DESCRIPTION)
                        for key,value in original.items():self.assertEqual(record[key],value)
                        actor.sent(response,.3);summary=actor.summary()
                        self.assertEqual(summary['phase'],'complete');self.assertEqual(summary['responses_sent'],1)
                        self.assertEqual(summary['grants_sent'],0);self.assertFalse(summary['real_rx_loss_required'])
                        self.assertIsNone(summary['real_rx_loss_sequence'])
                        self.assertEqual(summary['rearm_evidence_type'],'reviewed-reset')
                        self.assertEqual(summary['rearm_evidence_sequence'],end.sequence)
                        self.assertEqual(summary['rearm_request_sequence'],request.sequence)
                        with self.assertRaises(RuntimeError):actor.validate_send(response,.31)

    def test_optional_reset_keeps_binding_format_identity_deadline_and_initial_request_gates(self):
        for options in ({}, {'duid':5}, {'flag':2}):
            actor=self.acceptance_only(registration_rearm='reviewed-reset-or-loss')
            if options:actor.bind_modem(DESCRIPTION)
            else:
                with self.assertRaises(ValueError):actor.bind_modem(DESCRIPTION.replace('#89daa20','#1234567'))
            actor.observe(self.event(self.wire()));actor.observe(self.reset_event(**options))
            self.assertTrue(actor.rx_busy);self.assertIsNone(actor.next_response(.3,.3))
            self.assertIsNone(actor.rearm_evidence_sequence)
        actor=self.acceptance_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.wire()))
        malformed=self.reset_event();malformed=TOOL.MODEM.Event(malformed.sequence,malformed.received_at,malformed.wire[:-1])
        actor.observe(malformed);self.assertIsNone(actor.next_response(.3,.3))
        with self.assertRaisesRegex(RuntimeError,'reordered'):actor.observe(malformed)
        late=self.reset_event(stamp=1.11);actor.observe(late)
        self.assertIsNone(actor.rearm_evidence_sequence)
        with self.assertRaisesRegex(TimeoutError,'rearm'):actor.next_response(1.11,1.11)
        bad=bytearray(self.wire());bad[18:35]=bytes(value^255 for value in bad[18:35])
        for wire in (None,self.wire(nac=0x294),self.wire(argument=0xABCDE<<36|0x123<<24|RID+1),bytes(bad)):
            actor=self.acceptance_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
            if wire is not None:actor.observe(self.event(wire))
            actor.observe(self.reset_event());self.assertIsNone(actor.next_response(.3,.3))
            self.assertIsNone(actor.rearm_evidence_sequence);self.assertEqual(actor.requests_matched,0)
        actor=self.acceptance_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.wire()));loss=self.event(stamp=.8,command=0x32);actor.observe(loss)
        self.assertIsNotNone(actor.next_response(.81,.81));self.assertEqual(actor.rearm_evidence_type,'loss')
        self.assertEqual(actor.real_rx_loss_sequence,loss.sequence)
        with self.assertRaisesRegex(TimeoutError,'response window'):actor.next_response(1.36,1.36)

    def test_strict_rejected_header_reset_releases_receiver_without_response_proof(self):
        for rearm in ('loss','reviewed-reset-or-loss'):
            for bound in (False,True):
                with self.subTest(rearm=rearm,bound=bound):
                    actor=self.attach(registration_rearm=rearm)
                    if bound:actor.bind_modem(DESCRIPTION)
                    bad=bytes(45)
                    self.assertIsNone(self.decoder(bad))
                    actor.observe(self.event(bad,stamp=.1))
                    self.assertTrue(actor.rx_busy);self.assertIsNone(actor.pending)
                    actor.observe(self.reset_event(stamp=.4))
                    self.assertEqual(actor.rx_busy,not bound)
                    self.assertIsNone(actor.rearm_evidence_sequence)
                    self.assertEqual((actor.requests_matched,actor.responses_sent,actor.grants_sent),(0,0,0))
                    if not bound:
                        with self.assertRaisesRegex(TimeoutError,'rearm'):actor.next_response(1.2,1.2)
                        continue
                    self.assertIsNone(actor.next_response(1.2,1.2))
                    self.assertIsNone(actor.header_at)
                    actor.observe(self.event(self.wire(),stamp=1.3))
                    actor.observe(self.event(stamp=2.0,command=0x32))
                    response=actor.next_response(2.01,2.01)
                    self.assertIsNotNone(response)
                    self.assertEqual(response.stage,'registration')

    def test_acceptance_only_binding_crc_identity_loss_order_and_deadline_gates(self):
        unbound=self.acceptance_only();unbound.observe(self.event(self.wire()))
        unbound.observe(self.event(stamp=.77,command=0x32))
        with self.assertRaisesRegex(RuntimeError,'bound modem'):unbound.next_response(.8,.8)
        candidates=[self.wire(nac=0x294),self.wire(argument=0xABCDE<<36|0x123<<24|RID+1),
            self.wire(argument=0xABCDF<<36|0x123<<24|RID),self.wire(argument=0xABCDE<<36|0x124<<24|RID),
            self.wire(0x28,0x123<<40|TG<<24|RID),self.wire(0,TG<<24|RID)]
        bad=bytearray(self.wire());bad[18:35]=bytes(value^255 for value in bad[18:35]);candidates.append(bytes(bad))
        for wire in candidates:
            actor=self.acceptance_only();actor.bind_modem(DESCRIPTION)
            actor.observe(self.event(wire));actor.observe(self.event(stamp=.77,command=0x32))
            self.assertIsNone(actor.next_response(.8,.8));self.assertEqual(actor.requests_matched,0)
            self.assertIsNone(actor.real_rx_loss_sequence)
        actor=self.acceptance_only();actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(stamp=.01,command=0x32));actor.observe(self.event(self.wire()))
        self.assertIsNone(actor.real_rx_loss_sequence);self.assertIsNone(actor.next_response(.8,.8))
        malformed=self.event(stamp=.81,command=0x32)
        malformed=TOOL.MODEM.Event(malformed.sequence,malformed.received_at,TOOL.MODEM.packet(0x32,b'\0'))
        with self.assertRaisesRegex(ValueError,'exact empty'):actor.observe(malformed)
        self.assertTrue(actor.rx_busy)
        loss=self.event(stamp=.82,command=0x32);actor.observe(loss)
        with self.assertRaisesRegex(RuntimeError,'reordered'):actor.observe(loss)
        with self.assertRaisesRegex(TimeoutError,'response window'):actor.next_response(1.36,1.36)
        missing=self.acceptance_only();missing.bind_modem(DESCRIPTION);missing.observe(self.event(self.wire()))
        missing.observe(self.reset_event())
        with self.assertRaisesRegex(TimeoutError,'rearm'):missing.next_response(1.11,1.11)

    def test_acceptance_only_version_binding_precedes_interleaved_native_loss(self):
        actor=self.acceptance_only();clock=Clock();records=[]
        header=TOOL.MODEM.packet(0x30,b'\1'+self.wire());loss=TOOL.MODEM.packet(0x32)
        serial=Serial(clock);serial.reads.extend(header+loss)
        link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
        self.assertEqual(link.version(),DESCRIPTION)
        self.assertEqual(actor.modem_description,DESCRIPTION);self.assertEqual(actor.requests_matched,1)
        self.assertEqual([bytes.fromhex(row['wire_hex']) for row in records],[header,loss])
        self.assertIsNotNone(actor.next_response(clock(),clock()))

    def test_explicit_affiliation_leg_starts_without_a_fabricated_registration(self):
        for rearm in ('loss','reviewed-reset-or-loss'):
            with self.subTest(rearm=rearm):
                emitted=[];actor=self.affiliation_only(registration_rearm=rearm,emit=emitted.append)
                self.assertEqual(actor.phase,'affiliation')
                self.assertEqual((actor.requests_matched,actor.responses_sent,actor.grants_sent),(0,0,0))
                self.assertFalse(actor.registration_acceptance_only);self.assertIsNone(actor.pending)
                actor.bind_modem(DESCRIPTION);request=self.event(self.affiliation_wire());actor.observe(request)
                self.assertEqual(actor.requests_matched,1);self.assertIsNone(actor.next_response(.2,.2))
                ending=self.event(stamp=.77,command=0x32) if rearm=='loss' else self.reset_event()
                actor.observe(ending);response=actor.next_response(.8,.8)
                self.assertEqual((response.stage,response.kind),('affiliation','accepted'))
                self.assertEqual(actor.allowed_frames,frozenset((response.wire,)))
                self.assertNotIn(actor.frames['registration-accepted'],actor.allowed_frames)
                self.assertFalse(any(wire in actor.allowed_frames for wire in actor.grants.values()))
                fields=self.parse(response.wire)
                self.assertEqual((fields[0],fields[4],fields[6],fields[10]),(3,0,TG,RID))
                actor.sent(response,.8);summary=actor.summary()
                self.assertEqual(summary['phase'],'complete');self.assertTrue(summary['affiliation_acceptance_only'])
                self.assertEqual(summary['acceptance_stage'],'affiliation');self.assertEqual(summary['acceptance_rearm'],rearm)
                self.assertNotIn('registration_acceptance_only',summary)
                self.assertEqual((summary['requests_matched'],summary['responses_sent'],summary['grants_sent']),(1,1,0))
                self.assertEqual(summary['rearm_request_sequence'],request.sequence)
                self.assertEqual(summary['rearm_evidence_sequence'],ending.sequence)
                self.assertEqual([row['stage'] for row in emitted if row['event']=='request_matched'],['affiliation'])
                with self.assertRaises(RuntimeError):actor.validate_send(response,.81)

    def test_affiliation_leg_requires_native_crc_exact_nac_system_group_and_subscriber(self):
        bad=bytearray(self.affiliation_wire());bad[18:35]=bytes(value^255 for value in bad[18:35])
        candidates=[self.affiliation_wire(nac=0x294),self.affiliation_wire(rid=RID+1),
            self.affiliation_wire(group=TG+1),self.affiliation_wire(system=0x124),self.wire(),
            self.wire(0,TG<<24|RID),bytes(bad)]
        # CRC-valid foreign MFID/protection still must not enter the one-leg policy.
        for protected,mfid in ((1,0),(0,0x90)):
            word=self.reference['construct_tsbk'](True,protected,0x28,mfid,0x123<<40|TG<<24|RID)
            symbols=self.reference['start_packet'](0x293,7)
            symbols.extend(self.reference['data_interleave'](self.reference['trellis_1_2_encode'](
                self.reference['split_dibits'](word,48))))
            output=io.BytesIO();self.reference['outfile']=output
            try:
                with contextlib.redirect_stderr(io.StringIO()):
                    self.reference['print_spec'](self.reference['insert_status'](symbols,(2,)*5))
            finally:self.reference['outfile']=None
            wire=output.getvalue();self.assertIsNotNone(self.decoder(wire));candidates.append(wire)
        for wire in candidates:
            with self.subTest(wire=wire.hex()[:16]):
                actor=self.affiliation_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
                actor.observe(self.event(wire));actor.observe(self.reset_event())
                self.assertIsNone(actor.next_response(.3,.3));self.assertEqual(actor.requests_matched,0)
                self.assertEqual((actor.responses_sent,actor.grants_sent),(0,0));self.assertIsNone(actor.rearm_evidence_sequence)

    def test_affiliation_leg_retains_bound_rearm_order_deadline_and_one_frame_send_gates(self):
        actor=self.affiliation_only();actor.observe(self.event(self.affiliation_wire()))
        actor.observe(self.event(stamp=.77,command=0x32))
        with self.assertRaisesRegex(RuntimeError,'bound modem'):actor.next_response(.8,.8)
        actor=self.affiliation_only();actor.bind_modem(DESCRIPTION);actor.observe(self.event(self.affiliation_wire()))
        actor.observe(self.reset_event());self.assertIsNone(actor.next_response(.3,.3))
        with self.assertRaisesRegex(TimeoutError,'rearm'):actor.next_response(1.11,1.11)
        actor=self.affiliation_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.affiliation_wire()))
        actor.observe(self.reset_event(flag=2));self.assertIsNone(actor.next_response(.3,.3))
        late=self.reset_event(stamp=1.11);actor.observe(late)
        with self.assertRaisesRegex(TimeoutError,'rearm'):actor.next_response(1.11,1.11)
        with self.assertRaisesRegex(RuntimeError,'reordered'):actor.observe(late)
        actor=self.affiliation_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.affiliation_wire()));actor.observe(self.reset_event())
        response=actor.next_response(.3,.3);clock=Clock();clock.value=1.34;serial=Serial(clock)
        link=TOOL.CaptureLink(serial,self.site,lambda _:None,responder=actor,clock=clock,sleep=clock.sleep)
        with self.assertRaisesRegex(TimeoutError,'no longer fits'):link.send_response(response)
        self.assertEqual(serial.writes,[])
        clock.value=.3;link.send_response(response);actor.sent(response,.3)
        with self.assertRaises(RuntimeError):link.send_response(response)
        actor.observe(self.event(self.wire(),stamp=.4));actor.observe(self.event(stamp=.9,command=0x32))
        self.assertIsNone(actor.next_response(.9,.9));self.assertEqual(len(serial.sent),1)
        self.assertEqual(actor.rearm_evidence_type,'reviewed-reset')
        self.assertEqual(actor.phase,'complete')

    def test_voice_leg_freezes_exact_clear_options_grant_without_fabricated_prior_stages(self):
        for options in (*range(8),*range(0x80,0x88)):
            with self.subTest(options=options):
                emitted=[];actor=self.voice_only(emit=emitted.append);actor.bind_modem(DESCRIPTION)
                self.assertEqual(actor.phase,'voice');self.assertEqual(actor.allowed_frames,frozenset())
                self.assertEqual((actor.requests_matched,actor.responses_sent,actor.grants_sent),(0,0,0))
                self.assertFalse(actor.registration_acceptance_only or actor.affiliation_acceptance_only)
                request=self.event(self.voice_wire(options=options));actor.observe(request)
                self.assertIsNone(actor.next_response(.2,.2))
                actor.observe(self.event(stamp=.77,command=0x32));response=actor.next_response(.8,.8)
                self.assertEqual((response.stage,response.kind),('voice','accepted'))
                self.assertEqual(actor.allowed_frames,frozenset((response.wire,)))
                self.assertNotIn(actor.frames['registration-accepted'],actor.allowed_frames)
                self.assertNotIn(actor.frames['affiliation-accepted'],actor.allowed_frames)
                nac,blocks=self.decoder(response.wire);self.assertEqual(nac,0x293)
                expected=dict(opts=options,ch=0x1001,ga=TG,sa=RID)
                self.assertEqual(self.primary_fields(0,blocks[0],expected),expected)
                fields=self.parse(response.wire)
                self.assertEqual((fields[0],fields[3],fields[6],fields[8],fields[9],fields[15]),
                                 (1,options,TG,0x1001,RID,0))
                actor.sent(response,.8);summary=actor.summary()
                self.assertEqual((summary['phase'],summary['requests_matched'],summary['responses_sent'],summary['grants_sent']),
                                 ('complete',1,1,1))
                self.assertTrue(summary['voice_grant_only']);self.assertEqual(summary['acceptance_stage'],'voice')
                self.assertEqual(summary['acceptance_rearm'],'loss');self.assertFalse(summary['rf_timing_measured'])
                self.assertNotIn('registration_acceptance_only',summary);self.assertNotIn('affiliation_acceptance_only',summary)
                self.assertNotIn('voice_acceptance_only',summary)
                self.assertEqual([row['stage'] for row in emitted if row['event']=='request_matched'],['voice'])
                with self.assertRaises(RuntimeError):actor.validate_send(response,.81)

    def test_voice_leg_refuses_foreign_crc_protected_encrypted_reserved_and_source_free_packets(self):
        bad=bytearray(self.voice_wire());bad[18:35]=bytes(value^255 for value in bad[18:35])
        candidates=[self.voice_wire(nac=0x294),self.voice_wire(rid=RID+1),self.voice_wire(group=TG+1),
            self.voice_wire(rid=0),self.voice_wire(rid=0xFFFFFF),self.voice_wire(group=0),
            self.voice_wire(reserved=1),self.voice_wire(options=0x40),self.voice_wire(options=8),
            self.voice_wire(options=0x10),self.voice_wire(options=0x20),self.wire(),self.affiliation_wire(),bytes(bad),
            self.wire(2,0x1001<<48|TG<<32|0x1002<<16|TG),self.wire(3,0x1001<<32|0x1002<<16|TG)]
        # A valid downlink grant also cannot be mistaken for a source request:
        # its nonzero channel occupies uplink reserved bits.
        candidates.append(self.responder().grants[4])
        for protected,mfid in ((1,0),(0,0x90)):
            word=self.reference['construct_tsbk'](True,protected,0,mfid,4<<56|TG<<24|RID)
            symbols=self.reference['start_packet'](0x293,7)
            symbols.extend(self.reference['data_interleave'](self.reference['trellis_1_2_encode'](
                self.reference['split_dibits'](word,48))))
            output=io.BytesIO();self.reference['outfile']=output
            try:
                with contextlib.redirect_stderr(io.StringIO()):
                    self.reference['print_spec'](self.reference['insert_status'](symbols,(2,)*5))
            finally:self.reference['outfile']=None
            wire=output.getvalue();self.assertIsNotNone(self.decoder(wire));candidates.append(wire)
        for wire in candidates:
            with self.subTest(wire=wire.hex()):
                actor=self.voice_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
                actor.observe(self.event(wire));actor.observe(self.reset_event())
                self.assertIsNone(actor.next_response(.3,.3));self.assertEqual(actor.requests_matched,0)
                self.assertEqual(actor.allowed_frames,frozenset());self.assertIsNone(actor.rearm_evidence_sequence)
                self.assertEqual((actor.responses_sent,actor.grants_sent),(0,0))

    def test_voice_leg_keeps_bound_rearm_deadline_exact_catalog_and_single_send(self):
        actor=self.voice_only();actor.observe(self.event(self.voice_wire()))
        actor.observe(self.event(stamp=.77,command=0x32))
        with self.assertRaisesRegex(RuntimeError,'bound modem'):actor.next_response(.8,.8)
        for rearm,ending in (('loss',{}),('reviewed-reset-or-loss',{'flag':2}),
                             ('reviewed-reset-or-loss',{'stamp':1.11})):
            actor=self.voice_only(registration_rearm=rearm);actor.bind_modem(DESCRIPTION)
            actor.observe(self.event(self.voice_wire()));actor.observe(self.reset_event(**ending))
            self.assertIsNone(actor.rearm_evidence_sequence)
            with self.assertRaisesRegex(TimeoutError,'rearm'):actor.next_response(1.11,1.11)
        actor=self.voice_only(registration_rearm='reviewed-reset-or-loss');actor.bind_modem(DESCRIPTION)
        actor.observe(self.event(self.voice_wire(options=0x83)));ending=self.reset_event();actor.observe(ending)
        with self.assertRaisesRegex(RuntimeError,'reordered'):actor.observe(ending)
        response=actor.next_response(.3,.3);clock=Clock();clock.value=1.34;serial=Serial(clock)
        link=TOOL.CaptureLink(serial,self.site,lambda _:None,responder=actor,clock=clock,sleep=clock.sleep)
        with self.assertRaisesRegex(TimeoutError,'no longer fits'):link.send_response(response)
        self.assertEqual(serial.writes,[])
        foreign=TOOL.LabResponse('voice','accepted',actor.grants[0x82],response.request_sequence,
                                response.request_received_at,response.eligible_at,response.deadline)
        clock.value=.3
        with self.assertRaisesRegex(RuntimeError,'catalog'):link.send_response(foreign)
        actor.voice_options=0x82
        with self.assertRaisesRegex(RuntimeError,'clear service options'):link.send_response(response)
        actor.voice_options=0x83;link.send_response(response);actor.sent(response,.3)
        with self.assertRaises(RuntimeError):link.send_response(response)
        actor.observe(self.event(self.voice_wire(options=4),stamp=.4));actor.observe(self.event(stamp=.9,command=0x32))
        self.assertIsNone(actor.next_response(.9,.9));self.assertEqual(len(serial.sent),1)
        self.assertEqual((actor.phase,actor.responses_sent,actor.grants_sent),('complete',1,1))
        self.assertEqual(actor.rearm_evidence_type,'reviewed-reset')

    def test_version_binds_before_draining_interleaved_header_and_silent_reset(self):
        clock,records=Clock(),[]
        actor=TOOL.LabResponder(self.metadata,self.decoder,radio_id=RID,talkgroup=TG)
        header=TOOL.MODEM.packet(0x30,b'\1'+self.wire());ending=self.reset_event().wire
        serial=Serial(clock);serial.reads.extend(header+ending)
        link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
        self.assertEqual(link.version(),DESCRIPTION)
        self.assertEqual(actor.modem_description,DESCRIPTION)
        self.assertEqual([bytes.fromhex(record['wire_hex']) for record in records],[header,ending])
        self.assertFalse(records[1]['modem_receiver_reset']['air_validated'])
        self.assertFalse(actor.rx_busy);self.assertIsNone(actor.pending)
        self.assertEqual(actor.requests_matched,0);self.assertEqual(actor.rejected,1)
        self.assertIsNone(actor.armed_at)  # Version discovery must not arm a response.

    def test_failed_version_keeps_interleaved_records_unbound_and_unmodified(self):
        class ForeignSerial(Serial):
            def write(self,packet):
                if packet[2]==0:
                    self.writes.append(packet)
                    self.reads.extend(TOOL.MODEM.packet(0,b'\1MMDVM_HS-v1.6.1 #1234567'))
                    return len(packet)
                return super().write(packet)
        clock,records=Clock(),[]
        actor=TOOL.LabResponder(self.metadata,self.decoder,radio_id=RID,talkgroup=TG)
        header=TOOL.MODEM.packet(0x30,b'\1'+self.wire());ending=self.reset_event().wire
        serial=ForeignSerial(clock);serial.reads.extend(header+ending)
        link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
        with self.assertRaises(TOOL.MODEM.ProtocolError):link.version()
        self.assertIsNone(actor.modem_description);self.assertIsNone(link.modem_description)
        self.assertEqual([bytes.fromhex(record['wire_hex']) for record in records],[header,ending])
        self.assertNotIn('modem_receiver_reset',records[1])
        self.assertTrue(actor.rx_busy);self.assertIsNone(actor.pending)

    def test_last_moment_deadline_and_site_only_mode_refuse_response_before_serial_write(self):
        actor = self.responder()
        actor.observe(self.event(self.wire()))
        actor.observe(self.event(stamp=0.8, command=0x32))
        response = actor.next_response(0.81, 0.81)
        clock = Clock()
        clock.value = 1.34  # Header0.1 +1.25s deadline, with no37.5ms wire room.
        serial = Serial(clock)
        link = TOOL.CaptureLink(serial, self.site, lambda _: None, responder=actor, clock=clock, sleep=clock.sleep)
        with self.assertRaisesRegex(TimeoutError, "no longer fits"):
            link.send_response(response)
        self.assertEqual(serial.writes, [])
        site_only = TOOL.CaptureLink(serial, self.site, lambda _: None, clock=clock, sleep=clock.sleep)
        with self.assertRaisesRegex(RuntimeError, "explicit laboratory catalog"):
            site_only.send_response(response)
        self.assertEqual(serial.writes, [])

    def test_crc_valid_foreign_mfid_or_protected_isp_is_not_actionable(self):
        for protected, mfid in ((1, 0), (0, 0x90)):
            actor = self.responder()
            word = self.reference["construct_tsbk"](True, protected, 0x2C, mfid,
                0xABCDE << 36 | 0x123 << 24 | RID)
            symbols = self.reference["start_packet"](0x293, 7)
            symbols.extend(self.reference["data_interleave"](self.reference["trellis_1_2_encode"](
                self.reference["split_dibits"](word, 48))))
            output = io.BytesIO()
            self.reference["outfile"] = output
            try:
                with contextlib.redirect_stderr(io.StringIO()):
                    self.reference["print_spec"](self.reference["insert_status"](symbols, (2,) * 5))
            finally:
                self.reference["outfile"] = None
            wire = output.getvalue()
            self.assertIsNotNone(self.decoder(wire), "Malformed native frame would not test MFID/protection")
            actor.observe(self.event(wire))
            actor.observe(self.event(stamp=0.8, command=0x32))
            self.assertIsNone(actor.next_response(0.9, 0.9))
            self.assertEqual(actor.rejected, 1)

    def test_active_scheduler_preserves_capture_and_global_slot_marker_phase(self):
        clock, records = Clock(), []
        request = TOOL.MODEM.packet(0x30, b"\1" + self.wire()) + TOOL.MODEM.packet(0x32)
        serial = Serial(clock, request)
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG)
        link = TOOL.CaptureLink(serial, self.site, records.append, responder=actor, clock=clock, sleep=clock.sleep)
        result = TOOL.schedule(link, 2, 0.6, clock=clock, sleep=clock.sleep)
        self.assertEqual((result["responses_sent"], result["grants_sent"]), (1, 0))
        self.assertLessEqual(result["max_estimated_payload_queue_s"], 0.25000001)
        self.assertEqual([bytes.fromhex(item["wire_hex"])[2] for item in records], [0x30, 0x32])
        statuses = []
        for packet in serial.sent:
            wire = packet[4:]
            statuses += [(wire[i // 4] >> (6 - 2 * (i % 4))) & 3 for i in range(35, len(wire) * 4, 36)]
        self.assertEqual(statuses, [3 if i % 5 == 0 else 2 for i in range(len(statuses))])
        self.assertEqual(sum(len(packet) == 49 for packet in serial.sent), 1)

    def test_acceptance_only_actual_scheduler_queues_one_reply_after_captured_real_loss(self):
        clock,records=Clock(),[]
        request=TOOL.MODEM.packet(0x30,b'\1'+self.wire())+TOOL.MODEM.packet(0x32)
        serial=Serial(clock,request)
        actor=TOOL.LabResponder(self.metadata,self.decoder,radio_id=RID,talkgroup=TG,
            registration_acceptance_only=True,registration='accept',affiliation='timeout',voice='timeout',max_responses=1)
        actor.bind_modem(DESCRIPTION)
        link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
        result=TOOL.schedule(link,2,.6,clock=clock,sleep=clock.sleep)
        self.assertEqual((result['responses_sent'],result['grants_sent']),(1,0))
        self.assertEqual(result['responder']['phase'],'complete')
        self.assertEqual([bytes.fromhex(row['wire_hex'])[2] for row in records],[0x30,0x32])
        self.assertEqual(result['responder']['real_rx_loss_sequence'],records[-1]['sequence'])
        responses=[packet[4:] for packet in serial.sent if len(packet)==49]
        self.assertEqual(responses,[actor.frames['registration-accepted']])
        self.assertIsNotNone(self.decoder(responses[0]))
        self.assertFalse(result['rf_timing_measured']);self.assertFalse(result['rf_decode_verified'])

    def test_optional_reset_actual_scheduler_preserves_raw_capture_and_one_acceptance_catalog(self):
        clock,records=Clock(),[]
        ending=self.reset_event().wire;request=TOOL.MODEM.packet(0x30,b'\1'+self.wire())+ending
        serial=Serial(clock,request)
        actor=TOOL.LabResponder(self.metadata,self.decoder,radio_id=RID,talkgroup=TG,
            registration_acceptance_only=True,registration_rearm='reviewed-reset-or-loss',
            registration='accept',affiliation='timeout',voice='timeout',max_responses=1)
        actor.bind_modem(DESCRIPTION)
        link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
        result=TOOL.schedule(link,2,.6,clock=clock,sleep=clock.sleep)
        self.assertEqual((result['responses_sent'],result['grants_sent']),(1,0))
        self.assertEqual(bytes.fromhex(records[-1]['wire_hex']),ending)
        self.assertEqual(result['responder']['phase'],'complete')
        self.assertEqual(result['responder']['rearm_evidence_type'],'reviewed-reset')
        self.assertEqual(result['responder']['rearm_evidence_sequence'],records[-1]['sequence'])
        self.assertIsNone(result['responder']['real_rx_loss_sequence'])
        self.assertEqual([packet[4:] for packet in serial.sent if len(packet)==49],[actor.frames['registration-accepted']])
        self.assertFalse(result['rf_timing_measured']);self.assertFalse(result['rf_decode_verified'])

    def test_affiliation_actual_scheduler_sends_one_affiliation_acceptance_and_no_registration(self):
        for rearm in ('loss','reviewed-reset-or-loss'):
            with self.subTest(rearm=rearm):
                clock,records=Clock(),[]
                ending=TOOL.MODEM.packet(0x32) if rearm=='loss' else self.reset_event().wire
                request=TOOL.MODEM.packet(0x30,b'\1'+self.affiliation_wire())+ending
                serial=Serial(clock,request)
                actor=TOOL.LabResponder(self.metadata,self.decoder,radio_id=RID,talkgroup=TG,
                    affiliation_acceptance_only=True,registration_rearm=rearm,
                    registration='timeout',affiliation='accept',voice='timeout',max_responses=1)
                actor.bind_modem(DESCRIPTION)
                link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
                result=TOOL.schedule(link,2,.6,clock=clock,sleep=clock.sleep)
                self.assertEqual((result['responses_sent'],result['grants_sent']),(1,0))
                self.assertEqual(result['responder']['phase'],'complete')
                self.assertEqual(result['responder']['acceptance_stage'],'affiliation')
                self.assertEqual([bytes.fromhex(row['wire_hex'])[2] for row in records],[0x30,0x32 if rearm=='loss' else 0x31])
                responses=[packet[4:] for packet in serial.sent if len(packet)==49]
                self.assertEqual(responses,[actor.frames['affiliation-accepted']])
                self.assertEqual(self.parse(responses[0])[0],3)
                self.assertFalse(result['rf_timing_measured']);self.assertFalse(result['rf_decode_verified'])

    def test_voice_only_actual_scheduler_queues_exactly_one_grant_with_both_rearm_policies(self):
        for rearm in ('loss','reviewed-reset-or-loss'):
            with self.subTest(rearm=rearm):
                clock,records=Clock(),[]
                ending=TOOL.MODEM.packet(0x32) if rearm=='loss' else self.reset_event().wire
                request=TOOL.MODEM.packet(0x30,b'\1'+self.voice_wire(options=0x85))+ending
                serial=Serial(clock,request)
                actor=TOOL.LabResponder(self.metadata,self.decoder,radio_id=RID,talkgroup=TG,
                    voice_grant_only=True,registration_rearm=rearm,
                    registration='timeout',affiliation='timeout',voice='accept',max_responses=1)
                actor.bind_modem(DESCRIPTION)
                link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
                result=TOOL.schedule(link,2,.6,clock=clock,sleep=clock.sleep)
                self.assertEqual((result['responses_sent'],result['grants_sent']),(1,1))
                self.assertEqual(result['responder']['phase'],'complete');self.assertTrue(result['responder']['voice_grant_only'])
                self.assertEqual(result['responder']['acceptance_stage'],'voice')
                self.assertEqual(result['responder']['acceptance_rearm'],rearm)
                self.assertEqual([bytes.fromhex(row['wire_hex'])[2] for row in records],[0x30,0x32 if rearm=='loss' else 0x31])
                responses=[packet[4:] for packet in serial.sent if len(packet)==49]
                self.assertEqual(responses,[actor.grants[0x85]])
                self.assertEqual(actor.allowed_frames,frozenset(responses));self.assertEqual(self.parse(responses[0])[3],0x85)
                self.assertFalse(result['rf_timing_measured']);self.assertFalse(result['rf_decode_verified'])

    def test_attach_call_three_native_legs_require_ordered_bound_rearms_and_one_grant(self):
        for rearm in ('loss', 'reviewed-reset-or-loss'):
            with self.subTest(rearm=rearm):
                records = []
                actor = self.attach(registration_rearm=rearm, emit=records.append)
                actor.bind_modem(DESCRIPTION)
                self.assertFalse(actor.registered); self.assertFalse(actor.affiliated)
                self.assertEqual(actor.allowed_frames, frozenset())
                expected = (('registration', self.wire(), 2),
                            ('affiliation', self.affiliation_wire(), 3),
                            ('voice', self.voice_wire(), 1))
                receipts = []
                for index, (stage, wire, reply_type) in enumerate(expected):
                    header, ending, response = self.attach_leg(actor, wire, index + .1,
                        reset=rearm == 'reviewed-reset-or-loss')
                    self.assertEqual((response.stage, response.kind), (stage, 'accepted'))
                    self.assertEqual(self.parse(response.wire)[0], reply_type)
                    self.assertEqual((actor.registered, actor.affiliated), (True, index >= 1))
                    self.assertEqual(actor.allowed_frames, frozenset())
                    receipts.append(dict(stage=stage, request_sequence=header.sequence,
                        rearm_evidence_type='loss' if rearm == 'loss' else 'reviewed-reset',
                        rearm_evidence_sequence=ending.sequence,
                        request_received_at_monotonic=header.received_at,
                        queued_at_monotonic=index+.25,
                        response_sha256=hashlib.sha256(response.wire).hexdigest(), rf_timing_measured=False))
                    with self.assertRaises(RuntimeError): actor.validate_send(response, index + .3)
                summary = actor.summary()
                self.assertEqual((summary['phase'], summary['requests_matched'],
                    summary['responses_sent'], summary['grants_sent']), ('complete', 3, 3, 1))
                self.assertEqual(summary['receipts'], receipts)
                self.assertTrue(summary['exchange_complete'])
                self.assertFalse(summary['pending_response'])
                self.assertFalse(summary['subscriber_registration_qualified'])
                self.assertFalse(summary['automatic_access_qualified'])
                self.assertFalse(summary['rf_timing_measured'])
                queued = [row for row in records if row['event'] == 'response_queued']
                completed = [row for row in records if row['event'] == 'attach_responses_queued']
                self.assertEqual(len(completed), 1)
                self.assertTrue(completed[0]['exchange_complete'])
                self.assertFalse(completed[0]['rf_timing_measured'])
                summary['receipts'][0]['response_sha256'] = 'cannot alter retained evidence'
                self.assertEqual(actor.summary()['receipts'], receipts)
                self.assertEqual([(row['stage'], row['request_sequence'], row['rearm_evidence_sequence'])
                    for row in queued], [(row['stage'], row['request_sequence'], row['rearm_evidence_sequence'])
                    for row in receipts])
                actor.observe(self.event(self.voice_wire(), stamp=3.2))
                actor.observe(self.event(stamp=3.3, command=0x32))
                self.assertIsNone(actor.next_response(3.4, 3.4))
                self.assertEqual((actor.requests_matched, actor.responses_sent, actor.grants_sent), (3, 3, 1))

    def test_attach_call_refuses_skips_foreign_identity_and_nonfixed_service_options(self):
        actor = self.attach(); actor.bind_modem(DESCRIPTION)
        for wire in (self.affiliation_wire(), self.voice_wire(), self.wire(nac=0x294),
                     self.wire(argument=0xABCDE << 36 | 0x123 << 24 | RID + 1)):
            actor.observe(self.event(wire, stamp=self.sequence + .1))
            actor.observe(self.event(stamp=self.sequence + .2, command=0x32))
            self.assertIsNone(actor.next_response(self.sequence + .3, self.sequence + .3))
        self.assertEqual((actor.requests_matched, actor.responses_sent), (0, 0))
        self.assertFalse(actor.registered); self.assertFalse(actor.affiliated)
        self.attach_leg(actor, self.wire(), 20.1)
        self.attach_leg(actor, self.affiliation_wire(), 21.1)
        for index, wire in enumerate((self.voice_wire(options=0), self.voice_wire(options=0x84),
                                      self.voice_wire(group=TG+1), self.voice_wire(rid=RID+1))):
            stamp = 22.1 + index
            actor.observe(self.event(wire, stamp=stamp)); actor.observe(self.event(stamp=stamp+.1, command=0x32))
            self.assertIsNone(actor.next_response(stamp+.2, stamp+.2))
        self.assertEqual((actor.phase, actor.requests_matched, actor.responses_sent, actor.grants_sent), ('voice', 2, 2, 0))
        self.assertEqual(len(actor.attach_receipts), 2)

    def repeat_attach(self, **kwargs):
        actor = self.attach(attach_options=0, attach_grant_limit=3, max_responses=5,
                            registration_rearm='reviewed-reset-or-loss', **kwargs)
        actor.bind_modem(DESCRIPTION)
        self.attach_leg(actor, self.wire(), .1, reset=True)
        self.attach_leg(actor, self.affiliation_wire(), 1.1, reset=True)
        return actor

    def test_attach_grant_lease_requires_each_fresh_request_and_caps_identical_grants_at_three(self):
        events = []
        actor = self.repeat_attach(emit=events.append)
        header, ending, first = self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        self.assertTrue(actor.summary()['exchange_complete'])
        self.assertEqual(actor.phase, 'voice')
        self.assertEqual(actor.grant_lease_deadline, 22.1)
        # Calling the scheduler again cannot repeat the first grant by timer.
        self.assertIsNone(actor.next_response(3., 3.))
        for duplicate in (header, ending):
            with self.assertRaisesRegex(RuntimeError, 'reordered'):
                actor.observe(duplicate)
        for stamp in (4.1, 6.1):
            _, _, response = self.attach_leg(actor, self.voice_wire(options=0), stamp, reset=True)
            self.assertEqual(response.wire, first.wire)
            self.assertEqual(actor.grant_lease_deadline, 22.1)
        self.assertEqual((actor.responses_sent, actor.grants_sent, actor.phase), (5, 3, 'complete'))
        actor.observe(self.event(self.voice_wire(options=0), stamp=8.1))
        actor.observe(self.reset_event(stamp=8.2))
        self.assertIsNone(actor.next_response(10., 10.))
        self.assertEqual((actor.responses_sent, actor.grants_sent), (5, 3))
        receipts = actor.summary()['receipts']
        self.assertEqual([row['stage'] for row in receipts], ['registration', 'affiliation', 'voice', 'voice', 'voice'])
        self.assertEqual(len({row['request_sequence'] for row in receipts}), 5)
        self.assertTrue(all(row['rearm_evidence_sequence'] > row['request_sequence'] for row in receipts))
        self.assertEqual(len({row['response_sha256'] for row in receipts[2:]}), 1)
        self.assertFalse(actor.summary()['rf_timing_measured'])

    def test_attach_grant_lease_is_fixed_and_expiry_revokes_pending_and_later_requests(self):
        events = []
        actor = self.repeat_attach(emit=events.append)
        self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        self.attach_leg(actor, self.voice_wire(options=0), 20.1, reset=True)
        self.assertEqual(actor.grant_lease_deadline, 22.1)
        actor.observe(self.event(self.voice_wire(options=0), stamp=21.9))
        actor.observe(self.reset_event(stamp=22.0))
        response = actor.pending
        self.assertEqual(response.deadline, 22.1)
        self.assertIsNone(actor.next_response(22.1, 22.1))
        self.assertEqual(actor.phase, 'complete')
        with self.assertRaises(RuntimeError):
            actor.validate_send(response, 22.1)
        actor.observe(self.event(self.voice_wire(options=0), stamp=23.))
        self.assertIsNone(actor.next_response(24.1, 24.1))
        self.assertEqual((actor.responses_sent, actor.grants_sent), (4, 2))
        self.assertEqual(len([row for row in events if row['event'] == 'grant_lease_closed']), 1)

    def voice_header(self, *, stamp):
        # A modem HDU envelope establishes receive occupancy, not native
        # identity/CRC or authority to transmit another response.
        frame = bytearray(b'\x77' * 99)
        frame[:6] = TOOL.CC.GENERATOR.SYNC
        frame[7] &= 0xF0
        return self.event(bytes(frame), stamp=stamp)

    def test_postgrant_voice_occupancy_keeps_ten_second_call_outside_request_rearm(self):
        events = []
        actor = self.repeat_attach(emit=events.append)
        self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        receipts = copy.deepcopy(actor.attach_receipts)
        actor.observe(self.voice_header(stamp=2.8))
        for stamp in (3.9, 8., 12.8):
            self.assertIsNone(actor.next_response(stamp, stamp))
            self.assertTrue(actor.rx_busy)
            self.assertIsNone(actor.pending)
            self.assertEqual(actor.attach_receipts, receipts)
            self.assertEqual((actor.requests_matched, actor.responses_sent, actor.grants_sent), (3, 3, 1))
        self.assertTrue(any(row['event'] == 'modem_voice_receive_started' for row in events))

    def test_postgrant_voice_blocks_requests_and_reset_until_actual_loss_then_requires_fresh_rearm(self):
        actor = self.repeat_attach()
        self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        actor.observe(self.voice_header(stamp=2.8))
        actor.observe(self.event(self.voice_wire(options=0), stamp=4.))
        actor.observe(self.reset_event(stamp=4.1))
        self.assertIsNone(actor.next_response(5.2, 5.2))
        self.assertTrue(actor.rx_busy)
        self.assertIsNone(actor.pending)
        self.assertEqual((actor.requests_matched, actor.grants_sent), (3, 1))
        actor.observe(self.event(stamp=5.3, command=0x32))
        self.assertFalse(actor.rx_busy)
        self.assertIsNone(actor.next_response(5.31, 5.31))
        request = self.event(self.voice_wire(options=0), stamp=5.4)
        actor.observe(request)
        self.assertIsNone(actor.next_response(5.45, 5.45))
        self.assertIsNone(actor.rearm_request_sequence)
        actor.observe(self.reset_event(stamp=5.5))
        response = actor.next_response(5.55, 5.55)
        self.assertEqual(response.request_sequence, request.sequence)
        actor.sent(response, 5.55)
        self.assertEqual((actor.requests_matched, actor.responses_sent, actor.grants_sent), (4, 4, 2))

    def test_postgrant_voice_without_loss_closes_at_original_finite_grant_lease(self):
        actor = self.repeat_attach()
        self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        actor.observe(self.voice_header(stamp=2.8))
        self.assertIsNone(actor.next_response(22., 22.))
        self.assertTrue(actor.rx_busy)
        self.assertIsNone(actor.next_response(22.1, 22.1))
        self.assertEqual(actor.phase, 'complete')
        self.assertFalse(actor.rx_busy)
        actor.observe(self.event(self.voice_wire(options=0), stamp=23.))
        actor.observe(self.event(stamp=23.1, command=0x32))
        self.assertIsNone(actor.next_response(24., 24.))
        self.assertEqual((actor.requests_matched, actor.responses_sent, actor.grants_sent), (3, 3, 1))

    def test_postgrant_voice_actual_scheduler_keeps_control_running_until_explicit_stop(self):
        clock, records = Clock(), []
        actor = self.repeat_attach()
        self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        actor.armed_at = None
        actor.last_sequence, actor.last_stamp = 0, -float('inf')
        clock.value = 3.
        header = self.voice_header(stamp=3.).wire
        class VoiceSerial(Serial):
            injected = False
            def write(serial, packet):
                result = super(VoiceSerial, serial).write(packet)
                if packet[2] == 0x31 and len(packet) == 94 and not serial.injected \
                        and sum(len(item) == 94 for item in serial.sent) >= 3:
                    serial.reads.extend(header)
                    serial.injected = True
                return result
        serial = VoiceSerial(clock)
        link = TOOL.CaptureLink(serial, self.site, records.append, responder=actor,
                                clock=clock, sleep=clock.sleep)
        link.version()
        result = TOOL.schedule(link, 16, .6, clock=clock, sleep=clock.sleep,
                               stopping=lambda: clock.value >= 14.)
        self.assertTrue(result['stopped'])
        self.assertGreater(result['elapsed_s'], 10.)
        self.assertGreater(result['site_units_sent'], 3)
        self.assertTrue(result['responder']['voice_receive_active'])
        self.assertEqual((result['responses_sent'], result['grants_sent']), (3, 1))
        self.assertFalse(any(len(packet) == 49 for packet in serial.sent))

    def test_attach_repeat_still_requires_native_identity_and_its_own_bound_rearm(self):
        actor = self.repeat_attach()
        self.attach_leg(actor, self.voice_wire(options=0), 2.1, reset=True)
        receipts = copy.deepcopy(actor.attach_receipts)
        for index, wire in enumerate((self.voice_wire(options=4), self.voice_wire(group=TG+1),
                                      self.voice_wire(rid=RID+1), self.voice_wire(nac=0x294))):
            stamp = 4.1 + index
            actor.observe(self.event(wire, stamp=stamp))
            actor.observe(self.reset_event(stamp=stamp+.1))
            self.assertIsNone(actor.next_response(stamp+.2, stamp+.2))
            self.assertEqual(actor.attach_receipts, receipts)
        actor.observe(self.event(self.voice_wire(options=0), stamp=10.1))
        self.assertFalse(actor._qualified_rearm(actor.pending))
        self.assertIsNone(actor.next_response(10.2, 10.2))
        # Earlier requests' completion records are not reusable authorizations.
        self.assertIsNone(actor.rearm_request_sequence)
        actor.observe(self.reset_event(stamp=10.3))
        response = actor.next_response(10.4, 10.4)
        self.assertIsNotNone(response)
        actor.sent(response, 10.4)
        self.assertEqual(actor.grants_sent, 2)

    def test_repeated_grant_api_cannot_expand_single_leg_or_nonzero_options(self):
        for value in (True, False, 0, 4, None, '3'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.attach(attach_grant_limit=value)
        with self.assertRaises(ValueError):
            self.responder(attach_grant_limit=3)
        with self.assertRaises(ValueError):
            self.attach(attach_grant_limit=3, max_responses=5)
        with self.assertRaises(ValueError):
            self.attach(attach_options=0, attach_grant_limit=3, max_responses=3)

    def test_explicit_attach_options_zero_binds_native_three_leg_grant_and_rejects_other_options(self):
        for rearm in ('loss','reviewed-reset-or-loss'):
            with self.subTest(rearm=rearm):
                actor=self.attach(attach_options=0,registration_rearm=rearm);actor.bind_modem(DESCRIPTION)
                self.attach_leg(actor,self.wire(),.1,reset=rearm!='loss')
                self.attach_leg(actor,self.affiliation_wire(),1.1,reset=rearm!='loss')
                candidates=(self.voice_wire(options=4),self.voice_wire(options=0x40),
                    self.voice_wire(options=0x80),self.voice_wire(options=8),self.voice_wire(options=0,reserved=1))
                for index,wire in enumerate(candidates):
                    # CRC-native frames exercise the service/reserved field
                    # gates rather than relying on a decoder failure.
                    self.assertIsNotNone(self.decoder(wire))
                    stamp=2.1+index
                    actor.observe(self.event(wire,stamp=stamp));actor.observe(self.event(stamp=stamp+.1,command=0x32))
                    self.assertIsNone(actor.next_response(stamp+.2,stamp+.2))
                    self.assertEqual((actor.requests_matched,actor.responses_sent,actor.grants_sent),(2,2,0))
                    self.assertIsNone(actor.pending);self.assertEqual(actor.allowed_frames,frozenset())
                _,_,response=self.attach_leg(actor,self.voice_wire(options=0),8.1,reset=rearm!='loss')
                self.assertEqual(response.wire,actor.grants[0]);self.assertNotEqual(response.wire,actor.grants[4])
                nac,blocks=self.decoder(response.wire);self.assertEqual(nac,0x293)
                self.assertEqual(self.primary_fields(0,blocks[0],('opts','ch','ga','sa')),
                    dict(opts=0,ch=0x1001,ga=TG,sa=RID))
                summary=actor.summary();self.assertEqual(summary['attach_options'],0)
                self.assertEqual((summary['phase'],summary['requests_matched'],summary['requests_ignored'],
                    summary['responses_sent'],summary['grants_sent']),('complete',3,len(candidates),3,1))
                self.assertTrue(summary['exchange_complete']);self.assertFalse(summary['rf_timing_measured'])

    def test_attach_options_api_is_narrow_and_legacy_default_stays_four(self):
        self.assertEqual(self.attach().summary()['attach_options'],4)
        for bad in (True,False,1,8,0x40,0x80,'0',None):
            with self.subTest(bad=bad),self.assertRaises(ValueError):self.attach(attach_options=bad)
        with self.assertRaises(ValueError):self.responder(attach_options=0)

    def test_completed_attach_ignored_repeat_calls_do_not_arm_another_rearm_watchdog(self):
        events=[];actor=self.attach(attach_options=0,registration_rearm='reviewed-reset-or-loss',emit=events.append)
        actor.bind_modem(DESCRIPTION)
        for wire,stamp in ((self.wire(),.1),(self.affiliation_wire(),1.1),(self.voice_wire(options=0),2.1)):
            self.attach_leg(actor,wire,stamp,reset=True)
        receipts=copy.deepcopy(actor.summary()['receipts'])
        for index,ending in enumerate(('reset','loss','none','none')):
            stamp=10.1+index*2
            actor.observe(self.event(self.voice_wire(options=0),stamp=stamp))
            if ending=='reset':actor.observe(self.reset_event(stamp=stamp+.566))
            elif ending=='loss':actor.observe(self.event(stamp=stamp+.566,command=0x32))
            # The observed reset after the first ignored repeat used to leave
            # rx_busy set and falsely stop the CC after one second. No pending
            # response exists after this bounded session has completed.
            self.assertIsNone(actor.next_response(stamp+1.01,stamp+1.01))
            self.assertFalse(actor.rx_busy)
            self.assertEqual(actor.summary()['receipts'],receipts)
            self.assertEqual((actor.requests_matched,actor.responses_sent,actor.grants_sent),(3,3,1))
            self.assertIsNone(actor.pending);self.assertEqual(actor.allowed_frames,frozenset())
        self.assertEqual(actor.rejected,4);self.assertTrue(actor.summary()['exchange_complete'])
        self.assertEqual([row['reason'] for row in events if row['event']=='request_ignored'],
            ['unexpected_exchange_phase']*4)

    def test_completed_attach_actual_scheduler_survives_ignored_repeat_until_explicit_stop(self):
        clock,records,events=Clock(),[],[]
        actor=self.attach(attach_options=0,registration_rearm='reviewed-reset-or-loss')
        actor.bind_modem(DESCRIPTION)
        for wire,stamp in ((self.wire(),.1),(self.affiliation_wire(),1.1),(self.voice_wire(options=0),2.1)):
            self.attach_leg(actor,wire,stamp,reset=True)
        # schedule owns its own single arm, as in the real continuous source.
        actor.armed_at=None;clock.value=10.
        repeat=TOOL.MODEM.packet(0x30,b'\1'+self.voice_wire(options=0))
        reset=self.reset_event(stamp=10.5).wire
        class RepeatSerial(Serial):
            injected=False
            def write(serial,packet):
                result=super(RepeatSerial,serial).write(packet)
                if packet[2]==0x31 and len(packet)==94 and not serial.injected \
                        and sum(len(item)==94 for item in serial.sent)>=3:
                    serial.reads.extend(repeat+reset);serial.injected=True
                return result
        serial=RepeatSerial(clock)
        link=TOOL.CaptureLink(serial,self.site,records.append,responder=actor,clock=clock,sleep=clock.sleep)
        # Dispatcher sequence numbers are local to this separately started
        # capture; completion state is retained only to target its late path.
        actor.last_sequence=0;actor.last_stamp=-float('inf')
        link.version()
        result=TOOL.schedule(link,10,.6,clock=clock,sleep=clock.sleep,event=events.append,
            stopping=lambda:clock.value>=12.)
        self.assertTrue(result['stopped']);self.assertTrue(result['exchange_complete'])
        self.assertEqual((result['responses_sent'],result['grants_sent']),(3,1))
        self.assertGreater(result['site_units_sent'],3);self.assertEqual(actor.rejected,1)
        self.assertEqual([bytes.fromhex(row['wire_hex'])[2] for row in records],[0x30,0x31])
        self.assertFalse(any(len(packet)==49 for packet in serial.sent))

    def test_pending_attach_acceptance_still_requires_bounded_rearm(self):
        actor=self.attach(attach_options=0,registration_rearm='reviewed-reset-or-loss')
        actor.bind_modem(DESCRIPTION);actor.observe(self.event(self.wire(),stamp=.1))
        self.assertTrue(actor.rx_busy);self.assertIsNotNone(actor.pending)
        with self.assertRaisesRegex(TimeoutError,'Modem did not report RX loss'):
            actor.next_response(1.101,1.101)
        self.assertEqual((actor.responses_sent,actor.grants_sent),(0,0))

    def test_attach_call_each_leg_needs_fresh_positive_modem_and_header_bound_rearm(self):
        for failure in ('unbound', 'old_rearm', 'late_loss', 'replacement_header', 'malformed_loss', 'reset_without_opt_in'):
            with self.subTest(failure=failure):
                actor = self.attach()
                if failure != 'unbound': actor.bind_modem(DESCRIPTION)
                actor.observe(self.event(self.wire(), stamp=40.1))
                if failure == 'old_rearm':
                    actor.observe(self.event(stamp=40.2, command=0x32))
                    response = actor.next_response(40.3, 40.3); actor.sent(response, 40.3)
                    actor.observe(self.event(self.affiliation_wire(), stamp=41.1))
                    self.assertIsNone(actor.next_response(41.2, 41.2))
                    self.assertIsNone(actor.rearm_evidence_sequence)
                elif failure == 'malformed_loss':
                    self.sequence += 1
                    event = TOOL.MODEM.Event(self.sequence, 40.2, TOOL.MODEM.packet(0x32, b'\0'))
                    with self.assertRaises(ValueError): actor.observe(event)
                elif failure == 'reset_without_opt_in':
                    actor.observe(self.reset_event(stamp=40.2))
                    self.assertIsNone(actor.next_response(40.3, 40.3))
                else:
                    if failure == 'replacement_header':
                        # A request ignored while the old response is pending
                        # cannot lend its later RX-loss to the earlier request.
                        actor.observe(self.event(stamp=40.2, command=0x32))
                        actor.observe(self.event(self.wire(), stamp=40.3))
                    actor.observe(self.event(stamp=41.2 if failure == 'late_loss' else 40.4, command=0x32))
                    with self.assertRaises(RuntimeError): actor.next_response(41.21 if failure == 'late_loss' else 40.5,
                                                                            41.21 if failure == 'late_loss' else 40.5)
                self.assertEqual(actor.grants_sent, 0)

    def test_attach_call_actual_ninety_second_scheduler_keeps_three_response_limit(self):
        clock, records, events = Clock(), [], []
        requests = [self.wire(), self.affiliation_wire(), self.voice_wire()]
        inbound = TOOL.MODEM.packet(0x30, b'\1' + requests[0]) + TOOL.MODEM.packet(0x32)
        class ChainSerial(Serial):
            def write(serial, packet):
                result = super(ChainSerial, serial).write(packet)
                if packet[2] == 0x31 and len(packet) == 49:
                    count = sum(len(item) == 49 for item in serial.sent)
                    if count < 3:
                        serial.reads.extend(TOOL.MODEM.packet(0x30, b'\1' + requests[count]) + TOOL.MODEM.packet(0x32))
                return result
        serial = ChainSerial(clock, inbound)
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
            attach_call=True, max_responses=3)
        link = TOOL.CaptureLink(serial, self.site, records.append, responder=actor, clock=clock, sleep=clock.sleep)
        link.version()  # Actual version binding precedes buffered native RX.
        result = TOOL.schedule(link, 90, .6, clock=clock, sleep=clock.sleep, event=events.append)
        self.assertEqual((result['responses_sent'], result['grants_sent']), (3, 1))
        self.assertEqual(result['responder']['phase'], 'complete')
        self.assertTrue(result['exchange_complete'])
        self.assertFalse(result['stopped'])
        self.assertEqual([bytes.fromhex(row['wire_hex'])[2] for row in records], [0x30, 0x32] * 3)
        self.assertEqual(len([packet for packet in serial.sent if len(packet) == 49]), 3)
        self.assertEqual([self.parse(packet[4:])[0] for packet in serial.sent if len(packet) == 49], [2, 3, 1])
        self.assertEqual(len([event for event in events if event['event'] == 'cc_ready']), 1)
        self.assertLessEqual(result['max_estimated_payload_queue_s'], .25000001)
        self.assertFalse(result['rf_timing_measured']); self.assertFalse(result['rf_decode_verified'])
        # The extended duration is unavailable to a site-only/default link.
        plain = TOOL.CaptureLink(Serial(Clock()), self.site, lambda _: None)
        with self.assertRaises(ValueError): TOOL.schedule(plain, 31, .6)

    def test_attach_readiness_waits_for_three_primed_site_units_and_observed_tx(self):
        clock, events = Clock(), []
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
            attach_call=True, max_responses=3)
        serial = Serial(clock)
        link = TOOL.CaptureLink(serial, self.site, lambda _: None, responder=actor, clock=clock, sleep=clock.sleep)
        link.version()
        result = TOOL.schedule(link, 2, .6, clock=clock, sleep=clock.sleep, event=events.append)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]['event'], 'cc_ready')
        self.assertEqual(events[0]['site_units_queued'], 3)
        self.assertTrue(events[0]['tx_observed'])
        self.assertAlmostEqual(events[0]['estimated_payload_queue_s'], .225)
        self.assertFalse(events[0]['rf_timing_measured'] or events[0]['rf_decode_verified'])
        self.assertFalse(result['exchange_complete'])
        self.assertEqual((result['responses_sent'], result['grants_sent']), (0, 0))
        self.assertEqual(result['responder']['receipts'], [])

    def test_join_only_stop_drains_two_responses_without_inventing_a_voice_request_or_grant(self):
        for rearm in ('loss', 'reviewed-reset-or-loss'):
            with self.subTest(rearm=rearm):
                clock, records, events = Clock(), [], []
                actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
                    attach_call=True, max_responses=3, registration_rearm=rearm, emit=events.append)
                request = TOOL.MODEM.packet(0x30, b'\1'+self.wire()) + TOOL.MODEM.packet(0x32)
                second = TOOL.MODEM.packet(0x30, b'\1'+self.affiliation_wire())
                if rearm == 'loss':
                    second += TOOL.MODEM.packet(0x32)
                else:
                    second += self.reset_event(stamp=101).wire
                class JoinSerial(Serial):
                    def write(serial, packet):
                        result = super(JoinSerial, serial).write(packet)
                        if packet[2] == 0x31 and len(packet) == 49 and sum(len(p) == 49 for p in serial.sent) == 1:
                            serial.reads.extend(second)
                        return result
                serial = JoinSerial(clock, request)
                link = TOOL.CaptureLink(serial, self.site, records.append, responder=actor, clock=clock, sleep=clock.sleep)
                link.version()
                result = TOOL.schedule(link, 90, .6, clock=clock, sleep=clock.sleep,
                    stopping=lambda: actor.responses_sent == 2)
                self.assertTrue(result['stopped'])
                self.assertFalse(result['exchange_complete'])
                summary = result['responder']
                self.assertTrue(summary['registered'] and summary['affiliated'])
                self.assertEqual((summary['phase'], summary['requests_matched'], summary['responses_sent'], summary['grants_sent']),
                                 ('voice', 2, 2, 0))
                self.assertEqual([row['stage'] for row in summary['receipts']], ['registration', 'affiliation'])
                self.assertFalse(summary['exchange_complete'] or summary['pending_response'])
                self.assertEqual(len([p for p in serial.sent if len(p) == 49]), 2)
                self.assertFalse(any(row['event'] == 'attach_responses_queued' for row in events))
                self.assertGreaterEqual(clock(), serial.tail+TOOL.POSTROLL_SECONDS)
                self.assertLess(result['elapsed_s'], 3)

    def test_attach_stop_before_first_payload_queries_nothing_and_claims_no_exchange(self):
        clock = Clock()
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
            attach_call=True, max_responses=3)
        serial = Serial(clock)
        link = TOOL.CaptureLink(serial, self.site, lambda _: None, responder=actor, clock=clock, sleep=clock.sleep)
        result = TOOL.schedule(link, 90, .6, clock=clock, sleep=clock.sleep, stopping=lambda: True)
        self.assertEqual(serial.writes, [])
        self.assertTrue(result['stopped'])
        self.assertFalse(result['tx_observed'] or result['exchange_complete'])
        self.assertEqual(result['responses_sent'], 0)

    def test_late_status_cannot_return_transport_success_or_queue_any_payload(self):
        clock = Clock()
        actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
            attach_call=True, max_responses=3)
        class LateLink:
            responder, records = actor, 0
            def status(self):
                clock.sleep(6)
                return dict(p25=True, mode=0, tx=False, space=6)
            def send_site(self): raise AssertionError('no payload after deadline')
        with self.assertRaises(TimeoutError):
            TOOL.schedule(LateLink(), 2, .6, clock=clock, sleep=clock.sleep)

    def test_owner_stop_bounds_stuck_tx_drain_in_both_stop_check_positions(self):
        for trigger in ('before_status', 'after_status'):
            with self.subTest(trigger=trigger):
                clock = Clock()
                actor = TOOL.LabResponder(self.metadata, self.decoder, radio_id=RID, talkgroup=TG,
                    attach_call=True, max_responses=3)
                class StuckLink:
                    responder, records, sent, polls = actor, 0, 0, 0
                    def status(link):
                        link.polls += 1
                        return dict(p25=True, mode=4 if link.sent else 0, tx=bool(link.sent), space=6)
                    def send_site(link): link.sent += 1
                link = StuckLink()
                stop_at = []
                def stopping():
                    requested = link.sent >= 3 if trigger == 'before_status' else link.polls >= 4
                    if requested and not stop_at: stop_at.append(clock())
                    return requested
                with self.assertRaises(TimeoutError):
                    TOOL.schedule(link, 90, .6, clock=clock, sleep=clock.sleep, stopping=stopping)
                self.assertEqual(len(stop_at), 1)
                self.assertEqual(link.sent, 3)
                self.assertLessEqual(clock()-stop_at[0], TOOL.CC.DRAIN_SECONDS+.02)
                self.assertLess(clock(), 104)

    def test_exchange_fixture_roundtrip_and_offline_active_cli(self):
        files, manifest = TOOL.EXCHANGE.make_exchange_fixture(radio_id=RID, talkgroup=TG)
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            TOOL.EXCHANGE.write_exchange_fixture(directory, files, manifest)
            self.assertEqual(TOOL.EXCHANGE.load_exchange_fixture(directory), (files, manifest))
            (directory / "voice-grant.bin").write_bytes(b"wrong")
            with self.assertRaises(ValueError):
                TOOL.EXCHANGE.load_exchange_fixture(directory)
            TOOL.CC.GENERATOR.write_fixture(directory, self.frames, self.metadata)
            result = subprocess.run([sys.executable, "-B", str(ROOT / "scripts/hotspot-p25-access.py"),
                "--fixture", str(directory / "control.bin"), "--manifest", str(directory / "manifest.json"),
                "--active-responses", "--radio-id", hex(RID), "--talkgroup", str(TG)],
                cwd=ROOT, text=True, capture_output=True, check=True)
            plan = json.loads(result.stdout)
            self.assertTrue(plan["dry_run"])
            self.assertTrue(plan["active_responses"])
            self.assertEqual(plan["rf_payload_commands_sent"], 0)
            self.assertEqual(plan["responses_sent"], 0)

    def test_acceptance_only_offline_cli_and_policy_refusals(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp);TOOL.CC.GENERATOR.write_fixture(directory,self.frames,self.metadata)
            base=['--fixture',str(directory/'control.bin'),'--manifest',str(directory/'manifest.json'),
                  '--active-responses','--radio-id',hex(RID),'--talkgroup',str(TG),
                  '--registration-acceptance-only','--registration-policy','accept',
                  '--affiliation-policy','timeout','--voice-policy','timeout','--max-responses','1']
            with contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(TOOL.main(base),0)
            plan=json.loads(output.getvalue());policy=plan['response_policy']
            self.assertTrue(policy['registration_acceptance_only']);self.assertEqual(policy['max_responses'],1)
            self.assertTrue(plan['decoder_required_on_executing_host']);self.assertEqual(plan['rf_payload_commands_sent'],0)
            self.assertNotIn('registration_rearm',policy)
            with contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(TOOL.main(base+['--registration-rearm','reviewed-reset-or-loss']),0)
            self.assertEqual(json.loads(output.getvalue())['response_policy']['registration_rearm'],'reviewed-reset-or-loss')
            for bad in (['--registration-policy','deny'],['--affiliation-policy','accept'],
                        ['--voice-policy','accept'],['--max-responses','2'],['--queue-delay','1.5']):
                with self.subTest(bad=bad),contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
                    TOOL.main(base+bad)
        for options in ({'registration_acceptance_only':1},{'registration':'queue'},{'affiliation':'accept'},
                        {'voice':'accept'},{'max_responses':2},{'queue_delay':1.5}):
            with self.subTest(options=options),self.assertRaises(ValueError):self.acceptance_only(**options)
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            TOOL.main(['--registration-acceptance-only'])
        for options in ({'registration_rearm':'automatic'},{'registration_acceptance_only':False,'registration_rearm':'reviewed-reset-or-loss'}):
            with self.subTest(options=options),self.assertRaises(ValueError):self.acceptance_only(**options)
        with self.assertRaises(ValueError):self.responder(registration_rearm='reviewed-reset-or-loss')
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            TOOL.main(['--registration-rearm','reviewed-reset-or-loss'])

    def test_affiliation_only_cli_policy_alias_and_conflict_refusals(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp);TOOL.CC.GENERATOR.write_fixture(directory,self.frames,self.metadata)
            base=['--fixture',str(directory/'control.bin'),'--manifest',str(directory/'manifest.json'),
                '--active-responses','--radio-id',hex(RID),'--talkgroup',str(TG),
                '--affiliation-acceptance-only','--registration-policy','timeout',
                '--affiliation-policy','accept','--voice-policy','timeout','--max-responses','1']
            for rearm in ('loss','reviewed-reset-or-loss'):
                with contextlib.redirect_stdout(io.StringIO()) as output:
                    self.assertEqual(TOOL.main(base+['--acceptance-rearm',rearm]),0)
                plan=json.loads(output.getvalue());self.assertTrue(plan['dry_run']);self.assertEqual(plan['rf_payload_commands_sent'],0)
                policy=plan['response_policy'];self.assertTrue(policy['affiliation_acceptance_only'])
                self.assertNotIn('registration_acceptance_only',policy)
                self.assertEqual((policy['registration'],policy['affiliation'],policy['voice'],policy['max_responses']),('timeout','accept','timeout',1))
                if rearm=='loss':self.assertNotIn('registration_rearm',policy)
                else:self.assertEqual(policy['registration_rearm'],rearm)
            for bad in (['--registration-acceptance-only'],['--registration-policy','accept'],
                        ['--affiliation-policy','deny'],['--voice-policy','accept'],['--max-responses','2']):
                with self.subTest(bad=bad),contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
                    TOOL.main(base+bad)
        for options in ({'affiliation_acceptance_only':1},{'registration_acceptance_only':True},
                        {'registration':'accept'},{'affiliation':'queue'},{'voice':'accept'},
                        {'max_responses':2},{'queue_delay':1.5}):
            with self.subTest(options=options),self.assertRaises(ValueError):self.affiliation_only(**options)
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):TOOL.main(['--affiliation-acceptance-only'])

    def test_voice_only_cli_contract_and_conflicting_policy_refusals(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp);TOOL.CC.GENERATOR.write_fixture(directory,self.frames,self.metadata)
            base=['--fixture',str(directory/'control.bin'),'--manifest',str(directory/'manifest.json'),
                '--active-responses','--radio-id',hex(RID),'--talkgroup',str(TG),
                '--voice-grant-only','--registration-policy','timeout','--affiliation-policy','timeout',
                '--voice-policy','accept','--max-responses','1']
            for rearm in ('loss','reviewed-reset-or-loss'):
                with contextlib.redirect_stdout(io.StringIO()) as output:
                    self.assertEqual(TOOL.main(base+['--acceptance-rearm',rearm]),0)
                plan=json.loads(output.getvalue());self.assertTrue(plan['dry_run'])
                self.assertEqual((plan['rf_payload_commands_sent'],plan['responses_sent'],plan['grants_sent']),(0,0,0))
                policy=plan['response_policy'];self.assertTrue(policy['voice_grant_only'])
                self.assertNotIn('registration_acceptance_only',policy);self.assertNotIn('affiliation_acceptance_only',policy)
                self.assertEqual((policy['registration'],policy['affiliation'],policy['voice'],policy['max_responses']),('timeout','timeout','accept',1))
                if rearm=='loss':self.assertNotIn('registration_rearm',policy)
                else:self.assertEqual(policy['registration_rearm'],rearm)
            for bad in (['--registration-acceptance-only'],['--affiliation-acceptance-only'],
                        ['--registration-policy','accept'],['--affiliation-policy','accept'],
                        ['--voice-policy','queue'],['--max-responses','2'],['--queue-delay','1.5']):
                with self.subTest(bad=bad),contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
                    TOOL.main(base+bad)
        for options in ({'voice_grant_only':1},{'registration_acceptance_only':True},{'affiliation_acceptance_only':True},
                        {'registration':'accept'},{'affiliation':'accept'},{'voice':'deny'},
                        {'max_responses':2},{'queue_delay':1.5}):
            with self.subTest(options=options),self.assertRaises(ValueError):self.voice_only(**options)
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):TOOL.main(['--voice-grant-only'])

    def test_attach_call_cli_extends_only_explicit_strict_three_leg_policy_to_ninety_seconds(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp); TOOL.CC.GENERATOR.write_fixture(directory, self.frames, self.metadata)
            base = ['--fixture', str(directory/'control.bin'), '--manifest', str(directory/'manifest.json'),
                '--active-responses', '--radio-id', hex(RID), '--talkgroup', str(TG),
                '--attach-call', '--max-responses', '3', '--duration', '90']
            for rearm in ('loss', 'reviewed-reset-or-loss'):
                with contextlib.redirect_stdout(io.StringIO()) as output:
                    self.assertEqual(TOOL.main(base + ['--acceptance-rearm', rearm]), 0)
                plan = json.loads(output.getvalue()); policy = plan['response_policy']
                self.assertTrue(plan['dry_run']); self.assertTrue(policy['attach_call'])
                self.assertEqual(plan['attach_options'],4)
                self.assertEqual(plan['duration_limit_s'], 90)
                self.assertEqual((plan['rf_payload_commands_sent'], plan['responses_sent'], plan['grants_sent']), (0, 0, 0))
                self.assertTrue(plan['decoder_required_on_executing_host'])
                self.assertEqual((policy['registration'], policy['affiliation'], policy['voice'],
                    policy['max_responses'], policy['queue_delay']), ('accept', 'accept', 'accept', 3, 1))
                for name in ('registration_acceptance_only', 'affiliation_acceptance_only', 'voice_grant_only'):
                    self.assertNotIn(name, policy)
                with contextlib.redirect_stdout(io.StringIO()) as explicit:
                    self.assertEqual(TOOL.main(base+['--acceptance-rearm',rearm,'--attach-options','0']),0)
                normal=json.loads(explicit.getvalue())
                self.assertEqual(normal['attach_options'],0);self.assertEqual(normal['response_policy']['attach_options'],0)
                self.assertEqual(normal['rf_payload_commands_sent'],0)
            for bad in (['--duration', '91'], ['--registration-acceptance-only'], ['--affiliation-acceptance-only'],
                        ['--voice-grant-only'], ['--registration-policy', 'queue'], ['--affiliation-policy', 'deny'],
                        ['--voice-policy', 'timeout'], ['--max-responses', '4'], ['--queue-delay', '1.5'],
                        ['--attach-options','1'],['--attach-options','64']):
                with self.subTest(bad=bad), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                    TOOL.main(base + bad)
            for options in ({'attach_call': 1}, {'registration_acceptance_only': True},
                            {'affiliation_acceptance_only': True}, {'voice_grant_only': True},
                            {'registration': 'deny'}, {'affiliation': 'queue'}, {'voice': 'timeout'},
                            {'max_responses': 2}, {'queue_delay': .5}):
                with self.subTest(options=options), self.assertRaises(ValueError): self.attach(**options)
            ordinary = [value for value in base if value != '--attach-call']
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit): TOOL.main(ordinary)
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit): TOOL.main(['--attach-call'])
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit): TOOL.main(['--attach-options','0'])
        for duration in (True, float('nan'), float('inf'), -1, 1, 90.00001):
            with self.subTest(duration=duration), self.assertRaises(ValueError): TOOL.finite_duration(duration, attach_call=True)
        TOOL.finite_duration(90, attach_call=True)
        for duration in (30.00001, 90):
            with self.assertRaises(ValueError): TOOL.finite_duration(duration)

    def test_bad_identity_policy_mapping_or_bounds_refuse_before_serial(self):
        for kwargs in ({"radio_id": 0}, {"radio_id": 0xFFFFFF}, {"talkgroup": 0},
                       {"max_responses": 9}, {"max_responses": True}, {"queue_delay": float("nan")},
                       {"queue_delay": 0.1}, {"registration": "automatic"}):
            options = dict(radio_id=RID, talkgroup=TG)
            options.update(kwargs)
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                TOOL.LabResponder(self.metadata, self.decoder, **options)
        changed = copy.deepcopy(self.metadata)
        changed["bandplan"]["voice_channel"] = changed["bandplan"]["control_channel"]
        with self.assertRaisesRegex(ValueError, "channel pair"):
            TOOL.LabResponder(changed, self.decoder, radio_id=RID, talkgroup=TG)
        for argv in (["--active-responses"], ["--radio-id", hex(RID)], ["--registration-policy", "deny"]):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                TOOL.main(argv)


if __name__ == "__main__":
    unittest.main()
