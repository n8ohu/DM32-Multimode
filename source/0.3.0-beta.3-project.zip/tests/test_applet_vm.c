// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_applet_vm.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint8_t image[RADIO_APPLET_MAX_BYTES];
static uint32_t image_size,reads,failed_offset;
static bool fail_read,fail_service;
static unsigned emitted,displayed,started,lasts,shown,get_count;
static char last_text[96];

static void put16(uint8_t *p,unsigned n) {p[0]=(uint8_t)n;p[1]=(uint8_t)(n>>8);}
static void put32(uint8_t *p,uint32_t n) {for(unsigned i=0;i<4;++i)p[i]=(uint8_t)(n>>(8u*i));}
static uint32_t checksum(void) {
 uint32_t value=0xffffffffu;
 for(uint32_t i=0;i<image_size;++i) {
  if(i>=60 && i<64)continue;
  value^=image[i];for(unsigned bit=0;bit<8;++bit)value=value&1u ? (value>>1)^0xedb88320u : value>>1;
 }
 return ~value;
}
static void seal(void) {put32(image+60,checksum());}
static void package(unsigned count,uint32_t caps,const char *strings) {
 size_t n=strings ? strlen(strings) : 0;
 memset(image,0,sizeof image);memcpy(image,"DAPP",4);put16(image+4,1);put16(image+6,64);
 image_size=64u+count*8u+(uint32_t)n;
 put32(image+8,image_size);put32(image+12,caps);put32(image+16,64);put16(image+20,count);
 put32(image+24,64u+count*8u);put32(image+28,(uint32_t)n);memcpy(image+32,"Test app",8);
 if(n)memcpy(image+64u+count*8u,strings,n);
 fail_read=fail_service=false;reads=0;
}
static void insn(unsigned index,unsigned op,unsigned a,unsigned b,uint32_t imm) {
 uint8_t *p=image+64u+index*8u;p[0]=(uint8_t)op;p[1]=(uint8_t)a;put16(p+2,b);put32(p+4,imm);
}
static bool read_image(void *context,uint32_t offset,void *out,size_t count) {
 assert(context==image);++reads;
 if(offset>image_size || count>image_size-offset || (fail_read && offset>=failed_offset))return false;
 memcpy(out,image+offset,count);return true;
}
static bool emit(void *context,const char *text) {
 assert(context==last_text);++emitted;assert(strlen(text)<=95);strcpy(last_text,text);return !fail_service;
}
static bool display(void *context,const char *text) {++displayed;return emit(context,text);}
static bool same_start(void *context,uint32_t hz) {assert(context==last_text && hz==162550000u);++started;return !fail_service;}
static bool same_last(void *context) {assert(context==last_text);++lasts;return !fail_service;}
static bool display_same(void *context) {assert(context==last_text);++shown;return !fail_service;}
static bool get(void *context,unsigned field,uint32_t *value) {assert(context==last_text);++get_count;*value=100u+field;return !fail_service;}
static const radio_applet_services services={same_start,same_last,display,display_same,emit,get};
static void start(radio_applet_vm *vm) {
 seal();radio_applet_vm_init(vm,read_image,image,&services,last_text);
 radio_applet_error error=RADIO_APPLET_ERROR_READ;
 assert(radio_applet_vm_start(vm,&error));assert(error==RADIO_APPLET_ERROR_NONE);
}
static void invalid(radio_applet_error expected) {
 radio_applet_error error=RADIO_APPLET_ERROR_NONE;radio_applet_package meta;
 seal();memset(&meta,0xff,sizeof meta);
 assert(!radio_applet_vm_validate(read_image,image,&meta,&error));assert(error==expected);
 for(unsigned i=0;i<sizeof meta;++i)assert(!((uint8_t *)&meta)[i]);
}
static void test_validation(void) {
 radio_applet_package meta;radio_applet_error error;
 package(1,0,NULL);seal();assert(radio_applet_vm_validate(read_image,image,&meta,&error));
 assert(meta.instruction_count==1 && meta.entry==0 && !strcmp(meta.name,"Test app"));
 image[4]=2;invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);put16(image+20,0);invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);put16(image+22,1);invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,16,NULL);invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);image[56]=1;invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);image[32]=0;invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);memset(image+32,'A',24);invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);image[41]='X';invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);put32(image+24,100);invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);put32(image+8,RADIO_APPLET_MAX_BYTES+1u);invalid(RADIO_APPLET_ERROR_FORMAT);
 package(1,0,NULL);seal();image[60]^=1;assert(!radio_applet_vm_validate(read_image,image,&meta,&error));assert(error==RADIO_APPLET_ERROR_CRC);
 package(1,0,NULL);insn(0,255,0,0,0);invalid(RADIO_APPLET_ERROR_OPCODE);
 package(1,0,NULL);insn(0,RADIO_APPLET_END,1,0,0);invalid(RADIO_APPLET_ERROR_OPERAND);
 package(1,0,NULL);insn(0,RADIO_APPLET_SET,8,0,1);invalid(RADIO_APPLET_ERROR_OPERAND);
 package(1,0,NULL);insn(0,RADIO_APPLET_JMP,0,1,0);invalid(RADIO_APPLET_ERROR_BRANCH);
 package(1,0,NULL);insn(0,RADIO_APPLET_JEQ,0,65535,0);invalid(RADIO_APPLET_ERROR_BRANCH);
 package(1,0,NULL);insn(0,RADIO_APPLET_WAIT,0,0,0);invalid(RADIO_APPLET_ERROR_OPERAND);
 package(1,0,NULL);insn(0,RADIO_APPLET_WAIT,0,0,60001);invalid(RADIO_APPLET_ERROR_OPERAND);
 package(1,0,NULL);insn(0,RADIO_APPLET_EMIT_REG,0,0,0);invalid(RADIO_APPLET_ERROR_CAPABILITY);
 package(1,RADIO_APPLET_CAP_SERIAL,"Hello");insn(0,RADIO_APPLET_EMIT_LITERAL,0,6,0);invalid(RADIO_APPLET_ERROR_STRING);
 package(1,RADIO_APPLET_CAP_SERIAL,"Hello");insn(0,RADIO_APPLET_EMIT_LITERAL,0,1,UINT32_MAX);invalid(RADIO_APPLET_ERROR_STRING);
 package(1,0,"Hi");image[73]=10;invalid(RADIO_APPLET_ERROR_STRING);
 package(1,RADIO_APPLET_CAP_SAME,NULL);insn(0,RADIO_APPLET_SAME_START,0,0,146520000);invalid(RADIO_APPLET_ERROR_OPERAND);
 package(1,RADIO_APPLET_CAP_SAME,NULL);insn(0,RADIO_APPLET_SAME_LAST,0,0,0);invalid(RADIO_APPLET_ERROR_CAPABILITY);
 package(1,RADIO_APPLET_CAP_SAME,NULL);insn(0,RADIO_APPLET_AWAIT,0,RADIO_APPLET_EVENT_KEY,100);invalid(RADIO_APPLET_ERROR_CAPABILITY);
 package(1,0,NULL);insn(0,RADIO_APPLET_GET,0,14,0);invalid(RADIO_APPLET_ERROR_OPERAND);
 package(1,0,NULL);insn(0,RADIO_APPLET_GET,0,8,0);invalid(RADIO_APPLET_ERROR_CAPABILITY);
 package(1,0,NULL);insn(0,RADIO_APPLET_GET,0,9,0);seal();assert(radio_applet_vm_validate(read_image,image,&meta,&error));
 package(1,0,NULL);seal();fail_read=true;failed_offset=64;assert(!radio_applet_vm_validate(read_image,image,&meta,&error));assert(error==RADIO_APPLET_ERROR_READ);
 package(4088,0,NULL);seal();assert(image_size==32768u);assert(radio_applet_vm_validate(read_image,image,&meta,&error));
}
static void test_arithmetic_and_branches(void) {
 radio_applet_vm vm;package(10,RADIO_APPLET_CAP_SERIAL,NULL);
 insn(0,RADIO_APPLET_SET,0,0,UINT32_MAX);insn(1,RADIO_APPLET_ADD,0,0,1);
 insn(2,RADIO_APPLET_JEQ,0,5,0);insn(3,RADIO_APPLET_SET,0,0,99);insn(4,RADIO_APPLET_JMP,0,6,0);
 insn(5,RADIO_APPLET_SET,1,0,42);insn(6,RADIO_APPLET_JNE,1,8,41);
 insn(7,RADIO_APPLET_SET,0,0,99);insn(8,RADIO_APPLET_EMIT_REG,1,0,0);
 start(&vm);assert(radio_applet_vm_tick(&vm,0)==RADIO_APPLET_FINISHED);
 assert(vm.registers[0]==0 && vm.registers[1]==42 && !strcmp(last_text,"42"));
 assert(vm.instructions==7);
}
static void test_wait_wrap_and_yield(void) {
 radio_applet_vm vm;package(6,0,NULL);
 insn(0,RADIO_APPLET_SET,0,0,7);insn(1,RADIO_APPLET_WAIT,0,0,50);
 insn(2,RADIO_APPLET_ADD,0,0,1);insn(3,RADIO_APPLET_YIELD,0,0,0);insn(4,RADIO_APPLET_ADD,0,0,1);
 start(&vm);assert(radio_applet_vm_tick(&vm,UINT32_MAX-20u)==RADIO_APPLET_WAITING);
 assert(radio_applet_vm_tick(&vm,10)==RADIO_APPLET_WAITING && vm.registers[0]==7);
 assert(radio_applet_vm_tick(&vm,30)==RADIO_APPLET_WAITING && vm.registers[0]==8);
 assert(radio_applet_vm_tick(&vm,30)==RADIO_APPLET_WAITING);
 assert(radio_applet_vm_tick(&vm,31)==RADIO_APPLET_FINISHED && vm.registers[0]==9);
}
static void test_events_and_services(void) {
 radio_applet_vm vm;package(11,RADIO_APPLET_CAP_ALL,"WeatherReady");
 insn(0,RADIO_APPLET_SAME_START,0,0,162550000u);
 insn(1,RADIO_APPLET_DISPLAY_LITERAL,0,7,0);insn(2,RADIO_APPLET_EMIT_LITERAL,0,5,7);
 insn(3,RADIO_APPLET_SAME_LAST,0,0,0);insn(4,RADIO_APPLET_DISPLAY_SAME,0,0,0);
 insn(5,RADIO_APPLET_AWAIT,0,RADIO_APPLET_EVENT_HEADER|RADIO_APPLET_EVENT_KEY,100);
 insn(6,RADIO_APPLET_GET,1,8,0);insn(7,RADIO_APPLET_GET,3,13,0);
 insn(8,RADIO_APPLET_AWAIT,2,RADIO_APPLET_EVENT_CONFIRMED,10);insn(9,RADIO_APPLET_GET,4,9,0);
 start(&vm);assert(radio_applet_vm_tick(&vm,100)==RADIO_APPLET_WAITING);
 assert(started && displayed && lasts && shown && !strcmp(last_text,"Ready"));
 radio_applet_vm_signal(&vm,RADIO_APPLET_EVENT_EOM);
 assert(radio_applet_vm_tick(&vm,120)==RADIO_APPLET_WAITING);
 radio_applet_vm_signal(&vm,RADIO_APPLET_EVENT_KEY|RADIO_APPLET_EVENT_HEADER|128u);
 assert(radio_applet_vm_tick(&vm,125)==RADIO_APPLET_WAITING);
 assert(vm.registers[0]==9u && vm.registers[1]==108u && vm.registers[3]==113u);
 assert(vm.pending_events==RADIO_APPLET_EVENT_EOM);
 assert(radio_applet_vm_tick(&vm,134)==RADIO_APPLET_WAITING);
 assert(radio_applet_vm_tick(&vm,135)==RADIO_APPLET_FINISHED && vm.registers[2]==0 && vm.registers[4]==109u);
 start(&vm);radio_applet_vm_signal(&vm,RADIO_APPLET_EVENT_HEADER|RADIO_APPLET_EVENT_CONFIRMED);
 assert(radio_applet_vm_tick(&vm,10)==RADIO_APPLET_FINISHED && vm.registers[2]==RADIO_APPLET_EVENT_CONFIRMED);
 radio_applet_vm_stop(&vm);assert(vm.state==RADIO_APPLET_IDLE && !vm.pending_events);
 radio_applet_vm_signal(&vm,15u);assert(!vm.pending_events);
}
static void test_execution_bounds(void) {
 radio_applet_vm vm;package(1,0,NULL);insn(0,RADIO_APPLET_JMP,0,0,0);start(&vm);
 for(unsigned tick=0;tick<4000 && vm.state==RADIO_APPLET_RUNNING;++tick) {
  uint32_t before=vm.instructions;radio_applet_vm_tick(&vm,tick);
  assert(vm.instructions-before<=32u);
 }
 assert(vm.state==RADIO_APPLET_FAULT && vm.error==RADIO_APPLET_ERROR_FUEL && vm.instructions==100000u);
 package(2,0,NULL);insn(0,RADIO_APPLET_YIELD,0,0,0);insn(1,RADIO_APPLET_JMP,0,0,0);start(&vm);
 for(unsigned tick=0;tick<5000;++tick)assert(radio_applet_vm_tick(&vm,tick)==RADIO_APPLET_WAITING);
 assert(!vm.error && vm.instructions<10001u);
 package(1,0,NULL);insn(0,RADIO_APPLET_SET,0,0,1);start(&vm);
 assert(radio_applet_vm_tick(&vm,0)==RADIO_APPLET_FAULT && vm.error==RADIO_APPLET_ERROR_BRANCH);
 package(1,0,NULL);start(&vm);image[64]=255;
 assert(radio_applet_vm_tick(&vm,0)==RADIO_APPLET_FAULT && vm.error==RADIO_APPLET_ERROR_OPCODE);
 package(1,0,NULL);start(&vm);fail_read=true;failed_offset=64;
 assert(radio_applet_vm_tick(&vm,0)==RADIO_APPLET_FAULT && vm.error==RADIO_APPLET_ERROR_READ);
 package(2,RADIO_APPLET_CAP_SERIAL,"Hi");insn(0,RADIO_APPLET_EMIT_LITERAL,0,2,0);start(&vm);fail_service=true;
 assert(radio_applet_vm_tick(&vm,0)==RADIO_APPLET_FAULT && vm.error==RADIO_APPLET_ERROR_SERVICE);
 package(2,RADIO_APPLET_CAP_SERIAL,"Hi");insn(0,RADIO_APPLET_EMIT_LITERAL,0,2,0);seal();
 radio_applet_vm_init(&vm,read_image,image,NULL,NULL);assert(radio_applet_vm_start(&vm,NULL));
 assert(radio_applet_vm_tick(&vm,0)==RADIO_APPLET_FAULT && vm.error==RADIO_APPLET_ERROR_SERVICE);
}
int main(int argc,char **argv) {
 if(argc>1) {
  FILE *f=fopen(argv[1],"rb");assert(f);
  image_size=(uint32_t)fread(image,1,sizeof image,f);assert(!ferror(f));fclose(f);
  radio_applet_package meta;radio_applet_error error;
  if(!radio_applet_vm_validate(read_image,image,&meta,&error)) {printf("invalid:%s\n",radio_applet_vm_error_name(error));return 2;}
  printf("valid:%s:%u:%lu\n",meta.name,meta.instruction_count,(unsigned long)meta.capabilities);return 0;
 }
 test_validation();test_arithmetic_and_branches();test_wait_wrap_and_yield();test_events_and_services();test_execution_bounds();
 printf("applet VM checks passed; state=%zu bytes\n",sizeof(radio_applet_vm));return 0;
}
