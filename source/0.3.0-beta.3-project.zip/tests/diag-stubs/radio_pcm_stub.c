// SPDX-License-Identifier: GPL-3.0-or-later
// Link-only PCM transport/routing mocks for existing non-PCM adapter models.
#include "radio_pcm_uart.h"
#include "radio_pcm_fm_tx.h"
bool dm32_pcm_uart_baud(uint32_t baud) {return baud==115200u || baud==230400u;}
size_t dm32_pcm_uart_write(const uint8_t *data,size_t length) {
    (void)data;return length>128u ? 128u:length;
}
bool dm32_pcm_uart_idle(void) {return true;}
bool dm32_pcm_uart_drain(uint32_t timeout_ms) {(void)timeout_ms;return true;}
bool dm32_pcm_fm_route(bool on) {(void)on;return true;}
bool dm32_pcm_fm_prepare(uint32_t hz,bool wide,uint8_t power) {
    (void)hz;(void)wide;(void)power;return false;
}
bool dm32_pcm_fm_key(void) {return false;}
