# SPDX-License-Identifier: GPL-3.0-or-later
"""Gapless progressive recorder assembly, finite lifetime and race rejection."""
from pathlib import Path
import hashlib
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build/test-p25-rx-stream'
BUILD.mkdir(parents=True,exist_ok=True)
BINARY=BUILD/('stream.exe' if sys.platform=='win32' else 'stream')
subprocess.run(['gcc','-std=c11','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror',
    '-Wshadow','-Wstrict-aliasing=2','-pedantic','-Isrc/firmware','tests/test_p25_rx_stream.c',
    'src/firmware/p25_rx_stream.c','-o',str(BINARY)],cwd=ROOT,check=True)
subprocess.run([str(BINARY)],cwd=ROOT,check=True,timeout=20)

# The complete original core is the oracle for the reverted no-op experiment.
# Its pending check is one native MMIO read; the extra metadata predicate cost
# more on the actual target. Require exact IO callback order/count as well as
# all original state/bytes and fault precedence, including pending boundaries.
reference=ROOT/'tests/reference/p25_rx_stream_pre_noop.c'
normalized=reference.read_text().encode()
if hashlib.sha256(normalized).hexdigest()!='84dcfb0515067467fc9302671da13a6d5464c4ad5ab4b2e36ce68f6e7e5ae598':
    raise ValueError('Frozen pre-optimization RX stream reference changed')
names=('init','active','start','irq','step','pop','cancel','finalize','half_read','marker')
reference_object=BUILD/'reference.o'
subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-Isrc/firmware',
    *['-Dp25_rx_stream_'+name+'=reference_p25_rx_stream_'+name for name in names],
    '-c',str(reference),'-o',str(reference_object)],cwd=ROOT,check=True)
differential=BUILD/('differential.exe' if sys.platform=='win32' else 'differential')
subprocess.run(['gcc','-std=c11','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror',
    '-Wshadow','-Wstrict-aliasing=2','-pedantic','-Isrc/firmware',
    'tests/test_p25_rx_stream_differential.c','src/firmware/p25_rx_stream.c',
    str(reference_object),'-o',str(differential)],cwd=ROOT,check=True)
subprocess.run([str(differential)],cwd=ROOT,check=True,timeout=30)
