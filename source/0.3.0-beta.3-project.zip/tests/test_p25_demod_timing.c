// SPDX-License-Identifier: GPL-3.0-or-later
// Native timing/event bridge. No radio, heap, CPU clock or transport mocks.
#include "p25_demod.h"
#include "p25_trunking_slot.h"
#include <assert.h>
#include <limits.h>
#include <string.h>
#include "../src/firmware/p25_demod.c"

typedef struct {
    uint64_t *events;
    unsigned capacity,count,frames,hash,discontinuities;
    p25_trunking_slot slot;
    unsigned coherent;
} timing_output;
static uint32_t timing_profile_clock(void) {static uint32_t tick;return ++tick;}
static void timing_status(const p25_demod_status *event,void *context) {
    timing_output *o=context;
    if(o->count<o->capacity) {
        uint64_t *v=o->events+7u*o->count;
        v[0]=event->sample_tick;v[1]=event->stream_epoch;v[2]=event->lane_epoch;
        v[3]=event->nac;v[4]=event->status;v[5]=event->lane;
        v[6]=(event->selected?1u:0u)|(event->qualified?2u:0u)|((unsigned)event->duid<<8);
    }
    ++o->count;
    p25_trunking_slot_observation value={.sample_tick=event->sample_tick,
        .stream_epoch=event->stream_epoch,.lane_epoch=event->lane_epoch,
        .status=event->status,.selected=event->selected,.qualified=event->qualified};
    (void)p25_trunking_slot_observe(&o->slot,&value);
    p25_trunking_slot_phase_view phase;
    if(p25_trunking_slot_phase(&o->slot,event->sample_tick,&phase))++o->coherent;
}
static void timing_frame(const p25_rx *frame,void *context) {
    timing_output *o=context;++o->frames;
    for(unsigned i=0;i<frame->frame_bytes;++i) {o->hash^=frame->frame[i];o->hash*=16777619u;}
}
unsigned p25_timing_run(const int16_t *samples,unsigned count,uint64_t origin,
    unsigned mode,unsigned change_at,uint64_t *events,unsigned capacity,unsigned stats[6]) {
    p25_demod d;p25_demod_init(&d);
    timing_output out={.events=events,.capacity=capacity,.hash=2166136261u};
    assert(p25_trunking_slot_init(&out.slot,3,300));
    for(unsigned i=0;i<count;++i) {
        if(mode==0u)p25_demod_push(&d,samples[i],timing_frame,&out);
        else {
            uint64_t tick=origin+(uint64_t)i*6u;
            uint32_t epoch=11u;
            if(mode==2u && i>=change_at)tick+=6u;
            if(mode==3u && i>=change_at)++epoch;
            if(!p25_demod_push_at(&d,samples[i],tick,epoch,timing_frame,timing_status,&out))++out.discontinuities;
        }
    }
    stats[0]=out.frames;stats[1]=out.hash;stats[2]=out.discontinuities;
    stats[3]=(unsigned)sizeof d;stats[4]=out.coherent;stats[5]=d.selected_lane;
    return out.count>out.capacity?UINT_MAX:out.count;
}

unsigned p25_timing_unit(const uint8_t *wire,unsigned length) {
    assert(length==45u);
    p25_demod d;p25_demod_init(&d);
    uint64_t records[7u*16u];timing_output out={.events=records,.capacity=16};
    assert(p25_trunking_slot_init(&out.slot,3,300));
    d.status_emit=timing_status;d.status_context=&out;d.have_input_time=true;
    d.stream_epoch=11u;d.lane_epoch=22u;d.selected_lane=0u;d.selected_nac=0x293u;
    p25_demod_lane *lane=&d.lane[0];lane->gain=1000;
    for(unsigned i=0;i<24u;++i)(void)p25_rx_push(&lane->rx,(wire[i/4u]>>(6u-2u*(i%4u)))&3u);
    const int16_t levels[4]={1000,3000,-1000,-3000};
    for(unsigned i=24u;i<180u;++i) {
        d.decision_valid=true;d.decision_tick=10000u+10u*i;
        symbol(&d,lane,levels[(wire[i/4u]>>(6u-2u*(i%4u)))&3u]);
        if(i<56u)assert(!out.count); // first status is held until NID is valid.
        if(i==56u)assert(out.count==1u && records[0]==10350u && records[4]==3u);
    }
    assert(out.count==5u && d.pending_ticks && d.selected_lane==0u);
    for(unsigned i=0;i<5u;++i) {
        assert(records[7u*i]==10350u+360u*i);
        assert(records[7u*i+1]==11u && records[7u*i+2]==22u);
        assert(records[7u*i+3]==0x293u && records[7u*i+5]==0u);
        assert((records[7u*i+6]&3u)==3u);
    }
    // Parity is a counted correction: its first status retains the original
    // sample timestamp and qualification, without granting any new RF authority.
    p25_rx_gap(&lane->rx);d.selected_qualified=false;d.first_status_pending=false;
    for(unsigned i=0;i<24u;++i)(void)p25_rx_push(&lane->rx,(wire[i/4u]>>(6u-2u*(i%4u)))&3u);
    unsigned before=out.count;
    for(unsigned i=24u;i<=56u;++i) {
        unsigned dibit=(wire[i/4u]>>(6u-2u*(i%4u)))&3u;
        if(i==56u)dibit^=1u;
        d.decision_tick=12000u+10u*i;symbol(&d,lane,levels[dibit]);
    }
    assert(out.count==before+1u && records[7u*before]==12350u && records[7u*before+4]==3u);
    assert((records[7u*before+6]&3u)==3u && lane->rx.nid_corrected==1u);
    assert(d.selected_lane==0u && !d.first_status_pending);
    // Four BCH errors plus parity remain uncorrectable under the total4
    // policy, revoking the buffered first status just as any invalid NID does.
    p25_rx_gap(&lane->rx);d.selected_qualified=false;d.first_status_pending=false;
    for(unsigned i=0;i<24u;++i)(void)p25_rx_push(&lane->rx,(wire[i/4u]>>(6u-2u*(i%4u)))&3u);
    before=out.count;
    for(unsigned i=24u;i<=56u;++i) {
        unsigned dibit=(wire[i/4u]>>(6u-2u*(i%4u)))&3u;
        if(i==24u || i==25u)dibit^=3u;
        if(i==56u)dibit^=1u;
        d.decision_tick=14000u+10u*i;symbol(&d,lane,levels[dibit]);
    }
    assert(out.count==before+1u && records[7u*before+4]==0u && !(records[7u*before+6]&2u));
    assert(d.selected_lane==UINT8_MAX && !d.first_status_pending);
    // Unqualified initial samples cannot acquire timing without a CRC-valid unit.
    p25_demod_init(&d);memset(&out,0,sizeof out);out.events=records;out.capacity=16;
    assert(p25_trunking_slot_init(&out.slot,3,300));
    assert(p25_demod_push_at(&d,0,1000,11,timing_frame,timing_status,&out));
    assert(p25_demod_push_at(&d,0,1006,11,timing_frame,timing_status,&out));
    d.clock_us=timing_profile_clock;d.hunt_clock_us=timing_profile_clock;
    assert(!p25_demod_push_at(&d,0,1018,11,timing_frame,timing_status,&out));
    assert(d.clock_us==timing_profile_clock && d.hunt_clock_us==timing_profile_clock);
    assert(p25_demod_push_at(&d,0,1024,11,timing_frame,timing_status,&out));
    assert(!p25_demod_push_at(&d,0,1030,12,timing_frame,timing_status,&out));
    assert(!p25_demod_push_at(&d,0,UINT64_MAX,12,timing_frame,timing_status,&out));
    assert(!d.have_input_time && d.selected_lane==UINT8_MAX && !out.count);
    assert(!p25_demod_push_at(NULL,0,1000,11,timing_frame,timing_status,&out));
    assert(!p25_demod_push_at(&d,0,1000,11,NULL,timing_status,&out));
    return (unsigned)sizeof d;
}
