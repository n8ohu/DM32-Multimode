// SPDX-License-Identifier: GPL-3.0-or-later
// Compare every parser state byte with the frozen pre-dispatch implementation.
#include "p25_rx.h"
#include "p25_demod.h"
#include "p25_tsdu.h"
#include <assert.h>
#include <string.h>
#include <time.h>

void boundary_old_init(p25_rx *rx);
bool boundary_old_push(p25_rx *rx,uint8_t dibit);
void boundary_old_demod_init(p25_demod *d);
bool boundary_old_demod_push_at(p25_demod *d,int16_t sample,uint64_t tick,uint32_t epoch,
    p25_demod_frame_fn emit,p25_demod_status_fn status,void *context);

static uint64_t comparisons;
static uint32_t random_state=0x258192u;
static uint32_t random_word(void) {
    random_state^=random_state<<13;random_state^=random_state>>17;
    random_state^=random_state<<5;return random_state;
}
static void compare_push(p25_rx *old,p25_rx *current,uint8_t dibit) {
    bool before=boundary_old_push(old,dibit),after=p25_rx_push(current,dibit);
    assert(before==after&&!memcmp(old,current,sizeof *old));++comparisons;
}
uint64_t boundary_check_states(void) {
    const unsigned expected[]={0,1,57,72,158,180,259,288,359,360,864,2048,65535};
    assert(p25_tsdu_block_end_symbols(0)==158u);
    assert(p25_tsdu_block_end_symbols(1)==259u);
    assert(p25_tsdu_block_end_symbols(2)==359u);
    assert(!p25_tsdu_block_end_symbols(3));
    for(unsigned duid=0;duid<16u;++duid)for(unsigned pos=0;pos<=2048u;++pos)
      for(unsigned e=0;e<=sizeof expected/sizeof *expected;++e)for(unsigned input=0;input<5u;++input) {
        p25_rx old,current;p25_rx_init(&current);
        for(unsigned j=0;j<sizeof current.frame;++j)current.frame[j]=(uint8_t)(j*73u+pos);
        current.shift=((uint64_t)random_word()<<32)|random_word();
        current.symbols=(uint16_t)pos;
        current.expected=(uint16_t)(e<sizeof expected/sizeof *expected?expected[e]:pos+1u);
        current.duid=(uint8_t)duid;current.nac=0x293u;current.frame_bytes=45u;
        current.frames=17u;current.bad_input=23u;current.bad_nid=31u;
        old=current;compare_push(&old,&current,(uint8_t)input);
      }
    return comparisons;
}
uint64_t boundary_check_stream(const uint8_t *dibits,unsigned count) {
    p25_rx old,current;boundary_old_init(&old);p25_rx_init(&current);
    assert(!memcmp(&old,&current,sizeof old));
    for(unsigned i=0;i<count;++i)compare_push(&old,&current,dibits[i]);
    return comparisons;
}
typedef struct {uint64_t hash,frames,statuses;} observations;
static observations *active;
static void hash_byte(unsigned value) {active->hash=(active->hash^value)*UINT64_C(1099511628211);}
static void frame_output(const p25_rx *frame,void *context) {
    (void)context;++active->frames;
    const unsigned char *bytes=(const unsigned char *)frame;
    for(unsigned i=0;i<sizeof *frame;++i)hash_byte(bytes[i]);
}
static void status_output(const p25_demod_status *status,void *context) {
    (void)context;++active->statuses;
    // Hash named values, not unspecified padding in the callback's temporary.
    uint64_t values[]={status->sample_tick,status->stream_epoch,status->lane_epoch,
        status->nac,status->duid,status->status,status->lane,status->selected,status->qualified};
    for(unsigned i=0;i<sizeof values/sizeof *values;++i)
        for(unsigned b=0;b<8u;++b)hash_byte((unsigned)(values[i]>>(8u*b))&255u);
}
uint64_t boundary_check_pcm(const int16_t *pcm,unsigned count,uint64_t out[2]) {
    p25_demod old,current;boundary_old_demod_init(&old);p25_demod_init(&current);
    observations a={0},b={0};
    assert(!memcmp(&old,&current,sizeof old));
    for(unsigned i=0;i<count;++i) {
        active=&a;bool before=boundary_old_demod_push_at(&old,pcm[i],(uint64_t)i*6u,1u,
            frame_output,status_output,NULL);
        active=&b;bool after=p25_demod_push_at(&current,pcm[i],(uint64_t)i*6u,1u,
            frame_output,status_output,NULL);
        assert(before==after&&!memcmp(&old,&current,sizeof old));
        assert(!memcmp(&a,&b,sizeof a));++comparisons;
    }
    out[0]=a.frames;out[1]=a.statuses;return comparisons;
}
double boundary_benchmark(const uint8_t *dibits,unsigned count,unsigned repeats,unsigned old) {
    bool (*push)(p25_rx *,uint8_t)=old?boundary_old_push:p25_rx_push;
    clock_t started=clock();unsigned frames=0;
    for(unsigned n=0;n<repeats;++n) {
        p25_rx rx;p25_rx_init(&rx);
        for(unsigned i=0;i<count;++i)frames+=(unsigned)push(&rx,dibits[i]);
    }
    // Keep the complete parsing work observable to the optimizer.
    assert(frames);return (double)(clock()-started)/CLOCKS_PER_SEC;
}
