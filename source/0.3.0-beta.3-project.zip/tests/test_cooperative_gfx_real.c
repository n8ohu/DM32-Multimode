// SPDX-License-Identifier: GPL-3.0-or-later
// The real 240x320 indexed renderer, real AA fonts and physical row model.
// Build unchanged upstream and generated core separately; compare binary output.
#include <assert.h>
#include <stdio.h>
#include <string.h>
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif
#include "ui/gfx.h"
#ifdef TEST_COOPERATIVE
#include "radio_gfx.h"
#endif
#include "p25_radio_ui.h"

enum {REAL_W=240,REAL_H=320,REAL_BYTES=REAL_W*REAL_H/2};
static color_t real_panel[REAL_H][REAL_W],real_truth[REAL_H][REAL_W];
static uint8_t real_saved[REAL_BYTES];
static color_t real_saved_palette[16];
static unsigned real_rectangles,real_snapshots,real_rows;
static int real_clip_x,real_clip_y,real_clip_w,real_clip_h;
static const color_t real_colors[]={P25_UI_BG,P25_UI_PANEL,P25_UI_LINE,P25_UI_FG,
    P25_UI_MUTED,P25_UI_CYAN,P25_UI_GREEN,P25_UI_AMBER,
    RGB565(56,68,80),RGB565(104,124,136),RGB565(88,92,96),RGB565(160,172,176)};

static void real_transfer(const void *fb,const color_t *palette,uint16_t y0,uint16_t y1)
{
    assert(fb==gfx_framebuffer()&&palette&&y0<y1&&y1<=REAL_H);
    real_rows+=y1-y0;
    for(unsigned y=y0;y<y1;++y)for(unsigned x=0;x<REAL_W;++x) {
        uint8_t value=((const uint8_t *)fb)[y*REAL_W/2u+x/2u];
        real_panel[y][x]=palette[(value>>((x&1u)?0u:4u))&15u];
    }
}
static const hal_display_t real_display={.width=REAL_W,.height=REAL_H,.bpp=4,
    .inset_left=10,.inset_right=10,.inset_top=5,.inset_bottom=5,
    .flush_indexed=real_transfer};
static void real_sync(void)
{
    gfx_flush();
#ifdef TEST_COOPERATIVE
    for(unsigned steps=0;radio_gfx_pending();++steps) {
        assert(steps<2000u);unsigned before=real_rows;
        (void)radio_gfx_step(2u,8u);assert(real_rows-before<=2u);
    }
#endif
}
static void real_setup(void)
{
    assert(gfx_init(&real_display));assert(gfx_width()==220&&gfx_height()==310);
    memset(real_panel,0xa5,sizeof real_panel);real_rows=0;
    gfx_clear(P25_UI_BG);p25_ui_palette();
    // Cover seed pixels and keep all twelve fixed solids allocated.
    gfx_fill(0,0,gfx_width(),1,P25_UI_BG);real_sync();
    for(unsigned y=0;y<REAL_H;++y)for(unsigned x=0;x<REAL_W;++x)real_truth[y][x]=P25_UI_BG;
    real_clip_x=real_clip_y=0;real_clip_w=gfx_width();real_clip_h=gfx_height();
}
static void real_check_panel(void)
{
    for(unsigned y=0;y<REAL_H;++y)for(unsigned x=0;x<REAL_W;++x) {
        uint8_t value=((const uint8_t *)gfx_framebuffer())[y*REAL_W/2u+x/2u];
        assert(real_panel[y][x]==gfx_palette((uint8_t)((value>>((x&1u)?0u:4u))&15u)));
    }
}
static void real_snapshot(void)
{
    real_sync();real_check_panel();++real_snapshots;
    // Python compares every byte, including packed indexes, all palette entries
    // and the physical RGB565 panel, against the untouched upstream executable.
    assert(fwrite(gfx_framebuffer(),1,REAL_BYTES,stdout)==REAL_BYTES);
    for(unsigned i=0;i<16u;++i) {
        color_t color=gfx_palette((uint8_t)i);assert(fwrite(&color,sizeof color,1,stdout)==1u);
    }
    assert(fwrite(real_panel,1,sizeof real_panel,stdout)==sizeof real_panel);
}
static void real_clip(int x,int y,int w,int h)
{
    gfx_clip(x,y,w,h);real_clip_x=x<0?0:x;real_clip_y=y<0?0:y;
    int end_x=x+w>gfx_width()?gfx_width():x+w,end_y=y+h>gfx_height()?gfx_height():y+h;
    real_clip_w=end_x-real_clip_x;real_clip_h=end_y-real_clip_y;
}
static void real_fill(int x,int y,int w,int h,color_t color)
{
    gfx_fill(x,y,w,h,color);++real_rectangles;
    for(int py=0;py<gfx_height();++py)for(int px=0;px<gfx_width();++px)
        if(px>=real_clip_x&&px<real_clip_x+real_clip_w&&py>=real_clip_y&&py<real_clip_y+real_clip_h
           &&px>=x&&px<x+w&&py>=y&&py<y+h)real_truth[py+5][px+10]=color;
}
static void real_check_truth_rows(unsigned y0,unsigned y1)
{
    for(unsigned y=y0;y<y1;++y)for(unsigned x=0;x<REAL_W;++x) {
        uint8_t value=((const uint8_t *)gfx_framebuffer())[y*REAL_W/2u+x/2u];
        assert(gfx_palette((uint8_t)((value>>((x&1u)?0u:4u))&15u))==real_truth[y][x]);
    }
}
static void real_edges(void)
{
    static const int clips[][4]={{0,0,220,310},{1,16,218,3},{2,16,217,3},
        {-3,16,11,3},{215,16,20,3},{30,16,0,3},{31,16,-1,3}};
    real_setup();
    // Independent RGB truth catches either adjacent nibble being overwritten.
    // Every possible safe-area width, both start/end parities, empty/negative
    // spans and panel-clipped ends are covered, on a nonzero mixed-colour row.
    for(unsigned c=0;c<sizeof clips/sizeof *clips;++c) {
        gfx_clip_off();real_clip_x=real_clip_y=0;real_clip_w=220;real_clip_h=310;
        for(int x=0;x<220;++x)real_fill(x,17,1,1,real_colors[(unsigned)x%12u]);
        real_clip(clips[c][0],clips[c][1],clips[c][2],clips[c][3]);
        for(int x=-3;x<=223;++x)for(int w=-2;w<=223;++w) {
            // Truth only needs the touched row; avoid testing the implementation
            // against a duplicate packed-byte algorithm.
            color_t color=real_colors[(unsigned)(x+w+17)%12u];
            gfx_fill(x,17,w,1,color);++real_rectangles;
            for(int px=0;px<220;++px)
                if(px>=real_clip_x&&px<real_clip_x+real_clip_w&&px>=x&&px<x+w)
                    real_truth[22][px+10]=color;
            real_check_truth_rows(21,24);
        }
        real_snapshot();
    }
    gfx_clip_off();real_clip_x=real_clip_y=0;real_clip_w=220;real_clip_h=310;
    for(unsigned i=0;i<400u;++i) {
        int x=(int)(i*53u%250u)-15,y=(int)(i*31u%340u)-15;
        int w=(int)(i*17u%80u),h=(int)(i*23u%40u);
        real_fill(x,y,w,h,real_colors[i%12u]);
    }
    real_check_truth_rows(0,REAL_H);real_snapshot();
    // Palette reuse after clear, including unchanged index zero with new RGB.
    for(unsigned i=0;i<20u;++i) {
        color_t color=(color_t)(i*3011u);gfx_clear(color);gfx_fill(3,8,213,27,(color_t)~color);
        gfx_text(&font_12x24,7,18,"Real AA 0123456789",P25_UI_FG);real_snapshot();
    }
}
static void real_view(unsigned choice,p25_ui_view *view)
{
    *view=(p25_ui_view){.battery_pct=(uint8_t)(choice*13u),.rssi_bars=(uint8_t)(choice%6u),
        .rssi_valid=true,.phase=(uint8_t)(choice%3u),.tx_nac=0x293u,.tx_group=98638u,
        .tx_source=1234567u,.rx_nac=0x2a3u,.rx_group=1000u,.rx_source=12345678u,
        .rx_group_valid=true,.rx_source_valid=true,.state="Control channel locked",
        .filter="NAC+TG",.source_name="CALLSIGN / ALPHA",.target_name="GROUP / BRAVO",
        .cc=1u,.ts=2u};
    view->rx_active=(choice&1u)!=0;view->tx_active=(choice&2u)!=0;
    view->mode_dmr=(choice&4u)!=0;view->private_call=choice==3u;
    view->emergency=choice==5u;view->rx_muted=choice==5u;
    view->trunking=choice==0u;view->unread_message=choice==6u;
    if(choice==7u){view->mode_fm=true;view->wide_fm=true;view->squelch=4u;view->tone=0x4000u|885u;}
}
static void real_ui_clipping(void)
{
    for(unsigned choice=0;choice<8u;++choice) {
        p25_ui_view view;real_view(choice,&view);real_setup();
        gfx_frame_begin();p25_ui_header(&view);p25_ui_call(&view);real_sync();
        memcpy(real_saved,gfx_framebuffer(),sizeof real_saved);
        for(unsigned i=0;i<16u;++i)real_saved_palette[i]=gfx_palette((uint8_t)i);
        real_snapshot();real_setup();
#ifdef TEST_COOPERATIVE
        radio_gfx_defer(true);
#endif
        gfx_frame_begin();
        for(int row=0;row<gfx_height();row+=4) {
            // One framebuffer, stable fixed palette. No gfx_clear is allowed
            // inside a clipped render pass because upstream clear ignores clip.
            gfx_clip(0,row,gfx_width(),4);p25_ui_header(&view);p25_ui_call(&view);
#ifdef TEST_COOPERATIVE
            gfx_flush();unsigned before=real_rows;
            (void)radio_gfx_step(2u,8u);assert(real_rows-before<=2u);
#endif
        }
        gfx_clip_off();real_sync();
        assert(!memcmp(real_saved,gfx_framebuffer(),sizeof real_saved));
        for(unsigned i=0;i<16u;++i)assert(real_saved_palette[i]==gfx_palette((uint8_t)i));
        real_snapshot();
    }
}
int main(void)
{
#ifdef _WIN32
    assert(_setmode(_fileno(stdout),_O_BINARY)!=-1);
#endif
    assert(font_6x12.bpp==2u&&font_8x16.bpp==2u&&font_12x24.bpp==2u);
    real_edges();real_ui_clipping();
    fprintf(stderr,"real indexed AA PASS: %u rectangles, %u exact snapshots\n",real_rectangles,real_snapshots);
    return 0;
}
