// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded subscriber/backend composition. No hardware, allocation or storage.
#ifndef P25_TRUNKING_BACKEND_H
#define P25_TRUNKING_BACKEND_H
#include "p25_trunking_session.h"
#include "p25_trunking_preload.h"

typedef enum {P25_TRUNK_BACKEND_OFF,P25_TRUNK_BACKEND_QUALIFIED,
    P25_TRUNK_BACKEND_EXPERIMENTAL_NOMINAL} p25_trunking_backend_mode;
typedef struct {
    p25_trunking_session_action session;
    uint8_t native_ram[P25_TRUNK_PRELOAD_RAM_BYTES];
    uint32_t image_hash;
    bool experimental_nominal;
} p25_trunking_backend_action;
typedef struct {
    uint32_t action_id,dispatch_epoch,reply_epoch,anchor_ms,anchor_serial,receive_epoch,resume_ms;
    uint64_t anchor_tick,last_anchor_used;
    uint32_t anchor_epoch,anchor_lane_epoch;
    p25_trunking_access_action_type action_type;
    p25_trunking_backend_mode mode;
    uint8_t skip_remaining;
    bool running,inflight,suspended,have_anchor,have_anchor_used,receive_suspended,reacquiring;
} p25_trunking_backend;
// Existing session/map/access storage is borrowed, never duplicated. Selecting
// nominal mode is an explicit experimental policy, not clock qualification.
bool p25_trunking_backend_start(p25_trunking_backend *b,p25_trunking_session *s,
    const p25_trunking_session_config *config,p25_trunking_backend_mode mode,uint32_t now_ms);
bool p25_trunking_backend_observe(p25_trunking_backend *b,p25_trunking_session *s,
    const p25_trunking_slot_observation *observation,uint32_t now_ms);
bool p25_trunking_backend_consume_control(p25_trunking_backend *b,p25_trunking_session *s,
    uint16_t nac,uint32_t carrier_hz,uint32_t stream_epoch,const uint8_t block[12],uint32_t now_ms);
void p25_trunking_backend_poll(p25_trunking_backend *b,p25_trunking_session *s,
    uint32_t now_ms,const p25_trunking_session_clock *clock,bool physical_tx_allowed,bool ptt_down);
// A nominal control action is a one-use experimental transport job bound to an
// actually observed coherent boundary. The platform must recheck source age,
// complete source/owner identity, permissions and projected native-clock edge
// before RF. Neither this action nor its RAM image is an idle/RF permission.
bool p25_trunking_backend_take(p25_trunking_backend *b,p25_trunking_session *s,
    p25_trunking_backend_action *out,uint32_t now_ms,const p25_trunking_session_clock *clock);
// Call before the intentional RX teardown, with the current exact action ID.
// Only this spent action may suppress session_lost during its own handoff.
bool p25_trunking_backend_suspend(p25_trunking_backend *b,const p25_trunking_session *s,uint32_t action_id);
// Separate receive-only traffic follow, permitted only from quiescent READY.
// Attachment is retained, but return requires a fresh RX epoch and fresh site
// and network metadata before another subscriber RF job can be issued.
bool p25_trunking_backend_receive_suspend(p25_trunking_backend *b,p25_trunking_session *s);
bool p25_trunking_backend_receive_resume(p25_trunking_backend *b,p25_trunking_session *s,
    uint32_t stream_epoch,uint32_t now_ms);
// Control success means RF off AND fresh control RX ready. It is separate from
// addressed OSP acceptance. VOICE_START success means RF started; STOP requires
// RF off; RETURN requires fresh control RX. IDs and receive epochs are checked.
bool p25_trunking_backend_result(p25_trunking_backend *b,p25_trunking_session *s,
    uint32_t action_id,bool success,bool rf_off,bool control_rx_ready,uint32_t stream_epoch,uint32_t now_ms);
bool p25_trunking_backend_deregister(p25_trunking_backend *b,p25_trunking_session *s,uint32_t now_ms);
bool p25_trunking_backend_select_group(p25_trunking_backend *b,p25_trunking_session *s,uint16_t group,uint32_t now_ms);
void p25_trunking_backend_cancel(p25_trunking_backend *b,p25_trunking_session *s,
    p25_trunking_access_reason reason,uint32_t now_ms);
void p25_trunking_backend_lost(p25_trunking_backend *b,p25_trunking_session *s,uint32_t now_ms);
bool p25_trunking_backend_stop(p25_trunking_backend *b,p25_trunking_session *s,bool rf_off);
#endif
