# SPDX-License-Identifier: GPL-3.0-or-later
ifndef PROJECT_ROOT
$(error PROJECT_ROOT must name the project checkout)
endif
# The normal radio excludes retained captures and experimental bench paths.
# Opt in explicitly for an engineering image: DM32_LAB_DIAGNOSTICS=1.
DM32_LAB_DIAGNOSTICS ?= 0
DM32_RF_B_EXPERIMENTAL ?= 0
DM32_OMAHA_RX_ONLY ?= 0
ifneq ($(words $(DM32_OMAHA_RX_ONLY)),1)
$(error DM32_OMAHA_RX_ONLY must be 0 or 1)
endif
ifneq ($(filter $(DM32_OMAHA_RX_ONLY),0 1),$(DM32_OMAHA_RX_ONLY))
$(error DM32_OMAHA_RX_ONLY must be 0 or 1)
endif
ifeq ($(DM32_OMAHA_RX_ONLY),1)
ifneq ($(DM32_LAB_DIAGNOSTICS):$(DM32_RF_B_EXPERIMENTAL),0:0)
$(error Omaha RX-only requires diagnostics and experimental RF-B support disabled)
endif
endif
ifneq ($(words $(DM32_RF_B_EXPERIMENTAL)),1)
$(error DM32_RF_B_EXPERIMENTAL must be 0 or 1)
endif
ifneq ($(filter $(DM32_RF_B_EXPERIMENTAL),0 1),$(DM32_RF_B_EXPERIMENTAL))
$(error DM32_RF_B_EXPERIMENTAL must be 0 or 1)
endif
ifneq ($(words $(DM32_LAB_DIAGNOSTICS)),1)
$(error DM32_LAB_DIAGNOSTICS must be 0 or 1)
endif
ifneq ($(filter $(DM32_LAB_DIAGNOSTICS),0 1),$(DM32_LAB_DIAGNOSTICS))
$(error DM32_LAB_DIAGNOSTICS must be 0 or 1)
endif
include Makefile
CFLAGS_APP += -DDM32_LAB_DIAGNOSTICS=$(DM32_LAB_DIAGNOSTICS)
CFLAGS_APP += -DDM32_RF_B_EXPERIMENTAL=$(DM32_RF_B_EXPERIMENTAL)
CFLAGS_APP += -DDM32_OMAHA_RX_ONLY=$(DM32_OMAHA_RX_ONLY)
ifneq ($(BOARD),dm32)
$(error IMBE benchmark is prepared for dm32 only)
endif
IMBE_DIR := $(PROJECT_ROOT)/research/references/nostar/imbe_vocoder
IMBE_SRC := $(filter-out $(IMBE_DIR)/imbe_vocoder.cc,$(wildcard $(IMBE_DIR)/*.cc))
IMBE_UNITY_NAMES := basicop2 math_sub aux_sub dsp_sub dc_rmv pe_lpf pitch_est pitch_ref v_uv_det qnt_sub sa_encode ch_encode encode
IMBE_SRC := $(filter-out $(addprefix $(IMBE_DIR)/,$(addsuffix .cc,$(IMBE_UNITY_NAMES))),$(IMBE_SRC))
IMBE_OBJ := $(patsubst $(IMBE_DIR)/%.cc,$(BUILD)/imbe/%.o,$(IMBE_SRC))
IMBE_OBJ += $(BUILD)/imbe/encoder_unity.o
BENCH_OBJ := $(BUILD)/imbe/bench.o $(BUILD)/imbe/app.o $(BUILD)/imbe/mic.o $(BUILD)/imbe/live_frame.o
BENCH_APP_SOURCE := dm32_imbe_bench
ifeq ($(BENCH_LIVE_RF),1)
CFLAGS_APP += -DDM32_RUNTIME_STUB_ENTRY=1
CFLAGS_APP += -DDM32_TRUNK_SUBSCRIBER=1
BENCH_APP_SOURCE := dm32_p25_live
BENCH_OBJ := $(filter-out $(BUILD)/imbe/mic.o,$(BENCH_OBJ)) $(BUILD)/imbe/live_tx.o $(BUILD)/imbe/test_tx.o $(BUILD)/imbe/rx.o
BENCH_OBJ += $(BUILD)/imbe/demod.o
ifeq ($(DM32_LAB_DIAGNOSTICS),1)
BENCH_OBJ += $(BUILD)/imbe/receive_bench.o
endif
BENCH_OBJ += $(BUILD)/imbe/call.o
BENCH_OBJ += $(BUILD)/imbe/data.o $(BUILD)/imbe/tsdu.o $(BUILD)/imbe/trunking.o
# Compile the subscriber foundation on the target too. Its normal RF dispatcher
# stays gated pending access qualification; explicit lab PTT has a separate owner.
BENCH_OBJ += $(BUILD)/imbe/trunking_isp.o $(BUILD)/imbe/trunking_access.o $(BUILD)/imbe/trunking_slot.o
BENCH_OBJ += $(BUILD)/imbe/trunking_burst.o
BENCH_OBJ += $(BUILD)/imbe/trunking_session.o
BENCH_OBJ += $(BUILD)/imbe/trunking_backend.o
BENCH_OBJ += $(BUILD)/imbe/trunking_search.o
BENCH_OBJ += $(BUILD)/imbe/rx_progress.o $(BUILD)/imbe/rx_stream.o $(BUILD)/imbe/rx_feed.o $(BUILD)/imbe/trunking_preload.o
BENCH_OBJ += $(BUILD)/imbe/trunking_lab_exchange.o $(BUILD)/imbe/trunking_lab_voice.o
BENCH_OBJ += $(BUILD)/imbe/trunking_lab_ptt.o
BENCH_OBJ += $(BUILD)/imbe/trunking_lab_attach.o
BENCH_OBJ += $(BUILD)/imbe/runtime_stub.o
LDFLAGS += -Wl,--wrap=hrc_dmr_enter -Wl,--wrap=hrc_dmr_leave
ifeq ($(DM32_OMAHA_RX_ONLY),1)
# Keep an ELF-backed proof that the generated board's irreversible TX gates
# were compiled in. This is source/link evidence, not an RF measurement.
LDFLAGS += -Wl,--undefined=dm32_omaha_tx_blocked
endif
# The normal live path does not call the optional size-report API. Retain its
# read-only class-size evidence explicitly for the post-link memory audit.
LDFLAGS += -Wl,--undefined=imbe_codec_object_bytes
# Only the unified application shares the software object with native AMBE.
# The standalone benchmark keeps its original fixed static codec allocation.
BENCH_ARENA_FLAGS := -DBENCH_SHARED_CODEC=1
MULTIMODE_DIR := $(BUILD)/multimode
MULTIMODE_GEN := $(PROJECT_ROOT)/build/generated-multimode/$(notdir $(BUILD))
MULTIMODE_OBJ := $(MULTIMODE_DIR)/radio_dmr.o $(MULTIMODE_DIR)/codec_workspace.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/vocoder.o $(MULTIMODE_DIR)/audio_pcm.o $(MULTIMODE_DIR)/dmr_glue.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/dmr_call.o $(MULTIMODE_DIR)/hrc7000_dmr.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/dmrData.o $(MULTIMODE_DIR)/dmrDataService.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/radio_microapps.o $(MULTIMODE_DIR)/same_demod.o $(MULTIMODE_DIR)/same_protocol.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/radio_applet_vm.o $(MULTIMODE_DIR)/radio_applet_store.o $(MULTIMODE_DIR)/radio_applets.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/radio_pcm_engine.o $(MULTIMODE_DIR)/radio_pcm_fm_tx.o $(MULTIMODE_DIR)/uart.o
MULTIMODE_OBJ += $(MULTIMODE_DIR)/gfx.o
# The unified controller resumes display work between receiver drains. Preserve
# the pinned source and the benchmark/baseline graphics path byte-for-byte.
OBJ := $(filter-out $(BUILD)/core/ui/gfx.o,$(OBJ))
$(MULTIMODE_GEN)/gfx.c: core/ui/gfx.c $(PROJECT_ROOT)/scripts/generate-cooperative-gfx.py
	python3 $(PROJECT_ROOT)/scripts/generate-cooperative-gfx.py $< $@
$(MULTIMODE_DIR)/gfx.o: $(MULTIMODE_GEN)/gfx.c $(PROJECT_ROOT)/src/firmware/radio_gfx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Icore/ui -I$(PROJECT_ROOT)/src/firmware -fstack-usage -Werror -c $< -o $@
OBJ := $(filter-out $(BUILD)/platform/hrc7000/vocoder.o $(BUILD)/platform/hrc7000/audio_pcm.o $(BUILD)/platform/hrc7000/dmr_glue.o,$(OBJ))
OBJ := $(filter-out $(BUILD)/core/dmr/call/dmr_call.o $(BUILD)/drivers/modem/hrc7000/hrc7000_dmr.o,$(OBJ))
OBJ := $(filter-out $(BUILD)/core/dmr/dmrData.o $(BUILD)/core/dmr/dmrDataService.o,$(OBJ))
# Only the unified live image exposes the negotiated PCM UART and native FM
# prompt route. The benchmark and feature-disabled baseline remain untouched.
OBJ := $(filter-out $(BUILD)/platform/hrc7000/uart.o $(BUILD)/boards/dm32/radio_dm32.o,$(OBJ))
ifeq ($(DM32_RF_B_EXPERIMENTAL),1)
include $(PROJECT_ROOT)/src/firmware/radiofoundry-rf-compat.mk
else
MULTIMODE_OBJ += $(MULTIMODE_DIR)/radio_dm32.o
$(MULTIMODE_GEN)/radio_dm32.c: boards/dm32/radio_dm32.c $(PROJECT_ROOT)/scripts/generate-pcm-radio.py
	python3 $(PROJECT_ROOT)/scripts/generate-pcm-radio.py $< $@
$(MULTIMODE_DIR)/radio_dm32.o: $(MULTIMODE_GEN)/radio_dm32.c $(PROJECT_ROOT)/src/firmware/radio_pcm_fm_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
endif
OBJ += $(MULTIMODE_OBJ)
$(TARGET).elf: $(MULTIMODE_OBJ)
DMR_BACKPORT_GEN := $(MULTIMODE_GEN)/dmr-backports
DMR_BACKPORT_SRC := core/dmr/call/dmr_call.c core/dmr/call/dmr_call.h drivers/modem/hrc7000/hrc7000_dmr.c
DMR_BACKPORT_PATCHES := $(wildcard $(PROJECT_ROOT)/src/firmware/radiofoundry-patches/*.patch)
$(addprefix $(DMR_BACKPORT_GEN)/,$(DMR_BACKPORT_SRC)): $(DMR_BACKPORT_GEN)/%: % $(PROJECT_ROOT)/scripts/generate-dmr-backports.py $(DMR_BACKPORT_PATCHES)
	python3 $(PROJECT_ROOT)/scripts/generate-dmr-backports.py $* $< $@
# Preserve the native object basenames, especially hrc7000_dmr.o: the linker
# selects the complete IRQ slot engine into startup-copied RAM by filename.
$(MULTIMODE_DIR)/dmr_call.o: $(DMR_BACKPORT_GEN)/core/dmr/call/dmr_call.c $(DMR_BACKPORT_GEN)/core/dmr/call/dmr_call.h
	@mkdir -p $(dir $@)
	$(CC) -I$(DMR_BACKPORT_GEN)/core $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_DIR)/hrc7000_dmr.o: $(DMR_BACKPORT_GEN)/drivers/modem/hrc7000/hrc7000_dmr.c
	@mkdir -p $(dir $@)
	$(CC) -Idrivers/modem/hrc7000 $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_GEN)/vocoder.c: platform/hrc7000/vocoder.c $(PROJECT_ROOT)/scripts/generate-shared-vocoder.py
	python3 $(PROJECT_ROOT)/scripts/generate-shared-vocoder.py $< $@
$(MULTIMODE_GEN)/audio_pcm.c: platform/hrc7000/audio_pcm.c $(PROJECT_ROOT)/scripts/generate-drained-audio.py
	python3 $(PROJECT_ROOT)/scripts/generate-drained-audio.py $< $@
$(MULTIMODE_GEN)/dmr_glue.c: platform/hrc7000/dmr_glue.c $(PROJECT_ROOT)/scripts/generate-drained-dmr.py
	python3 $(PROJECT_ROOT)/scripts/generate-drained-dmr.py $< $@
$(MULTIMODE_DIR)/vocoder.o: $(MULTIMODE_GEN)/vocoder.c $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/audio_pcm.o: $(MULTIMODE_GEN)/audio_pcm.c $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h $(PROJECT_ROOT)/src/firmware/radio_pcm_output.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
# Keep the dmr_glue.o basename: the pinned linker script places this complete
# deferred modem/IRQ host in startup-copied RAM using its filename pattern.
$(MULTIMODE_DIR)/dmr_glue.o: $(MULTIMODE_GEN)/dmr_glue.c $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_dmr.o: $(PROJECT_ROOT)/src/firmware/radio_dmr.c $(PROJECT_ROOT)/src/firmware/radio_dmr.h $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
# Keep only SMS wire formats and their link/TMS acknowledgments in the shared
# application. No registration, location, gateway, zone-share or signaling
# service can initiate traffic through this host.
DM32_DATA_OFF := DMR_ARS DMR_LRRP DMR_SIGNALING DMR_EMERGENCY DMR_IP_GATEWAY DMR_CONTROL_STATION ZONE_SHARE CRASH_REPORT
DM32_DATA_OFF += NET_PPP NET_TCP NET_KISS NET_HTTP NET_HTTP_GZIP NET_WEBCTL NET_RIGCTL NET_APRSIS NET_USRP MDNS TFTP TFTP_IDDB SNMP
DM32_DATA_ON := DMR_DATA_CORE DMR_SMS DMR_TMS DMR_CONFIRMED DMR_UDP_COMPRESS
DM32_DATA_FLAGS := $(foreach opt,$(DM32_DATA_OFF),-UCONFIG_$(opt) -DCONFIG_$(opt)=0) $(foreach opt,$(DM32_DATA_ON),-UCONFIG_$(opt) -DCONFIG_$(opt)=1)
$(MULTIMODE_GEN)/dmrDataService.c: core/dmr/dmrDataService.c $(PROJECT_ROOT)/scripts/generate-dmr-message-service.py
	python3 $(PROJECT_ROOT)/scripts/generate-dmr-message-service.py $< $@
$(MULTIMODE_DIR)/dmrDataService.o: $(MULTIMODE_GEN)/dmrDataService.c
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) $(DM32_DATA_FLAGS) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_DIR)/dmrData.o: core/dmr/dmrData.c
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) $(DM32_DATA_FLAGS) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_DIR)/codec_workspace.o: $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.c $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_microapps.o: $(PROJECT_ROOT)/src/firmware/radio_microapps.c $(PROJECT_ROOT)/src/firmware/radio_microapps.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/same_demod.o: $(PROJECT_ROOT)/src/firmware/same_demod.c $(PROJECT_ROOT)/src/firmware/same_demod.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/same_protocol.o: $(PROJECT_ROOT)/src/firmware/same_protocol.c $(PROJECT_ROOT)/src/firmware/same_protocol.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_applet_vm.o: $(PROJECT_ROOT)/src/firmware/radio_applet_vm.c $(PROJECT_ROOT)/src/firmware/radio_applet_vm.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_applet_store.o: $(PROJECT_ROOT)/src/firmware/radio_applet_store.c $(PROJECT_ROOT)/src/firmware/radio_applet_store.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_applets.o: $(PROJECT_ROOT)/src/firmware/radio_applets.c $(addprefix $(PROJECT_ROOT)/src/firmware/,radio_applets.h radio_applet_vm.h radio_applet_store.h)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_pcm_engine.o: $(PROJECT_ROOT)/src/firmware/radio_pcm_engine.c $(PROJECT_ROOT)/src/firmware/radio_pcm_engine.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_DIR)/radio_pcm_fm_tx.o: $(PROJECT_ROOT)/src/firmware/radio_pcm_fm_tx.c $(PROJECT_ROOT)/src/firmware/radio_pcm_fm_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(MULTIMODE_GEN)/uart.c: platform/hrc7000/uart.c $(PROJECT_ROOT)/scripts/generate-pcm-uart.py
	python3 $(PROJECT_ROOT)/scripts/generate-pcm-uart.py $< $@
$(MULTIMODE_DIR)/uart.o: $(MULTIMODE_GEN)/uart.c $(PROJECT_ROOT)/src/firmware/radio_pcm_uart.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
endif
OBJ += $(IMBE_OBJ) $(BENCH_OBJ)
LDFLAGS += -Wl,--wrap=app_start -Wl,--wrap=hrc_dmr_board_init
# Only the codec changes optimization level; HAL, RTOS and the measuring app
# retain the baseline flags. Preserve integer semantics and avoid fast-math.
IMBE_OPT ?= -O3
IMBE_PROFILE_FLAGS := -DIMBE_PITCH_SPECIALIZE=1 -DBENCH_MICROPHONE=1 -I$(abspath $(BUILD)/imbe)
# Encoder stage callbacks are only useful for the standalone/lab benchmark.
ifneq ($(BENCH_LIVE_RF):$(DM32_LAB_DIAGNOSTICS),1:0)
IMBE_PROFILE_FLAGS += -DIMBE_STAGE_PROFILE=1
endif
DIAGNOSTICS_PROFILE_STAMP := $(BUILD)/dm32-diagnostics-profile
$(shell mkdir -p $(BUILD); printf '%s\n' '$(BENCH_LIVE_RF):$(DM32_LAB_DIAGNOSTICS):$(DM32_RF_B_EXPERIMENTAL):$(DM32_OMAHA_RX_ONLY)' | cmp -s - $(DIAGNOSTICS_PROFILE_STAMP) || printf '%s\n' '$(BENCH_LIVE_RF):$(DM32_LAB_DIAGNOSTICS):$(DM32_RF_B_EXPERIMENTAL):$(DM32_OMAHA_RX_ONLY)' > $(DIAGNOSTICS_PROFILE_STAMP))
$(OBJ) $(IMBE_OBJ) $(BENCH_OBJ) $(MULTIMODE_OBJ): $(DIAGNOSTICS_PROFILE_STAMP)
BENCH_CXXFLAGS := -DDM32_LAB_DIAGNOSTICS=$(DM32_LAB_DIAGNOSTICS) $(filter-out -Os -O0 -O1 -O2 -O3 -Og -Ofast,$(COMMON)) $(IMBE_OPT) -std=gnu++17 -fwrapv -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-use-cxa-atexit -fstack-usage -nostdinc++ -I$(PROJECT_ROOT)/src/firmware/freestanding-cxx -I$(IMBE_DIR) -I$(PROJECT_ROOT)/src/firmware
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/p25_preferences.h $(PROJECT_ROOT)/src/firmware/p25_channel_store.h $(PROJECT_ROOT)/src/firmware/radio_channel.h $(PROJECT_ROOT)/src/firmware/p25_fm.h $(PROJECT_ROOT)/src/firmware/radio_ux.h $(PROJECT_ROOT)/src/firmware/p25_radio_features.h $(PROJECT_ROOT)/src/firmware/radio_dmr.h $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h $(PROJECT_ROOT)/src/firmware/radio_service_schedule.h $(PROJECT_ROOT)/src/firmware/radio_dmr_metrics.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_signal_meter.h $(PROJECT_ROOT)/src/firmware/p25_diagnostics.h $(PROJECT_ROOT)/src/firmware/p25_pcm_trace.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/p25_stub_entry.h $(PROJECT_ROOT)/src/firmware/p25_runtime_update.h
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_live.h p25_trunking_session.h p25_trunking_slot.h p25_trunking_backend.h p25_trunking_subscriber_live.h p25_trunking_search.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_pcm_applet.h radio_pcm_engine.h radio_pcm_fm_tx.h radio_pcm_uart.h)
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_functions.h $(PROJECT_ROOT)/src/firmware/radio_broadcast.h $(PROJECT_ROOT)/src/firmware/radio_tx_guard.h $(PROJECT_ROOT)/src/firmware/imbe_mic_queue.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_broadcast_input.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_airband.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/dm32_rf_compat.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/dm32_omaha_rx_only.h
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,radio_microapps.h radio_app_audio.h same_demod.h same_protocol.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,radio_applets.h radio_applet_vm.h radio_applet_store.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,radio_pcm_engine.h radio_pcm_fm_tx.h radio_pcm_uart.h)
$(TARGET).elf: $(IMBE_OBJ) $(BENCH_OBJ)
$(BUILD)/imbe/imbe_encode_profile.cc: $(IMBE_DIR)/encode.cc $(PROJECT_ROOT)/scripts/generate-imbe-profile.py
	python3 $(PROJECT_ROOT)/scripts/generate-imbe-profile.py $< $@
$(BUILD)/imbe/imbe_pitch_specialized.cc: $(IMBE_DIR)/pitch_est.cc $(PROJECT_ROOT)/scripts/generate-imbe-pitch.py
	python3 $(PROJECT_ROOT)/scripts/generate-imbe-pitch.py $< $@
$(BUILD)/imbe/encoder_unity.o: $(PROJECT_ROOT)/src/firmware/imbe_encoder_unity.cpp $(addprefix $(IMBE_DIR)/,$(addsuffix .cc,$(IMBE_UNITY_NAMES))) $(BUILD)/imbe/imbe_encode_profile.cc $(BUILD)/imbe/imbe_pitch_specialized.cc
	@mkdir -p $(dir $@)
	$(CROSS)g++ $(BENCH_CXXFLAGS) $(IMBE_PROFILE_FLAGS) -c $< -o $@
$(BUILD)/imbe/%.o: $(IMBE_DIR)/%.cc
	@mkdir -p $(dir $@)
	$(CROSS)g++ $(BENCH_CXXFLAGS) -c $< -o $@
$(BUILD)/imbe/bench.o: $(PROJECT_ROOT)/src/firmware/imbe_bench.cpp $(PROJECT_ROOT)/src/firmware/imbe_bench.h $(PROJECT_ROOT)/src/firmware/radio_codec_workspace.h
	@mkdir -p $(dir $@)
	$(CROSS)g++ $(BENCH_CXXFLAGS) $(BENCH_ARENA_FLAGS) -Wall -Wextra -Werror -c $< -o $@
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/$(BENCH_APP_SOURCE).c $(PROJECT_ROOT)/src/firmware/imbe_bench.h $(PROJECT_ROOT)/src/firmware/imbe_stream.h $(PROJECT_ROOT)/src/firmware/radio_control.h $(PROJECT_ROOT)/src/firmware/rx_capture.h $(PROJECT_ROOT)/src/firmware/p25_monitor.h $(PROJECT_ROOT)/src/firmware/p25_call.h $(PROJECT_ROOT)/src/firmware/p25_receive_policy.h $(PROJECT_ROOT)/src/firmware/p25_voice_policy.h $(PROJECT_ROOT)/src/firmware/p25_radio_ui.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) $(IMBE_PROFILE_FLAGS) -Werror -DBENCH_CLOCK_REGISTERS=1 -DBENCH_GIT=\"$(shell git -C $(PROJECT_ROOT) rev-parse --short HEAD)\" -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/runtime_stub.o: $(PROJECT_ROOT)/src/firmware/p25_stub_entry.c $(PROJECT_ROOT)/src/firmware/p25_stub_entry.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/mic.o: $(PROJECT_ROOT)/src/firmware/dm32_imbe_mic.c $(PROJECT_ROOT)/src/firmware/imbe_mic.h $(PROJECT_ROOT)/src/firmware/imbe_mic_queue.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -DBENCH_GIT=\"$(shell git -C $(PROJECT_ROOT) rev-parse --short HEAD)\" -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/live_frame.o: $(PROJECT_ROOT)/src/firmware/p25_live_frame.c $(PROJECT_ROOT)/src/firmware/p25_live_frame.h $(PROJECT_ROOT)/src/firmware/p25_interleave.h $(PROJECT_ROOT)/src/firmware/p25_channel_masks.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@
$(BUILD)/imbe/live_tx.o: $(PROJECT_ROOT)/src/firmware/p25_live_tx.c $(PROJECT_ROOT)/src/firmware/p25_live_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@
$(BUILD)/imbe/test_tx.o: $(PROJECT_ROOT)/src/firmware/p25_test_tx.c $(PROJECT_ROOT)/src/firmware/p25_test_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -Werror -I$(PROJECT_ROOT)/src/firmware -I$(PROJECT_ROOT)/fixtures/p25-1011 -c $< -o $@

RX_CFLAGS := $(filter-out -Os -O0 -O1 -O2 -O3 -Og -Ofast,$(CFLAGS_APP)) -O3 -fstack-usage

# Audit-only reference object: never added to BENCH_OBJ or the linked image.
# Use exactly the production demodulator flags to compare generated arithmetic.
.PHONY: demod-cost-audit
demod-cost-audit: $(BUILD)/imbe/demod-reference.o $(BUILD)/imbe/demod.o
$(BUILD)/imbe/demod-reference.o: $(PROJECT_ROOT)/tests/fixtures/p25-demod-7d38b96/p25_demod.c $(PROJECT_ROOT)/tests/fixtures/p25-demod-7d38b96/p25_demod_math.h $(PROJECT_ROOT)/src/firmware/p25_demod.h $(PROJECT_ROOT)/src/firmware/p25_demod_filter.h
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

$(BUILD)/imbe/rx.o: $(PROJECT_ROOT)/src/firmware/p25_rx.c $(PROJECT_ROOT)/src/firmware/p25_rx.h $(PROJECT_ROOT)/src/firmware/p25_rx_golay.h
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

P25_DATA_HEADERS := $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_data.h p25_data_fec.h p25_rx.h)
P25_DATA_HEADERS += $(PROJECT_ROOT)/src/firmware/p25_tsdu.h
$(BUILD)/imbe/rx.o $(BUILD)/imbe/demod.o $(BUILD)/imbe/receive_bench.o $(BUILD)/imbe/app.o: $(P25_DATA_HEADERS)
$(BUILD)/imbe/app.o: $(wildcard $(PROJECT_ROOT)/src/firmware/p25_message*.h) $(PROJECT_ROOT)/src/firmware/radio_messages.h $(PROJECT_ROOT)/src/firmware/radio_message_input.h
$(BUILD)/imbe/app.o: $(PROJECT_ROOT)/src/firmware/radio_call_services.h $(PROJECT_ROOT)/src/firmware/p25_live_tx.h $(PROJECT_ROOT)/src/firmware/p25_trunking.h $(PROJECT_ROOT)/src/firmware/p25_trunking_probe.h $(PROJECT_ROOT)/src/firmware/p25_trunking_isp.h $(PROJECT_ROOT)/src/firmware/p25_trunking_burst.h $(PROJECT_ROOT)/src/firmware/p25_telemetry.h
$(BUILD)/imbe/data.o: $(PROJECT_ROOT)/src/firmware/p25_data.c $(P25_DATA_HEADERS)
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

$(BUILD)/imbe/tsdu.o: $(PROJECT_ROOT)/src/firmware/p25_tsdu.c $(P25_DATA_HEADERS)
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking.o: $(PROJECT_ROOT)/src/firmware/p25_trunking.c $(PROJECT_ROOT)/src/firmware/p25_trunking.h $(P25_DATA_HEADERS)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_isp.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_isp.c $(PROJECT_ROOT)/src/firmware/p25_trunking_isp.h $(P25_DATA_HEADERS)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_access.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_access.c $(PROJECT_ROOT)/src/firmware/p25_trunking_access.h $(PROJECT_ROOT)/src/firmware/p25_trunking_isp.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_slot.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_slot.c $(PROJECT_ROOT)/src/firmware/p25_trunking_slot.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_session.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_session.c $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_session.h p25_trunking_access.h p25_trunking_slot.h p25_trunking.h p25_trunking_isp.h p25_tsdu.h)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_backend.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_backend.c $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_backend.h p25_trunking_session.h p25_trunking_access.h p25_trunking_slot.h p25_trunking_preload.h)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_search.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_search.c $(PROJECT_ROOT)/src/firmware/p25_trunking_search.h $(PROJECT_ROOT)/src/firmware/p25_trunking.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_burst.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_burst.c $(PROJECT_ROOT)/src/firmware/p25_trunking_burst.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

$(BUILD)/imbe/rx_progress.o: $(PROJECT_ROOT)/src/firmware/p25_rx_progress.c $(PROJECT_ROOT)/src/firmware/p25_rx_progress.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_preload.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_preload.c $(PROJECT_ROOT)/src/firmware/p25_trunking_preload.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_lab_exchange.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_lab_exchange.c $(PROJECT_ROOT)/src/firmware/p25_trunking_lab_exchange.h $(PROJECT_ROOT)/src/firmware/p25_trunking_isp.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_lab_voice.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_lab_voice.c $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_lab_voice.h p25_trunking_lab_exchange.h p25_trunking_lab.h)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_lab_ptt.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_lab_ptt.c $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_lab_ptt.h p25_trunking_lab_voice.h p25_trunking_lab_exchange.h p25_trunking_lab.h p25_trunking_isp.h)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/trunking_lab_attach.o: $(PROJECT_ROOT)/src/firmware/p25_trunking_lab_attach.c $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_lab_attach.h p25_trunking_lab_voice.h p25_trunking_lab_exchange.h p25_trunking_lab.h p25_trunking_isp.h)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/rx_stream.o: $(PROJECT_ROOT)/src/firmware/p25_rx_stream.c $(PROJECT_ROOT)/src/firmware/p25_rx_stream.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/rx_feed.o: $(PROJECT_ROOT)/src/firmware/p25_rx_feed.c $(PROJECT_ROOT)/src/firmware/p25_rx_feed.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_rx_progress_live.h p25_rx_progress.h p25_rx_stream_live.h p25_rx_stream.h p25_trunking_preload_live.h p25_trunking_preload.h p25_trunking_lab_exchange_live.h p25_trunking_lab_exchange.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_rx_feed_live.h p25_rx_feed.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_lab_voice_live.h p25_trunking_lab_voice.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_lab_ptt_live.h p25_trunking_lab_ptt.h)
$(BUILD)/imbe/app.o: $(addprefix $(PROJECT_ROOT)/src/firmware/,p25_trunking_lab_attach_live.h p25_trunking_lab_attach.h)

$(BUILD)/imbe/call.o: $(PROJECT_ROOT)/src/firmware/p25_call.c $(PROJECT_ROOT)/src/firmware/p25_call.h
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@

$(BUILD)/imbe/demod.o: $(PROJECT_ROOT)/src/firmware/p25_demod.c $(PROJECT_ROOT)/src/firmware/p25_demod.h $(PROJECT_ROOT)/src/firmware/p25_demod_filter.h $(PROJECT_ROOT)/src/firmware/p25_demod_math.h $(PROJECT_ROOT)/scripts/place-p25-demod-ram.py
	@mkdir -p $(dir $@)
	$(CC) $(RX_CFLAGS) -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
ifeq ($(BENCH_LIVE_RF),1)
	python3 $(PROJECT_ROOT)/scripts/place-p25-demod-ram.py $(OBJCOPY) $@
endif
$(BUILD)/imbe/receive_bench.o: $(PROJECT_ROOT)/src/firmware/p25_receive_bench.c $(PROJECT_ROOT)/src/firmware/p25_receive_bench.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -I$(PROJECT_ROOT)/src/firmware -c $< -o $@
