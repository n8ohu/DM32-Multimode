// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded Phase 1 trunking signaling; raw blocks carry no voice authorization.
#ifndef P25_TSDU_H
#define P25_TSDU_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define P25_TSDU_MAX_BLOCKS 3u
#define P25_TSDU_BLOCK_BYTES 12u
#define P25_TSDU_MAX_FRAME_BYTES 90u
typedef struct {
    uint16_t nac;
    uint8_t count;
    // Byte 0: last/protected/opcode; byte 1: MFID; bytes 2..9: argument.
    // CRC is retained in bytes 10..11. Consumers must qualify format/MFID.
    uint8_t block[P25_TSDU_MAX_BLOCKS][P25_TSDU_BLOCK_BYTES];
} p25_tsdu;

// Number of physical dibits through a complete trellis block, before padding.
static inline unsigned p25_tsdu_block_end_symbols(unsigned index) {
    if(index>=P25_TSDU_MAX_BLOCKS)return 0;
    unsigned last=56u+(index+1u)*98u-1u;
    return last+last/35u+1u;
}
// TSDU ends on a 36-dibit microslot, including its final status symbol.
static inline unsigned p25_tsdu_frame_symbols(unsigned count) {
    if(!count || count>P25_TSDU_MAX_BLOCKS)return 0;
    return ((56u+count*98u+34u)/35u)*36u;
}
// Decode only the indicated trellis block and validate its CRC. Useful while
// framing; no sync/NID or last-block assertion is made by this helper.
// Both APIs leave outputs unchanged on failure and require no allocation.
bool p25_tsdu_decode_block(const uint8_t *frame,size_t bytes,unsigned index,
                          uint8_t out[P25_TSDU_BLOCK_BYTES]);
// Accept exactly one complete 1..3-block TSDU: conservative BCH/parity-valid
// NID, all block CRCs, final last-block flag, and exact padded wire length.
bool p25_tsdu_decode(const uint8_t *frame,size_t bytes,p25_tsdu *out);
// Encode already CRC-qualified blocks, requiring LB only on the final block.
// This produces padded CAI bytes (45/72/90), with explicit status dibits 0..3.
// It is not an RF burst scheduler or evidence of ISP slot conformance. No
// preamble/PA timing is included. Zero means failure; output stays unchanged.
size_t p25_tsdu_encode(uint8_t *out,size_t capacity,uint16_t nac,
                      const uint8_t blocks[][P25_TSDU_BLOCK_BYTES],unsigned count,
                      uint8_t status);
#endif
