// SPDX-License-Identifier: GPL-3.0-or-later
// Unified P25, DMR and analog FM. Versioned settings in the designated data-flash ring.
#include "p25_live_tx.h"
#include "p25_live_frame.h"
#include "p25_rx.h"
#include "p25_data.h"
#include "p25_tsdu.h"
#include "p25_trunking.h"
#include "p25_receive_bench.h"
#include "p25_monitor.h"
#include "p25_test_tone.h"
#include "radio_control.h"
#include "rx_capture.h"
#define MIC_FRAMES LIVE_CAPTURE_FRAMES
#include "imbe_mic_queue.h"
#include "imbe_bench.h"
#include "board.h"
#include "hal_time.h"
#include "p25_preferences.h"
#include "p25_channel_store.h"
#include "p25_fm.h"
#include "radio_tx_guard.h"
#include "radio_broadcast.h"
#include "radio_broadcast_input.h"
#include "radio_airband.h"
#include "radio_channel.h"
#include "radio_call_services.h"
#include "radio_messages.h"
#include "radio_message_input.h"
#include "radio_microapps.h"
#include "radio_applets.h"
#include "radio_app_audio.h"
#include "radio_pcm_engine.h"
#include "radio_pcm_fm_tx.h"
#include "radio_pcm_uart.h"
#include "same_demod.h"
#include "same_protocol.h"
#include "radio_dmr.h"
#include "dm32_rf_compat.h"
#include "dmr/ambe/ambeVoice.h"
#include "radio_dmr_metrics.h"
#include "radio_service_schedule.h"
#include "radio_signal_meter.h"
#include "radio_codec_workspace.h"
#include "radio_ux.h"
#include "platform.h"
#include "pins.h"
#include "audio_pcm.h"
#include "dmr_glue.h"
#include "cal/baofeng/baofeng_cal.h"
#include "ui/gfx.h"
#include "radio_gfx.h"
#include "p25_radio_ui.h"
#include "FreeRTOS.h"
#include "task.h"
#include "config.h"
#ifndef DM32_RUNTIME_STUB_ENTRY
#define DM32_RUNTIME_STUB_ENTRY 0
#endif
#ifndef DM32_TRUNK_SUBSCRIBER
#define DM32_TRUNK_SUBSCRIBER 0
#endif
#include "dm32_omaha_rx_only.h"
#if DM32_TRUNK_SUBSCRIBER
#include "p25_trunking_session.h"
#include "p25_trunking_backend.h"
#include "p25_trunking_search.h"
#endif
#if DM32_RUNTIME_STUB_ENTRY
#include "p25_stub_entry.h"
#endif
#include "app/watchdog.h"
#if CONFIG_CRASH_LOG
#include "crash/crash.h"
#endif
#include <stdio.h>
#include <stdlib.h>

#define PHY_READY (1u<<12)
#define ARM_US 30000000u
#define HARD_TIMER 6
#define SPEAKER_TIMER 4 // Exclusive to this overlay; APRS TX is not started here.
_Static_assert((uint64_t)RADIO_TX_GUARD_PERIOD_US*(HRC_APB_HZ/1000000u)<=UINT32_MAX,
               "RF watchdog exceeds hardware timer range");
static hrc7000_t *dev;
static const hrc_dmr_board_t *hooks;
static p25_live_tx live;
static radio_tx_guard hard_guard;
static radio_broadcast broadcast;
static bool broadcast_show;
static radio_airband airband;
static bool airband_show;
static uint32_t airband_hz=RADIO_AIRBAND_DEFAULT_HZ;
static uint32_t airband_step_hz=RADIO_AIRBAND_STEP_25K,airband_due;
static unsigned airband_squelch=5;
static volatile bool call_tot_expired;
static uint32_t broadcast_due,call_soft_limit_us;
static unsigned call_capture_frames;
static imbe_mic_queue pcmq;
static uint8_t payload[9][11];
static unsigned encoded, target, max_encode, max_pack;
static uint32_t arm_until, ptt_mask, capture_started, last_pcm;
static uint32_t driver_loss, payload_hash, saved_rf_mode;
static uint32_t pcm_mode, pcm_audio, rf_audio;
static radio_control control={.nac=0x293,.talkgroup=1,.source_id=1};
static radio_dmr digital_dmr;
static bool message_packet_tx;
static volatile bool native_irq_owned;
static volatile bool dmr_hard_timeout;
static uint32_t dmr_ui_serial,dmr_ui_due;
static bool dmr_ui_pending;
static radio_dmr_cost_t dmr_ui_cost;
static uint32_t power_sample_us;
static uint32_t ui_display_steps,ui_display_max_us;
static uint32_t native_sys_irq_mask;
extern void __real_hrc_dmr_board_init(hrc7000_t *,const hrc_dmr_board_t *);
extern void __real_hrc_dmr_enter(void),__real_hrc_dmr_leave(void);
extern bool hrc_vocoder_resume(void),hrc_vocoder_quiesce(void);
static p25_channel_frames call_frames;
// Volatile diagnostics; boot and TXSOURCE MIC restore normal speech alignment.
#if DM32_LAB_DIAGNOSTICS
static bool tx_fixed;
static unsigned tx_pairs=14, tx_startup_extra;
#else
static const bool tx_fixed=false;
static const unsigned tx_pairs=14,tx_startup_extra=0;
#endif
// Hardware-validated defaults; diagnostic alternatives never grant RF permission.
typedef enum { TX_WRITER_DUP, TX_WRITER_ALT0, TX_WRITER_ALT1 } tx_writer_mode;
#if DM32_LAB_DIAGNOSTICS
static tx_writer_mode tx_writer=TX_WRITER_ALT1;
#else
static const tx_writer_mode tx_writer=TX_WRITER_ALT1;
#endif
static uint8_t tx_write_half;
#if DM32_LAB_DIAGNOSTICS
static bool tx_dac_restore=true;
#else
static const bool tx_dac_restore=true;
#endif
enum { TX_DAC_BEFORE_TX=1u, TX_DAC_AFTER_STOP=2u, TX_DAC_PRE_RF=4u, TX_DAC_PA=8u, TX_DAC_END=16u, TX_DAC_PREPARED=32u };
static volatile struct {
    uint32_t before_tx,prepared,after_stop,pre_rf,pa,end,seen;
} tx_dac;
static const char *tx_writer_name(void) {
    return tx_writer==TX_WRITER_ALT0 ? "ALT0" : tx_writer==TX_WRITER_ALT1 ? "ALT1" : "DUP";
}
static p25_pref_store pref_store;
static p25_preferences pref_saved;
static unsigned mic_gain_db=11;
// Owner permission is persistent; diagnostic sessions and STOP are temporary.
static bool owner_tx_inhibit,rx_promiscuous,normal_mode,ptt_release_required;
#if DM32_TRUNK_SUBSCRIBER
// A system is a temporary radio profile. Never capture it into the selected
// conventional memory or overwrite the owner's global radio ID.
static bool trunk_system_overlay_owned,trunk_system_overlay_staging;
static struct {
    radio_control control;
    uint8_t channel[32];
    bool promiscuous,tg_filter;
} trunk_system_saved;
static char trunk_system_name[13];
static p25_trunking_search trunk_search;
static bool trunk_system_subscriber,trunk_system_logout_requested,trunk_system_logout_keys_released;
static bool trunk_system_search_revoked;
static uint8_t trunk_system_idle_recoveries;
static uint32_t trunk_system_logout_deadline;
#endif
static bool trunk_system_boot_checked;
#if DM32_TRUNK_SUBSCRIBER
static struct {
    uint32_t due_us,started_us,revision;
    uint8_t index,attempts,selection;
    bool pending;
} passive_receive_recovery;
#if DM32_OMAHA_RX_ONLY
// Existing dedicated-profile adapter cases use the original private name.
#define omaha_receive_recovery passive_receive_recovery
#endif
#endif
static bool ptt_release_seen;
static uint32_t ptt_release_since;
static bool pref_dirty;
static const char *pref_state="not_loaded";
static p25_preferences pref_current(void) {
    p25_preferences p={control.frequency,control.tx_frequency,control.nac,control.talkgroup,control.source_id,control.split,mic_gain_db,owner_tx_inhibit,rx_promiscuous};return p;
}
static void preferences_restore(void);
static void preferences_poll(bool down);

#define frequency control.frequency
static bool session_enabled,armed, audio_on, prepared, display_ok;
static volatile bool call_active, hardware_running, pa_started;
static const char *reason="idle";
static char command[120];
static size_t command_used;
static bool command_overflow;
static bool editing, rx_lab, rx_checked, rx_pass;
static bool menu_open;
typedef enum {MENU_ROOT,MENU_CHANNEL,MENU_VOICE,MENU_DIAGNOSTICS,MENU_MEMORY,MENU_SCAN,MENU_DISPLAY,MENU_FM,MENU_DMR,MENU_TRANSMIT,MENU_FUNCTIONS,MENU_AUDIO_TX,MENU_SETTINGS,MENU_TOOLS,MENU_RECEIVERS,MENU_HISTORY,MENU_HEARD_CALL,MENU_MESSAGES,MENU_MESSAGE_LIST,MENU_MESSAGE_VIEW,MENU_MESSAGE_COMPOSE,MENU_APPLETS,MENU_SAME_CHANNELS,MENU_TRUNK,MENU_TRUNK_SYSTEMS,MENU_TRUNK_ACTIVE} ui_menu;
static ui_menu menu_page;
static unsigned menu_item;
static radio_call_history heard_calls;
static uint8_t call_contacts[RADIO_CONTACT_CAPACITY][32];
static char ui_source_name[25],ui_target_name[25];
static uint32_t dmr_history_start;
static bool dmr_history_active;
static unsigned heard_selection;
static bool edit_from_menu,diag_from_menu;
typedef enum { EDIT_RX, EDIT_TX, EDIT_NAC, EDIT_TG, EDIT_ID, EDIT_MIC, EDIT_MEMORY, EDIT_SCREEN, EDIT_LIGHT, EDIT_TXTONE, EDIT_RXTONE, EDIT_RECALL, EDIT_SQL, EDIT_DMR_CC, EDIT_TOT, EDIT_BCAST, EDIT_AIRBAND, EDIT_TRUNK_TG } edit_field;
static edit_field field;
static const char *field_names[]={"RX frequency","TX frequency","NAC code","Destination ID","Radio ID","Digital mic gain","Save channel","Screen timeout","Keypad light","TX tone code","RX tone code","Select channel","FM squelch","DMR color code","TX timeout","Broadcast FM","Airband AM","System talkgroup"};
static unsigned field_digits(void);
static char frequency_digits[9];
static char scan_received_label[16];
static unsigned digit_count;
static uint32_t key_candidate, key_stable, key_changed_at;
// DMR borrows the idle P25 receive/capture storage; IMBE keeps its own small
// state while this union is in active use by P25. No queues or captures shrink.
typedef struct {
    radio_app_audio audio;
    same_demod demod;
    same_protocol protocol;
    uint8_t serial[2048];
    uint16_t serial_head,serial_tail;
    uint32_t serial_dropped;
    bool serial_partial;
    int16_t pcm_frame[160];
    unsigned pcm_position;
} same_receiver;
_Static_assert(sizeof(same_receiver)<=sizeof(p25_monitor),"SAME must fit the existing receive window");
static union { rx_capture capture; p25_monitor monitor; same_receiver same; } rx_storage __attribute__((aligned(8)));
#define rxcap rx_storage.capture
#define monitor rx_storage.monitor
#define same_rx rx_storage.same
static radio_microapps_t microapps;
static radio_applets applets;
static bool applet_owns_radio,applet_display_pending,applet_saved_watch;
static char applet_display[96];
static uint32_t applet_display_due,applet_keys;
static volatile bool same_running;
static radio_pcm_engine pcm_engine;
static radio_pcm_fm_tx pcm_fm;
static bool pcm_owner,pcm_binary,pcm_backend_started;
static volatile bool pcm_raw_capture;
static uint32_t pcm_baud_due,pcm_source_due,pcm_close_due,pcm_hz,pcm_session;
static uint8_t pcm_saved_channel[32];
static bool pcm_saved_audio;
static audio_block_cb_t pcm_dmr_callback;
static void *pcm_dmr_context;
static bool same_resume_on_stop=true;
static bool same_return_rx_enabled;
static uint32_t same_clock_us,same_clock_ms,same_clock_carry,same_samples;
static volatile uint32_t same_last_pcm_us;
static bool same_ui_pending;
#if DM32_LAB_DIAGNOSTICS
_Static_assert(sizeof(p25_monitor)<=sizeof(rx_capture),"Monitor must reuse capture budget");
#endif
_Static_assert(sizeof(rx_storage)>=RADIO_CODEC_WORKSPACE_BYTES,"DMR window exceeds receive storage");
#if DM32_LAB_DIAGNOSTICS
_Static_assert(offsetof(rx_capture,count)>=RADIO_CODEC_WORKSPACE_BYTES,"DMR window overwrites capture metadata");
#endif
static bool mon_enabled,mon_used;
#if DM32_LAB_DIAGNOSTICS
static bool mon_local_tone,mon_output_tone,mon_replay;
#else
static const bool mon_local_tone=false,mon_output_tone=false,mon_replay=false;
#endif
static unsigned mon_tone_hz=1000;
static uint32_t mon_tone_phase;
static unsigned mon_fifo_limit=8; // Preserve the measured baseline until A/B tested.
static unsigned mon_service_ms=2;
static unsigned mon_timer_us=500; // Current measured baseline; runtime alternatives remain available.
#if DM32_LAB_DIAGNOSTICS
static bool mon_pcm_backend=true;
#else
static const bool mon_pcm_backend=true;
#endif // Validated PCM_RD output; FIFO is diagnostic-only.
static volatile bool mon_pcm_pending;
static volatile uint32_t mon_pcm_submitted,mon_pcm_consumed,mon_pcm_irqs,mon_pcm_last,mon_pcm_gap;
#ifndef P25_SPEAKER_PCM_WINDOW
#define P25_SPEAKER_PCM_WINDOW ((volatile uint8_t *)C7_PCM_SPK_ADDR)
#endif
static void mon_pcm_disable(void);
static volatile uint32_t mon_timer_ticks;
static uint32_t mon_notify_max;
static uint32_t mon_hdu,mon_ldu1,mon_ldu2,mon_tdu;
static uint32_t mon_step_max_us,mon_step_total_us,mon_step_calls;
#if DM32_LAB_DIAGNOSTICS
static unsigned mon_perf_index;
// Playback-relative seconds 0..30; bin 31 includes all later activity.
typedef struct {uint32_t pushes,full,max_gap,max_service,empty,route_missing;} mon_perf_bin;
static mon_perf_bin mon_perf[32];
#endif
static uint32_t mon_worst_at,mon_worst_queue;
static uint32_t mon_local_started,mon_local_frames;
static uint32_t mon_pushes,mon_full,mon_first_push,mon_last_push,mon_push_gap;
#if DM32_LAB_DIAGNOSTICS
static void mon_local_frame(int16_t pcm[160]) {p25_tone_frame(pcm,&mon_tone_phase,mon_tone_hz);}
#endif
static bool mon_audio_enabled=true;
static uint32_t mon_fault_age,mon_fault_audio,mon_fault_mask,mon_fault_mode;
static bool mon_have_sync,mon_badge_sync;
#define mon_have_nac monitor.call.active
#define mon_call_nac monitor.call.nac
static unsigned mon_badge_phase;
static char mon_shown_context[48];
static uint32_t mon_sync_us,mon_voice_us,mon_ui_max_us,mon_spk_last_us,mon_spk_gap_us;
static volatile bool mon_running,mon_failed,mon_routed;
static volatile bool mon_control_only;
// Laboratory ownership and ordinary subscriber control reception are distinct.
// Both leave the voice queue inactive; only the lab mode diverts decoded units.
static volatile bool mon_subscriber_control_only;
static bool mon_capture_control_only(void) {return mon_control_only || mon_subscriber_control_only;}
typedef enum {MON_RX_VOICE,MON_RX_LAB_CONTROL,MON_RX_SUBSCRIBER_CONTROL} mon_rx_purpose;
// One stopped P25 receiver may retain its physical frontend until the next
// P25 tune. It never retains samples, speaker state or transmit permission.
static bool mon_frontend_ready;
static TaskHandle_t mon_task_handle;
static uint32_t mon_empty_since;
static const char *mon_reason="disabled";
// Volatile passive follower: saved channel and TX frequencies never move.
static p25_trunking trunk;
static bool trunk_enabled;
#if DM32_TRUNK_SUBSCRIBER
static p25_trunking_session trunk_session;
static bool trunk_rx_progress_owned;
static void trunk_rx_progress_irq(unsigned half,uint32_t now);
static void trunk_rx_progress_poll(bool down);
static void trunk_rx_progress_release(void);
static int trunk_rx_progress_status_row(unsigned row,char *line,size_t capacity);
static bool trunk_rx_progress_status_last(unsigned next_row);
static volatile bool trunk_rx_stream_owned;
static void trunk_rx_stream_irq(unsigned half,uint32_t now);
static void trunk_rx_stream_poll(bool down);
static bool trunk_rx_stream_timer_active(void);
static void trunk_rx_stream_timer_tick(void);
static void trunk_rx_stream_irq_cost(unsigned kind,uint32_t begin);
static void trunk_rx_stream_timer_stop(void);
static void trunk_rx_stream_release(void);
static void trunk_rx_stream_worker(void);
static void trunk_rx_stream_service(void);
static bool trunk_rx_stream_command(const char *text,bool down);
static int trunk_rx_stream_status_row(unsigned row,char *line,size_t capacity);
static bool trunk_rx_stream_status_last(unsigned next_row);
static void trunk_rx_feed_irq(unsigned half,uint32_t now);
static bool trunk_rx_feed_timer_active(void);
static void trunk_rx_feed_timer_tick(void);
static void trunk_rx_feed_timer_stop(void);
static void trunk_rx_feed_irq_cost(uint32_t begin);
static void trunk_rx_feed_release(void);
static bool trunk_rx_feed_start(unsigned sample_limit,bool tracking);
static bool trunk_rx_feed_selected(void);
static bool trunk_rx_feed_terminal(void);
static bool trunk_rx_feed_defer_display(void);
static void trunk_rx_feed_service(void);
static void trunk_rx_feed_poll(bool down);
static bool trunk_rx_feed_drain(bool down);
static void trunk_rx_feed_ui_cost(bool paint,uint32_t elapsed);
static bool trunk_rx_feed_command(const char *cmd,bool down);
static int trunk_rx_feed_status_row(unsigned row,char *line,size_t capacity);
static uint32_t trunk_stream_epoch,trunk_last_irq_us;
static uint64_t trunk_sample_tick;
static void trunk_access_stop(void);
static void trunk_access_status_symbol(const p25_demod_status *status,void *context);
static bool trunk_access_start(void);
static void trunk_access_poll(bool down);
static bool trunk_subscriber_active(void);
static bool trunk_subscriber_menu_paused(void);
static bool trunk_subscriber_begin_logout(void);
static bool trunk_subscriber_logout_pending(void);
static bool trunk_subscriber_logout_finished(void);
static bool trunk_subscriber_logout_succeeded(void);
static bool trunk_subscriber_transport_owned(void);
static bool trunk_subscriber_handoff(void);
static bool trunk_subscriber_control_receive_allowed(void);
static bool trunk_subscriber_prepare_permission(bool packet,uint32_t tx_hz);
static bool trunk_subscriber_request_owned(void);
static bool trunk_subscriber_voice_owned(void);
static bool trunk_subscriber_boundary(uint32_t now,unsigned source);
static bool trunk_subscriber_rf_irq(void);
static bool trunk_subscriber_pa_timer(void);
static bool trunk_subscriber_cutoff(void);
static bool trunk_subscriber_voice_irq_permission(void);
static bool trunk_subscriber_voice_pa_started(void);
static void trunk_subscriber_block(uint64_t first_tick,uint32_t irq_us,bool valid);
static void trunk_subscriber_status(const p25_demod_status *status);
static void trunk_subscriber_cancel(void);
static void trunk_subscriber_poll(bool down);
static void trunk_subscriber_cleanup(void);
static void trunk_subscriber_return_stopping(void);
static void trunk_subscriber_return_enable(void);
static void trunk_subscriber_return_input(uint32_t now);
static void trunk_subscriber_return_control(void);
static void trunk_subscriber_return_epoch_end(void);
static int trunk_subscriber_return_row(unsigned row,char *line,size_t capacity);
static bool trunk_subscriber_start(const p25_trunking_session_config *config);
static bool trunk_subscriber_consume_control(uint16_t nac,uint32_t hz,const uint8_t block[12],uint32_t now);
static bool trunk_subscriber_allow_follow(void);
static bool trunk_subscriber_receive_begin(void);
static void trunk_subscriber_receive_return(void);
static bool trunk_subscriber_receive_following(void);
static bool trunk_subscriber_receive_restoring(void);
static bool trunk_preload_cc_active(void);
static bool trunk_preload_cc_request_permission(void);
static bool trunk_preload_cc_defer_clock(void);
static bool trunk_preload_cc_timer(void);
static bool trunk_preload_cc_native(uint32_t now,unsigned count);
static void trunk_preload_cc_cleanup(void);
static void trunk_preload_cc_cancel(void);
static void trunk_preload_cc_receive_stop(void);
static void trunk_preload_cc_block(uint64_t first_tick,uint32_t irq_us,bool valid);
static void trunk_preload_cc_status(const p25_demod_status *status);
static void trunk_preload_cc_poll(bool down);
static bool trunk_preload_cc_start(bool down);
static int trunk_preload_cc_status_row(unsigned row,char *line,size_t capacity);
#endif
static uint32_t trunk_receiver_hz,trunk_units,trunk_clock_us,trunk_clock_ms,trunk_clock_carry;
static const char *trunk_reason="off";
static bool trunk_start(void);
static void trunk_stop(const char *why);
static void trunk_poll(bool down);
static void trunk_follow_poll(void);
static void trunk_status(void);
static bool trunk_system_start_selected(void);
static bool trunk_system_load_selected(unsigned selection,p25_cs_trunk_system *out);
static void trunk_system_restore(void);
static bool trunk_system_select(unsigned selection);
static unsigned trunk_system_group(void);
static bool trunk_system_save_group(uint16_t group);
static void trunk_system_boot_poll(bool down);
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_system_search_poll(void);
#endif
static bool trunk_system_menu_action(unsigned action,bool down);
#if DM32_TRUNK_SUBSCRIBER
static bool passive_receive_recovery_queue(unsigned index,const char *why);
static void passive_receive_recovery_poll(bool down);
#endif
static uint32_t receiver_frequency(void) {return trunk_enabled ? trunk_receiver_hz : frequency;}
static uint32_t trunk_now_ms(void) {
    uint32_t now=hrc_micros(),delta=now-trunk_clock_us;trunk_clock_us=now;
    trunk_clock_ms+=delta/1000u;trunk_clock_carry+=delta%1000u;
    if(trunk_clock_carry>=1000u) {++trunk_clock_ms;trunk_clock_carry-=1000u;}
    return trunk_clock_ms;
}
static void mon_stop(const char *why);
static void mon_stop_retune(const char *why);
static void mon_poll(bool down);
static void controller_receive_checkpoint(void);
static bool controller_runtime_owned(void);
static int mon_status_row(unsigned row,char *line,size_t capacity);
static bool normal_resume(void);
static bool rx_job;
static volatile bool rx_sampling;
static uint32_t rx_hz;
static const char *rx_reason="not_run";
#if DM32_LAB_DIAGNOSTICS
static uint32_t rx_due,rx_started;
static unsigned rx_profile,rx_capture_profile;
typedef struct { uint32_t us; int16_t dbm; uint8_t noise; } rx_signal;
static rx_signal rx_signals[60];
static unsigned rx_signal_count;
static uint32_t rx_signal_due, rx_signal_max_us;
#endif
// Slow, task-context meter samples. No frontend/ADC reads from audio or IRQ code.
static uint16_t ui_battery_mv;
static uint8_t ui_battery_pct,ui_rssi_bars;
static bool ui_battery_valid,ui_rssi_valid;
static int16_t ui_rssi_dbm;
static uint32_t ui_battery_due,ui_rssi_due,ui_signal_us,ui_meter_max_us,ui_header_shown;
static radio_signal_meter ui_strength;
#if DM32_LAB_DIAGNOSTICS
static uint32_t rx_reg_work, rx_reg_rf, rx_reg_bw, rx_reg_audio, rx_reg_phase;
static bool rx_pin_source, rx_pin_mic;
#endif
static void rx_end(const char *why);
static void screen(const char *title);
static void ui_lab_transition_poll(void);
static void dmr_tx_preview(void);
static void send(const char *s);
typedef enum {TELEMETRY_NONE,TELEMETRY_LIVE,TELEMETRY_PROBE,TELEMETRY_TRUNK,
              TELEMETRY_RXPROGRESS,TELEMETRY_PRELOAD,TELEMETRY_RXSTREAM,TELEMETRY_LABVOICE,TELEMETRY_LABPTT,TELEMETRY_LABATTACH,TELEMETRY_RXFEED,TELEMETRY_RETURN} telemetry_kind;
static void telemetry_request(telemetry_kind kind);
static void telemetry_abort_after_row(void);
static void telemetry_reset(void);
static bool telemetry_pending(void);
static bool telemetry_partial(void);
static void telemetry_poll(bool down);
static int trunk_status_row(unsigned row,char *line,size_t capacity);
static void normal_permission(void);
static bool ptt_start_requested(bool down,bool was_down);
static void hardware_stop(void);
static void stop_call(const char *why,bool revoke);
static void wr(uint32_t r,uint32_t v);
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_rx_progress_timer_active(void);
static void trunk_rx_progress_timer_tick(void);
static void trunk_rx_progress_timer_stop(void);
#endif
static bool hard_guard_arm(unsigned seconds);
static void broadcast_screen(void);
static void broadcast_leave(bool ptt_down);
static void broadcast_toggle(void);
static void airband_screen(void);
static void airband_leave(bool ptt_down);
static void airband_toggle(void);
static void home_hint_refresh(void);
static void apps_init(void);
static void apps_stop(bool resume);
static void apps_screen(void);
static void apps_poll(void);
static bool apps_active(void);
static bool mon_sync_active(uint32_t now);
static bool prepare_p25_tx(bool packet);
static bool prepare_p25_tx_at(bool packet,uint32_t tx_hz);
static void start_rf(void),cleanup(void);
static void capture(const int16_t *pcm,int16_t *speaker,void *ctx);
static void audio_stop(void);
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_lab_voice_owned(void);
static bool trunk_lab_voice_preserve(void);
static bool trunk_lab_voice_prepare(uint8_t mode);
static bool trunk_lab_voice_begin(void);
static bool trunk_lab_voice_poll(bool down);
static void trunk_lab_voice_cancel(void);
static bool trunk_lab_voice_irq_permission(void);
static bool trunk_lab_voice_rf_started(void);
static bool trunk_lab_voice_pa_started(void);
static bool trunk_lab_ptt_selected(void);
static bool trunk_lab_ptt_request_held(void);
static bool trunk_lab_ptt_request_permission(void);
static bool trunk_lab_ptt_fire_permitted(void);
static bool trunk_lab_ptt_voice_held(bool initial);
static void trunk_lab_ptt_cancel(void);
static void trunk_lab_ptt_cancel_off(void);
static bool trunk_lab_ptt_grant(void);
static bool trunk_lab_ptt_pa_started(void);
static void trunk_lab_ptt_voice_done(bool success);
static void trunk_lab_ptt_return_ready(void);
static bool trunk_lab_ptt_released_voice(void);
static unsigned trunk_lab_ptt_mic_target(void);
static void trunk_lab_ptt_capture_stop(void);
static void trunk_lab_ptt_note_padding(void);
static void trunk_lab_ptt_voice_cancelled(void);
static bool trunk_lab_attach_selected(void);
static bool trunk_lab_attach_preserve(void);
static bool trunk_lab_attach_request_permission(void);
static bool trunk_lab_attach_internal(void);
static bool trunk_lab_attach_arm_permission(void);
static bool trunk_lab_attach_fire_permitted(void);
static bool trunk_lab_attach_commit_permitted(void);
static bool trunk_lab_attach_exchange(void);
static void trunk_lab_attach_cancel(void);
static void trunk_lab_attach_cancel_off(void);
#endif
static bool start_probe_short_rf(void);
static void pcm_poll(void);
static void pcm_leave(bool resume);
static bool pcm_command(const char *line);
static bool pcm_p25_tx(void) {return pcm_owner && pcm_engine.config.modulation==RADIO_PCM_P25 && pcm_engine.config.operations==RADIO_PCM_TX;}
static bool call_selected(const p25_receive_policy *c);
static bool message_cps(bool down);
static bool message_menu_active(void);
// Communications modes use the supported VHF/UHF frontend paths. Optional
// AM and broadcast board entries are routed separately, never as P25/DMR/FM.
static bool channel_in_band(uint32_t hz,bool need_tx) {
    return ((hz>=136000000u && hz<=174000000u) || (hz>=400000000u && hz<=480000000u))
        && board_in_band(hz,need_tx);
}
#if DM32_OMAHA_RX_ONLY
#define preferences_restore preferences_restore_saved
#define preferences_poll preferences_poll_saved
#endif
#include "p25_radio_features.h"
#if DM32_OMAHA_RX_ONLY
#undef preferences_restore
#undef preferences_poll
static hal_flash_t omaha_read_only_flash;
static bool omaha_flash_write(uint32_t address,const void *data,uint32_t bytes) {
    (void)address;(void)data;(void)bytes;return false;
}
static bool omaha_flash_erase(uint32_t address) {(void)address;return false;}
static bool omaha_flash_replace(uint32_t address,const void *data) {
    (void)address;(void)data;return false;
}
static void preferences_restore(void) {
    preferences_restore_saved();
    if(board.flash) {
        omaha_read_only_flash=*board.flash;
        omaha_read_only_flash.write=omaha_flash_write;
        omaha_read_only_flash.erase=omaha_flash_erase;
        omaha_read_only_flash.replace=omaha_flash_replace;
        channel_store.flash=pref_store.flash=&omaha_read_only_flash;
    }
    channel_store.writable=pref_store.writable=false;
    pref_dirty=false;pref_state="read_only";
}
static void preferences_poll(bool down) {
    (void)down;
    // Keep display changes in RAM. Never capture or publish the fixed profile.
    if(!DM32_OMAHA_RX_ONLY)preferences_poll_saved(down);
    pref_dirty=false;pref_state="read_only";
}
static void omaha_profile_apply(void) {
    p25_cs_trunk_system system;(void)dm32_omaha_system(1u,&system);
    memset(channel_record,0,sizeof channel_record);
    pref_put(channel_record,system.control_hz[0]);
    pref_put(channel_record+4,system.control_hz[0]);
    feature_put16(channel_record+8,system.nac);
    feature_put16(channel_record+10,system.talkgroup);
    channel_record[12]=P25_CS_OCCUPIED|P25_CS_TG_FILTER|P25_CS_RX_ONLY;
    memcpy(channel_record+14,system.name,12);
    global_record[9]=0;global_record[28]=1;global_record[29]=1;
    p25_cs_set_selection(global_record,0,0);
    feature_apply();control.source_id=1u;
    owner_tx_inhibit=true;rx_promiscuous=false;rx_tg_filter=true;
    normal_mode=true;session_enabled=armed=false;
    control.tx_enabled=false;control.inhibit=true;control.cancel=false;
    features_ready=true;channel_store.writable=pref_store.writable=false;
    pref_dirty=false;pref_state="read_only";
    trunk_system_boot_checked=false;memset(&passive_receive_recovery,0,sizeof passive_receive_recovery);
    snprintf(channel_label,sizeof channel_label,"NDOT Yard / RX only");
}
#endif
#include "p25_message_services.h"
#include "p25_message_ui.h"
#include "p25_trunking_probe.h"
#include "p25_trunking_preload_live.h"
#if DM32_TRUNK_SUBSCRIBER
#include "p25_trunking_lab_voice_live.h"
#include "p25_trunking_lab_ptt_live.h"
#include "p25_trunking_lab_attach_live.h"
#include "p25_trunking_cc_live.h"
#endif
_Static_assert((unsigned)RADIO_CONTACT_CAPACITY==(unsigned)P25_CS_CONTACTS,"Contact cache geometry differs from codeplug");
_Static_assert(sizeof(radio_call_history)<=1100u,"Call history exceeds its RAM budget");
static unsigned field_digits(void) { return field==EDIT_AIRBAND ? 9 : field<=EDIT_TX || field==EDIT_BCAST ? 7 : field==EDIT_NAC ? 3 : field==EDIT_TRUNK_TG ? 5u : field==EDIT_TG ? (feature_dmr() || radio_channel_get_private(channel_record) ? 8u : 5u) : field==EDIT_MIC || field==EDIT_DMR_CC ? 2 : field==EDIT_ID ? 8 : field==EDIT_SQL ? 1 : field==EDIT_TXTONE || field==EDIT_RXTONE ? 4 : 3; }

void imbe_profile_mark(unsigned stage) { (void)stage; }
void __wrap_hrc_dmr_board_init(hrc7000_t *m,const hrc_dmr_board_t *h) {
    dev=m;hooks=h;
    // The board's power-on initialization has installed its native event mask.
    // Safe stops clear it; ordinary native DMR re-entry does not reinstall it.
    native_sys_irq_mask=hrc7000_rd(m,C7_SYS_INTERP_MASK);
}
void __wrap_hrc_dmr_enter(void) {
    if(!native_irq_owned)return;
    uint32_t lock=hrc_irq_save();
    hrc_irq_enable(IRQ_MODEM_SYS,false);hrc_irq_enable(IRQ_MODEM_TS_TX,false);
    hrc_irq_enable(IRQ_MODEM_TS_RX,false);hrc_irq_enable(IRQ_MODEM_RF_TX,false);
    hrc7000_wr(dev,C7_SYS_INTERP_CLEAR,0xffffffffu);
    hrc7000_wr(dev,C7_SYS_INTERP_MASK,native_sys_irq_mask);
    hrc_irq_restore(lock);
    // Native run installs layer-2 state before enabling its PIC sources.
    __real_hrc_dmr_enter();
}
void __wrap_hrc_dmr_leave(void) {if(native_irq_owned)__real_hrc_dmr_leave();}
static void wr(uint32_t r,uint32_t v) { hrc7000_wr(dev,r,v); }
static void send(const char *s) { board.host_port->write((const uint8_t *)s,strlen(s)); }

// IRQ-safe RF kill; audio/board cleanup is deferred to task context.
static void hardware_stop(void) {
    bool ending=call_active || hardware_running;
#if DM32_TRUNK_SUBSCRIBER
    trunk_subscriber_return_stopping();
    trunk_rx_progress_timer_stop();
    trunk_rx_stream_timer_stop();
    trunk_rx_feed_timer_stop();
    trunk_preload_timer_stop();
#endif
    trunk_probe_short_timer_stop();
    trunk_probe_hardware_end();
    mon_pcm_disable();
    hrc_timer_stop(SPEAKER_TIMER);hrc_irq_enable(IRQ_TIMER4,false);
    if(dev) { wr(C7_LAYER2_TXRX_CTRL,0); wr(C7_LAYER2_CONTROL,0xc0); wr(C7_SYS_INTERP_MASK,0); }
    hrc_irq_enable(IRQ_MODEM_SYS,false);
    hrc_irq_enable(IRQ_MODEM_TS_TX,false); hrc_irq_enable(IRQ_MODEM_TS_RX,false);
    hrc_irq_enable(IRQ_MODEM_RF_TX,false); hrc_irq_enable(IRQ_MODEM_RF_RX,false);
    hrc_timer_stop(TIMER_PA); hrc_timer_stop(HARD_TIMER);radio_tx_guard_stop(&hard_guard);
    if(hardware_running && hooks && !analog_fm.owned) hooks->rf_switch(false);
    board_rf_safe(); hardware_running=false; pa_started=false;
    if(ending) {tx_dac.end=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_END;}
}
static void stop_call(const char *why,bool revoke) {
    uint32_t lock=hrc_irq_save();
    reason=why; pcmq.accepting=false;
    p25_test_tx_abort(&live.timing,P25_TX_CANCELLED);
    hardware_stop(); call_active=false; armed=false;
    if(revoke) {session_enabled=false;radio_inhibit(&control,true);}
    hrc_irq_restore(lock);
}
static void fail(const char *why) { stop_call(why,true); }
static bool ptt_fresh_request(bool down,bool was_down) {
    if(DM32_OMAHA_RX_ONLY)return false;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_lab_return_owned() || trunk_lab_ptt_selected() || trunk_lab_attach_selected())return false;
#endif
    bool permitted=(normal_mode && !tx_fixed) || session_enabled
        || (armed && (int32_t)(hrc_micros()-arm_until)<0);
    return down && !was_down && !ptt_release_required && !broadcast_show && !airband_show && !rx_job && !editing && !menu_open && !rx_lab
        && control.state!=RADIO_FAULT
        && !call_active && !prepared && permitted;
}
static bool ptt_start_requested(bool down,bool was_down) {
    if(trunk_enabled)return false;
    return ptt_fresh_request(down,was_down) && control.tx_enabled && !control.inhibit;
}
static void boundary_source(unsigned source) {
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_boundary(hrc_micros(),source))return;
    if(trunk_preload_phase.selected && trunk_preload_warmed()) {
        trunk_preload_phase_boundary(hrc_micros(),source);return;
    }
#endif
    if(!hardware_running) return;
    uint8_t block[36]; uint32_t now=hrc_micros();
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_preload_active()) {trunk_preload_boundary(now,source);return;}
    if(trunk_subscriber_voice_owned() && !trunk_subscriber_voice_irq_permission())return;
    if(trunk_lab_voice_owned() && hardware_running && !trunk_lab_voice_irq_permission())return;
#endif
    if(trunk_probe_short_active()) {trunk_probe_short_boundary(now,source);return;}
    if(!trunk_probe_irq_profile_valid())return;
    if(!p25_live_tx_boundary(&live,now,block)) {
        if(!p25_test_tx_active(&live.timing)) {
            reason=live.timing.state==P25_TX_DONE ? "complete" : live.underruns ? "rf_underrun" : "rf_timing";
            if(live.timing.state!=P25_TX_DONE) session_enabled=false;
            hardware_stop(); call_active=false; pcmq.accepting=false;
        } else if(live.timing.state==P25_TX_DRAINING && now-live.timing.last_boundary_us>=15000u) {
            wr(C7_LAYER2_TXRX_CTRL,0);
        }
        return;
    }
    trunk_probe_boundary(now,source);
    // SEND_DATA0/1 alternate (pinned modem-hrc7000.md 2.10). Updating both
    // can replace the still-playing half's tail. Both possible initial halves
    // remain selectable until the physical phase is measured on this radio.
    if(tx_writer==TX_WRITER_DUP) {
        for(unsigned i=0;i<36;++i) { dev->buf[i]=block[i]; dev->buf[36+i]=block[i]; }
    } else {
        unsigned offset=tx_write_half ? 36u : 0u;
        for(unsigned i=0;i<36;++i)dev->buf[offset+i]=block[i];
        tx_write_half^=1u; // Only after a unique boundary published a full block.
    }
    wr(C7_LAYER2_TXRX_CTRL,0x80);
}
static void boundary(void) {boundary_source(1u);}
static void isr_sys(void) {
#if DM32_TRUNK_SUBSCRIBER
    uint32_t stream_cost_begin=trunk_rx_stream_owned ? hrc_micros() : 0u;
    uint32_t feed_cost_begin=trunk_rx_feed_selected() ? hrc_micros() : 0u;
#endif
    uint32_t list=hrc7000_rd(dev,C7_SYS_INTERP_LIST); wr(C7_SYS_INTERP_CLEAR,list);
    if(same_running || pcm_raw_capture) {
        if(list&(1u<<14)) {
            unsigned half=hrc7000_rd(dev,C7_FM_ADDR_SW)&3u;
            uint32_t now=hrc_micros();
            (void)radio_app_audio_push(&same_rx.audio,dev->buf+C7_FM_RX_AUDIO,half,now);
            if(half==1u || half==2u)same_last_pcm_us=now;
        }
        return;
    }
    if(mon_running) {
#if DM32_TRUNK_SUBSCRIBER
        if(trunk_rx_feed_selected()) {
            if(list&(1u<<14))trunk_rx_feed_irq(hrc7000_rd(dev,C7_FM_ADDR_SW)&3u,hrc_micros());
            trunk_rx_feed_irq_cost(feed_cost_begin);return;
        }
        if(trunk_rx_stream_owned) {
            if(list&(1u<<14))trunk_rx_stream_irq(hrc7000_rd(dev,C7_FM_ADDR_SW)&3u,hrc_micros());
            trunk_rx_stream_irq_cost(0u,stream_cost_begin);
            return;
        }
        if(trunk_rx_progress_owned) {
            if(list&(1u<<14))trunk_rx_progress_irq(hrc7000_rd(dev,C7_FM_ADDR_SW)&3u,hrc_micros());
            return;
        }
#endif
        if(list&(1u<<14)) {
            uint32_t now=hrc_micros();
            if(!mon_raw_push(&monitor,dev->buf+C7_FM_RX_AUDIO,
                hrc7000_rd(dev,C7_FM_ADDR_SW)&3,now))mon_failed=true;
#if DM32_TRUNK_SUBSCRIBER
            else {trunk_lab_return_first_input(now);trunk_subscriber_return_input(now);}
#endif
        }
        return;
    }
    if(rx_sampling) {
        if(list&(1u<<14))rxcap_push(&rxcap,dev->buf+C7_FM_RX_AUDIO,
                                  hrc7000_rd(dev,C7_FM_ADDR_SW)&3,hrc_micros());
        return;
    }
    if(list&PHY_READY) boundary();
}
static void isr_slot(void) { wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX); boundary_source(2u); }
static void isr_slot_tx(void) {isr_slot();}
static void isr_slot_rx(void) {wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX);boundary_source(3u);}
static void isr_rftx(void) {
    wr(C7_INTERP_CLEAR,C7_INT_RF_TX);
    if(DM32_OMAHA_RX_ONLY)return;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_rf_irq())return;
    if(trunk_preload_active()) {trunk_preload_rf_irq();return;}
    if(trunk_subscriber_voice_owned() && !trunk_subscriber_voice_irq_permission())return;
    if(trunk_lab_voice_owned() && hardware_running && !trunk_lab_voice_irq_permission())return;
#endif
    if(trunk_probe_short_active()) {trunk_probe_short_rf_irq();return;}
    if(!trunk_probe_irq_profile_valid())return;
    if(hardware_running && p25_test_tx_active(&live.timing) && !pa_started) {
#if DM32_TRUNK_SUBSCRIBER
        if(trunk_lab_voice_owned() && !trunk_lab_voice_rf_started())return;
#endif
        trunk_probe_rf_irq();
        pa_started=true; hooks->rf_switch(true); hrc_timer_oneshot(TIMER_PA,hooks->pa_delay_us);
    }
}
static void isr_rfrx(void) { wr(C7_INTERP_CLEAR,C7_INT_RF_RX); }
static void isr_pa(void) {
    hrc_timer_ack(TIMER_PA); hrc_timer_stop(TIMER_PA);
    if(DM32_OMAHA_RX_ONLY)return;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_pa_timer())return;
    if(trunk_preload_cc_timer())return;
    if(trunk_preload_active()) {trunk_preload_pa();return;}
    if(trunk_subscriber_voice_owned() && !trunk_subscriber_voice_irq_permission())return;
    if(trunk_lab_voice_owned() && hardware_running && !trunk_lab_voice_irq_permission())return;
#endif
    if(trunk_probe_short_active()) {trunk_probe_short_pa();return;}
    if(!trunk_probe_irq_profile_valid())return;
    if(hardware_running && p25_test_tx_active(&live.timing)) {
#if DM32_TRUNK_SUBSCRIBER
        if(trunk_subscriber_voice_owned() && !trunk_subscriber_voice_pa_started())return;
        if(trunk_lab_voice_owned() && !trunk_lab_voice_pa_started())return;
#endif
        hooks->pa_on();tx_dac.pa=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PA;
        trunk_probe_pa();
    }
}
static bool hard_guard_arm(unsigned seconds) {
    if(DM32_OMAHA_RX_ONLY) {(void)seconds;return false;}
    uint32_t lock=hrc_irq_save();hrc_timer_stop(HARD_TIMER);
    bool ok=radio_tx_guard_start(&hard_guard,seconds);
    if(ok)hrc_timer_oneshot(HARD_TIMER,RADIO_TX_GUARD_PERIOD_US);
    hrc_irq_restore(lock);return ok;
}
static bool dmr_machine_tx_begin(void *ctx) {
    (void)ctx;return !DM32_OMAHA_RX_ONLY && message_tx_permission() && hard_guard_arm(feature_tx_tot()+2u);
}
static void isr_hard_stop(void) {
    hrc_timer_ack(HARD_TIMER);
    if(!hard_guard.remaining) {hrc_timer_stop(HARD_TIMER);return;}
    if(!radio_tx_guard_tick(&hard_guard)) {
        hrc_timer_oneshot(HARD_TIMER,RADIO_TX_GUARD_PERIOD_US);return;
    }
    if(pcm_owner)radio_pcm_engine_abort(&pcm_engine,RADIO_PCM_TOT);
    if(native_irq_owned) {
        // Quiesce slot/PA IRQs immediately; task context stops the call engine.
        dmr_hard_timeout=true;hardware_stop();call_active=false;return;
    }
    p25_test_tx_abort(&live.timing,P25_TX_TIMEOUT);
    session_enabled=false; radio_inhibit(&control,true); reason="hard_timeout"; pcmq.accepting=false; call_active=false; hardware_stop();
}
static void isr_probe_cutoff(void) {
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_cutoff())return;
    if(trunk_rx_feed_timer_active()) {
        uint32_t begin=hrc_micros();trunk_rx_feed_timer_tick();trunk_rx_feed_irq_cost(begin);return;
    }
    if(trunk_rx_stream_timer_active()) {
        uint32_t begin=hrc_micros();
        trunk_rx_stream_timer_tick();trunk_rx_stream_irq_cost(1u,begin);return;
    }
    if(trunk_rx_progress_timer_active()) {trunk_rx_progress_timer_tick();return;}
    if(trunk_preload_active()) {trunk_preload_cutoff();return;}
#endif
    trunk_probe_short_cutoff();
}
static void p25_irqs_install(void) {
    hrc_irq_register(IRQ_MODEM_SYS,isr_sys);hrc_irq_register(IRQ_MODEM_TS_TX,isr_slot_tx);
    hrc_irq_register(IRQ_MODEM_TS_RX,isr_slot_rx);hrc_irq_register(IRQ_MODEM_RF_TX,isr_rftx);
    hrc_irq_register(IRQ_MODEM_RF_RX,isr_rfrx);hrc_irq_register(IRQ_TIMER3,isr_pa);
    hrc_irq_enable(IRQ_TIMER3,true);
    hrc_irq_register(IRQ_TIMER5,isr_probe_cutoff);
    hrc_irq_enable(IRQ_TIMER5,false);
}
static bool dmr_acquire(void *ctx) {
    (void)ctx;
    if(!dev || !hooks || call_active || prepared || audio_on || mon_running || rx_job)return false;
    if(mon_frontend_ready)mon_stop("dmr_acquire");
    if(!native_sys_irq_mask) {digital_dmr.error=RADIO_DMR_RX_FAILED;return false;}
    hardware_stop();
    if(!imbe_bench_release())return false;
    if(!board.vocoder || !board.vocoder->present()) {digital_dmr.error=RADIO_DMR_NO_CODEC;return false;}
    // Old trace/capture bytes cease to be evidence once native state uses them.
    mon_used=false;memset(&rx_storage,0,sizeof rx_storage);rx_reason="dmr_workspace";
#if DM32_LAB_DIAGNOSTICS
    rx_signal_count=0;
#endif
    rx_hz=0;
    if(!hrc_vocoder_resume())return false;
    __real_hrc_dmr_board_init(dev,hooks);
    native_irq_owned=true;dmr_hard_timeout=false;return true;
}
static void dmr_release(void *ctx) {
    (void)ctx;
    // The backend has stopped AMBE audio and left DMR before this callback.
    __real_hrc_dmr_leave();
    native_irq_owned=false;
    bool released=hrc_vocoder_quiesce();
    hardware_stop();p25_irqs_install();
    if(!released) {reason="codec_busy";radio_complete(&control,true);}
}
static uint32_t dmr_clock_us(void *ctx) {(void)ctx;return hrc_micros();}
static void dmr_native_tx_diag(radio_dmr_native_tx_diag_t *out,void *ctx) {(void)ctx;hrc_dmr_tx_diag(out);}
static void feature_dmr_tick(bool down) {
    bool home=(!menu_open || message_menu_active()) && !editing && !rx_lab && !rx_job && !cps_link && !cps_active;
    if(!normal_mode || !feature_dmr() || !mon_enabled || !frequency || !home) {
        if(digital_dmr.owned && !digital_dmr.tx_armed)radio_dmr_stop(&digital_dmr);
        return;
    }
    if(mon_running || mon_frontend_ready)mon_stop("dmr");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    if(!digital_dmr.owned && control.state!=RADIO_FAULT) {
        radio_dmr_config config={.rx_hz=frequency,.tx_hz=control.tx_frequency,
            .source_id=control.source_id,.target_id=radio_channel_get_destination(channel_record),
            .cc=(uint8_t)radio_channel_get_color_code(channel_record),
            .ts=(uint8_t)radio_channel_get_timeslot(channel_record),.power=(uint8_t)feature_tx_power(),.tot_s=(uint16_t)feature_tx_tot(),
            .private_call=radio_channel_get_private(channel_record),.rmo=radio_channel_get_repeater(channel_record),
            .filter=rx_promiscuous ? RADIO_DMR_FILTER_PROM : rx_tg_filter ? RADIO_DMR_FILTER_TARGET : RADIO_DMR_FILTER_SLOT,
            .rx_only=(channel_record[12]&16u)!=0,.owner_permission=!owner_tx_inhibit};
        if(!feature_tx_settings_valid() || !radio_dmr_start(&digital_dmr,&config)) {
            reason=radio_dmr_error_name(digital_dmr.error);radio_complete(&control,true);screen("HOME");return;
        }
        hrc7000_set_mic_gain(dev,(uint8_t)mic_gain_db);
        dmr_ui_serial=UINT32_MAX;dmr_ui_due=hrc_micros();reason="listening";
        radio_receive_state(&control,true,true,false,false);screen("HOME");
    }
    if(!digital_dmr.running)return;
    digital_dmr.config.owner_permission=!owner_tx_inhibit;
    digital_dmr.config.rx_only=(channel_record[12]&16u)!=0;
    bool allowed=home && !ptt_release_required && control.tx_enabled && !control.inhibit && !control.cancel;
    if(message_menu_active()) {if(down)allowed=false;down=false;} // Held PTT cancels data without starting menu voice.
    bool was_tx=digital_dmr.tx_armed;
    radio_dmr_tx_result old_result=digital_dmr.diagnostics.result;
    if(!was_tx && down && allowed && !digital_dmr.ptt_last
       && !digital_dmr.release_required && !digital_dmr.config.rx_only) {
        // LCD transfers share this task with native burst feeding. Show TX
        // before starting the producer/slot engine, then leave graphics alone
        // through access, voice and terminator drain. A release during a slow
        // preview must not turn the cached key sample into an unwanted call.
        dmr_tx_preview();
        down=down && !hrc_pin_read(PIN_PTT);
    }
    // Arm independently before the first call into the slot engine can key RF.
    if(!was_tx && down && allowed && !hard_guard_arm(feature_tx_tot()+2u))allowed=false;
    radio_dmr_poll(&digital_dmr,hal_millis(),down,allowed);
    // A board-level refusal need not change the native call view's serial.
    if(old_result!=digital_dmr.diagnostics.result)dmr_ui_serial=UINT32_MAX;
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    call_active=hardware_running=digital_dmr.tx_armed || digital_dmr.data_armed;
    if(!call_active) {hrc_timer_stop(HARD_TIMER);radio_tx_guard_stop(&hard_guard);}
    if(was_tx && !digital_dmr.tx_armed) {
        control.cancel=false;radio_complete(&control,false);
        reason=digital_dmr.tx_error==DMR_TX_OK ? "listening" : radio_dmr_tx_error_name(digital_dmr.tx_error);
        normal_permission();
        if(down) {ptt_release_required=true;ptt_release_seen=false;}
    }
    if(dv && digital_dmr.tx_armed) {
        control.state=dv->phase==DMR_CALL_PHASE_TX_ENDING ? RADIO_TX_DRAIN : RADIO_TX_VOICE;
        reason="voice_call";
    } else if(digital_dmr.data_armed) {
        control.state=RADIO_TX_VOICE;reason="sending_message";
    } else if(dv) {
        if(radio_busy(&control))radio_complete(&control,false);
        bool rx=dv->state==DMR_CALL_STATE_RX;
        radio_receive_state(&control,true,true,rx,dv->phase==DMR_CALL_PHASE_RX_VOICE);
    }
    board.power->led(LED_GREEN,dv && dv->state==DMR_CALL_STATE_RX);
}
static void capture(const int16_t *pcm,int16_t *speaker,void *ctx) {
    (void)ctx; memset(speaker,0,320);
    uint32_t lock=hrc_irq_save();
    if(call_active && pcmq.accepting) {
        mic_queue_push_limit(&pcmq,pcm,hrc_micros(),call_capture_frames);last_pcm=hrc_micros();
        if(pcmq.captured>=call_capture_frames)call_tot_expired=true;
    }
    hrc_irq_restore(lock);
}
static void audio_stop(void) {
    if(audio_on) { board.audio->stop(); audio_on=false; }
    // Do not change modem mode or PA while queued RF is draining.
}
static void cleanup(void) {
#if DM32_TRUNK_SUBSCRIBER
    trunk_lab_return_cleanup_trace(true);
#endif
    audio_stop();
    // Completion may arrive in the PHY IRQ before poll_call runs again.
    if(prepared && call_tot_expired && (!strcmp(reason,"complete") || !strcmp(reason,"time_limit"))) {
        reason="time_limit";ptt_release_required=true;ptt_release_seen=false;
    }
    if(prepared)ui_battery_due=hrc_micros()+3000000u; // Let pack voltage recover before refreshing its icon.
    uint32_t lock=hrc_irq_save(); hardware_stop();
    if(prepared) wr(C7_RF_MODE,saved_rf_mode);
    hrc_irq_restore(lock);
    if(prepared) { board.radio->tx_off(); board.radio->set_mode(RADIO_MODE_FM); }
    prepared=false; board_rf_safe(); board.power->led(LED_RED,false);
    trunk_probe_cleanup();
#if DM32_TRUNK_SUBSCRIBER
    trunk_preload_cleanup();
    trunk_subscriber_cleanup();
#endif
    // The main loop resumes an enabled receiver only after TX cleanup.
    bool fault=strcmp(reason,"complete") && strcmp(reason,"released_before_rf")
        && strcmp(reason,"idle") && strcmp(reason,"cancelled") && strcmp(reason,"time_limit");
    radio_complete(&control,fault);
    if(fault) {session_enabled=armed=false;radio_inhibit(&control,true);}
    if(!normal_mode && !session_enabled)radio_inhibit(&control,true);
    if(normal_mode && !fault)radio_receive_state(&control,mon_enabled,false,false,false);
#if DM32_TRUNK_SUBSCRIBER
    trunk_lab_return_cleanup_trace(false);
#endif
}
static void normal_permission(void) {
    if(DM32_OMAHA_RX_ONLY) {owner_tx_inhibit=true;radio_inhibit(&control,true);return;}
#if DM32_TRUNK_SUBSCRIBER
    // Preserve the frozen WARM authorization. The lab owner blocks ordinary
    // PTT separately and never grants subscriber/access authorization.
    if(trunk_lab_return_owned())return;
#endif
    if(!normal_mode || call_active || prepared || radio_busy(&control))return;
    if(control.state==RADIO_FAULT) {radio_inhibit(&control,true);return;}
    bool blocked=trunk_enabled || owner_tx_inhibit || broadcast_show || airband_show || apps_active() || cps_link || cps_active || (channel_record[12]&16u) || !feature_tx_settings_valid() || !channel_in_band(frequency,false)
        || !channel_in_band(control.tx_frequency,true) || !bf_cal_valid()
        || board.power->battery_mv()<board.battery_critical_mv;
    radio_inhibit(&control,blocked);
}
static bool normal_resume(void) {
    if(call_active || prepared || rx_job)return false;
    trunk_stop("radio");
    if(airband.owned)radio_airband_stop(&airband);
    airband_show=false;
    if(mon_running)mon_stop("resume_radio");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
    normal_mode=true;session_enabled=armed=false;
#if DM32_LAB_DIAGNOSTICS
    tx_fixed=false;tx_startup_extra=0;tx_writer=TX_WRITER_ALT1;tx_dac_restore=true;
    mon_pcm_backend=true;mon_local_tone=mon_replay=mon_output_tone=false;
#endif
    mon_audio_enabled=true;
    editing=menu_open=rx_lab=false;edit_from_menu=diag_from_menu=false;digit_count=0;
    radio_complete(&control,false);
    mon_enabled=channel_in_band(frequency,false);mon_reason=mon_enabled ? "ready" : "no_channel";
    reason=mon_enabled ? "listening" : "enter_frequency";
    normal_permission();radio_receive_state(&control,mon_enabled,false,false,false);
    return mon_enabled;
}
static void boot_policy(void) {
#if DM32_OMAHA_RX_ONLY
    omaha_profile_apply();
#endif
    // The shared UART/PTT driver initially reports released while its 20-ms
    // low filter settles. Never use that first filtered scan as permission.
    ptt_release_required=true;ptt_release_seen=false;
    (void)normal_resume();
}
static int dmr_cost_row(char *line,size_t capacity,const char *name,const radio_dmr_cost_t *cost) {
    return snprintf(line,capacity,"DMRCOST kind=%s calls=%lu total_us=%lu max_us=%lu saturated=%lu\r\n",name,
        (unsigned long)cost->calls,(unsigned long)cost->total_us,(unsigned long)cost->max_us,(unsigned long)cost->saturated);
}
// One row is sampled/formatted on demand; no persistent diagnostic snapshot.
static int dmr_status_row(unsigned row,char *line,size_t capacity) {
    switch(row) {
    case 0u: {
        radio_dmr_rx_diag_t rx;hrc_dmr_rx_diag(&rx);
        return snprintf(line,capacity,"DMRHW saved_mask=%08lx current_mask=%08lx active=%u callback=%u closed=%u deferred=%u sys=%lu ts_rx=%lu ts_tx=%lu ticks=%lu\r\n",
                (unsigned long)native_sys_irq_mask,(unsigned long)(dev ? hrc7000_rd(dev,C7_SYS_INTERP_MASK) : 0u),
                (unsigned)rx.active,(unsigned)rx.callback_bound,(unsigned)rx.deferred_closed,(unsigned)rx.deferred_active,
                (unsigned long)rx.sys_ints,(unsigned long)rx.ts_rx_ints,(unsigned long)rx.ts_tx_ints,(unsigned long)rx.ticks);
    }
    case 1u: {
        radio_dmr_rx_diag_t rx;hrc_dmr_rx_diag(&rx);
        return snprintf(line,capacity,"DMRBURST voice=%lu header=%lu end=%lu crc=%lu unusable=%lu late=%lu overflow=%lu cc=%u ts=%d type=%08lx sys_list=%08lx l2=%08lx\r\n",
                (unsigned long)rx.rx_voice,(unsigned long)rx.rx_lc_header,(unsigned long)rx.rx_terminator,
                (unsigned long)rx.rx_crc_err,(unsigned long)rx.rx_unusable,(unsigned long)rx.late_entry,(unsigned long)rx.ev_overflow,
                (unsigned)rx.last_cc,(int)rx.last_ts,(unsigned long)rx.last_rx_type_info,(unsigned long)rx.last_sys_list,
                (unsigned long)rx.last_l2_status);
    }
    case 2u: {
        dmr_call_stats_t calls;
        uint32_t lock=hrc_irq_save();dmr_call_get_stats(&calls);hrc_irq_restore(lock);
        return snprintf(line,capacity,"DMRRXCALL scope=mode calls=%lu played=%lu bursts=%lu lost=%lu duplicate=%lu encrypted=%lu cc_drop=%lu ts_drop=%lu event_overflow=%lu\r\n",
                (unsigned long)calls.rx_calls,(unsigned long)calls.rx_calls_played,(unsigned long)calls.rx_voice_bursts,
                (unsigned long)calls.rx_lost_frames,(unsigned long)calls.rx_dup_dropped,(unsigned long)calls.rx_enc_dropped,
                (unsigned long)calls.rx_cc_dropped,(unsigned long)calls.rx_ts_dropped,(unsigned long)calls.evq_overflows);
    }
    case 3u: {
        ambe_voice_stats_t voice;
        uint32_t lock=hrc_irq_save();ambeVoiceGetStats(&voice);hrc_irq_restore(lock);
        return snprintf(line,capacity,"DMRRXAUDIO scope=boot in=%lu frames=%lu bad=%lu lost=%lu concealed=%lu silence=%lu queue_max=%lu empty=%lu overflow=%lu bit_corrections=%lu peak=%lu repeats=%lu\r\n",
                (unsigned long)voice.rx_in,(unsigned long)voice.rx_frames,(unsigned long)voice.rx_bad,(unsigned long)voice.rx_lost,
                (unsigned long)voice.rx_concealed,(unsigned long)voice.rx_silence,(unsigned long)voice.rx_queue_max,
                (unsigned long)voice.rx_underruns,(unsigned long)voice.rx_overflows,(unsigned long)voice.rx_bit_errors,
                (unsigned long)voice.rx_peak,(unsigned long)voice.rx_repeats);
    }
    case 4u: {
        radio_dmr_diagnostics d;
        if(!radio_dmr_get_diagnostics(&digital_dmr,&d))return 0;
        return snprintf(line,capacity,"DMRTX result=%s backend=%s native=%s phase=%u last_tx_phase=%u valid=%u start_ms=%lu end_ms=%lu calls=%lu denied=%lu frames=%lu repeats=%lu overflow=%lu source_empty=%lu event_overflow=%lu\r\n",
                    radio_dmr_tx_result_name(d.result),radio_dmr_error_name(d.backend_error),radio_dmr_tx_error_name(d.tx_error),
                    d.phase,d.last_tx_phase,(unsigned)d.metrics_valid,(unsigned long)d.start_ms,(unsigned long)d.end_ms,
                    (unsigned long)d.calls,(unsigned long)d.denied,(unsigned long)d.encoded_frames,(unsigned long)d.encoded_repeats,
                    (unsigned long)d.encoded_overflows,(unsigned long)d.source_underruns,(unsigned long)d.event_overflows);
    }
    case 5u: {
        radio_dmr_diagnostics d;
        if(!radio_dmr_get_diagnostics(&digital_dmr,&d))return 0;
        return snprintf(line,capacity,"DMRMIC blocks=%lu peak=%lu level_db=%lu spread_db=%lu zc=%lu\r\n",
                    (unsigned long)d.mic_blocks,(unsigned long)d.mic_peak,(unsigned long)d.mic_level_db,
                    (unsigned long)d.mic_spread_db,(unsigned long)d.mic_zc);
    }
    case 6u: {
        radio_dmr_diagnostics d;
        if(!radio_dmr_get_diagnostics(&digital_dmr,&d))return 0;
        return snprintf(line,capacity,"DMRPACE scope=attempt valid=%u poll_gap_us=%lu\r\n",
                    (unsigned)d.poll_timing_valid,(unsigned long)d.poll_gap_max_us);
    }
    case 7u: {
        radio_dmr_diagnostics d;
        if(!radio_dmr_get_diagnostics(&digital_dmr,&d))return 0;
        return dmr_cost_row(line,capacity,"poll",&d.poll_cost);
    }
    case 8u: {
        radio_dmr_diagnostics d;
        if(!radio_dmr_get_diagnostics(&digital_dmr,&d))return 0;
        return snprintf(line,capacity,"DMRDRIVER scope=attempt valid=%u bursts=%lu underrun=%lu rejected=%lu done=%lu event_overflow=%lu\r\n",
                    (unsigned)d.native_metrics_valid,(unsigned long)d.native_tx_bursts,(unsigned long)d.native_tx_underruns,
                    (unsigned long)d.native_tx_rejected,(unsigned long)d.native_tx_done,(unsigned long)d.native_event_overflows);
    }
    case 9u: {
        radio_dmr_audio_diag_t audio;hrc_audio_pcm_diag(&audio);
        return snprintf(line,capacity,"DMRPCM counts_scope=native_reset cost_scope=boot blocks=%lu overwritten=%lu fifo_underrun_available=0 service_gap_us=%lu callback_gap_us=%lu\r\n",
                (unsigned long)audio.blocks,(unsigned long)audio.overruns,
                (unsigned long)audio.service_gap_max_us,(unsigned long)audio.callback_gap_max_us);
    }
    case 10u: {
        radio_dmr_audio_diag_t audio;hrc_audio_pcm_diag(&audio);
        return snprintf(line,capacity,"DMRSPK scope=boot backend=PCM half_samples=80 prefill_samples=320 submitted=%lu consumed=%lu irqs=%lu irq_gap_us=%lu queue_max_samples=%lu\r\n",
                (unsigned long)audio.output_submitted,(unsigned long)audio.output_consumed,
                (unsigned long)audio.output_irqs,(unsigned long)audio.output_irq_gap_max_us,
                (unsigned long)audio.output_queue_max);
    }
    case 11u: {
        radio_dmr_audio_diag_t audio;hrc_audio_pcm_diag(&audio);
        return snprintf(line,capacity,"DMRSPKFAULT scope=boot overflow=%lu starvation=%lu restart=%lu drain=%lu discarded_samples=%lu timeout=%lu\r\n",
                (unsigned long)audio.output_overflows,(unsigned long)audio.output_starvations,
                (unsigned long)audio.output_restarts,(unsigned long)audio.output_drains,
                (unsigned long)audio.output_discarded,(unsigned long)audio.output_timeouts);
    }
    case 12u: {
        radio_dmr_vocoder_diag_t codec;hrc_vocoder_diag(&codec);
        return snprintf(line,capacity,"DMRCODEC scope=owner reset_rejected=%lu encode_rejected=%lu decode_rejected=%lu\r\n",
                (unsigned long)codec.reset_rejected,(unsigned long)codec.encode_rejected,(unsigned long)codec.decode_rejected);
    }
    case 13u: {
        radio_dmr_audio_diag_t audio;hrc_audio_pcm_diag(&audio);
        return dmr_cost_row(line,capacity,"service",&audio.service);
    }
    case 14u: {
        radio_dmr_audio_diag_t audio;hrc_audio_pcm_diag(&audio);
        return dmr_cost_row(line,capacity,"callback",&audio.callback);
    }
    case 15u: {
        radio_dmr_vocoder_diag_t codec;hrc_vocoder_diag(&codec);
        return dmr_cost_row(line,capacity,"reset",&codec.reset);
    }
    case 16u: {
        radio_dmr_vocoder_diag_t codec;hrc_vocoder_diag(&codec);
        return dmr_cost_row(line,capacity,"encode",&codec.encode);
    }
    case 17u: {
        radio_dmr_vocoder_diag_t codec;hrc_vocoder_diag(&codec);
        return dmr_cost_row(line,capacity,"decode",&codec.decode);
    }
    case 18u: {
        return dmr_cost_row(line,capacity,"dmr_display",&dmr_ui_cost);
    }
    case 19u:
#if CONFIG_WATCHDOG
    {
        uint32_t lock=hrc_irq_save();watchdog_state_t wd=*watchdog_state();hrc_irq_restore(lock);
        return snprintf(line,capacity,"WATCHDOG feeds=%lu last_idle_ms=%lu last_fed_ms=%lu max_gap_ms=%lu seen=%u starving=%u\r\n",
                (unsigned long)wd.feeds,(unsigned long)wd.last_idle_ms,(unsigned long)wd.last_fed_ms,
                (unsigned long)wd.max_gap_ms,(unsigned)wd.seen,(unsigned)wd.starving);
    }
#else
        return 0;
#endif
    case 20u:
#if CONFIG_CRASH_LOG
    {
        const crash_reset_t *boot=crash_reset();const crash_record_t *crash=crash_last();
        return snprintf(line,capacity,"RESET cause=%s flags=%08lx prior_uptime_ms=%lu warm=%lu crash=%u kind=%u code=%lu pc=%08lx task=%.8s\r\n",
                crash_reset_name(boot->cause),(unsigned long)boot->flags,(unsigned long)boot->uptime_ms,(unsigned long)boot->warm,
                (unsigned)(crash!=NULL),crash ? crash->kind : 0u,(unsigned long)(crash ? crash->cause : 0u),
                (unsigned long)(crash ? crash->pc : 0u),crash ? crash->task : "none");
    }
#else
        return 0;
#endif
    default:return -1;
    }
}

enum {COMMAND_DEFER_STATUS=1u,COMMAND_DEFER_BUSY=2u,COMMAND_DEFER_STOP_ACK=4u,COMMAND_DEFER_MESSAGE=8u,
      COMMAND_DEFER_TELEMETRY_BUSY=16u,COMMAND_DEFER_TRUNK_STOP_ACK=32u};
static unsigned command_deferred;
static bool command_critical_pass;
static void command_deferred_reset(void) {command_deferred=0;command_critical_pass=false;}
static bool command_tx_critical(bool down) {
    if(trunk_probe.active)return true;
    if(digital_dmr.tx_armed || digital_dmr.data_armed)return true; // Data lists need the same uninterrupted feeding.
    bool home=!menu_open && !editing && !rx_lab && !rx_job && !cps_link && !cps_active;
    return normal_mode && feature_dmr() && home && digital_dmr.running && down
        && !digital_dmr.ptt_last && !digital_dmr.release_required && !ptt_release_required
        && control.tx_enabled && !control.inhibit && !control.cancel
        && !owner_tx_inhibit && !(channel_record[12]&16u);
}
// Fixed row numbers keep optional sections from changing later wire order.
// Positive is snprintf's complete row length; zero omits a row; -1 ends.
static int live_status_row(unsigned row,char *line,size_t capacity) {
    if(row>=6u && row<=15u)return mon_used ? mon_status_row(row-6u,line,capacity) : 0;
    if(row>=21u && row<=41u)return dmr_status_row(row-21u,line,capacity);
    switch(row) {
    case 0u:
#if DM32_RF_B_EXPERIMENTAL
        return snprintf(line,capacity,"RFSETUP setup=%c experimental=1 hardware_qualified=0\r\n",dm32_rf_compat_setup());
#else
        return 0;
#endif
    case 1u: {
        return snprintf(line,capacity,"TXPATH writer=%s dac=%s dac_seen=%02lx dac_before_tx=%08lx dac_prepared=%08lx dac_after_stop=%08lx dac_pre_rf=%08lx dac_pa=%08lx dac_end=%08lx\r\n",
                tx_writer_name(),tx_dac_restore ? "RESTORE" : "KEEP",(unsigned long)tx_dac.seen,
                (unsigned long)tx_dac.before_tx,(unsigned long)tx_dac.prepared,(unsigned long)tx_dac.after_stop,(unsigned long)tx_dac.pre_rf,
                (unsigned long)tx_dac.pa,(unsigned long)tx_dac.end);
    }
    case 2u: {
        return snprintf(line,capacity,"TXDIAG source=%s pairs=%u startup_extra=%u ldu_phase=%u\r\n",
                tx_fixed ? "FIXED1011" : "MIC",tx_pairs,tx_startup_extra,
                (LIVE_STARTUP_BASE_BYTES+99u+tx_startup_extra)%36u);
    }
    case 3u: {
        return snprintf(line,capacity,"OPERATING mode=%s owner_inhibit=%u ptt_release=%u prom=%u\r\n",
                normal_mode ? "RADIO" : "BENCH",(unsigned)owner_tx_inhibit,(unsigned)ptt_release_required,(unsigned)rx_promiscuous);
    }
    case 4u: {
        return snprintf(line,capacity,"LIVE git=%s armed=%u session=%u hz=%lu active=%u rf=%u state=%u reason=%s cal=%s captured=%u encoded=%u pcm_high=%u overflow=%u driver_loss=%lu ldu_high=%u published=%u consumed=%u underrun=%u blocks=%lu dup=%lu late=%lu maxgap=%lu max_encode_us=%u max_pack_us=%u hash=%08lx\r\n",
                BENCH_GIT,(unsigned)armed,(unsigned)session_enabled,(unsigned long)frequency,(unsigned)call_active,(unsigned)hardware_running,
                (unsigned)live.timing.state,reason,bf_cal_source(),pcmq.captured,encoded,pcmq.high,pcmq.overflow,
                (unsigned long)driver_loss,live.high,live.published,live.consumed,live.underruns,
                (unsigned long)live.timing.blocks,(unsigned long)live.timing.duplicate_irqs,
                (unsigned long)live.timing.late_irqs,(unsigned long)live.timing.max_gap_us,max_encode,max_pack,
                (unsigned long)payload_hash);
    }
    case 5u:
        if(mon_used)return snprintf(line,capacity,"RXCAP pending=0 sampling=0 hz=0 blocks=0 invalid=0 repeats=0 gaps=0 maxgap_us=0 reason=monitor_storage\r\n");
#if DM32_LAB_DIAGNOSTICS
        return snprintf(line,capacity,"RXCAP pending=%u sampling=%u hz=%lu blocks=%lu invalid=%lu repeats=%lu gaps=%lu maxgap_us=%lu reason=%s\r\n",
                (unsigned)rx_job,(unsigned)rx_sampling,(unsigned long)rx_hz,(unsigned long)rxcap.count,
                (unsigned long)rxcap.invalid,(unsigned long)rxcap.repeats,(unsigned long)rxcap.gaps,
                (unsigned long)rxcap.maxgap,rx_reason);
#else
        return 0;
#endif
    case 16u: {
        return snprintf(line,capacity,"RADIO rx_hz=%lu tx_hz=%lu split=%u nac=%03lx tg=%lu source=%lu ui_state=%u inhibit=%u\r\n",
                (unsigned long)frequency,(unsigned long)control.tx_frequency,(unsigned)control.split,
                (unsigned long)control.nac,(unsigned long)control.talkgroup,(unsigned long)control.source_id,
                (unsigned)control.state,(unsigned)control.inhibit);
    }
    case 17u: {
        return snprintf(line,capacity,"UIMETER battery_pct=%u battery_mv=%u rssi_dbm=%d bars=%u valid=%u max_poll_us=%lu\r\n",
                (unsigned)ui_battery_pct,(unsigned)ui_battery_mv,(int)ui_rssi_dbm,(unsigned)ui_rssi_bars,
                (unsigned)ui_rssi_valid,(unsigned long)ui_meter_max_us);
    }
    case 18u: {
        return snprintf(line,capacity,"PREF state=%s dirty=%u writable=%u sequence=%lu mic_db=%u version=%u tx_inhibit=%u prom_mode=%u\r\n",pref_state,pref_dirty,pref_store.writable,(unsigned long)pref_store.seq,mic_gain_db,PREF_VERSION,(unsigned)owner_tx_inhibit,(unsigned)rx_promiscuous);
    }
    case 19u: {
        return snprintf(line,capacity,"CODEPLUG version=%u revision=%lu active=%u legacy=%u mode=%s vfo=%c memory=%u filter=%u scan=%u list=%u locked=%u screen_s=%u keypad_s=%u cps=%u scan_members=%u scan_match=%u\r\n",
                P25_CS_VERSION,(unsigned long)channel_store.revision,(unsigned)channel_store.have_active,(unsigned)channel_store.have_legacy,
                feature_mode_name(),'A'+feature_vfo(),feature_memory(),feature_filter(),(unsigned)channel_scan.running,
                global_record[12]+1u,(unsigned)radio_lights.locked,radio_lights.screen_seconds,radio_lights.keypad_seconds,(unsigned)(cps_link || cps_active),feature_scan_group_size(),feature_scan_received_slot());
    }
    case 20u: {
        const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
        return snprintf(line,capacity,"DMR running=%u owned=%u cc=%u ts=%u destination=%lu private=%u repeater=%u phase=%u error=%s codec_owner=%u\r\n",
                (unsigned)digital_dmr.running,(unsigned)digital_dmr.owned,radio_channel_get_color_code(channel_record),
                radio_channel_get_timeslot(channel_record),(unsigned long)(feature_dmr() ? radio_channel_get_destination(channel_record) : 0u),
                (unsigned)radio_channel_get_private(channel_record),(unsigned)radio_channel_get_repeater(channel_record),
                dv ? dv->phase : 0u,radio_dmr_error_name(digital_dmr.error),(unsigned)radio_codec_owner());
    }
    case 42u: {
        return snprintf(line,capacity,"TXSPAN captured_ms=%lu encoded_ms=%lu boundary_span_us=%lu\r\n",(unsigned long)pcmq.captured*20u,(unsigned long)encoded*20u,(unsigned long)(live.timing.blocks ? live.timing.last_boundary_us-live.timing.started_us : 0));
    }
    case 43u: {
        return snprintf(line,capacity,"LIVE_AUDIO peak=%u mean_abs=%lu clipped=%u mode=%08lx pcm_audio=%08lx rf_audio=%08lx stack_free_bytes=%lu\r\n",
                pcmq.peak,(unsigned long)(pcmq.captured ? pcmq.sum_abs/(pcmq.captured*160u) : 0),pcmq.clipped,
                (unsigned long)pcm_mode,(unsigned long)pcm_audio,(unsigned long)rf_audio,
                (unsigned long)(uxTaskGetStackHighWaterMark(NULL)*sizeof(StackType_t)));
    }
    default:return -1;
    }
}
static void status(void) {
    if(apps_active()) {
        if(applet_owns_radio) {(void)radio_applets_command(&applets,"APP STATUS");return;}
        (void)radio_microapps_command(&microapps,"APP SAME STATUS");return;
    }
    // Queue normal telemetry for bounded output. Even a BUSY reply must not
    // interrupt an active TX/capture on the shared UART/PTT path.
    if(call_active || rx_sampling || command_tx_critical(false)) {
        command_deferred|=COMMAND_DEFER_STATUS;return;
    }
    if(trunk_enabled) {telemetry_request(TELEMETRY_TRUNK);return;}
    command_deferred&=~(COMMAND_DEFER_STATUS|COMMAND_DEFER_BUSY);
    telemetry_request(TELEMETRY_LIVE);
}
#include "p25_telemetry.h"

static const char *message(void) {
    if(radio_busy(&control)) return "RX paused / clear voice";
    if(!strcmp(reason,"invalid_frequency")) return "Invalid value / check digits";
    if(!strcmp(reason,"frequency_saved")) return !strcmp(pref_state,"saved") ? "Setting saved" : "Setting changed / save pending";
    if(!strcmp(reason,"battery_low")) return "Battery too low for TX";
    if(!strcmp(reason,"calibration_invalid")) return "Calibration unavailable";
    if(control.state==RADIO_FAULT) return "Call stopped / see diagnostics";
    if(!strcmp(reason,"complete")) return "Call finished";
    if(!strcmp(reason,"released_before_rf")) return "Call cancelled before RF";
    return !strcmp(pref_state,"saved") ? "Channel settings retained" : "Settings: see diagnostics";
}
static bool mon_sync_active(uint32_t now) {
    return mon_running && mon_have_sync && now-mon_sync_us<400000u;
}
static bool call_selected(const p25_receive_policy *c) {
#if DM32_OMAHA_RX_ONLY
    uint16_t expected_nac=0;
    if(trunk_search.index>=DM32_OMAHA_CONTROL_COUNT
       || !dm32_omaha_candidate(trunk_search.index,trunk_search.config.control_hz[trunk_search.index],
            &expected_nac,NULL,NULL)
       || c->private_call || !c->group_valid || c->group!=3075u || c->nac!=expected_nac)return false;
#endif
    if(trunk_enabled)return trunk.phase==P25_TRUNKING_VOICE && !c->private_call && c->group_valid
        && c->group==trunk.group && c->nac==trunk.learned_nac;
    if(rx_promiscuous)return true;
    if(c->private_call)return c->destination_valid && c->destination==control.source_id;
    return !rx_tg_filter || (c->group_valid && feature_scan_group_allows(c->group));
}
static void call_services_p25(bool boundary) {
    const p25_receive_policy *c=&monitor.call;
    if(boundary)radio_history_end(&heard_calls);
    if(!c->active || !c->lc_valid || !c->source_valid
       || (c->private_call ? !c->destination_valid : !c->group_valid))return;
    radio_heard_call v={.rx_hz=receiver_frequency(),.source=c->source,
        .destination=c->private_call ? c->destination : c->group,.nac=c->nac,
        .protocol=RADIO_PROTOCOL_P25,.kind=c->private_call ? RADIO_CALL_INDIVIDUAL : RADIO_CALL_GROUP,
        .flags=(uint8_t)((trunk_enabled ? RADIO_CALL_TRUNKED : 0u)|(c->emergency ? RADIO_CALL_EMERGENCY : 0u)
            |(c->state==P25_RX_ENCRYPTED ? RADIO_CALL_ENCRYPTED : 0u)
            |(!call_selected(c) || c->state!=P25_RX_CLEAR ? RADIO_CALL_FILTERED : 0u))};
    (void)radio_history_observe(&heard_calls,&v,hal_millis(),false);
}
static void call_services_poll(void) {
    if(normal_mode && feature_dmr() && digital_dmr.running) {
        const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
        if(dv && dv->state==DMR_CALL_STATE_RX
           && (dv->phase==DMR_CALL_PHASE_RX_VOICE || dv->phase==DMR_CALL_PHASE_RX_BUSY)) {
            radio_heard_call v={.rx_hz=frequency,.source=dv->caller.src,.destination=dv->caller.dst,
                .protocol=RADIO_PROTOCOL_DMR,.kind=dv->caller.group ? RADIO_CALL_GROUP : RADIO_CALL_INDIVIDUAL,
                .cc=dv->cc,.ts=dv->ts,
                .flags=(uint8_t)((dv->caller.emergency ? RADIO_CALL_EMERGENCY : 0u)
                    |(dv->caller.encrypted ? RADIO_CALL_ENCRYPTED : 0u)
                    |(dv->phase!=DMR_CALL_PHASE_RX_VOICE ? RADIO_CALL_FILTERED : 0u))};
            bool fresh=!dmr_history_active || dmr_history_start!=dv->call_start_ms;
            if(radio_history_observe(&heard_calls,&v,hal_millis(),fresh)) {
                dmr_history_start=dv->call_start_ms;dmr_history_active=true;
            }
            return;
        }
        radio_history_end(&heard_calls);dmr_history_active=false;
    } else if(!mon_running || !monitor.call.active)radio_history_end(&heard_calls);
}
static void mon_context(char *line,size_t size) {
    const p25_receive_policy *c=&monitor.call;
    if(mon_running && !radio_busy(&control) && !mon_local_tone && !mon_replay && c->active) {
        // This is a redraw key, not display text. Every visible identity and
        // validity flag participates even while encrypted/unsupported/muted.
        unsigned flags=(unsigned)c->source_valid|(unsigned)c->group_valid<<1
            |(unsigned)c->destination_valid<<2|(unsigned)c->emergency<<3
            |(unsigned)c->lc_valid<<4|(unsigned)call_selected(c)<<5;
        snprintf(line,size,"%03X/%u/%u/%06lX/%06lX/%04X/%02X",c->nac,c->state,(unsigned)c->private_call,
            (unsigned long)c->source,(unsigned long)c->destination,c->group,flags);
    }
#if DM32_TRUNK_SUBSCRIBER
    else if(trunk_subscriber_active())snprintf(line,size,"SUB/%u/%u/%lu/%u/%u",
        (unsigned)trunk_session.access.phase,(unsigned)trunk_session.access.reason,
        (unsigned long)receiver_frequency(),(unsigned)trunk.phase,trunk.group);
#endif
    else if(trunk_enabled)snprintf(line,size,"TRUNK/%u/%lu/%03X/%u/%u/%u",(unsigned)trunk.phase,
        (unsigned long)receiver_frequency(),trunk.system_id,trunk.rfss,trunk.site,trunk.group);
    else snprintf(line,size,"%s",tx_fixed ? "FIXED RF TEST / HOLD PTT" : mon_enabled ? (mon_replay ? "20s delay / saved tail once" : mon_local_tone ? "20s unplug delay / 6s tone" : mon_output_tone ? "TEST TONE / decoding active" : mon_audio_enabled ? (rx_promiscuous ? "PROM / all NACs and talkgroups" : "NAC filter / all talkgroups") : "RX audio muted / PC setting") : mon_used ? mon_reason : message());
}
static void ui_meters_poll(void) {
    uint32_t now=hrc_micros(),begin=now;
    bool blocked=call_active || prepared || audio_on || hardware_running || rx_sampling;
    radio_signal_mode mode=blocked ? RADIO_SIGNAL_OFF : digital_dmr.running ? RADIO_SIGNAL_DMR
        : (airband.running && airband.have_status) || (analog_fm.running && analog_fm.have_status) ? RADIO_SIGNAL_FM
        : mon_running && !mon_local_tone && !mon_replay ? RADIO_SIGNAL_P25 : RADIO_SIGNAL_OFF;
    radio_signal_configure(&ui_strength,mode,airband.running ? airband.hz : receiver_frequency(),now);
    ui_rssi_valid=radio_signal_read(&ui_strength,now,NULL);
    if(!ui_rssi_valid)ui_rssi_bars=0;
    if(blocked)return;
    if(!ui_battery_valid || (int32_t)(now-ui_battery_due)>=0) {
        ui_battery_mv=board.power->battery_mv();
        unsigned empty=board.battery_critical_mv ? board.battery_critical_mv : 6400u;
        ui_battery_pct=board.power->battery_pct ? board.power->battery_pct()
            : ui_battery_mv<=empty ? 0 : ui_battery_mv>=8200u ? 100
            : (uint8_t)((ui_battery_mv-empty)*100u/(8200u-empty));
        ui_battery_valid=true;ui_battery_due=now+1000000u;
    }
    if(radio_signal_due(&ui_strength,now) && board.radio->status
       && (!mon_running || mon_count(monitor.raw_head,monitor.raw_tail,MON_RAW_BLOCKS)<4u)
       ) {
        radio_status_t st={0};if(airband.running)st=airband.status;else if(analog_fm.running)st=analog_fm.status;else board.radio->status(&st);
        radio_signal_sample(&ui_strength,now,st.rssi_dbm);
    }
    int16_t strength;
    if(radio_signal_read(&ui_strength,now,&strength)) {
        if(!ui_rssi_valid || abs((int)strength-ui_rssi_dbm)>=2)ui_rssi_dbm=strength;
        ui_rssi_valid=true;ui_signal_us=now;ui_rssi_bars=radio_signal_bars(ui_rssi_dbm);
    } else {
        ui_rssi_valid=false;ui_rssi_bars=0;
    }
    uint32_t elapsed=hrc_micros()-begin;
    if(elapsed>ui_meter_max_us)ui_meter_max_us=elapsed;
}
static const char *home_hint(void) {
    if(DM32_OMAHA_RX_ONLY)return "RX only / TG3075";
    if(cps_link || cps_active)return "Programming / PTT paused";
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_active())return "Experimental trunk / Back stops";
    if(trunk_lab_attach_selected() && !trunk_lab_ptt_selected())return "LAB JOIN / one sequence";
    if(trunk_lab_ptt_selected())return trunk_lab_ptt.phase==P25_LAB_PTT_ARMED
        ? "LAB PTT ARMED / one call":"LAB PTT / stop or rearm";
#endif
    if(trunk_enabled)return "Trunk RX / Back stops";
    if(!strcmp(reason,"trunk_logout_sent"))return "Logout sent / unconfirmed";
    if(!strcmp(reason,"trunk_logout_failed"))return "Logged out locally / not sent";
    if(!strcmp(reason,"trunk_search_failed"))return "Control search stopped / retry";
    if(!strcmp(reason,"trunk_unavailable"))return "Choose a P25 control channel";
    if(!strcmp(reason,"trunk_tune_failed"))return "Trunk tune failed / stopped";
    if(!strcmp(reason,"reply_trunked"))return "Trunked call / receive only";
    if(!strcmp(reason,"reply_channel_mismatch"))return "Reply: select matching channel";
    if(!strcmp(reason,"reply_stop_scan"))return "Stop scan before choosing reply";
    if(!strcmp(reason,"reply_call_muted"))return "Muted call cannot set reply";
    if(!strcmp(reason,"reply_target_saved"))return "Reply destination selected";
    if(!strcmp(reason,"scan_reply_unmatched"))return "Select a channel to reply";
    if(!strcmp(reason,"no_memories"))return "No saved channels";
    if(!strcmp(reason,"channel_read_failed"))return "Channel read failed";
    if(!frequency)return "Set a receive frequency";
    if(radio_busy(&control))return "Release PTT to finish";
    if(ptt_release_required)return "Release PTT before use";
    if(control.state==RADIO_FAULT)return "Open menu to review fault";
    if(radio_lights.locked)return "Locked / hold OK + *";
    if(!strcmp(pref_state,"save_failed"))return "Settings save failed";
    if(!strcmp(pref_state,"read_only"))return "Settings are read-only";
    if(!strcmp(reason,"empty_scan_list"))return "Scan list is empty";
    if(!strcmp(reason,"memory_saved"))return "Channel saved";
    if(!strcmp(reason,"channel_empty"))return "Channel is empty";
    if(feature_dmr() && digital_dmr.diagnostics.result==RADIO_DMR_TX_FAILED) {
        switch(digital_dmr.tx_error) {
        case DMR_TX_ERR_BUSY:return "Channel busy / try again";
        case DMR_TX_ERR_NO_REPEATER:return "Repeater did not answer";
        case DMR_TX_ERR_TIMEOUT:return "Transmit time limit";
        case DMR_TX_ERR_STALLED:return "Modem stalled / see Info";
        default:return "Call refused / see Info";
        }
    }
    return control.tx_enabled ? "" : "Transmit disabled";
}
static unsigned ui_lab_call_stage(void) {
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_active()) {
        switch(trunk_session.access.phase) {
        case P25_TRUNK_ACCESS_REQUEST:return P25_UI_CALL_REQUEST;
        case P25_TRUNK_ACCESS_WAIT_GRANT:return P25_UI_CALL_WAIT_GRANT;
        case P25_TRUNK_ACCESS_GRANTED:return hardware_running && pa_started ? P25_UI_CALL_VOICE:P25_UI_CALL_STARTING;
        case P25_TRUNK_ACCESS_DRAIN:return hardware_running && pa_started ? P25_UI_CALL_DRAIN:P25_UI_CALL_RETURN;
        case P25_TRUNK_ACCESS_RETURN:return P25_UI_CALL_RETURN;
        default:return P25_UI_CALL_NONE;
        }
    }
    bool receiving=normal_mode && feature_p25() && mon_running && !mon_control_only
        && !mon_local_tone && !mon_replay && monitor.call.active;
    if(trunk_lab_ptt_selected()) {
        switch(trunk_lab_ptt.phase) {
        case P25_LAB_PTT_ARMED:return receiving ? P25_UI_CALL_NONE:P25_UI_CALL_READY;
        case P25_LAB_PTT_REQUEST:
            return trunk_lab_exchange.owner.sequence==trunk_lab_ptt.owner.sequence
                && (trunk_lab_exchange.phase==P25_LAB_PREPARED || trunk_lab_exchange.phase==P25_LAB_TX_ACTIVE)
                ? P25_UI_CALL_REQUEST:P25_UI_CALL_WAIT_GRANT;
        case P25_LAB_PTT_GRANTED:return P25_UI_CALL_STARTING;
        case P25_LAB_PTT_VOICE:return hardware_running && pa_started ? P25_UI_CALL_VOICE:P25_UI_CALL_RETURN;
        case P25_LAB_PTT_DRAIN:return hardware_running && pa_started ? P25_UI_CALL_DRAIN:P25_UI_CALL_RETURN;
        case P25_LAB_PTT_RETURN:return P25_UI_CALL_RETURN;
        default:return receiving ? P25_UI_CALL_NONE:P25_UI_CALL_FINISHED;
        }
    }
    if(trunk_lab_attach_selected())return trunk_lab_attach.phase>=P25_LAB_ATTACH_ARMED
        ? receiving ? P25_UI_CALL_NONE:P25_UI_CALL_FINISHED:P25_UI_CALL_REQUEST;
#endif
    return P25_UI_CALL_NONE;
}
static const char *ui_state_label(void) {
#if DM32_TRUNK_SUBSCRIBER
    if(passive_receive_recovery.pending)return "Recovering receiver";
#endif
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_system_logout_requested||trunk_subscriber_logout_pending())return "Logging out";
    if(trunk_subscriber_active()&&trunk_session.access.phase==P25_TRUNK_ACCESS_FAILED) {
        unsigned failure=trunk_session.access.reason;
        return failure==P25_TRUNK_ACCESS_DENIED ? "Access denied"
            : failure==P25_TRUNK_ACCESS_AUTH ? "Authentication unsupported"
            : failure==P25_TRUNK_ACCESS_SITE_LOST ? "Control channel lost"
            : failure==P25_TRUNK_ACCESS_TRANSPORT ? "Trunk request failed":"System unavailable";
    }
    if(trunk_subscriber_receive_restoring())return "Returning to control";
    if(trunk_system_overlay_owned&&trunk_search.phase!=P25_TRUNK_SEARCH_LOCKED
       &&trunk_search.phase!=P25_TRUNK_SEARCH_PAUSED)return "Searching control channels";
    // Following a received call retains affiliation. Let its actual receive
    // policy supply clear/encrypted/filtered labels instead of idle READY.
    if(trunk_subscriber_active()&&!trunk_subscriber_receive_following()) {
        const p25_trunking_access *access=&trunk_session.access;
        if(access->queued)return "Queued / waiting for system";
        switch(access->phase) {
        case P25_TRUNK_ACCESS_WAIT_SITE:return "Searching for system";
        case P25_TRUNK_ACCESS_REGISTER:case P25_TRUNK_ACCESS_WAIT_REG:return "Registering";
        case P25_TRUNK_ACCESS_AFFILIATE:case P25_TRUNK_ACCESS_WAIT_AFF:return "Joining talkgroup";
        case P25_TRUNK_ACCESS_READY:return access->release_required ? "Release PTT before use":"Affiliated / ready";
        case P25_TRUNK_ACCESS_REQUEST:return "Requesting channel";
        case P25_TRUNK_ACCESS_WAIT_GRANT:return "Waiting for grant";
        case P25_TRUNK_ACCESS_GRANTED:return hardware_running && pa_started ? "Microphone active":"Speak at red TX light";
        case P25_TRUNK_ACCESS_DRAIN:return "Finishing call";
        case P25_TRUNK_ACCESS_RETURN:return "Returning to control";
        default:break;
        }
    }
    unsigned lab_stage=ui_lab_call_stage();
    if(lab_stage && trunk_lab_attach_selected() && !trunk_lab_ptt_selected())
        return lab_stage==P25_UI_CALL_FINISHED ? "Lab join finished":"Lab join in progress";
    if(lab_stage && trunk_lab_ptt_selected()) {
        if(trunk_lab_ptt.phase==P25_LAB_PTT_ARMED)return "LAB PTT ARMED";
        if(trunk_lab_ptt.phase==P25_LAB_PTT_REQUEST)return ui_lab_call_stage()==P25_UI_CALL_REQUEST
            ? "Requesting channel":"Wait for grant";
        if(trunk_lab_ptt.phase==P25_LAB_PTT_GRANTED)return "Grant accepted";
        if(trunk_lab_ptt.phase==P25_LAB_PTT_VOICE)return hardware_running && pa_started
            ? "Microphone active":"Returning to control";
        if(trunk_lab_ptt.phase==P25_LAB_PTT_DRAIN)return "Finishing lab call";
        if(trunk_lab_ptt.phase==P25_LAB_PTT_RETURN)return "Returning to control";
        return "Lab call finished";
    }
#endif
    if(control.state==RADIO_TX_DRAIN)return "Finishing call";
    if(radio_busy(&control))return "Voice call";
    if(control.state==RADIO_FAULT)return feature_dmr() && digital_dmr.error==RADIO_DMR_NO_CODEC ? "AMBE codec required" : "Radio fault / see Info";
    if(control.state==RADIO_RX_RESTORE)return "Returning to receive";
    if(control.state==RADIO_RX_PAUSED)return "Receive paused";
    if(!frequency)return "Set your frequency";
    if(cps_link || cps_active)return "Programming";
    if(trunk_enabled && trunk.phase==P25_TRUNKING_CONTROL)
        return mon_sync_active(hrc_micros()) ? "Control channel locked" : "Control channel search";
    if(normal_mode && feature_dmr()) {
        if(digital_dmr.error==RADIO_DMR_NO_CODEC)return "AMBE codec required";
        const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
        if(dv && dv->state==DMR_CALL_STATE_RX) {
            if(dv->phase!=DMR_CALL_PHASE_RX_VOICE && dv->phase!=DMR_CALL_PHASE_RX_BUSY)return "DMR data activity";
            return dv->caller.encrypted ? "Encrypted / muted"
                : dv->phase==DMR_CALL_PHASE_RX_BUSY ? "Call filtered" : "Receiving DMR";
        }
        return channel_scan.running ? "CH SCAN / DMR" : "DMR listening";
    }
    if(normal_mode && feature_fm())return analog_fm.audio_open ? "Receiving FM" : channel_scan.running ? "CH SCAN / FM" : "FM listening";
    if(monitor.call.active && monitor.call.lc_valid && monitor.call.source_valid && !call_selected(&monitor.call))return monitor.call.private_call ? "Individual call filtered" : "Talkgroup filtered";
    if(channel_scan.running && !mon_have_sync)return feature_scan_tg() ? "TG SCAN / listening" : "CH SCAN / listening";
    if(!mon_enabled)return normal_mode ? "Receive unavailable" : "Bench mode";
    if(mon_local_tone)return "Local speaker test";
    if(mon_replay)return "Saved audio playback";
    if(mon_output_tone)return "Decoder tone test";
    if(trunk_enabled && !monitor.call.active)return "Voice channel search";
    if(mon_running && monitor.call.active) {
        switch(monitor.call.state) {
        case P25_RX_CLEAR:return "Receiving voice";
        case P25_RX_ENCRYPTED:return "Encrypted / muted";
        case P25_RX_UNSUPPORTED:return "Unsupported / muted";
        case P25_RX_BAD_METADATA:return "Signal not decoded";
        default:return "Identifying call...";
        }
    }
    return "Listening";
}
static void ui_header_fields(p25_ui_view *v,unsigned phase) {
    v->battery_pct=ui_battery_pct;v->battery_low=ui_battery_valid && (ui_battery_pct<=15u
        || (board.battery_low_mv && ui_battery_mv<=board.battery_low_mv));
    v->rssi_valid=(airband.running || mon_running || analog_fm.running || digital_dmr.running) && ui_rssi_valid
        && radio_signal_read(&ui_strength,hrc_micros(),NULL);
    v->rssi_bars=ui_rssi_bars;v->phase=(uint8_t)phase;
    v->unread_message=radio_mail_unread(&mailbox)!=0;
}
static p25_ui_view ui_view(unsigned phase) {
    const p25_receive_policy *c=&monitor.call;
    p25_ui_view v={0};
    v.call_stage=(uint8_t)ui_lab_call_stage();
    v.tx_active=v.call_stage ? (v.call_stage==P25_UI_CALL_VOICE || v.call_stage==P25_UI_CALL_DRAIN)
        && hardware_running && pa_started : radio_busy(&control);
    v.display_hz=v.tx_active ? control.tx_frequency : receiver_frequency();
    v.receive_hz=receiver_frequency();v.trunking=trunk_enabled;
    v.tx_frequency=control.tx_frequency;v.split=control.split;
    if(trunk_enabled)v.split=false;
    v.tx_nac=control.nac;v.tx_group=radio_channel_get_private(channel_record) ? radio_channel_get_destination(channel_record) : control.talkgroup;v.tx_source=control.source_id;
    v.private_call=radio_channel_get_private(channel_record);
    ui_header_fields(&v,phase);
    if(!normal_mode || feature_p25()) {
        v.rx_active=mon_running && !v.tx_active && !v.call_stage && !mon_local_tone && !mon_replay && c->active;
        v.rx_nac=c->nac;v.rx_group=c->private_call ? c->destination : c->group;v.rx_source=c->source;
        if(v.rx_active)v.private_call=c->private_call;
        v.emergency=v.rx_active && c->lc_valid && c->emergency;
        v.rx_group_valid=c->private_call ? c->destination_valid : c->group_valid;v.rx_source_valid=c->source_valid;
        v.rx_muted=c->state!=P25_RX_CLEAR || !call_selected(c);
    }
    v.mode_am=airband_show;
    v.mode_fm=!airband_show && normal_mode && feature_fm();v.mode_dmr=!airband_show && normal_mode && feature_dmr();
    v.wide_fm=(channel_record[12]&32u)!=0;v.locked=radio_lights.locked;
    v.scanning=channel_scan.running;v.tg_scanning=feature_scan_tg();v.channel_label=channel_label;v.squelch=channel_record[30];
    v.active_side=(uint8_t)feature_vfo();v.channel_mode=feature_memory()!=0 || channel_scan.running;
    v.channel_number=(uint16_t)(channel_scan.running ? channel_scan.cursor+1u : feature_memory());v.channel_name=(const char *)channel_record+14;
    if(channel_scan.running && feature_p25() && feature_scan_received_slot()) {
        v.channel_number=(uint16_t)feature_scan_received_slot();
        if(feature_scan_tg() || v.channel_number!=channel_scan.cursor+1u) {
            snprintf(scan_received_label,sizeof scan_received_label,"TG %u",feature_scan_received_group());
            v.channel_name=scan_received_label;
        }
    }
    v.tone=feature_u16(channel_record+(v.tx_active ? 26 : 28));
    if(v.mode_fm) {v.phase=analog_fm.audio_open ? 2 : 0;v.rx_active=analog_fm.audio_open;v.rx_muted=false;}
    if(v.mode_dmr) {
        const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
        v.tx_group=radio_channel_get_destination(channel_record);
        v.cc=(uint8_t)radio_channel_get_color_code(channel_record);v.ts=(uint8_t)radio_channel_get_timeslot(channel_record);
        v.private_call=radio_channel_get_private(channel_record);v.rx_active=dv && dv->state==DMR_CALL_STATE_RX
            && (dv->phase==DMR_CALL_PHASE_RX_VOICE || dv->phase==DMR_CALL_PHASE_RX_BUSY);
        v.rx_group_valid=v.rx_source_valid=v.rx_active;v.rx_muted=false;v.phase=0;
        if(dv) {
            v.phase=dv->phase==DMR_CALL_PHASE_RX_VOICE && v.rx_active && !dv->caller.encrypted ? 2 : dv->state==DMR_CALL_STATE_RX ? 1 : 0;
            v.rx_muted=v.rx_active && (dv->caller.encrypted || dv->phase!=DMR_CALL_PHASE_RX_VOICE);
            if(v.rx_active) {v.rx_group=dv->caller.dst;v.rx_source=dv->caller.src;v.emergency=dv->caller.emergency;
                v.cc=dv->cc;v.ts=dv->ts;v.private_call=!dv->caller.group;}
        }
    }
    if(!v.mode_fm && !v.mode_am) {
        unsigned protocol=v.mode_dmr ? RADIO_PROTOCOL_DMR : RADIO_PROTOCOL_P25;
        bool receiving=v.rx_active && !v.tx_active;
        (void)radio_contact_name(call_contacts,RADIO_CONTACT_CAPACITY,protocol,RADIO_CALL_INDIVIDUAL,
            receiving ? v.rx_source : v.tx_source,ui_source_name);
        (void)radio_contact_name(call_contacts,RADIO_CONTACT_CAPACITY,protocol,
            v.private_call ? RADIO_CALL_INDIVIDUAL : RADIO_CALL_GROUP,receiving ? v.rx_group : v.tx_group,ui_target_name);
        v.source_name=ui_source_name;v.target_name=ui_target_name;
    }
    v.debug_active=!normal_mode || tx_fixed || mon_local_tone || mon_replay || mon_output_tone
        || !mon_pcm_backend || !mon_audio_enabled || tx_writer!=TX_WRITER_ALT1 || !tx_dac_restore;
    v.state=ui_state_label();v.hint=home_hint();v.filter=rx_promiscuous ? "PROM" : rx_tg_filter ? (v.mode_dmr ? "CC+ID" : "NAC+TG") : v.mode_dmr ? "CC" : "NAC filter";
    if(trunk_enabled)v.filter="TRUNK";
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_system_overlay_owned) {
        v.channel_name=trunk_system_name;v.channel_mode=true;v.channel_number=global_record[28];
    }
    if(trunk_subscriber_active()) {v.filter="TRUNK / EXP";v.debug_active=true;}
#endif
    return v;
}
static void ui_lab_transition_poll(void) {
#if DM32_TRUNK_SUBSCRIBER
    static uint8_t shown;
    unsigned stage=ui_lab_call_stage();
    if(!stage) {shown=0;return;}
    if(stage==shown || !display_ok || !trunk_lab_ptt_selected() || editing || menu_open || rx_lab
       || cps_link || cps_active || apps_active() || trunk_probe.active || trunk_preload_warmed()
       || hardware_running || audio_on || rx_sampling || pcmq.count
       || (stage!=P25_UI_CALL_STARTING && mon_running && monitor.raw_head!=monitor.raw_tail))return;
    // One task-side transition, never an ISR or active-MIC/LCD workload. In
    // particular GRANTED clears WAIT before microphone/RF startup; VOICE and
    // DRAIN redraws may remain deferred until RF ends. No timing gates change.
    uint32_t start=hrc_micros();p25_ui_view v=ui_view(0);
    // This explicit lab transition already requires RF/MIC off. Preserve its
    // pre-RF preview instead of leaving a queued WAIT visible throughout TX.
    bool deferred=radio_gfx_deferred();radio_gfx_defer(false);
    gfx_frame_begin();p25_ui_header(&v);gfx_flush();
    gfx_frame_begin();p25_ui_call_badge(&v);gfx_flush();
    gfx_frame_begin();p25_ui_call_state(&v);gfx_flush();
    radio_gfx_defer(deferred);
    shown=(uint8_t)stage;
    uint32_t elapsed=hrc_micros()-start;if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
#endif
}
static uint32_t ui_header_token(const p25_ui_view *v) {
    return v->battery_pct | (uint32_t)v->battery_low<<7 | (uint32_t)v->rssi_bars<<8
        | (uint32_t)v->rssi_valid<<11 | (uint32_t)v->phase<<12 | (uint32_t)v->unread_message<<15;
}
static uint32_t ui_header_token_now(unsigned phase) {
    // Header identity must not resolve caller/contact names on an unchanged
    // controller pass. Share its fields with the full view to prevent drift.
    p25_ui_view header={0};ui_header_fields(&header,phase);return ui_header_token(&header);
}
static void mon_badge(const p25_ui_view *v) {
    p25_ui_header(v);ui_header_shown=ui_header_token(v);
}
enum {MON_RENDER_HEADER=1u,MON_RENDER_CALL=2u,MON_RENDER_ROWS=4u};
static struct {
    p25_ui_view view;
    char source_name[25],target_name[25],context[48];
    uint32_t token;
    uint16_t cursor;
    uint8_t phase,bands;
    bool active,rescan;
} mon_render;
static void mon_render_cancel(void) {
    if(!mon_render.active)return;
    memset(&mon_render,0,sizeof mon_render);
    // These identify the latest queued snapshot, not completed panel output.
    // A cancelled partial snapshot must be requested afresh on return to RX.
    mon_shown_context[0]=0;mon_badge_phase=255u;ui_header_shown=UINT32_MAX;
}
#if DM32_TRUNK_SUBSCRIBER
static void ui_subscriber_grant_preview(void) {
    if(!display_ok || !trunk_subscriber_active() || !trunk_subscriber_voice_owned()
       || trunk_session.access.phase!=P25_TRUNK_ACCESS_GRANTED
       || hardware_running || audio_on || call_active || mon_running || rx_sampling
       || editing || menu_open || rx_lab || cps_link || cps_active || apps_active())return;
    // Commit a grant cue that stays useful while active voice pauses the LCD.
    // The TX light follows admitted hardware in normal_tick; this preview must
    // not claim microphone/RF activity before the final admission checks pass.
    uint32_t start=hrc_micros();mon_render_cancel();p25_ui_view view=ui_view(0);
    bool deferred=radio_gfx_deferred();radio_gfx_defer(false);
    gfx_frame_begin();p25_ui_header(&view);gfx_flush();
    gfx_frame_begin();p25_ui_call_badge(&view);gfx_flush();
    gfx_frame_begin();p25_ui_call_state(&view);gfx_flush();
    radio_gfx_defer(deferred);
    uint32_t elapsed=hrc_micros()-start;if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
}
#endif
static bool mon_render_allowed(void) {
    if(!display_ok || !mon_running || mon_control_only || !radio_gfx_deferred()
       || editing || menu_open || rx_lab || cps_link || cps_active || apps_active()
       || call_active || prepared || hardware_running || audio_on || rx_sampling
       || digital_dmr.tx_armed || digital_dmr.data_armed || (normal_mode&&!feature_p25()))return false;
    if(controller_runtime_owned())return false;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_stream_owned || trunk_rx_progress_owned || trunk_rx_feed_terminal()
       || trunk_probe.active || trunk_preload_warmed() || trunk_lab_return_defer_ui())return false;
#endif
    return true;
}
static void mon_render_request(const p25_ui_view *v,const char *context,
                               unsigned phase,uint32_t token,unsigned bands) {
    if(mon_render.active) {
        if(((bands&MON_RENDER_HEADER)&&mon_render.cursor>P25_UI_HEADER_Y)
           ||((bands&MON_RENDER_CALL)&&mon_render.cursor>P25_UI_CALL_Y))mon_render.rescan=true;
        mon_render.bands|=(uint8_t)bands;
    } else {
        mon_render.cursor=(uint16_t)((bands&MON_RENDER_HEADER)?P25_UI_HEADER_Y:P25_UI_CALL_Y);
        mon_render.bands=(uint8_t)bands;mon_render.rescan=false;mon_render.active=true;
    }
    // ui_view uses shared name buffers. A later menu/history view may reuse
    // those buffers while this snapshot is waiting for its next paint stripe.
    snprintf(mon_render.source_name,sizeof mon_render.source_name,"%.24s",v->source_name?v->source_name:"");
    snprintf(mon_render.target_name,sizeof mon_render.target_name,"%.24s",v->target_name?v->target_name:"");
    mon_render.view=*v;mon_render.view.source_name=mon_render.source_name;
    mon_render.view.target_name=mon_render.target_name;
    snprintf(mon_render.context,sizeof mon_render.context,"%s",context);
    mon_render.token=token;mon_render.phase=(uint8_t)phase;
    snprintf(mon_shown_context,sizeof mon_shown_context,"%s",context);
    mon_badge_phase=(uint8_t)phase;ui_header_shown=token;
}
static void mon_render_step(void) {
    if(!mon_render.active)return;
    controller_receive_checkpoint();
    if(!mon_render_allowed() || mon_render.view.receive_hz!=receiver_frequency()) {mon_render_cancel();return;}
    unsigned y=mon_render.cursor;
    if(y>=P25_UI_HEADER_H && y<P25_UI_CALL_Y)y=P25_UI_CALL_Y;
    bool header=y<P25_UI_HEADER_H;
    unsigned end=header?P25_UI_HEADER_H:P25_UI_CALL_Y+P25_UI_CALL_H;
    unsigned rows=end-y;if(rows>MON_RENDER_ROWS)rows=MON_RENDER_ROWS;
    uint32_t start=hrc_micros();
    gfx_clip(0,(int)y,gfx_width(),(int)rows);gfx_frame_begin();
    if(header)p25_ui_header(&mon_render.view);else p25_ui_call(&mon_render.view);
    gfx_clip_off();gfx_flush();
    uint32_t elapsed=hrc_micros()-start;
#if DM32_TRUNK_SUBSCRIBER
    trunk_rx_feed_ui_cost(true,elapsed);
#endif
    if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
    mon_render.cursor=(uint16_t)(y+rows);
    if(mon_render.cursor==P25_UI_HEADER_H) {
        if(mon_render.bands&MON_RENDER_CALL)mon_render.cursor=P25_UI_CALL_Y;
        else mon_render.cursor=P25_UI_CALL_Y+P25_UI_CALL_H;
    }
    if(mon_render.cursor==P25_UI_CALL_Y+P25_UI_CALL_H) {
        if(mon_render.rescan) {
            mon_render.cursor=(uint16_t)((mon_render.bands&MON_RENDER_HEADER)?P25_UI_HEADER_Y:P25_UI_CALL_Y);
            mon_render.rescan=false;
        } else mon_render.active=false;
    }
    controller_receive_checkpoint();
    if(!mon_render_allowed())mon_render_cancel();
}
static void mon_indicator(void) {
    if(mon_control_only) {mon_render_cancel();return;}
    uint32_t now=hrc_micros();bool synced=mon_sync_active(now);
    bool voice=synced && mon_voice_us && now-mon_voice_us<400000u;
    unsigned phase=voice ? 2u : synced ? 1u : 0u;
    radio_receive_state(&control,mon_enabled,mon_running,synced,voice);
    board.power->led(LED_GREEN,synced);
#if DM32_TRUNK_SUBSCRIBER
    // A finite timing comparison must not block its sole packet consumer on
    // synchronous LCD transfers. Keep state/LED updates live; redraw on release.
    if(trunk_rx_feed_defer_display()) {mon_render_cancel();return;}
#endif
    bool cooperative=radio_gfx_deferred();
    if(cooperative&&!mon_render_allowed()) {mon_render_cancel();return;}
    if(!display_ok || !mon_running) {mon_render_cancel();return;}
    if(!cooperative)mon_render_cancel();
    char context[48];mon_context(context,sizeof context);
    bool context_changed=strcmp(context,mon_shown_context)!=0;
    uint32_t token=ui_header_token_now(phase);
    bool phase_changed=phase!=mon_badge_phase;
    if(!phase_changed && !context_changed && token==ui_header_shown) {
        if(cooperative)mon_render_step();
        return;
    }
    // Only changed header/call bands resolve names or draw. Include view
    // construction in this elapsed observation; it is controller work too.
    controller_receive_checkpoint();
    if(!mon_running || (cooperative&&!mon_render_allowed())) {mon_render_cancel();return;}
    uint32_t start=hrc_micros();p25_ui_view v=ui_view(phase);
    if(cooperative) {
        unsigned bands=(token!=ui_header_shown?MON_RENDER_HEADER:0u)
            |(context_changed||phase_changed?MON_RENDER_CALL:0u);
        mon_render_request(&v,context,phase,token,bands);
        uint32_t elapsed=hrc_micros()-start;
#if DM32_TRUNK_SUBSCRIBER
        trunk_rx_feed_ui_cost(false,elapsed);
#endif
        if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
        controller_receive_checkpoint();
        if(!mon_render_allowed()) {mon_render_cancel();return;}
        mon_badge_sync=synced;mon_render_step();return;
    }
    controller_receive_checkpoint();if(!mon_running)return;gfx_frame_begin();
    if(token!=ui_header_shown)mon_badge(&v);
    if(context_changed || phase_changed) {
        p25_ui_call(&v);snprintf(mon_shown_context,sizeof mon_shown_context,"%s",context);
    }
    gfx_flush();uint32_t elapsed=hrc_micros()-start;
    if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
    mon_badge_sync=synced;mon_badge_phase=phase;controller_receive_checkpoint();
}
static void dmr_indicator(void) {
    if(!display_ok || !digital_dmr.running || menu_open || editing || rx_lab || cps_link || cps_active)return;
    if(digital_dmr.tx_armed || digital_dmr.data_armed) {dmr_ui_pending=true;return;}
    const dmr_call_view_t *dv=radio_dmr_view(&digital_dmr);
    if(!dv)return;
    uint32_t now=hrc_micros();
    p25_ui_view v=ui_view(0);uint32_t token=ui_header_token(&v);
    if(!dmr_ui_pending && dv->serial==dmr_ui_serial && token==ui_header_shown)return;
    if(!dmr_ui_pending && (int32_t)(now-dmr_ui_due)<0)return;
    // Encoding and IRQs running at higher priority do not feed the native
    // call queue: this controller does. Flush only before/after transmission.
    uint32_t start=hrc_micros();
    gfx_frame_begin();p25_ui_header(&v);p25_ui_channel(&v);p25_ui_call(&v);p25_ui_hint(&v);gfx_flush();
    radio_dmr_cost_record(&dmr_ui_cost,hrc_micros()-start);
    ui_header_shown=token;dmr_ui_serial=dv->serial;dmr_ui_due=now+100000u;
    dmr_ui_pending=false;
}
static void dmr_tx_preview(void) {
    if(!display_ok)return;
    p25_ui_view v=ui_view(0);
    v.tx_active=true;v.rx_active=false;v.phase=0;v.rssi_valid=false;
    v.cc=(uint8_t)radio_channel_get_color_code(channel_record);
    v.ts=(uint8_t)radio_channel_get_timeslot(channel_record);
    v.private_call=radio_channel_get_private(channel_record);
    v.display_hz=control.tx_frequency;v.state="Voice call";v.hint="";
    // The existing preview runs before native TX admission, with RF/MIC off.
    // Keep it visible before the feeder starts; never service queued stripes
    // after native voice/data TX is armed.
    uint32_t start=hrc_micros();bool deferred=radio_gfx_deferred();radio_gfx_defer(false);
    gfx_frame_begin();p25_ui_header(&v);p25_ui_channel(&v);p25_ui_call(&v);p25_ui_hint(&v);gfx_flush();
    radio_gfx_defer(deferred);
    radio_dmr_cost_record(&dmr_ui_cost,hrc_micros()-start);
    // The preview has no matching RX serial/token. Always restore the newest
    // idle/RX view, even if PTT was released before the native call began.
    dmr_ui_pending=true;
}
static const char *function_name(unsigned action) {
    static const char *const names[]={"Default","Disabled","Frequency / Channel","Side A / B","Scan","Cycle power","Broadcast FM","Radio status","Keypad lock","Last heard"};
    return action<RADIO_FUNCTION_COUNT ? names[action] : "Disabled";
}
static const char *power_name(void) {
    unsigned level=feature_tx_power();
    return board.power_names && level<board.power_count ? board.power_names[level] : "Unavailable";
}
static void power_cycle(void) {
    unsigned count=board.power_count<RADIO_POWER_LEVELS ? board.power_count : RADIO_POWER_LEVELS;
    if(count && radio_functions_set_power(channel_record,(feature_tx_power()+1u)%count))pref_state="pending";
}
static unsigned menu_count(void) {if(DM32_OMAHA_RX_ONLY)return 4u;return message_menu_active() ? message_menu_count() : menu_page==MENU_HISTORY ? heard_calls.count+1u
    : menu_page==MENU_TRUNK_ACTIVE ? 3u : menu_page==MENU_TRUNK ? 6u : menu_page==MENU_TRUNK_SYSTEMS ? P25_CS_TRUNK_SYSTEMS+1u
    : menu_page==MENU_HEARD_CALL ? 7u
    : menu_page==MENU_VOICE ? (feature_fm() ? 3u : 4u) : menu_page==MENU_MEMORY ? 9u : menu_page==MENU_ROOT ? 5u
    : menu_page==MENU_CHANNEL ? 8u : menu_page==MENU_FUNCTIONS || menu_page==MENU_DMR ? 4u
    : menu_page==MENU_AUDIO_TX || menu_page==MENU_SETTINGS ? 2u
    : menu_page==MENU_TOOLS ? 3u : menu_page==MENU_APPLETS ? 10u : menu_page==MENU_SAME_CHANNELS ? 7u
    : menu_page==MENU_RECEIVERS ? 5u : menu_page==MENU_FM ? 6u
    : menu_page==MENU_DIAGNOSTICS && !DM32_LAB_DIAGNOSTICS ? 1u : 3u;}
// Each leaf has one fixed parent; Back restores the item that opened it.
static void menu_back(void) {
    switch(menu_page) {
    case MENU_TRUNK:menu_page=MENU_MEMORY;menu_item=8;break;
    case MENU_TRUNK_SYSTEMS:menu_page=MENU_TRUNK;menu_item=0;break;
    case MENU_HISTORY:menu_page=MENU_MEMORY;menu_item=6;break;
    case MENU_HEARD_CALL:menu_page=MENU_HISTORY;menu_item=heard_selection;break;
    case MENU_MESSAGES:menu_page=MENU_MEMORY;menu_item=7;break;
    case MENU_MEMORY:menu_page=MENU_ROOT;menu_item=0;break;
    case MENU_CHANNEL:menu_page=MENU_ROOT;menu_item=1;break;
    case MENU_AUDIO_TX:menu_page=MENU_ROOT;menu_item=2;break;
    case MENU_SETTINGS:menu_page=MENU_ROOT;menu_item=3;break;
    case MENU_TOOLS:menu_page=MENU_ROOT;menu_item=4;break;
    case MENU_SCAN:menu_page=MENU_MEMORY;menu_item=4;break;
    case MENU_VOICE:menu_page=MENU_AUDIO_TX;menu_item=0;break;
    case MENU_TRANSMIT:menu_page=MENU_AUDIO_TX;menu_item=1;break;
    case MENU_DISPLAY:menu_page=MENU_SETTINGS;menu_item=0;break;
    case MENU_FUNCTIONS:menu_page=MENU_SETTINGS;menu_item=1;break;
    case MENU_DIAGNOSTICS:menu_page=MENU_TOOLS;menu_item=1;break;
    case MENU_RECEIVERS:menu_page=MENU_TOOLS;menu_item=0;break;
    case MENU_APPLETS:menu_page=MENU_TOOLS;menu_item=2;break;
    case MENU_SAME_CHANNELS:menu_page=MENU_APPLETS;menu_item=0;break;
    case MENU_FM:case MENU_DMR:menu_page=MENU_CHANNEL;menu_item=5;break;
    default:menu_open=false;break;
    }
}
static void menu_row(unsigned item,char *label,size_t label_n,char *value,size_t value_n) {
    label[0]=value[0]=0;
#if DM32_OMAHA_RX_ONLY
    static const char *const omaha_menu_names[]={"Screen off after","Keypad light","Lock keypad","Fixed receiver"};
    snprintf(label,label_n,"%s",omaha_menu_names[item%4u]);
    if(item<2u) {
        unsigned seconds=item ? radio_lights.keypad_seconds:radio_lights.screen_seconds;
        if(seconds)snprintf(value,value_n,"%u seconds / select next",seconds);
        else snprintf(value,value_n,"Always on / select next");
    } else snprintf(value,value_n,"%s",item==2u ? "Hold OK + * to unlock":"Omaha sites / TG3075 / RX only");
    return;
#endif
    if(message_menu_active()) {message_menu_row(item,label,label_n,value,value_n);return;}
    if(menu_page==MENU_HISTORY) {
        const radio_heard_call *c=radio_history_get(&heard_calls,item);
        if(!c) {snprintf(label,label_n,"%s",heard_calls.count ? "Clear history" : "No calls heard yet");
            snprintf(value,value_n,"%s",heard_calls.count ? "This power session only" : "P25 and DMR calls appear here");return;}
        char name[25];(void)radio_contact_name(call_contacts,RADIO_CONTACT_CAPACITY,c->protocol,RADIO_CALL_INDIVIDUAL,c->source,name);
        if(name[0])snprintf(label,label_n,"%s",name);else snprintf(label,label_n,"ID %lu",(unsigned long)c->source);
        snprintf(value,value_n,"%s %s %lu%s",c->protocol==RADIO_PROTOCOL_P25 ? "P25" : "DMR",c->kind ? "TO" : "TG",
            (unsigned long)c->destination,c->flags&RADIO_CALL_EMERGENCY ? " / EMERGENCY" : "");return;
    } else if(menu_page==MENU_HEARD_CALL) {
        const radio_heard_call *c=radio_history_get(&heard_calls,heard_selection);
        if(!c) {snprintf(label,label_n,"Call no longer available");return;}
        const char *names[]={"Caller","Destination","Received on","Access code","Duration / age","Call details","Use reply target"};
        snprintf(label,label_n,"%s",names[item]);char name[25];
        if(item<2) {
            uint32_t id=item ? c->destination : c->source;
            (void)radio_contact_name(call_contacts,RADIO_CONTACT_CAPACITY,c->protocol,item ? c->kind : RADIO_CALL_INDIVIDUAL,id,name);
            if(name[0])snprintf(value,value_n,"%lu / %.24s",(unsigned long)id,name);
            else snprintf(value,value_n,"%s %lu",item ? (c->kind ? "TO" : "TG") : "ID",(unsigned long)id);
        } else if(item==2)snprintf(value,value_n,"%lu.%06lu MHz / %s",(unsigned long)(c->rx_hz/1000000u),
            (unsigned long)(c->rx_hz%1000000u),c->protocol==RADIO_PROTOCOL_P25 ? "P25" : "DMR");
        else if(item==3) {
            if(c->protocol==RADIO_PROTOCOL_P25)snprintf(value,value_n,"NAC %03X",c->nac);
            else snprintf(value,value_n,"Color code %u / Slot %u",c->cc,c->ts);
        } else if(item==4)snprintf(value,value_n,"%lu.%lus / %lus ago",(unsigned long)((c->last_ms-c->start_ms)/1000u),
            (unsigned long)((c->last_ms-c->start_ms)%1000u/100u),(unsigned long)((hal_millis()-c->last_ms)/1000u));
        else if(item==5)snprintf(value,value_n,"%s%s",c->flags&RADIO_CALL_EMERGENCY ? "EMERGENCY / " : "",
            c->flags&RADIO_CALL_ENCRYPTED ? "Encrypted" : c->flags&RADIO_CALL_FILTERED ? "Filtered / muted" : "Clear voice");
        else snprintf(value,value_n,"%s",c->flags&RADIO_CALL_TRUNKED ? "Trunked / receive only" : c->kind ? "Reply to caller / current channel" : "Reply to group / current channel");
        return;
    } else if(menu_page==MENU_TRUNK_ACTIVE) {
        const char *names[]={"Resume","Log out and stop","Stop now"};
        const char *values[]={"Return to control channel","Send logout / unconfirmed","Cancel immediately / no logout"};
        snprintf(label,label_n,"%s",names[item]);snprintf(value,value_n,"%s",values[item]);
    } else if(menu_page==MENU_TRUNK_SYSTEMS) {
        if(!item) {snprintf(label,label_n,"Current channel");snprintf(value,value_n,"Passive receive / no saved system");}
        else {
            uint8_t descriptor[32];
            bool valid=p25_cs_read(&channel_store,p25_cs_trunk_key(item-1u),descriptor)
                && descriptor[0] && p25_cs_trunk_descriptor_valid(descriptor);
            snprintf(label,label_n,"%u: %.12s",item,valid ? (const char *)descriptor:"Unused");
            snprintf(value,value_n,"%s",valid ? descriptor[12] ? "Subscriber / experimental timing":"Receive only" : "Program this system in CPS");
        }
    } else if(menu_page==MENU_TRUNK) {
        const char *names[]={"Selected system","Start selected system","Stop trunking","Talkgroup","Start at power on","Receive current channel"};
        snprintf(label,label_n,"%s",names[item]);
        p25_cs_trunk_system system;bool valid=trunk_system_load_selected(global_record[28],&system);
        if(!item)snprintf(value,value_n,"%s",valid ? system.name:"Current P25 channel");
        else if(item==1u)snprintf(value,value_n,"%s",valid && system.mode ? "Subscriber / experimental timing":"Passive receive");
        else if(item==2u)snprintf(value,value_n,"Return to your normal channel");
        else if(item==3u) {
            if(valid)snprintf(value,value_n,"%u / edit selected system",system.talkgroup);
            else snprintf(value,value_n,"Select a saved system first");
        }
        else if(item==4u)snprintf(value,value_n,"%s / select to change",global_record[29] ? "On":"Off");
        else snprintf(value,value_n,"Use this channel as control / RX only");
    } else if(menu_page==MENU_ROOT) {
        const char *names[]={"Operating","Channel","Audio & TX","Settings","Tools"};
        const char *values[]={"Frequency / Channel, A/B, scan","Frequencies, mode and filters",
            "Voice, radio ID, power, timeout","Display, keypad and buttons","Receivers and radio status"};
        snprintf(label,label_n,"%s",names[item]);snprintf(value,value_n,"%s",values[item]);
    } else if(menu_page==MENU_AUDIO_TX) {
        snprintf(label,label_n,"%s",item ? "Transmit" : "Voice & ID");
        if(item)snprintf(value,value_n,"Power %s / timeout %us",power_name(),feature_tx_tot());
        else snprintf(value,value_n,"Destination, radio ID, mic gain");
    } else if(menu_page==MENU_SETTINGS) {
        snprintf(label,label_n,"%s",item ? "Button actions" : "Display & keys");
        snprintf(value,value_n,"%s",item ? "Assign P1, P2, SK1 and SK2" : "Screen, keypad light and lock");
    } else if(menu_page==MENU_TOOLS) {
        const char *names[]={"Receivers","Diagnostics","Applets"};
        snprintf(label,label_n,"%s",names[item]);
        snprintf(value,value_n,"%s",item==2u ? "SAME and installed scripts" : item ? (DM32_LAB_DIAGNOSTICS ? "Status and optional test tools" : "Build, battery and counters") : "Broadcast FM and airband AM");
    } else if(menu_page==MENU_APPLETS) {
        if(!item) {snprintf(label,label_n,"SAME weather decoder");snprintf(value,value_n,"Choose NOAA channel / receive only");}
        else if(item==9u) {snprintf(label,label_n,"Refresh applet list");snprintf(value,value_n,"Read storage / radio pauses briefly");}
        else radio_applets_slot_label(&applets,item,label,label_n,value,value_n);
    } else if(menu_page==MENU_SAME_CHANNELS) {
        uint32_t hz=162400000u+item*25000u;
        snprintf(label,label_n,"%lu.%03lu MHz",(unsigned long)(hz/1000000u),(unsigned long)(hz/1000u%1000u));
        snprintf(value,value_n,"Start SAME / receive only");
    } else if(menu_page==MENU_RECEIVERS) {
        const char *names[]={"Broadcast FM","Airband AM","Broadcast frequency","Airband tuning step","Airband squelch"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"65-108 MHz / receive only");
        else if(item==1)snprintf(value,value_n,"108-137 MHz / receive only");
        else if(item==2) {uint32_t khz=radio_functions_get_broadcast_khz(global_record);snprintf(value,value_n,"%lu.%03lu MHz",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));}
        else if(item==3)snprintf(value,value_n,"%s / select next",airband_step_hz==RADIO_AIRBAND_STEP_833 ? "8.33 kHz" : "25 kHz");
        else snprintf(value,value_n,"%u / select next (0 opens)",airband_squelch);
    } else if(menu_page==MENU_TRANSMIT) {
        const char *names[]={"Transmit permission","Channel power","TX timeout"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%s",owner_tx_inhibit ? "Inhibited / select to enable" : "Enabled / select to inhibit");
        else if(item==1)snprintf(value,value_n,"%s / select next",power_name());
        else snprintf(value,value_n,"%u seconds",feature_tx_tot());
    } else if(menu_page==MENU_FUNCTIONS) {
        const char *names[]={"P1 button","P2 button","SK1 button","SK2 button"};
        snprintf(label,label_n,"%s",names[item]);
        snprintf(value,value_n,"%s / select next",function_name(radio_functions_get_action(global_record,(radio_function_key)item)));
    } else if(menu_page==MENU_CHANNEL) {
        const char *names[]={"Receive frequency","Transmit frequency","Use simplex",feature_dmr() ? "Color code" : "NAC code","Modulation",feature_dmr() ? "DMR settings" : "FM settings","Receive only","Receive filter"};
        snprintf(label,label_n,"%s",names[item]);
        if(item<=1) {uint32_t hz=item ? control.tx_frequency : frequency;snprintf(value,value_n,"%lu.%06lu MHz",(unsigned long)(hz/1000000u),(unsigned long)(hz%1000000u));}
        else if(item==2)snprintf(value,value_n,"%s",control.split ? "Set TX to receive frequency" : "TX and RX use same frequency");
        else if(item==3) {if(feature_dmr())snprintf(value,value_n,"%u",radio_channel_get_color_code(channel_record));
            else snprintf(value,value_n,"%03lX (hex)",(unsigned long)control.nac);}
        else if(item==4)snprintf(value,value_n,"%s / select next",feature_mode_name());
        else if(item==5)snprintf(value,value_n,"%s",feature_dmr() ? "Slot, call type and access" : feature_fm() ? "Width, squelch and tones" : "Select FM or DMR first");
        else if(item==6)snprintf(value,value_n,"%s",(channel_record[12]&16u) ? "On / channel TX disabled" : "Off / normal owner TX setting");
        else snprintf(value,value_n,"%s",feature_dmr() ? (rx_promiscuous ? "PROM / any CC / selected slot" : rx_tg_filter ? "Color code + destination" : "Color code / all groups / slot")
            : rx_promiscuous ? "PROM / all NACs and talkgroups" : rx_tg_filter ? "Configured NAC + talkgroup" : "Configured NAC / all groups");
    } else if(menu_page==MENU_VOICE) {
        const char *names[]={feature_dmr() || radio_channel_get_private(channel_record) ? "TX destination" : "TX talkgroup","Radio ID","Digital mic gain","Call type"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%lu",(unsigned long)(feature_dmr() || radio_channel_get_private(channel_record) ? radio_channel_get_destination(channel_record) : control.talkgroup));
        else if(item==1)snprintf(value,value_n,"%lu",(unsigned long)control.source_id);
        else if(item==2)snprintf(value,value_n,"%u dB",mic_gain_db);
        else snprintf(value,value_n,"%s / select next",radio_channel_get_private(channel_record) ? "Individual" : "Group");
    } else if(menu_page==MENU_DMR) {
        const char *names[]={"Color code","Timeslot","Call type","Operation"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%u",radio_channel_get_color_code(channel_record));
        else if(item==1)snprintf(value,value_n,"Slot %u",radio_channel_get_timeslot(channel_record));
        else if(item==2)snprintf(value,value_n,"%s",radio_channel_get_private(channel_record) ? "Private / unit to unit" : "Group / talkgroup");
        else snprintf(value,value_n,"%s",radio_channel_get_repeater(channel_record) ? "Repeater / hotspot" : "Direct / simplex");
    } else if(menu_page==MENU_MEMORY) {
        const char *names[]={"Operating mode","Side A / B","Save channel","Select channel","Scan lists","Selected zone","Last heard","Messages","P25 trunking"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%s",feature_memory() ? "Channel / select for Frequency" : "Frequency / select for Channel");
        else if(item==1)snprintf(value,value_n,"Active side %c / select other",'A'+feature_vfo());
        else if(item==5)snprintf(value,value_n,"%.12s / select next",feature_zone_name);
        else if(item==6)snprintf(value,value_n,"%u recent calls / this session",heard_calls.count);
        else if(item==7)snprintf(value,value_n,"P25 / DMR messaging status");
        else if(item==8)snprintf(value,value_n,"Systems, talkgroup and receive mode");
        else snprintf(value,value_n,"%s",item==4 ? "16 named lists / CH or TG" : "Choose channel 001 to 256");
    } else if(menu_page==MENU_SCAN) {
        const char *names[]={channel_scan.running ? "Stop scanning" : "Start scanning","Selected scan list","Edit list in CPS"};
        snprintf(label,label_n,"%s",names[item]);
        uint8_t descriptor[32];feature_scan_description(descriptor);
        if(item==0)snprintf(value,value_n,"%s / dwell %ums / hold %ums",descriptor[12] ? "TG SCAN" : "CH SCAN",feature_u16(descriptor+18),feature_u16(descriptor+20));
        else if(item==1)snprintf(value,value_n,"%u: %.12s / next",global_record[12]+1u,descriptor[0] ? (const char *)descriptor : "Unused");
        else snprintf(value,value_n,"Type, members, timing and reply");
    } else if(menu_page==MENU_DISPLAY) {
        const char *names[]={"Screen off after","Keypad light","Lock keypad"};
        snprintf(label,label_n,"%s",names[item]);
        if(item<2) {unsigned seconds=item ? radio_lights.keypad_seconds : radio_lights.screen_seconds;
            if(seconds)snprintf(value,value_n,"%u seconds",seconds);else snprintf(value,value_n,"Always on");}
        else snprintf(value,value_n,"Hold OK + * for 1s to unlock");
    } else if(menu_page==MENU_FM) {
        const char *names[]={"Bandwidth","Squelch","TX tone type","TX tone code","RX tone type","RX tone code"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%s",(channel_record[12]&32u) ? "Wide / 25 kHz" : "Narrow / 12.5 kHz");
        else if(item==1)snprintf(value,value_n,"%u / 0 opens squelch",channel_record[30]);
        else feature_tone_label(item<4 ? 26 : 28,value,value_n);
    } else {
#if DM32_LAB_DIAGNOSTICS
        const char *names[]={"Radio status","Run frame test",normal_mode ? "Enter bench mode" : "Return to radio"};
        snprintf(label,label_n,"%s",names[item]);
        snprintf(value,value_n,"%s",item==0 ? "Build, battery and counters" : item==1 ? "Software only / no RF" : "Optional diagnostic tools");
#else
        snprintf(label,label_n,"Radio status");
        snprintf(value,value_n,"Build, battery and counters");
#endif
    }
}
static void broadcast_entry_label(char *line,size_t size) {
    uint32_t khz;
    if(radio_broadcast_input_khz(frequency_digits,digit_count,&khz))
        snprintf(line,size,"%lu.%03lu MHz",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));
    else snprintf(line,size,"%.*s_",(int)digit_count,frequency_digits);
}
static void broadcast_screen(void) {
    if(!display_ok)return;
    char line[48];p25_ui_view v=ui_view(0);
    v.mode_fm=true;v.mode_dmr=false;v.tx_active=false;
    v.rx_active=broadcast.audio_open;v.phase=broadcast.audio_open ? 2u : 0u;v.rssi_valid=false;
    gfx_frame_begin();gfx_clear(P25_UI_BG);p25_ui_palette();p25_ui_header(&v);
    gfx_text(&font_12x24,8,52,"Broadcast FM",P25_UI_FG);
    uint32_t khz=broadcast.khz ? broadcast.khz : radio_functions_get_broadcast_khz(global_record);
    snprintf(line,sizeof line,"%lu.%03lu MHz",(unsigned long)(khz/1000u),(unsigned long)(khz%1000u));
    gfx_text(&font_12x24,8,104,line,P25_UI_CYAN);
    gfx_text(&font_8x16,8,156,broadcast.failed ? "Receiver unavailable" : broadcast.busy ? "Tuning..." : broadcast.have_status && broadcast.status.stereo ? "Stereo" : "Listening",P25_UI_FG);
    if(editing) {
        gfx_text(&font_6x12,8,182,"New frequency (MHz)",P25_UI_MUTED);
        broadcast_entry_label(line,sizeof line);
        gfx_round_fill(4,200,212,36,P25_UI_PANEL);gfx_text(&font_12x24,12,205,line,P25_UI_FG);
        const char *hint=!strcmp(reason,"invalid_frequency") ? "Use 65-108 MHz / 50 kHz steps"
            : broadcast.busy ? "Wait for tuning, then press OK" : "Example: 101#7 or 1017";
        gfx_text(&font_6x12,8,245,hint,!strcmp(reason,"invalid_frequency") ? P25_UI_AMBER : P25_UI_MUTED);
        gfx_text(&font_6x12,8,268,"OK: tune  *: erase  #: decimal",P25_UI_MUTED);
        gfx_text(&font_8x16,8,290,"Back: cancel entry",P25_UI_CYAN);
    } else {
        gfx_text(&font_8x16,8,192,"Radio channel paused",P25_UI_MUTED);
        gfx_text(&font_6x12,8,228,"P1: seek down  P2: seek up",P25_UI_MUTED);
        gfx_text(&font_6x12,8,248,"Up/Down: tune 50 kHz",P25_UI_MUTED);
        gfx_text(&font_6x12,8,268,"Keypad: frequency  OK: tune",P25_UI_MUTED);
        gfx_text(&font_8x16,8,290,"Back: return to radio",P25_UI_CYAN);
    }
    gfx_flush();
}
static void broadcast_leave(bool ptt_down) {
    radio_broadcast_stop(&broadcast);broadcast_show=false;
    editing=false;digit_count=0;edit_from_menu=false;
    // A key held during broadcast must never become an implicit TX on exit.
    if(ptt_down || !hrc_pin_read(PIN_PTT)) {ptt_release_required=true;ptt_release_seen=false;}
    (void)normal_resume();screen("HOME");
}
static void broadcast_toggle(void) {
    if(broadcast_show) {broadcast_leave(false);return;}
    if(call_active || prepared || rx_job || audio_on || hardware_running)return;
    feature_stop_scan(true);feature_pause();preferences_poll(false);
    session_enabled=armed=false;editing=menu_open=rx_lab=false;
    board_rf_safe();board.radio->audio(false);
    bool started=radio_broadcast_start(&broadcast,board.bcast,radio_functions_get_broadcast_khz(global_record));
    broadcast_show=true;broadcast_due=hrc_micros();
    if(!started)broadcast.failed=true;
    radio_inhibit(&control,true);control.state=RADIO_RX_PAUSED;
    board.power->led(LED_GREEN,false);reason="broadcast_fm";broadcast_screen();
}
static void airband_screen(void) {
    if(!display_ok)return;
    char line[48];p25_ui_view v=ui_view(0);
    v.mode_am=true;v.mode_fm=v.mode_dmr=v.tx_active=false;
    v.rx_active=airband.audio_open;v.phase=airband.audio_open ? 2u : 0u;
    gfx_frame_begin();gfx_clear(P25_UI_BG);p25_ui_palette();p25_ui_header(&v);
    gfx_text(&font_12x24,8,48,"Airband AM",P25_UI_FG);
    gfx_text(&font_6x12,8,78,"AM / RECEIVE ONLY",P25_UI_MUTED);
    // Show the exact 8.33-kHz carrier rather than an aviation channel number.
    snprintf(line,sizeof line,"%lu.%06lu MHz",(unsigned long)(airband_hz/1000000u),(unsigned long)(airband_hz%1000000u));
    gfx_text(&font_12x24,8,104,line,P25_UI_CYAN);
    snprintf(line,sizeof line,"%s step / SQ %u",airband_step_hz==RADIO_AIRBAND_STEP_833 ? "8.33 kHz" : "25 kHz",airband.squelch);
    gfx_text(&font_6x12,8,136,line,P25_UI_MUTED);
    gfx_text(&font_8x16,8,156,airband.failed ? "Receiver unavailable" : !airband.squelch ? "Monitor open" : airband.audio_open ? "Receiving" : "Listening",P25_UI_FG);
    if(editing) {
        gfx_text(&font_6x12,8,182,"Carrier frequency (MHz)",P25_UI_MUTED);
        uint32_t hz;
        if(radio_airband_input_hz(frequency_digits,digit_count,&hz))
            snprintf(line,sizeof line,"%lu.%06lu",(unsigned long)(hz/1000000u),(unsigned long)(hz%1000000u));
        else snprintf(line,sizeof line,"%.*s_",(int)digit_count,frequency_digits);
        gfx_round_fill(4,200,212,36,P25_UI_PANEL);gfx_text(&font_12x24,12,205,line,P25_UI_FG);
        gfx_text(&font_6x12,8,245,!strcmp(reason,"invalid_frequency") ? "Use 108 MHz to below 137 MHz" : "Example: 118#025 or 118025",!strcmp(reason,"invalid_frequency") ? P25_UI_AMBER : P25_UI_MUTED);
        gfx_text(&font_6x12,8,268,"OK: tune  *: erase  #: decimal",P25_UI_MUTED);
        gfx_text(&font_8x16,8,290,"Back: cancel entry",P25_UI_CYAN);
    } else {
        gfx_text(&font_8x16,8,192,"Radio channel paused",P25_UI_MUTED);
        gfx_text(&font_6x12,8,220,"P1/P2 or Up/Down: tune",P25_UI_MUTED);
        gfx_text(&font_6x12,8,240,"Knob: tune   *: monitor",P25_UI_MUTED);
        gfx_text(&font_6x12,8,260,"Keypad + OK: frequency",P25_UI_MUTED);
        gfx_text(&font_8x16,8,290,"Back: return to radio",P25_UI_CYAN);
    }
    gfx_flush();
}
static void airband_leave(bool ptt_down) {
    radio_airband_stop(&airband);airband_show=false;
    editing=false;digit_count=0;edit_from_menu=false;
    if(ptt_down || !hrc_pin_read(PIN_PTT)) {ptt_release_required=true;ptt_release_seen=false;}
    (void)normal_resume();screen("HOME");
}
static void airband_toggle(void) {
    if(airband_show) {airband_leave(false);return;}
    if(call_active || prepared || rx_job || audio_on || hardware_running)return;
    feature_stop_scan(true);feature_pause();preferences_poll(false);
    session_enabled=armed=false;editing=menu_open=rx_lab=false;digit_count=0;
    board_rf_safe();board.radio->audio(false);
    memset(&airband,0,sizeof airband);
    bool started=(board.caps&CAP_AM_RX) && radio_airband_start(&airband,board.radio,board.audio,airband_hz,
        airband_step_hz==RADIO_AIRBAND_STEP_833 ? RADIO_BW_12K5 : RADIO_BW_25K,airband_squelch,hrc_micros());
    airband_show=true;airband_due=hrc_micros();
    if(!started)airband.failed=true;
    radio_inhibit(&control,true);control.state=RADIO_RX_PAUSED;
    board.power->led(LED_GREEN,false);reason="airband_am";airband_screen();
}
// Built-in receive applications share the exclusive receive storage. Capture
// only copies a half in the ISR; demodulation, parsing and terminal I/O are task
// work. Saved channel/VFO/settings records are never replaced by the app tune.
static bool apps_active(void) {
    return microapps.active!=RADIO_MICROAPP_NONE || applet_owns_radio || pcm_owner;
}
static void apps_emit(void *context,const char *line) {
    (void)context;
    if(pcm_owner)return; // Never interleave ASCII with the framed PCM wire.
    if(telemetry_pending()) {command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return;}
    if(!same_running && !applet_owns_radio) {send(line);send("\r\n");return;}
    size_t n=strlen(line),size=sizeof same_rx.serial;
    unsigned free_bytes=(same_rx.serial_tail+size-same_rx.serial_head-1u)%size;
    // Reserve a whole line or drop it; never publish a truncated header.
    if(n+2u>free_bytes) {++same_rx.serial_dropped;return;}
    for(size_t i=0;i<n;++i) {same_rx.serial[same_rx.serial_head]=(uint8_t)line[i];same_rx.serial_head=(uint16_t)((same_rx.serial_head+1u)%size);}
    same_rx.serial[same_rx.serial_head]='\r';same_rx.serial_head=(uint16_t)((same_rx.serial_head+1u)%size);
    same_rx.serial[same_rx.serial_head]='\n';same_rx.serial_head=(uint16_t)((same_rx.serial_head+1u)%size);
}
static void apps_output_flush(void) {
    unsigned head=same_rx.serial_head,tail=same_rx.serial_tail;
    if(head==tail)return;
    unsigned n=head>tail ? head-tail : sizeof same_rx.serial-tail;
    if(n>48u)n=48u; // At most about 4.2 ms of UART wire time per task pass.
    size_t sent=board.host_port->write(same_rx.serial+tail,n);
    if(sent>n)sent=n;
    if(sent) {
        same_rx.serial_partial=same_rx.serial[tail+sent-1u]!='\n';
        same_rx.serial_tail=(uint16_t)((tail+sent)%sizeof same_rx.serial);
    }
}
static void apps_audio_status(void *context) {
    (void)context;
    if(!same_running)return;
    char line[256];
    snprintf(line,sizeof line,"SAME AUDIO blocks=%lu dropped=%lu gaps=%lu samples=%lu valid=%lu confirmed=%lu invalid=%lu partial=%lu eom=%lu tx_dropped=%lu",
        (unsigned long)same_rx.audio.blocks,(unsigned long)same_rx.audio.dropped,
        (unsigned long)same_rx.audio.gaps,(unsigned long)same_samples,
        (unsigned long)same_rx.protocol.headers,(unsigned long)same_rx.protocol.confirmations,
        (unsigned long)same_rx.protocol.invalid,(unsigned long)same_rx.protocol.partials,
        (unsigned long)same_rx.protocol.eoms,(unsigned long)same_rx.serial_dropped);apps_emit(NULL,line);
}
static void apps_same_byte(void *context,uint8_t byte) {
    (void)context;
    uint32_t event=same_protocol_feed_byte(&same_rx.protocol,byte,same_clock_ms);
    if(event&SAME_EVENT_HEADER) {
        const same_header *h=&same_rx.protocol.latest;
        (void)radio_microapps_publish_same(&microapps,h->raw,h->length,same_rx.protocol.latest_confirmed!=0);
        if(microapps.watch) {
            char line[144];
            snprintf(line,sizeof line,"SAME FIELDS org=%s event=%s locations=%u purge_min=%u issue=%03u/%02u:%02uZ sender=%.8s",
                h->originator,h->event,h->location_count,h->purge_minutes,
                h->issue_day,h->issue_hour,h->issue_minute,h->sender);apps_emit(NULL,line);
        }
        same_ui_pending=true;
        if(applet_owns_radio)radio_applet_vm_signal(&applets.vm,RADIO_APPLET_EVENT_HEADER
            | (same_rx.protocol.latest_confirmed ? RADIO_APPLET_EVENT_CONFIRMED : 0u));
        (void)radio_ux_activity(&radio_lights,hrc_micros(),false);
    }
    if(event&SAME_EVENT_EOM) {
        if(applet_owns_radio)radio_applet_vm_signal(&applets.vm,RADIO_APPLET_EVENT_EOM);
        if(microapps.watch)apps_emit(NULL,event&SAME_EVENT_EOM_CONFIRMED ? "SAME EOM CONFIRMED" : "SAME EOM UNCONFIRMED");
    }
}
static void apps_radio_resume(void) {
    (void)normal_resume();
    if(!same_return_rx_enabled) {
        mon_enabled=false;mon_reason="disabled";
        radio_receive_state(&control,false,false,false,false);
    }
}
static bool apps_same_start(void *context,uint32_t hz) {
    (void)context;
    if(telemetry_pending() || !dev || !hooks || !board.audio || !board.audio->stop || !board.audio->speaker_pcm
       || call_active || prepared || rx_job || audio_on || hardware_running || cps_link || cps_active
       || control.state==RADIO_FAULT
       || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)
       || !radio_microapps_same_frequency_valid(hz))return false;
    if(!applet_owns_radio) {
        if(!feature_stop_scan(true))return false;
        same_return_rx_enabled=mon_enabled;feature_pause();
    }
    mon_enabled=mon_used=false;session_enabled=armed=false;
    editing=menu_open=rx_lab=false;digit_count=0;
    hardware_stop();board.audio->stop();board.audio->speaker_pcm(false);
    board.radio->audio(false);board.radio->tx_off();board.radio->set_mode(RADIO_MODE_FM);
    // NOAA NWR uses 4-5 kHz deviation; retain wide FM, without sub-audio gating.
    if(!board.radio->rx(hz,RADIO_BW_25K,NULL)) {
        board.radio->audio(false);hardware_stop();if(!applet_owns_radio)apps_radio_resume();return false;
    }
    hardware_stop();hrc7000_fm_rx(dev,true);hrc7000_audio_bits(dev,0,C7_AUDIO_FM_PLAY);
    if(!applet_owns_radio)memset(&same_rx,0,sizeof same_rx);
    else memset(&same_rx.audio,0,sizeof same_rx.audio);
    same_protocol_init(&same_rx.protocol);same_demod_init(&same_rx.demod,apps_same_byte,NULL);
    same_clock_us=same_last_pcm_us=hrc_micros();same_clock_ms=same_clock_carry=same_samples=0;
    same_ui_pending=false;same_resume_on_stop=true;
    radio_inhibit(&control,true);control.state=RADIO_RX_PAUSED;reason="same_monitor";
    uint32_t lock=hrc_irq_save();
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);same_running=true;
    wr(C7_SYS_INTERP_MASK,1u<<14);hrc_irq_enable(IRQ_MODEM_SYS,true);
    hrc_irq_restore(lock);return true;
}
static void apps_hardware_stop(void *context) {
    (void)context;
    uint32_t lock=hrc_irq_save();same_running=false;
    wr(C7_SYS_INTERP_MASK,0);hrc_irq_enable(IRQ_MODEM_SYS,false);
    hrc_irq_restore(lock);hardware_stop();
    if(same_rx.serial_partial)send("\r\n"); // Close an interrupted line before CPS or STOP replies.
    same_rx.serial_head=same_rx.serial_tail=0;same_rx.serial_partial=false;
    board.radio->audio(false);board.radio->tx_off();
    board.audio->stop();board.audio->speaker_pcm(false);board_rf_safe();
    mon_used=false;same_ui_pending=false;
    if(!hrc_pin_read(PIN_PTT)) {ptt_release_required=true;ptt_release_seen=false;}
    if(same_resume_on_stop && !applet_owns_radio)apps_radio_resume();
}
static bool applet_flash_geometry(void) {
    const hal_flash_t *f=board.flash;
    return f && f->read && f->write && f->erase && f->map && f->size==0x1000000u
        && f->erase_size==4096u && f->map->settings_addr==0x711000u && f->map->settings_size==0x8000u
        && f->map->native_addr==0xF00000u && f->map->native_size==0x100000u;
}
static bool applet_flash_read(void *context,uint32_t off,void *out,uint32_t n) {
    (void)context;
    return applet_flash_geometry() && off<=RADIO_APPLET_STORE_BYTES && n<=RADIO_APPLET_STORE_BYTES-off
        && board.flash->read(RADIO_APPLET_STORE_BASE+off,out,n);
}
static bool applet_flash_write(void *context,uint32_t off,const void *data,uint32_t n) {
    if(DM32_OMAHA_RX_ONLY)return false;
    (void)context;
    return applet_owns_radio && !same_running && applet_flash_geometry()
        && off<RADIO_APPLET_STORE_BYTES && n<=RADIO_APPLET_STORE_BYTES-off
        && board.flash->write(RADIO_APPLET_STORE_BASE+off,data,n);
}
static bool applet_flash_erase(void *context,uint32_t off) {
    if(DM32_OMAHA_RX_ONLY)return false;
    (void)context;
    return applet_owns_radio && !same_running && applet_flash_geometry()
        && off<RADIO_APPLET_STORE_BYTES && !(off%RADIO_APPLET_STORE_ERASE_BYTES)
        && board.flash->erase(RADIO_APPLET_STORE_BASE+off);
}
static bool applet_acquire(void *context) {
    if(DM32_OMAHA_RX_ONLY)return false;
    (void)context;
    if(telemetry_pending() || apps_active() || !dev || !hooks || !board.audio || !board.audio->stop || !board.audio->speaker_pcm
       || call_active || prepared || rx_job || audio_on || hardware_running || cps_link || cps_active
       || control.state==RADIO_FAULT || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask))return false;
    if(!feature_stop_scan(true))return false;
    same_return_rx_enabled=mon_enabled;feature_pause();
    mon_enabled=mon_used=false;session_enabled=armed=false;
    editing=menu_open=rx_lab=false;digit_count=0;
    hardware_stop();board.audio->stop();board.audio->speaker_pcm(false);
    board.radio->audio(false);board.radio->tx_off();board_rf_safe();
    memset(&same_rx,0,sizeof same_rx);applet_display[0]=0;applet_keys=0;applet_saved_watch=microapps.watch;
    applet_owns_radio=true;applet_display_pending=true;applet_display_due=hrc_micros();
    radio_inhibit(&control,true);control.state=RADIO_RX_PAUSED;reason="applet";return true;
}
static void applet_release(void *context) {
    (void)context;
    bool resume=same_resume_on_stop;same_resume_on_stop=false;
    if(microapps.active!=RADIO_MICROAPP_NONE)radio_microapps_stop(&microapps);
    else apps_hardware_stop(NULL);
    microapps.watch=applet_saved_watch;applet_owns_radio=false;applet_display_pending=false;same_resume_on_stop=resume;
    if(resume)apps_radio_resume();
}
static uint32_t applet_millis(void *context) {(void)context;return hal_millis();}
static bool applet_output_pending(void *context) {(void)context;return same_rx.serial_head!=same_rx.serial_tail;}
static bool applet_emit(void *context,const char *text) {apps_emit(context,text);return true;}
static bool applet_same_start(void *context,uint32_t hz) {
    (void)context;
    if(!applet_owns_radio || !radio_microapps_same_frequency_valid(hz))return false;
    if(microapps.active==RADIO_MICROAPP_SAME)return microapps.frequency_hz==hz;
    microapps.watch=false; // Scripts choose what to publish through LAST/EMIT.
    char request[48];snprintf(request,sizeof request,"APP SAME START %lu",(unsigned long)hz);
    (void)radio_microapps_command(&microapps,request);return same_running;
}
static bool applet_same_last(void *context) {
    (void)context;
    if(!same_running)return false;
    return radio_microapps_command(&microapps,"APP SAME LAST");
}
static bool applet_show(void *context,const char *text) {
    (void)context;snprintf(applet_display,sizeof applet_display,"%s",text);
    applet_display_pending=true;(void)radio_ux_activity(&radio_lights,hrc_micros(),false);return true;
}
static bool applet_show_same(void *context) {
    if(!same_running)return false;
    const same_header *h=&same_rx.protocol.latest;char text[96];
    if(h->length)snprintf(text,sizeof text,"%s / %s / %u areas / %.8s / %s",h->originator,h->event,
        h->location_count,h->sender,same_rx.protocol.latest_confirmed ? "CONFIRMED" : "One copy");
    else snprintf(text,sizeof text,"Listening for SAME weather alerts");
    return applet_show(context,text);
}
static bool applet_get(void *context,unsigned field_id,uint32_t *value) {
    (void)context;
    if(field_id==8u) {*value=applet_keys;applet_keys=0;return true;}
    if(field_id==9u) {*value=hal_millis();return true;}
    if(!same_running)return false;
    const same_header *h=&same_rx.protocol.latest;
    switch(field_id) {
    case 0:case 1: {const char *s=field_id ? h->originator : h->event;
        *value=(uint8_t)s[0]|(uint32_t)(uint8_t)s[1]<<8|(uint32_t)(uint8_t)s[2]<<16;break;}
    case 2:*value=h->location_count;break;
    case 3:*value=h->purge_minutes;break;
    case 4:*value=h->issue_day;break;
    case 5:*value=h->issue_hour;break;
    case 6:*value=h->issue_minute;break;
    case 7:*value=same_rx.protocol.latest_confirmed;break;
    case 10:*value=same_rx.protocol.headers;break;
    case 11:*value=same_rx.protocol.confirmations;break;
    case 12:*value=same_rx.protocol.eoms;break;
    case 13:*value=microapps.headers+same_rx.protocol.eoms;break;
    default:return false;
    }
    return true;
}
static void apps_init(void) {
    const radio_microapps_hal_t hal={.start_same=apps_same_start,.stop=apps_hardware_stop,
        .emit=apps_emit,.status=apps_audio_status};
    radio_microapps_init(&microapps,&hal,NULL);
    const radio_applet_store_io io={.size=RADIO_APPLET_STORE_BYTES,.erase_size=RADIO_APPLET_STORE_ERASE_BYTES,
        .read=applet_flash_read,.write=applet_flash_write,.erase=applet_flash_erase};
    const radio_applets_hal app_hal={.acquire=applet_acquire,.release=applet_release,.emit=apps_emit,
        .output_pending=applet_output_pending,.millis=applet_millis,
        .services={.same_start=applet_same_start,.same_last=applet_same_last,.display=applet_show,
            .display_same=applet_show_same,.emit=applet_emit,.get=applet_get}};
    radio_applets_init(&applets,&io,&app_hal,NULL);
}
static void apps_stop(bool resume) {
    if(pcm_owner) {pcm_leave(resume);return;}
    same_resume_on_stop=resume;
    if(radio_applets_active(&applets))radio_applets_stop(&applets);
    else radio_microapps_stop(&microapps);
    same_resume_on_stop=true;
}
static void apps_screen(void) {
    if(!display_ok)return;
    char line[48];
    gfx_frame_begin();gfx_clear(P25_UI_BG);p25_ui_palette();
    gfx_fill(0,0,gfx_width(),4,P25_UI_BG); // Cover palette seeds on this headerless view.
    if(pcm_owner) {
        p25_ui_text(&font_12x24,8,24,204,"PCM engine",P25_UI_FG);
        snprintf(line,sizeof line,"%s / %s / %s",pcm_engine.config.mode==RADIO_PCM_RAW ? "Raw" : "Voice",
            pcm_engine.config.operations==RADIO_PCM_TX ? "TX" : "RX",
            pcm_engine.config.modulation==RADIO_PCM_P25 ? "P25" : pcm_engine.config.modulation==RADIO_PCM_DMR ? "DMR" : pcm_engine.config.modulation==RADIO_PCM_NFM ? "NFM" : "FM");
        gfx_text(&font_8x16,8,72,line,P25_UI_CYAN);
        snprintf(line,sizeof line,"%lu.%06lu MHz",(unsigned long)(pcm_hz/1000000u),(unsigned long)(pcm_hz%1000000u));
        gfx_text(&font_8x16,8,104,line,P25_UI_FG);
        gfx_text(&font_6x12,8,144,"8 kHz / 16-bit / serial PCM",P25_UI_MUTED);
        gfx_text(&font_6x12,8,164,"Back: stop and restore radio",P25_UI_MUTED);
        gfx_flush();return;
    } else if(applet_owns_radio) {
        p25_ui_text(&font_12x24,8,24,204,applets.running ? applets.vm.package.name : "Applet storage",P25_UI_FG);
        gfx_text(&font_8x16,8,64,applets.running ? "SCRIPT / RECEIVE ONLY" : "Updating / radio paused",P25_UI_MUTED);
        if(!applets.running) {
            snprintf(line,sizeof line,"%lu / %lu KiB checked",(unsigned long)(applets.store.progress/1024u),
                (unsigned long)(RADIO_APPLET_STORE_BYTES/1024u));gfx_text(&font_8x16,8,110,line,P25_UI_CYAN);
            gfx_text(&font_6x12,8,140,"Wait for the serial acknowledgement",P25_UI_MUTED);
        } else {
            unsigned pos=0,n=(unsigned)strlen(applet_display);
            for(unsigned row=0;row<4u && pos<n;++row) {
                unsigned take=n-pos;if(take>25u)take=25u;
                if(take<n-pos) {unsigned split=take;while(split && applet_display[pos+split]!=' ')--split;if(split)take=split;}
                snprintf(line,sizeof line,"%.*s",(int)take,applet_display+pos);
                gfx_text(&font_8x16,8,110+(int)row*26,line,P25_UI_FG);pos+=take;
                while(pos<n && applet_display[pos]==' ')++pos;
            }
            if(same_running) {
                snprintf(line,sizeof line,"SAME %lu.%03lu / %lu headers",(unsigned long)(microapps.frequency_hz/1000000u),
                    (unsigned long)(microapps.frequency_hz/1000u%1000u),(unsigned long)same_rx.protocol.headers);
                gfx_text(&font_6x12,8,242,line,P25_UI_CYAN);
            }
        }
        gfx_text(&font_8x16,8,290,"Back: stop app",P25_UI_CYAN);gfx_flush();return;
    }
    gfx_text(&font_12x24,8,24,"SAME decoder",P25_UI_FG);
    snprintf(line,sizeof line,"%lu.%03lu MHz",(unsigned long)(microapps.frequency_hz/1000000u),
        (unsigned long)(microapps.frequency_hz/1000u%1000u));
    gfx_text(&font_12x24,8,68,line,P25_UI_CYAN);
    gfx_text(&font_8x16,8,108,"Receive only / serial app",P25_UI_MUTED);
    const same_header *h=&same_rx.protocol.latest;
    if(h->length) {
        snprintf(line,sizeof line,"%s / %s",h->originator,h->event);
        gfx_text(&font_12x24,8,152,line,P25_UI_FG);
        gfx_text(&font_8x16,8,188,same_rx.protocol.latest_confirmed ? "Repeated header confirmed" : "Header: unconfirmed copy",P25_UI_CYAN);
        snprintf(line,sizeof line,"%u areas / %.8s",h->location_count,h->sender);
        gfx_text(&font_8x16,8,216,line,P25_UI_FG);
    } else gfx_text(&font_8x16,8,152,"Listening for SAME data",P25_UI_FG);
    gfx_text(&font_6x12,8,260,"APP HELP / APP SAME LAST",P25_UI_MUTED);
    gfx_text(&font_8x16,8,290,"Back: return to radio",P25_UI_CYAN);gfx_flush();
}
static void apps_poll(void) {
    if(pcm_owner) {pcm_poll();return;}
    if(!same_running)goto scripts;
    // The recorder ISR may update its timestamp between task instructions.
    // Read it before the clock and tolerate a just-published, newer sample.
    uint32_t last_pcm_us=same_last_pcm_us;
    uint32_t now=hrc_micros(),elapsed=now-same_clock_us;same_clock_us=now;
    same_clock_ms+=elapsed/1000u;same_clock_carry+=elapsed%1000u;
    if(same_clock_carry>=1000u) {++same_clock_ms;same_clock_carry-=1000u;}
    if((int32_t)(now-last_pcm_us)>1000000) {
        apps_stop(true);send("APP ERROR SAME audio stalled; radio restored\r\n");screen("HOME");return;
    }
    for(unsigned limit=0;limit<4u;++limit) {
        const radio_app_audio_block *b=radio_app_audio_peek(&same_rx.audio);
        if(!b)break;
        if(b->gap) {same_demod_reset(&same_rx.demod);(void)same_protocol_discontinuity(&same_rx.protocol);}
        same_demod_feed(&same_rx.demod,b->pcm,RADIO_APP_AUDIO_SAMPLES);
        same_samples+=RADIO_APP_AUDIO_SAMPLES;radio_app_audio_commit(&same_rx.audio);
    }
    (void)same_protocol_tick(&same_rx.protocol,same_clock_ms);
scripts:
    if(applet_owns_radio)radio_applets_poll(&applets);
    if(!apps_active()) {screen("HOME");return;}
    apps_output_flush();
    if(applet_owns_radio) {
        if((applet_display_pending || !applets.running || same_ui_pending)
           && (int32_t)(hrc_micros()-applet_display_due)>=0 && (!same_running || same_rx.audio.head==same_rx.audio.tail)) {
            applet_display_pending=same_ui_pending=false;applet_display_due=hrc_micros()+250000u;apps_screen();
        }
    } else if(same_ui_pending && same_rx.audio.head==same_rx.audio.tail) {same_ui_pending=false;apps_screen();}
}
static void screen(const char *title) {
    (void)title;
    mon_render_cancel();
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_feed_defer_display())return;
#endif
    if(apps_active()) {apps_screen();return;}
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_lab_return_defer_ui() || trunk_probe.active || trunk_preload_warmed()
       || trunk_subscriber_transport_owned())return;
#endif
    // Full LCD flush remains frozen while audio/PHY runs.
    if(!display_ok || audio_on || hardware_running || rx_sampling || mon_running)return;
    if(airband_show) {airband_screen();return;}
    if(broadcast_show) {broadcast_screen();return;}
    if(!ui_battery_valid)ui_meters_poll();
    char line[48];p25_ui_view v=ui_view(0);
    gfx_frame_begin();gfx_clear(P25_UI_BG);
    if(!rx_job && !rx_lab && !menu_open && !editing) {
        p25_ui_home(&v);mon_context(mon_shown_context,sizeof mon_shown_context);
        ui_header_shown=ui_header_token(&v);mon_badge_sync=false;mon_badge_phase=0;
        gfx_flush();return;
    }
    p25_ui_palette();p25_ui_header(&v);
    if(rx_job) {
        gfx_text(&font_12x24,8,50,"RX capture",P25_UI_FG);
        gfx_text(&font_8x16,8,100,!strcmp(rx_reason,"recording") ? "Recording RF input" : "Waiting to record",P25_UI_FG);
        gfx_text(&font_8x16,8,140,"Transmitter disabled",P25_UI_AMBER);
        gfx_text(&font_8x16,8,284,"Back: cancel",P25_UI_CYAN);
    } else if(rx_lab) {
        gfx_text(&font_12x24,8,46,"Radio status",P25_UI_FG);
        gfx_text(&font_8x16,8,84,DM32_LAB_DIAGNOSTICS ? (rx_checked ? (rx_pass ? "Frame test: PASS" : "Frame test: FAIL") : "Frame test: not run") : "Operational counters",P25_UI_CYAN);
        snprintf(line,sizeof line,"PCM loss %lu / overflow %u",(unsigned long)driver_loss,pcmq.overflow);
        p25_ui_text(&font_6x12,8,114,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"RX frames %lu / FEC %lu",(unsigned long)(mon_used ? monitor.voices : 0),(unsigned long)(mon_used ? monitor.corrected : 0));
        p25_ui_text(&font_6x12,8,138,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Refill %lu / raw loss %lu",(unsigned long)(mon_used ? monitor.starved : 0),(unsigned long)(mon_used ? monitor.raw_overflow : 0));
        p25_ui_text(&font_6x12,8,162,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Mic %u dB / clip %lu",mic_gain_db,(unsigned long)pcmq.clipped);
        p25_ui_text(&font_6x12,8,186,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Battery %u.%02u V / cal %s",ui_battery_mv/1000u,(ui_battery_mv%1000u)/10u,bf_cal_source());
        p25_ui_text(&font_6x12,8,210,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Settings: %s",pref_dirty ? "pending" : pref_state);
        p25_ui_text(&font_6x12,8,234,204,line,P25_UI_MUTED);
        snprintf(line,sizeof line,"Build %s / %s",BENCH_GIT,mon_used ? mon_reason : reason);
        p25_ui_text(&font_6x12,8,258,204,line,P25_UI_MUTED);
        gfx_text(&font_6x12,8,288,DM32_LAB_DIAGNOSTICS ? "OK: frame test   Back: return" : "Back: return",P25_UI_CYAN);
    } else if(message_ui_draw()) {
        // The message reader and keypad composer use the full body area.
    } else if(menu_open) {
        const char *heading=menu_page==MENU_ROOT ? "Radio menu" : menu_page==MENU_CHANNEL ? "Channel"
            : menu_page==MENU_HISTORY ? "Last heard" : menu_page==MENU_HEARD_CALL ? "Received call"
            : menu_page==MENU_MESSAGES ? "Messages" : menu_page==MENU_MESSAGE_LIST ? (message_inbox ? "Inbox" : "Outbox")
            : menu_page==MENU_MESSAGE_COMPOSE ? "New message" : menu_page==MENU_VOICE ? "Voice & ID" : menu_page==MENU_MEMORY ? "Operating"
            : menu_page==MENU_TRUNK || menu_page==MENU_TRUNK_ACTIVE ? "P25 trunking" : menu_page==MENU_TRUNK_SYSTEMS ? "Trunking systems"
            : menu_page==MENU_SCAN ? "Scan lists" : menu_page==MENU_DISPLAY ? "Display & keys"
            : menu_page==MENU_FM ? "FM settings" : menu_page==MENU_DMR ? "DMR settings"
            : menu_page==MENU_TRANSMIT ? "Transmit" : menu_page==MENU_FUNCTIONS ? "Button actions"
            : menu_page==MENU_AUDIO_TX ? "Audio & TX" : menu_page==MENU_SETTINGS ? "Settings" : menu_page==MENU_TOOLS ? "Tools"
            : menu_page==MENU_APPLETS ? "Applets" : menu_page==MENU_SAME_CHANNELS ? "SAME channel" : menu_page==MENU_RECEIVERS ? "Receivers" : "Diagnostics";
        gfx_text(&font_12x24,8,44,heading,P25_UI_FG);
        unsigned first=menu_item>=5u ? menu_item-4u : 0u;
        for(unsigned row=0;row<5u && first+row<menu_count();++row) {
            unsigned i=first+row;
            char label[32],value[48];menu_row(i,label,sizeof label,value,sizeof value);
            int y=78+(int)row*39;
            if(i==menu_item) {gfx_round_fill(4,y-2,212,37,P25_UI_PANEL);gfx_fill(4,y+1,3,28,P25_UI_CYAN);}
            p25_ui_text(&font_8x16,12,y,196,label,i==menu_item ? P25_UI_CYAN : P25_UI_FG);
            p25_ui_text(&font_6x12,12,y+18,196,value,P25_UI_MUTED);
        }
        if(message_menu_active())p25_ui_text(&font_6x12,8,273,204,message_notice,P25_UI_AMBER);
        gfx_text(&font_6x12,8,292,"Up/Down: choose  OK: open  Back",P25_UI_MUTED);
    } else {
        gfx_text(&font_12x24,8,48,field_names[field],P25_UI_FG);
        uint32_t current=field==EDIT_RX ? frequency : field==EDIT_TX ? control.tx_frequency : field==EDIT_NAC ? control.nac
            : field==EDIT_TG ? (feature_dmr() || radio_channel_get_private(channel_record) ? radio_channel_get_destination(channel_record) : control.talkgroup) : field==EDIT_ID ? control.source_id : field==EDIT_MIC ? mic_gain_db
            : field==EDIT_MEMORY || field==EDIT_RECALL ? feature_memory() : field==EDIT_SCREEN ? radio_lights.screen_seconds
            : field==EDIT_LIGHT ? radio_lights.keypad_seconds : field==EDIT_SQL ? channel_record[30]
            : field==EDIT_DMR_CC ? radio_channel_get_color_code(channel_record)
            : field==EDIT_TRUNK_TG ? trunk_system_group()
            : field==EDIT_TOT ? feature_tx_tot() : field==EDIT_BCAST ? radio_functions_get_broadcast_khz(global_record)*1000u
            : feature_tone(field==EDIT_TXTONE ? 26 : 28).value;
        if(field==EDIT_MEMORY || field==EDIT_RECALL)snprintf(line,sizeof line,"Current %s",channel_label[0] ? channel_label : "Frequency");
        else if(field<=EDIT_TX || field==EDIT_BCAST)snprintf(line,sizeof line,"Current %lu.%06lu MHz",(unsigned long)(current/1000000u),(unsigned long)(current%1000000u));
        else if(field==EDIT_NAC)snprintf(line,sizeof line,"Current %03lX (hex)",(unsigned long)current);
        else if((field==EDIT_TXTONE || field==EDIT_RXTONE) && feature_tone(field==EDIT_TXTONE ? 26 : 28).type>=TONE_DCS)
            snprintf(line,sizeof line,"Current DCS %03lo",(unsigned long)current);
        else snprintf(line,sizeof line,"Current %lu%s",(unsigned long)current,field==EDIT_MIC ? " dB" : "");
        p25_ui_text(&font_8x16,8,88,204,line,P25_UI_MUTED);
        char digits[10]="_________";memcpy(digits,frequency_digits,digit_count);
        if(field<=EDIT_TX)snprintf(line,sizeof line,"%.3s.%.4s",digits,digits+3);
        else if(field==EDIT_BCAST)broadcast_entry_label(line,sizeof line);
        else {digits[field_digits()]=0;snprintf(line,sizeof line,"%s",digits);}
        gfx_round_fill(4,118,212,46,P25_UI_PANEL);gfx_text(&font_12x24,12,128,line,P25_UI_FG);
        const char *range=field<=EDIT_TX ? "7 digits; e.g. 1457000" : field==EDIT_BCAST ? "65-108 MHz; 101#7 or 1017" : field==EDIT_TOT ? "15-600 seconds" : field==EDIT_NAC ? "Hex 000-FFF; Up/Down A-F"
            : field==EDIT_TRUNK_TG ? "1 to 65535 / saved system"
            : field==EDIT_TG ? (feature_dmr() || radio_channel_get_private(channel_record) ? "1 to 16777215" : "1 to 65535") : field==EDIT_ID ? "1 to 16777215" : field==EDIT_MIC ? "0 to 42 dB"
            : field==EDIT_MEMORY || field==EDIT_RECALL ? "Channel number 001 to 256" : field==EDIT_SCREEN || field==EDIT_LIGHT ? "0-600 seconds; 0 always on"
            : field==EDIT_DMR_CC ? "0 to 15" : field==EDIT_SQL ? "0-9; 0 opens squelch" : feature_tone(field==EDIT_TXTONE ? 26 : 28).type>=TONE_DCS ? "DCS octal code; 0 disables" : "CTCSS Hz x 10; 0 disables";
        p25_ui_text(&font_8x16,8,184,204,range,P25_UI_MUTED);
        if(!strcmp(reason,"invalid_frequency") || !strcmp(reason,"channel_empty"))gfx_text(&font_8x16,8,220,"Check value and try again",P25_UI_AMBER);
        gfx_text(&font_8x16,8,268,field==EDIT_RECALL ? "OK: select  Back: cancel" : "OK: save   Back: cancel",P25_UI_CYAN);
        gfx_text(&font_6x12,8,294,field==EDIT_BCAST ? "*: erase  #: decimal" : "*: erase last digit",P25_UI_MUTED);
    }
    gfx_flush();
}
static void home_hint_refresh(void) {
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_feed_defer_display())return;
#endif
    if(mon_control_only || !display_ok || call_active || prepared || rx_job || editing || menu_open || rx_lab)return;
    if(!mon_running) {screen("HOME");return;}
    uint32_t start=hrc_micros();gfx_frame_begin();p25_ui_view v=ui_view(mon_badge_phase);
    p25_ui_hint(&v);gfx_flush();
    uint32_t elapsed=hrc_micros()-start;if(elapsed>mon_ui_max_us)mon_ui_max_us=elapsed;
}
static bool ptt_release_poll(bool filtered_down) {
    if(!ptt_release_required)return false;
    // A real held key keeps this shared pin LOW, even while the logical input
    // filter or recent host UART data temporarily reports no press. Require a
    // continuous physical HIGH plus logical release before accepting new PTT.
    if(filtered_down || !hrc_pin_read(PIN_PTT)) {ptt_release_seen=false;return false;}
    uint32_t now=hrc_micros();
    if(!ptt_release_seen) {ptt_release_since=now;ptt_release_seen=true;return false;}
    if(now-ptt_release_since<50000u)return false;
    ptt_release_required=false;return true;
}
#if DM32_LAB_DIAGNOSTICS
static bool rx_frame_test(void) {
    p25_rx r; p25_rx_init(&r);
    uint8_t payloads[9][11],frame[216],decoded[11];unsigned errors;
    for(unsigned i=0;i<99;++i) ((uint8_t*)payloads)[i]=(uint8_t)(i*37u);
    p25_live_ldu(frame,(const uint8_t (*)[11])payloads,false);
    bool done=false;
    for(unsigned i=0;i<864;++i) done=p25_rx_push(&r,(frame[i/4]>>(6-2*(i%4)))&3);
    if(!done || r.nac!=0x293 || r.duid!=5) return false;
    for(unsigned i=0;i<9;++i) if(!p25_rx_voice(r.frame,i,decoded,&errors) || errors || memcmp(decoded,payloads[i],11)) return false;
    return true;
}
#endif
static void menu_edit(edit_field next) {
    if(DM32_OMAHA_RX_ONLY)return;
    preferences_poll(false);
    field=next;edit_from_menu=true;editing=true;menu_open=false;digit_count=0;
    reason=next==EDIT_RECALL ? "enter_channel" : "enter_frequency";
}
static bool history_reply(void) {
    const radio_heard_call *entry=radio_history_get(&heard_calls,heard_selection);
    if(!entry)return false;
    // Copy before stopping scan: history is independent, but adoption can change
    // the current channel. Never silently retune or change TX permission here.
    radio_heard_call c=*entry;
    if(c.flags&RADIO_CALL_TRUNKED) {reason="reply_trunked";return false;}
    if(c.rx_hz!=frequency || (c.protocol==RADIO_PROTOCOL_DMR ? !feature_dmr()
        || c.cc!=radio_channel_get_color_code(channel_record) || c.ts!=radio_channel_get_timeslot(channel_record)
        : !feature_p25() || c.nac!=control.nac)) {reason="reply_channel_mismatch";return false;}
    if(channel_scan.running) {reason="reply_stop_scan";return false;}
    if(c.flags&(RADIO_CALL_ENCRYPTED|RADIO_CALL_FILTERED)) {reason="reply_call_muted";return false;}
    feature_pause();
    radio_channel_set_private(channel_record,c.kind==RADIO_CALL_INDIVIDUAL);
    uint32_t reply_destination=c.kind==RADIO_CALL_INDIVIDUAL ? c.source : c.destination;
    if(!radio_channel_set_destination(channel_record,reply_destination))return false;
    if(feature_p25() && c.kind==RADIO_CALL_GROUP)control.talkgroup=reply_destination;
    pref_state="pending";reason="reply_target_saved";return true;
}
static void menu_transmit(void) {
    if(DM32_OMAHA_RX_ONLY) {owner_tx_inhibit=true;radio_inhibit(&control,true);return;}
    armed=false;
    if(normal_mode && control.tx_enabled) {
        owner_tx_inhibit=true;radio_inhibit(&control,true);reason="tx_inhibited";pref_state="pending";
    } else if(!channel_in_band(control.tx_frequency,true) || !channel_in_band(frequency,false))reason="enter_frequency";
    else if(!bf_cal_valid())reason="calibration_invalid";
    else if(board.power->battery_mv()<board.battery_critical_mv)reason="battery_low";
    else {owner_tx_inhibit=false;(void)normal_resume();reason="ptt_ready";pref_state="pending";}
}
// Key actions are accepted only on debounced fresh presses; saves are deferred.
static void local_action(unsigned action,bool ptt_down) {
#if DM32_OMAHA_RX_ONLY
    // Fixed receiver controls never call feature_pause(), stop the follower,
    // modify the preset, or enter a message/app/programming mode.
    if(ptt_down)return;
    if(action==ACT_BACK) {menu_open=false;screen("HOME");return;}
    if(!menu_open) {
        if(action==ACT_SELECT) {menu_open=true;menu_page=MENU_DISPLAY;menu_item=0;screen("MENU");}
        return;
    }
    if(action==ACT_NAV_UP)menu_item=(menu_item+3u)%4u;
    else if(action==ACT_NAV_DOWN)menu_item=(menu_item+1u)%4u;
    else if(action==ACT_SELECT) {
        if(menu_item<2u) {
            static const uint16_t times[]={0,15,30,60,120};
            uint16_t *seconds=menu_item ? &radio_lights.keypad_seconds:&radio_lights.screen_seconds;
            unsigned next=0;for(unsigned i=0;i<5u;++i)if(*seconds==times[i])next=(i+1u)%5u;
            *seconds=times[next];
        } else if(menu_item==2u) {radio_lights.locked=true;menu_open=false;}
    }
    screen(menu_open ? "MENU":"HOME");return;
#endif
    if(cps_link || cps_active)return;
    if(trunk_system_menu_action(action,ptt_down))return;
    if(apps_active()) {
        if(action==ACT_BACK) {
            if(ptt_down) {ptt_release_required=true;ptt_release_seen=false;}
            apps_stop(true);screen("HOME");
        } else if(applet_owns_radio && !ptt_down) {
            applet_keys=action;radio_applet_vm_signal(&applets.vm,RADIO_APPLET_EVENT_KEY);
        }
        return;
    }
    if(message_ui_action(action,ptt_down))return;
    if(airband_show) {
        bool broadcast_key=(action==ACT_MONITOR && radio_functions_get_action(global_record,RADIO_FUNCTION_SK1)==RADIO_FUNCTION_BROADCAST)
            || (action==ACT_AB && radio_functions_get_action(global_record,RADIO_FUNCTION_SK2)==RADIO_FUNCTION_BROADCAST);
        if(broadcast_key) {airband_leave(ptt_down);if(!ptt_down)broadcast_toggle();return;}
        if(action==ACT_BACK) {
            if(editing) {editing=false;digit_count=0;reason="airband_am";airband_screen();}
            else airband_leave(ptt_down);
            return;
        }
        if(ptt_down)return;
        if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9) {
            if(!editing) {field=EDIT_AIRBAND;editing=true;edit_from_menu=false;digit_count=0;}
            if(digit_count<field_digits())frequency_digits[digit_count++]=(char)('0'+action-ACT_DIGIT_0);
            reason="enter_frequency";
        } else if(action==ACT_CONTEXT) {
            if(!editing) {field=EDIT_AIRBAND;editing=true;edit_from_menu=false;digit_count=0;}
            if(digit_count && digit_count<field_digits() && !memchr(frequency_digits,'.',digit_count))frequency_digits[digit_count++]='.';
            reason="enter_frequency";
        } else if(action==ACT_QUICK && editing) {
            if(digit_count)--digit_count;
            reason="enter_frequency";
        } else if(action==ACT_QUICK && airband.running) {
            airband.squelch=airband.squelch ? 0u : (uint8_t)airband_squelch;
            airband.close_count=0;airband.have_status=false;
        } else if(action==ACT_SELECT && editing) {
            uint32_t hz;
            if(!radio_airband_input_hz(frequency_digits,digit_count,&hz))reason="invalid_frequency";
            else if(radio_airband_tune(&airband,hz)) {
                airband_hz=hz;editing=false;digit_count=0;reason="airband_am";
            }
        } else if(action==ACT_NAV_LEFT || action==ACT_NAV_RIGHT || action==ACT_NAV_UP || action==ACT_NAV_DOWN) {
            editing=false;digit_count=0;reason="airband_am";
            uint32_t hz=radio_airband_step(airband_hz,action==ACT_NAV_UP || action==ACT_NAV_RIGHT ? 1 : -1,airband_step_hz);
            if(radio_airband_tune(&airband,hz))airband_hz=hz;
        }
        airband_screen();return;
    }
    if(broadcast_show) {
        // P1/P2 have fixed seek meanings here, independent of home shortcuts.
        bool toggle=(action==ACT_MONITOR && radio_functions_get_action(global_record,RADIO_FUNCTION_SK1)==RADIO_FUNCTION_BROADCAST)
            || (action==ACT_AB && radio_functions_get_action(global_record,RADIO_FUNCTION_SK2)==RADIO_FUNCTION_BROADCAST);
        if(toggle) {broadcast_leave(ptt_down);return;}
        if(action==ACT_BACK) {
            if(editing) {editing=false;digit_count=0;reason="broadcast_fm";broadcast_screen();}
            else broadcast_leave(ptt_down);
            return;
        }
        if(ptt_down)return;
        if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9) {
            if(!editing) {field=EDIT_BCAST;editing=true;edit_from_menu=false;digit_count=0;}
            if(digit_count<field_digits())frequency_digits[digit_count++]=(char)('0'+action-ACT_DIGIT_0);
            reason="enter_frequency";
        } else if(action==ACT_CONTEXT) {
            if(!editing) {field=EDIT_BCAST;editing=true;edit_from_menu=false;digit_count=0;}
            if(digit_count && digit_count<field_digits() && !memchr(frequency_digits,'.',digit_count))
                frequency_digits[digit_count++]='.';
            reason="enter_frequency";
        } else if(action==ACT_QUICK && editing) {
            if(digit_count)--digit_count;
            reason="enter_frequency";
        } else if(action==ACT_SELECT && editing) {
            uint32_t khz;
            if(!radio_broadcast_input_khz(frequency_digits,digit_count,&khz))reason="invalid_frequency";
            else if(broadcast.busy)reason="broadcast_busy";
            else if(broadcast.owned && broadcast.running
                    && (khz==broadcast.khz || radio_broadcast_tune(&broadcast,khz))) {
                (void)radio_functions_set_broadcast_khz(global_record,khz);pref_state="pending";
                editing=false;digit_count=0;reason="broadcast_fm";
            }
        } else if(action==ACT_NAV_LEFT || action==ACT_NAV_RIGHT) {
            editing=false;digit_count=0;reason="broadcast_fm";
            (void)radio_broadcast_seek(&broadcast,action==ACT_NAV_RIGHT);
        } else if(action==ACT_NAV_UP || action==ACT_NAV_DOWN) {
            editing=false;digit_count=0;reason="broadcast_fm";
            uint32_t khz=broadcast.khz;
            if(action==ACT_NAV_UP)khz=khz>=RADIO_BCAST_MAX_KHZ ? RADIO_BCAST_MIN_KHZ : khz+RADIO_BCAST_STEP_KHZ;
            else khz=khz<=RADIO_BCAST_MIN_KHZ ? RADIO_BCAST_MAX_KHZ : khz-RADIO_BCAST_STEP_KHZ;
            (void)radio_broadcast_tune(&broadcast,khz);
        }
        broadcast_screen();return;
    }
    // Reassign only home-screen function keys; menu navigation and * retain
    // their fixed meanings, including the OK + * unlock chord.
    if(!ptt_down && !call_active && !prepared && !editing && !menu_open && !rx_lab) {
        int key=action==ACT_NAV_LEFT ? RADIO_FUNCTION_P1 : action==ACT_NAV_RIGHT ? RADIO_FUNCTION_P2
            : action==ACT_MONITOR ? RADIO_FUNCTION_SK1 : action==ACT_AB ? RADIO_FUNCTION_SK2 : -1;
        if(key>=0) {
            unsigned fn=radio_functions_get_action(global_record,(radio_function_key)key);
            if(fn==RADIO_FUNCTION_NONE)return;
            if(fn==RADIO_FUNCTION_LAST_HEARD) {
                feature_stop_scan(true);feature_pause();menu_open=true;menu_page=MENU_HISTORY;menu_item=0;
                screen("HOME");return;
            }
            if(fn==RADIO_FUNCTION_BROADCAST) {broadcast_toggle();return;}
            if(fn==RADIO_FUNCTION_SCAN) {
                if(channel_scan.running) {feature_stop_scan(true);feature_pause();reason="listening";}
                else (void)feature_scan_start();
                screen("HOME");return;
            }
            if(fn==RADIO_FUNCTION_POWER || fn==RADIO_FUNCTION_LOCK) {
                feature_stop_scan(true);feature_pause();
                if(fn==RADIO_FUNCTION_POWER)power_cycle();
                else {radio_lights.locked=true;reason="keypad_locked";}
                screen("HOME");return;
            }
            action=fn==RADIO_FUNCTION_MEMORY ? ACT_NAV_LEFT : fn==RADIO_FUNCTION_AB ? ACT_AB : ACT_NAV_RIGHT;
        }
    }
    if(!call_active && !prepared) {feature_stop_scan(true);feature_pause();}
    if(rx_job) {if(action==ACT_BACK) {rx_end("cancelled");screen("INFO");}return;}
    if(action==ACT_BACK) {
        if(call_active || prepared) {control.cancel=true;return;}
        if(editing) {
            editing=false;digit_count=0;menu_open=edit_from_menu;edit_from_menu=false;
        } else if(rx_lab) {
            rx_lab=false;menu_open=diag_from_menu;diag_from_menu=false;
        } else if(menu_open && menu_page!=MENU_ROOT) {
            menu_back();
        } else menu_open=false;
        screen("HOME");return;
    }
    if(ptt_down || call_active || prepared)return;
    if(rx_lab) {
#if DM32_LAB_DIAGNOSTICS
        if(action==ACT_SELECT) {rx_pass=rx_frame_test();rx_checked=true;screen("INFO");}
#endif
        return;
    }
    if(menu_open) {
        if(action==ACT_NAV_UP)menu_item=(menu_item+menu_count()-1u)%menu_count();
        else if(action==ACT_NAV_DOWN)menu_item=(menu_item+1u)%menu_count();
        else if(action==ACT_SELECT) {
            if(menu_page==MENU_HISTORY) {
                if(menu_item<heard_calls.count) {heard_selection=menu_item;menu_page=MENU_HEARD_CALL;menu_item=0;}
                else if(heard_calls.count) {memset(&heard_calls,0,sizeof heard_calls);menu_item=0;}
            } else if(menu_page==MENU_HEARD_CALL) {
                if(menu_item==6 && history_reply()) {menu_open=false;reason="reply_target_saved";}
            } else if(menu_page==MENU_TRUNK_SYSTEMS) {
                if(trunk_system_select(menu_item)) {menu_page=MENU_TRUNK;menu_item=0;}
            } else if(menu_page==MENU_TRUNK) {
                if(menu_item==0u) {menu_page=MENU_TRUNK_SYSTEMS;menu_item=global_record[28];}
                else if(menu_item==1u) {menu_open=false;(void)trunk_system_start_selected();}
                else if(menu_item==2u) {trunk_stop("operator");menu_open=false;reason="listening";}
                else if(menu_item==3u) {if(trunk_system_group())menu_edit(EDIT_TRUNK_TG);else reason="trunk_system_missing";}
                else if(menu_item==4u) {
                    if(global_record[28]) {global_record[29]^=1u;pref_state="pending";}
                    else reason="trunk_system_missing";
                } else {menu_open=false;(void)trunk_start();}
            } else if(menu_page==MENU_ROOT) {
                static const ui_menu groups[]={MENU_MEMORY,MENU_CHANNEL,MENU_AUDIO_TX,MENU_SETTINGS,MENU_TOOLS};
                menu_page=groups[menu_item];menu_item=0;
            } else if(menu_page==MENU_AUDIO_TX) {
                menu_page=menu_item ? MENU_TRANSMIT : MENU_VOICE;menu_item=0;
            } else if(menu_page==MENU_SETTINGS) {
                menu_page=menu_item ? MENU_FUNCTIONS : MENU_DISPLAY;menu_item=0;
            } else if(menu_page==MENU_TOOLS) {
                menu_page=menu_item==2u ? MENU_APPLETS : menu_item ? MENU_DIAGNOSTICS : MENU_RECEIVERS;menu_item=0;
            } else if(menu_page==MENU_APPLETS) {
                if(!menu_item) {menu_page=MENU_SAME_CHANNELS;menu_item=0;}
                else if(menu_item==9u) {(void)radio_applets_catalogue(&applets);screen("HOME");return;}
                else {unsigned slot=menu_item;if(radio_applets_run(&applets,slot))menu_open=false;screen("HOME");return;}
            } else if(menu_page==MENU_SAME_CHANNELS) {
                char request[48];snprintf(request,sizeof request,"APP SAME START %lu",(unsigned long)(162400000u+menu_item*25000u));
                (void)radio_microapps_command(&microapps,request);screen("HOME");return;
            } else if(menu_page==MENU_RECEIVERS) {
                if(menu_item==0) {broadcast_toggle();return;}
                else if(menu_item==1) {airband_toggle();return;}
                else if(menu_item==2)menu_edit(EDIT_BCAST);
                else if(menu_item==3)airband_step_hz=airband_step_hz==RADIO_AIRBAND_STEP_25K ? RADIO_AIRBAND_STEP_833 : RADIO_AIRBAND_STEP_25K;
                else airband_squelch=(airband_squelch+1u)%10u;
            } else if(menu_page==MENU_TRANSMIT) {
                if(menu_item==0)menu_transmit();
                else if(menu_item==1)power_cycle();
                else menu_edit(EDIT_TOT);
            } else if(menu_page==MENU_FUNCTIONS) {
                unsigned next=(radio_functions_get_action_raw(global_record,(radio_function_key)menu_item)+1u)%RADIO_FUNCTION_COUNT;
                (void)radio_functions_set_action(global_record,(radio_function_key)menu_item,(radio_function_action)next);pref_state="pending";
            } else if(menu_page==MENU_CHANNEL) {
                if(menu_item==0)menu_edit(EDIT_RX);
                else if(menu_item==1)menu_edit(EDIT_TX);
                else if(menu_item==3)menu_edit(feature_dmr() ? EDIT_DMR_CC : EDIT_NAC);
                else if(menu_item==2) {
                    if(channel_in_band(frequency,true)) {control.split=false;control.tx_frequency=frequency;reason="frequency_saved";pref_state="pending";}
                    else reason="invalid_frequency";
                } else if(menu_item==4) {
                    feature_capture();
                    radio_channel_mode_t next=(radio_channel_mode_t)((radio_channel_get_mode(channel_record)+1u)%3u);
                    if(radio_channel_set_mode(channel_record,next)) {
                        feature_apply();radio_complete(&control,false);normal_permission();pref_state="pending";
                    }
                }
                else if(menu_item==5) {if(feature_fm() || feature_dmr()) {menu_page=feature_dmr() ? MENU_DMR : MENU_FM;menu_item=0;}}
                else if(menu_item==6) {channel_record[12]^=16u;pref_state="pending";}
                else {unsigned next=(feature_filter()+1u)%3u;rx_promiscuous=next==1u;rx_tg_filter=next==2u;pref_state="pending";reason="rx_filter_saved";}
            } else if(menu_page==MENU_VOICE) {
                if(menu_item==3) {radio_channel_set_private(channel_record,!radio_channel_get_private(channel_record));pref_state="pending";}
                else menu_edit(menu_item==0 ? EDIT_TG : menu_item==1 ? EDIT_ID : EDIT_MIC);
            } else if(menu_page==MENU_DMR) {
                if(menu_item==0)menu_edit(EDIT_DMR_CC);
                else if(menu_item==1)(void)radio_channel_set_timeslot(channel_record,radio_channel_get_timeslot(channel_record)==1u ? 2u : 1u);
                else if(menu_item==2)radio_channel_set_private(channel_record,!radio_channel_get_private(channel_record));
                else radio_channel_set_repeater(channel_record,!radio_channel_get_repeater(channel_record));
                pref_state="pending";
            } else if(menu_page==MENU_MEMORY) {
                if(menu_item==0) {
                    (void)feature_toggle_mode();
                    menu_open=false;
                } else if(menu_item==1) {(void)feature_select_vfo(true);menu_open=false;}
                else if(menu_item<4)menu_edit(menu_item==2 ? EDIT_MEMORY : EDIT_RECALL);
                else if(menu_item==4) {menu_page=MENU_SCAN;menu_item=0;}
                else if(menu_item==5)(void)feature_zone_next();
                else if(menu_item==8) {menu_page=MENU_TRUNK;menu_item=0;}
                else {menu_page=menu_item==6 ? MENU_HISTORY : MENU_MESSAGES;menu_item=0;}
            } else if(menu_page==MENU_SCAN) {
                if(menu_item==0) {menu_open=false;if(channel_scan.running) {feature_stop_scan(true);feature_pause();reason="listening";}else (void)feature_scan_start();}
                else if(menu_item==1)feature_scan_next();
                else reason="edit_list_in_cps";
            } else if(menu_page==MENU_DISPLAY) {
                if(menu_item<2)menu_edit(menu_item==0 ? EDIT_SCREEN : EDIT_LIGHT);
                else {radio_lights.locked=true;menu_open=false;reason="keypad_locked";}
            } else if(menu_page==MENU_FM) {
                if(menu_item==0) {channel_record[12]^=32u;pref_state="pending";}
                else if(menu_item==1)menu_edit(EDIT_SQL);
                else if(menu_item==3 || menu_item==5)menu_edit(menu_item==3 ? EDIT_TXTONE : EDIT_RXTONE);
                else {unsigned offset=menu_item==2 ? 26u : 28u;unsigned type=(feature_u16(channel_record+offset)>>14)+1u;
                    type%=4u;feature_put16(channel_record+offset,type ? (type<<14)|(type==1u ? 1000u : 19u) : 0u);pref_state="pending";}
            } else if(menu_item<2) {
#if DM32_LAB_DIAGNOSTICS
                if(menu_item==1) {rx_pass=rx_frame_test();rx_checked=true;}
#endif
                menu_open=false;rx_lab=true;diag_from_menu=true;
            }
#if DM32_LAB_DIAGNOSTICS
            else {
                menu_open=false;diag_from_menu=false;
                if(normal_mode) {normal_mode=false;mon_enabled=false;session_enabled=armed=false;radio_inhibit(&control,true);radio_receive_state(&control,false,false,false,false);reason="bench";}
                else (void)normal_resume();
            }
#endif
        }
        screen("MENU");return;
    }
    if(!editing && action==ACT_NAV_RIGHT) {rx_lab=true;diag_from_menu=false;screen("INFO");return;}
    if(!editing && action==ACT_AB) {(void)feature_select_vfo(true);screen("HOME");return;}
    if(!editing && (action==ACT_NAV_UP || action==ACT_NAV_DOWN)) {
        if(feature_memory())(void)feature_recall(action==ACT_NAV_UP ? 1 : -1);
        else {uint32_t step=12500u,hz=action==ACT_NAV_UP ? frequency+step : frequency>=step ? frequency-step : 0;
            if(radio_configure(&control,hz,channel_in_band(hz,false))) {reason="frequency_saved";pref_state="pending";}}
        screen("HOME");return;
    }
    if(!editing && action==ACT_NAV_LEFT) {
        (void)feature_toggle_mode();
        screen("HOME");return;
    }
    if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9) {
        if(!editing) {armed=false;field=feature_memory() ? EDIT_RECALL : EDIT_RX;editing=true;edit_from_menu=false;digit_count=0;}
        if(digit_count<field_digits())frequency_digits[digit_count++]=(char)('0'+action-ACT_DIGIT_0);
        reason=field==EDIT_RECALL ? "enter_channel" : "enter_frequency";
    } else if(action==ACT_CONTEXT && editing && field==EDIT_BCAST) {
        if(digit_count && digit_count<field_digits() && !memchr(frequency_digits,'.',digit_count))
            frequency_digits[digit_count++]='.';
        reason="enter_frequency";
    } else if(action==ACT_CONTEXT && !editing) {
        armed=false;field=feature_memory() ? EDIT_RECALL : EDIT_RX;editing=true;edit_from_menu=false;digit_count=0;
        reason=field==EDIT_RECALL ? "enter_channel" : "enter_frequency";
    } else if(editing && field==EDIT_NAC && (action==ACT_NAV_UP || action==ACT_NAV_DOWN)) {
        if(!digit_count)frequency_digits[digit_count++]='0';
        char c=frequency_digits[digit_count-1];unsigned value=c<='9' ? c-'0' : c-'A'+10;
        value=(value+(action==ACT_NAV_UP ? 1 : 15))%16;
        frequency_digits[digit_count-1]="0123456789ABCDEF"[value];
    } else if(action==ACT_QUICK && editing) {
        if(digit_count)--digit_count;
        if(field==EDIT_BCAST)reason="enter_frequency";
    } else if(action==ACT_SELECT) {
        if(editing) {
            uint32_t value=0;
            for(unsigned i=0;field!=EDIT_BCAST && i<digit_count;++i) {
                unsigned digit=frequency_digits[i]<='9' ? frequency_digits[i]-'0' : frequency_digits[i]-'A'+10;
                value=value*(field==EDIT_NAC ? 16u : 10u)+digit;
            }
            bool valid=digit_count!=0;
            if(field<=EDIT_TX) {
                value*=100u;
                valid=digit_count==7 && channel_in_band(value,field==EDIT_TX || !control.split);
                if(field==EDIT_RX)valid=radio_configure(&control,value,valid);
                else if(valid) {control.tx_frequency=value;control.split=true;}
            } else if(field==EDIT_NAC) {valid=valid && value<=0xfff;if(valid)control.nac=value;}
            else if(field==EDIT_TG) {valid=valid && value && value<=(feature_dmr() || radio_channel_get_private(channel_record) ? 0xffffffu : 0xffffu);
                if(valid) {if(feature_dmr() || radio_channel_get_private(channel_record))valid=radio_channel_set_destination(channel_record,value);else {control.talkgroup=value;feature_temporary_tg=false;}}}
            else if(field==EDIT_DMR_CC)valid=valid && radio_channel_set_color_code(channel_record,value);
            else if(field==EDIT_MIC) {valid=valid && value<=42;if(valid)mic_gain_db=value;}
            else if(field==EDIT_TOT)valid=valid && value>=RADIO_TOT_MIN_SECONDS && radio_functions_set_tot_seconds(global_record,value);
            else if(field==EDIT_TRUNK_TG)valid=valid && value>0u && value<=65535u && trunk_system_save_group((uint16_t)value);
            else if(field==EDIT_BCAST) {
                uint32_t khz;valid=radio_broadcast_input_khz(frequency_digits,digit_count,&khz)
                    && radio_functions_set_broadcast_khz(global_record,khz);
            }
            else if(field==EDIT_ID) {valid=valid && value && value<=0xffffff;if(valid)control.source_id=value;}
            else if(field==EDIT_MEMORY)valid=valid && feature_save_memory(value);
            else if(field==EDIT_RECALL) {
                reason="channel_empty";valid=valid && value>=1 && value<=P25_CS_CHANNELS;
                if(valid)valid=feature_select_channel(value);
            } else if(field==EDIT_SCREEN || field==EDIT_LIGHT) {
                valid=valid && value<=600;
                if(valid) {if(field==EDIT_SCREEN)radio_lights.screen_seconds=(uint16_t)value;else radio_lights.keypad_seconds=(uint16_t)value;}
            } else if(field==EDIT_SQL) {valid=valid && value<=9;if(valid)channel_record[30]=(uint8_t)value;}
            else {
                unsigned offset=field==EDIT_TXTONE ? 26u : 28u,type=feature_u16(channel_record+offset)>>14;
                if(!value)feature_put16(channel_record+offset,0);
                else if(type>=2) {
                    unsigned code=0;for(unsigned i=0;i<digit_count;++i) {unsigned digit=(unsigned)(frequency_digits[i]-'0');if(digit>7)valid=false;code=(code<<3)|digit;}
                    valid=valid && code && code<=511;if(valid)feature_put16(channel_record+offset,(type<<14)|code);
                } else {valid=valid && value>=600 && value<=2600;if(valid)feature_put16(channel_record+offset,(1u<<14)|value);}
            }
            if(!valid) {if(field!=EDIT_RECALL)reason="invalid_frequency";}
            else {
                editing=false;digit_count=0;reason=field==EDIT_MEMORY ? "memory_saved" : "frequency_saved";pref_state="pending";
                menu_open=edit_from_menu;edit_from_menu=false;
                if(normal_mode) {mon_enabled=channel_in_band(frequency,false);mon_reason=mon_enabled ? "ready" : "no_channel";}
            }
        } else {menu_open=true;menu_page=MENU_ROOT;menu_item=0;}
    } else return;
    screen("HOME");
}
// Encoder drivers may return accumulated detents. Channel selection resolves
// the final populated slot once, rather than flashing intermediate selections.
static void local_encoder(int steps) {
#if DM32_OMAHA_RX_ONLY
    if(steps && menu_open) {
        unsigned delta=(steps>0 ? (unsigned)steps:0u-(unsigned)steps)%4u;
        menu_item=(menu_item+(steps>0 ? 4u-delta:delta))%4u;screen("MENU");
    }
    return;
#endif
    if(apps_active())return;
    if(!steps || cps_link || cps_active || call_active || prepared)return;
    if(airband_show) {
        editing=false;digit_count=0;reason="airband_am";
        uint32_t hz=radio_airband_step(airband_hz,steps,airband_step_hz);
        if(radio_airband_tune(&airband,hz))airband_hz=hz;
        airband_screen();return;
    }
    if(broadcast_show || editing || rx_lab || rx_job) {
        local_action(steps>0 ? ACT_NAV_UP : ACT_NAV_DOWN,false);return;
    }
    if(menu_open) {
        unsigned count=menu_count(),delta=(steps>0 ? (unsigned)steps : 0u-(unsigned)steps)%count;
        menu_item=(menu_item+(steps>0 ? count-delta : delta))%count;
        screen("MENU");return;
    }
    if(channel_scan.running) {feature_stop_scan(true);feature_pause();}
    if(feature_memory())(void)feature_recall(steps);
    else {
        feature_stop_scan(true);feature_pause();
        int64_t hz=(int64_t)frequency+(int64_t)steps*12500;
        if(hz>=0 && hz<=UINT32_MAX && radio_configure(&control,(uint32_t)hz,channel_in_band((uint32_t)hz,false))) {
            reason="frequency_saved";pref_state="pending";
        } else reason="invalid_frequency";
    }
    screen("HOME");
}
static void keypad_poll(uint32_t keys) {
    uint32_t now=hrc_micros();
    if(keys!=key_candidate) { key_candidate=keys; key_changed_at=now; return; }
    if(now-key_changed_at<25000u || keys==key_stable) return;
    uint32_t pressed=keys&~key_stable; key_stable=keys;
    // BACK requests a controlled call end even with PTT held.
    for(unsigned i=0;i<board.keymap_len;++i) {
        const keymap_entry_t *k=&board.keymap[i];
        if(k->short_action==ACT_BACK && (pressed&(1u<<k->bit))) {
            local_action(ACT_BACK,(keys&ptt_mask)!=0); return;
        }
    }
    uint32_t other=keys&~ptt_mask;
    if(!other || (other&(other-1u))) return; // reject chords
    for(unsigned i=0;i<board.keymap_len;++i) {
        const keymap_entry_t *k=&board.keymap[i];
        if(pressed&(1u<<k->bit)) local_action(k->short_action,(keys&ptt_mask)!=0);
    }
}
static bool prepare_p25_tx_at(bool packet,uint32_t tx_hz) {
    if(DM32_OMAHA_RX_ONLY) {(void)packet;(void)tx_hz;return false;}
#if DM32_TRUNK_SUBSCRIBER
    // Snapshot the exact subscriber action before its deliberate RX handoff.
    // Conventional PTT remains inhibited on the control channel.
    bool subscriber=trunk_subscriber_prepare_permission(packet,tx_hz);
#else
    bool subscriber=false;
#endif
    if(trunk_enabled && !subscriber)return false;
    if(mon_running || mon_frontend_ready)mon_stop("transmit");
    if(analog_fm.owned)p25_fm_stop(&analog_fm);
    if(rx_job || call_active || prepared || editing || (menu_open && !(packet && message_menu_active())) || rx_lab || control.state==RADIO_FAULT) return false;
    bool permitted=(normal_mode && !tx_fixed && !owner_tx_inhibit) || session_enabled
        || (armed && (int32_t)(hrc_micros()-arm_until)<0);
    armed=false;
    if(!permitted || (!subscriber && (control.inhibit || !control.tx_enabled)) || !dev || !hooks || !board.audio || !bf_cal_valid() || !channel_in_band(tx_hz,true) || !channel_in_band(frequency,false)
       || board.power->battery_mv()<board.battery_critical_mv) return false;
    board.radio->audio(false); board.radio->set_mode(RADIO_MODE_DMR);
    // DMR board TX prepares calibrated settings, but RF switch and PA wait for
    // our IRQ handlers. Normal DMR entry/exit are interposed above.
    saved_rf_mode=hrc7000_rd(dev,C7_RF_MODE); prepared=true;
    tx_dac.before_tx=tx_dac.prepared=tx_dac.after_stop=tx_dac.pre_rf=tx_dac.pa=tx_dac.end=tx_dac.seen=0;
    if(!board.radio->rx(tx_hz,RADIO_BW_12K5,NULL)) return false;
    tx_dac.before_tx=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_BEFORE_TX;
    if(!feature_tx_settings_valid() || !board.radio->tx(tx_hz,RADIO_BW_12K5,(uint8_t)feature_tx_power(),NULL)) return false;
    tx_dac.prepared=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PREPARED;
    saved_rf_mode=hrc7000_rd(dev,C7_RF_MODE);
    uint32_t lock=hrc_irq_save(); hardware_stop();
    tx_dac.after_stop=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_AFTER_STOP;
    wr(C7_LAYER2_SLOTON,0); wr(C7_FM_PTT,0);
    wr(C7_WORK_MODE,C7_WORK_MODE_FM);
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_preload_active() || trunk_subscriber_request_owned()) {
        // Finite short bursts release both native slot synchronizers before
        // publishing the new immutable RAM image. Match the raw-PHY driver's
        // layer-2 release context; this is not a measured reader-origin reset.
        // RF/PA are off here. FIRE and the absolute cutoff remain unchanged.
        wr(C7_WORK_MODE,C7_WORK_MODE_DMR);
        wr(C7_LAYER2_CONTROL,0xc0);
        wr(C7_LAYER2_TXRX_CTRL,0xc00000);
        wr(C7_LAYER2_TXRX_CTRL,0);
        wr(C7_WORK_MODE,C7_WORK_MODE_FM);
    }
#endif
    wr(C7_WORK_MODE,0x02);
    hrc7000_audio_bits(dev,0,C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY|C7_AUDIO_PCM_SPK|C7_AUDIO_PCM_MIC);
    wr(C7_AUDIO_BUFFER_CLR,3);
    hrc_pin_write(PIN_MIC_PATH,false);
    hrc_irq_restore(lock);
    return true;
}
static bool prepare_p25_tx(bool packet) {return prepare_p25_tx_at(packet,control.tx_frequency);}
static bool begin_capture(void) {
    if(DM32_OMAHA_RX_ONLY)return false;
    if(!p25_channel_build_call(&call_frames,control.nac,control.talkgroup,control.source_id,
        normal_mode && radio_channel_get_private(channel_record),radio_channel_get_destination(channel_record)) || !prepare_p25_tx(false))return false;
    p25_live_tx_init(&live); memcpy(live.hdu,call_frames.hdu,99); memcpy(live.tdu,call_frames.tdu,18); memset(&pcmq,0,sizeof pcmq); memset(payload,0,sizeof payload);
    if(!p25_live_tx_set_startup_extra(&live,tx_startup_extra))return false;
    unsigned seconds=feature_tx_tot();call_capture_frames=seconds*50u;call_tot_expired=false;
    call_soft_limit_us=(seconds+3u)*1000000u;
    if(!p25_live_tx_set_rf_limit(&live,(seconds+5u)*1000000u))return false;
    encoded=target=max_encode=max_pack=driver_loss=rf_audio=0; payload_hash=2166136261u;
    if(!tx_fixed && !imbe_bench_init())return false;
    hrc_audio_pcm_reset_stats();
    capture_started=last_pcm=hrc_micros(); reason="running"; call_active=true; pcmq.accepting=!tx_fixed;
    if(tx_fixed) {
        target=tx_pairs*18u;payload_hash=0;
        pcm_mode=hrc7000_rd(dev,C7_WORK_MODE);pcm_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
        return true; // No microphone or codec work for the pre-encoded fixture.
    }
    if(pcm_p25_tx())return true; // Serial source is paced by pcm_poll; no live microphone.
    hrc7000_set_mic_gain(dev,(uint8_t)mic_gain_db);
    audio_on=board.audio->start(capture,NULL);
    pcm_mode=hrc7000_rd(dev,C7_WORK_MODE); pcm_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
    if(!audio_on) { fail("audio_start"); return false; }
    return true;
}
static void start_rf(void) {
    if(DM32_OMAHA_RX_ONLY) {hardware_stop();return;}
    uint32_t lock=hrc_irq_save();
    if(!call_active || !p25_live_tx_start(&live,hrc_micros())) { hrc_irq_restore(lock); return; }
    tx_write_half=tx_writer==TX_WRITER_ALT1 ? 1u : 0u;
    // hardware_stop powers the native PA-drive DAC down after board TX setup.
    // Restore only its power, while RF/PA and DAC_DATA_B are still off; the
    // existing calibrated board hook supplies the selected level's PA drive.
    if(tx_dac_restore)hrc_dac_b_power(true);
    tx_dac.pre_rf=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PRE_RF;
    for(unsigned i=0;i<72;++i) dev->buf[i]=0x77;
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);
    wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    wr(C7_SYS_INTERP_MASK,PHY_READY);
    hardware_running=true; pa_started=false; control.state=RADIO_TX_VOICE;
    rf_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
    hrc_irq_enable(IRQ_MODEM_SYS,true);
    hrc_irq_enable(IRQ_MODEM_TS_TX,true); hrc_irq_enable(IRQ_MODEM_TS_RX,true);
    hrc_irq_enable(IRQ_MODEM_RF_TX,true); hrc_irq_enable(IRQ_MODEM_RF_RX,true);
    (void)hard_guard_arm(live.rf_limit_us/1000000u);
    wr(C7_LAYER2_CONTROL,0x82);
    hrc_irq_restore(lock);
}
// The finite lab path borrows only packet scratch. Its renderer and hardware
// cutoff replace the ordinary voice startup/drain; no microphone is started.
static bool start_probe_short_rf(void) {
    if(DM32_OMAHA_RX_ONLY)return false;
    uint32_t lock=hrc_irq_save();
    if(!trunk_probe_short_active() || !call_active || hardware_running ||
       !p25_test_tx_start(&live.timing,hrc_micros(),true)) {
        hrc_irq_restore(lock);return false;
    }
    tx_write_half=1u;
    if(tx_dac_restore)hrc_dac_b_power(true);
    tx_dac.pre_rf=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PRE_RF;
    for(unsigned i=0;i<72;++i)dev->buf[i]=0x77;
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);
    wr(C7_INTERP_CLEAR,C7_INT_TS_TX|C7_INT_TS_RX|C7_INT_RF_TX|C7_INT_RF_RX);
    wr(C7_SYS_INTERP_MASK,PHY_READY);
    // Keep the independent seconds-scale fallback even if modem/task or the
    // separate microsecond cutoff IRQ disappears. Validate both arms before
    // enabling modem timing; failure never enables RF.
    if(!hard_guard_arm(2u) || !trunk_probe_short_guard_arm()) {
        hardware_stop();hrc_irq_restore(lock);return false;
    }
    hardware_running=true;pa_started=false;control.state=RADIO_TX_VOICE;
    rf_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
    hrc_irq_enable(IRQ_MODEM_SYS,true);
    hrc_irq_enable(IRQ_MODEM_TS_TX,true);hrc_irq_enable(IRQ_MODEM_TS_RX,true);
    hrc_irq_enable(IRQ_MODEM_RF_TX,true);hrc_irq_enable(IRQ_MODEM_RF_RX,true);
    wr(C7_LAYER2_CONTROL,0x82);
    hrc_irq_restore(lock);return true;
}
static void poll_call(bool down) {
    if(!call_active || message_packet_tx) return;
    uint32_t blocks=0, under=0;
    if(!tx_fixed)hrc_audio_pcm_stats(&blocks,&driver_loss,&under);
    (void)blocks; (void)under;
    // Audio runs at higher priority and updates last_pcm. A callback between
    // an earlier clock read and this age check would make unsigned subtraction
    // wrap and falsely report a 200-ms stall. Sample both under the same short
    // lock, just as the finite lab microphone producer already does.
    uint32_t clock_lock=hrc_irq_save(),now=hrc_micros();
    bool stalled=pcmq.accepting&&now-last_pcm>=200000u;
    unsigned overflow=pcmq.overflow;
    hrc_irq_restore(clock_lock);
    if(driver_loss || overflow) { fail(driver_loss ? "pcm_driver_loss" : "pcm_overflow"); return; }
    if(now-capture_started>call_soft_limit_us) { fail("call_timeout"); return; }
    if(stalled) { fail("pcm_stalled"); return; }
    if((!down || control.cancel) && !hardware_running && !pcm_p25_tx()) { stop_call("released_before_rf",false); return; }
    if(tx_fixed) {
        uint32_t lock=hrc_irq_save();
        if(!down || control.cancel) {
            // Preserve already-published audio, rounding up only to a complete
            // alternating pair. Release never publishes a fresh full fixture.
            target=((live.published+1u)/2u)*18u;
            control.state=RADIO_TX_DRAIN;
        }
        if(encoded<target && live.count<LIVE_BANKS) {
            const uint8_t *ldu=((encoded/9u)&1u) ? call_frames.ldu2 : call_frames.ldu1;
            if(!p25_live_tx_push(&live,ldu)) {hrc_irq_restore(lock);fail("ldu_publish");return;}
            encoded+=9u;
        }
        if(encoded==target && !live.finished && !p25_live_tx_finish(&live)) {
            hrc_irq_restore(lock);fail("ldu_publish");return;
        }
        hrc_irq_restore(lock);
    } else {
    uint32_t lock=hrc_irq_save();
    if(!down || control.cancel) pcmq.accepting=false;
    bool finished=!pcmq.accepting;
    if(finished && !target) target=((pcmq.captured+17u)/18u)*18u;
    // Subscriber voice can already have a complete primed pair when PTT is
    // released before the first microphone callback. Close that pair through
    // the normal TDU path; target0 alone must never finish an open input.
    if(finished && encoded==target && !live.finished) (void)p25_live_tx_finish(&live);
    int16_t pcm[160]; bool have=mic_queue_pop(&pcmq,pcm);
    hrc_irq_restore(lock);
    if(finished) { control.state=RADIO_TX_DRAIN; audio_stop(); }
    if(!have && target && encoded<target) { memset(pcm,0,sizeof pcm); have=true; }
    if(have) {
        uint32_t start=hrc_micros(); imbe_bench_encode_pcm(pcm,payload[encoded%9u]);
        if(!imbe_bench_ready()) {fail("codec_owner");return;}
        uint32_t elapsed=hrc_micros()-start; if(elapsed>max_encode) max_encode=elapsed;
        for(unsigned i=0;i<11;++i) payload_hash=(payload_hash^payload[encoded%9u][i])*16777619u;
        ++encoded;
        if(encoded%9u==0) {
            uint8_t ldu[216]; start=hrc_micros();
            p25_live_ldu_template(ldu,(const uint8_t (*)[11])payload,((encoded/9u)&1u)==0 ? call_frames.ldu2 : call_frames.ldu1);
            elapsed=hrc_micros()-start; if(elapsed>max_pack) max_pack=elapsed;
            lock=hrc_irq_save();
            bool ok=call_active && p25_live_tx_push(&live,ldu);
            if(ok && target && encoded==target) ok=p25_live_tx_finish(&live);
            hrc_irq_restore(lock);
            if(!ok) { fail("ldu_publish"); return; }
        }
    }
    }
    // PTT may have been released while the encoder ran. Do not initiate RF then.
    down=pcm_p25_tx() ? pcm_engine.tx_started && !control.cancel : (board.input->scan()&ptt_mask)!=0;
    if(!hardware_running && down && !control.cancel && live.count>=2) start_rf();
    uint32_t lock=hrc_irq_save();
    p25_test_tx_poll_limit(&live.timing,hrc_micros(),true,live.rf_limit_us); // normal release drains through TDU
    if(hardware_running && !p25_test_tx_active(&live.timing)) {
        reason=live.timing.state==P25_TX_DONE ? (call_tot_expired ? "time_limit" : "complete") : "rf_timing";
        if(call_tot_expired) {ptt_release_required=true;ptt_release_seen=false;}
        if(live.timing.state!=P25_TX_DONE) session_enabled=false;
        hardware_stop(); call_active=false; pcmq.accepting=false;
    }
    hrc_irq_restore(lock);
}
#include "p25_message_radio.h"

static void rx_end(const char *why) {
    uint32_t lock=hrc_irq_save();
#if DM32_LAB_DIAGNOSTICS
    rxcap.accepting=false;
#endif
    rx_sampling=false;rx_job=false;rx_reason=why;
    hardware_stop();hrc_irq_restore(lock);
    board.radio->set_mode(RADIO_MODE_FM);board.radio->audio(false);board_rf_safe();
}
static void rx_poll(bool down) {
#if DM32_LAB_DIAGNOSTICS
    if(!rx_job)return;
    if(down) {rx_end("ptt_cancelled");screen("INFO");return;}
    uint32_t now=hrc_micros();
    if(!rx_sampling && (int32_t)(now-rx_due)>=0) {
        rxcap_reset(&rxcap);rx_started=now;rx_reason="recording";
        rx_signal_count=0;rx_signal_max_us=0;rx_signal_due=now;
        rx_reg_work=hrc7000_rd(dev,C7_WORK_MODE);rx_reg_rf=hrc7000_rd(dev,C7_RF_MODE);
        rx_reg_bw=hrc7000_rd(dev,C7_FM_BANDWIDTH);rx_reg_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
        rx_reg_phase=hrc7000_rd(dev,0x128u); // PHASE_OUT: AF input min/max, read-only
        rx_pin_source=hrc_pin_read(PIN_SPK_SOURCE);rx_pin_mic=hrc_pin_read(PIN_MIC_PATH);
        screen("INFO");
        rx_started=now=hrc_micros();rx_signal_due=now;
        uint32_t lock=hrc_irq_save();
        wr(C7_SYS_INTERP_CLEAR,0xffffffffu);rx_sampling=true;
        wr(C7_SYS_INTERP_MASK,1u<<14);hrc_irq_enable(IRQ_MODEM_SYS,true);
        hrc_irq_restore(lock);
    }
    // RF chip bus accesses are task-only. Never put them in the 32-ms ISR.
    if(rx_sampling && rxcap.accepting && board.radio->status && rx_signal_count<60
       && (int32_t)(now-rx_signal_due)>=0) {
        radio_status_t st={0};uint32_t begin=hrc_micros();board.radio->status(&st);
        uint32_t elapsed=hrc_micros()-begin;
        if(elapsed>rx_signal_max_us)rx_signal_max_us=elapsed;
        rx_signals[rx_signal_count++]=(rx_signal){begin-rx_started,st.rssi_dbm,st.noise};
        rx_signal_due=hrc_micros()+100000u;
    }
    if(rx_sampling && (!rxcap.accepting || now-rx_started>RXCAP_TIMEOUT_US)) {
        rx_end(rxcap.count==RXCAP_BLOCKS ? "complete" : "capture_timeout");
        screen("INFO");status();
    }
#else
    (void)down;
#endif
}
// Advance at most 31 times per call, rather than divide on every timer wakeup.
#if DM32_LAB_DIAGNOSTICS
static mon_perf_bin *mon_perf_at(uint32_t now) {
    uint32_t age=now-mon_first_push;
    while(mon_perf_index<31 && age>=(mon_perf_index+1u)*1000000u)++mon_perf_index;
    return &mon_perf[mon_perf_index];
}
#endif
// Dedicated speaker PCM path: fixed 80-sample halves, no codec or board work
// in the consumed-buffer ISR. Byte stores match the stock playback routine.
static void mon_pcm_disable(void) {
    hrc_irq_enable(IRQ_PCM_RD,false);
    if(dev) {
        hrc7000_audio_bits(dev,0,C7_AUDIO_PCM_SPK);
        wr(C7_INTERP_CLEAR,C7_INT_PCM_RD);
    }
    mon_pcm_pending=false;
}
static void mon_pcm_load(const int16_t *samples) {
    volatile uint8_t *window=P25_SPEAKER_PCM_WINDOW;
    for(unsigned i=0;i<80;++i) {
        uint16_t s=(uint16_t)samples[i];
        window[2*i]=(uint8_t)s;window[2*i+1]=(uint8_t)(s>>8);
    }
    hrc_barrier();
    mon_pcm_commit_samples(&monitor,80);
    mon_pcm_submitted+=80;mon_pcm_pending=true;
}
static void mon_pcm_irq(void) {
    wr(C7_INTERP_CLEAR,C7_INT_PCM_RD);
    if(mon_capture_control_only() || !mon_pcm_backend || !mon_running || mon_failed || !mon_routed || !mon_pcm_pending) {
        mon_pcm_disable();return;
    }
    uint32_t now=hrc_micros(),gap=now-mon_pcm_last;
    if(gap>mon_pcm_gap)mon_pcm_gap=gap;
    mon_pcm_last=now;++mon_pcm_irqs;mon_pcm_consumed+=80;
    mon_pcm_pending=false;
    const int16_t *chunk=mon_pcm_peek(&monitor);
    if(chunk)mon_pcm_load(chunk);
    else mon_pcm_disable(); // Do not replay stale RAM on starvation or end.
}
static void mon_pcm_service(void) {
    if(!mon_running || mon_failed || mon_capture_control_only()) {mon_pcm_disable();return;}
    if(mon_pcm_pending) {
        // A missing peripheral event must not replay the same half forever.
        if(hrc_micros()-mon_pcm_last>30000u) {mon_pcm_disable();mon_failed=true;}
        return;
    }
    const int16_t *chunk=mon_pcm_peek(&monitor);
    if(!chunk) {
        if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
        return;
    }
    mon_pcm_load(chunk); // Prime RAM before starting the hardware consumer.
    if(!mon_routed) {board.audio->speaker_pcm(true);mon_routed=true;}
    // Board hook supplies source selection and amp ownership but enables ring.
    // Replace that source; never leave both PCM and prompt playback enabled.
    hrc7000_audio_bits(dev,0,C7_AUDIO_RING_PLAY|C7_AUDIO_FM_PLAY);
    wr(C7_INTERP_CLEAR,C7_INT_PCM_RD);
    mon_pcm_last=hrc_micros();
    hrc_irq_enable(IRQ_PCM_RD,true);
    hrc7000_audio_bits(dev,C7_AUDIO_PCM_SPK,0);
}
// Higher-priority speaker service does no codec work and never starts the mic.
static void mon_speaker_step(void) {
    uint32_t lock=hrc_irq_save();
    // This task survives a P25 stop. Another mode may now own the shared PCM
    // hardware and receive arena; cleanup belongs to mon_stop(), not an idle
    // worker that could disable DMR's newly armed speaker interrupt/output.
    if(!mon_running || mon_capture_control_only() || pcm_owner) {hrc_irq_restore(lock);return;}
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_progress_owned || trunk_rx_stream_owned||trunk_rx_feed_selected()) {hrc_irq_restore(lock);return;}
#endif
    if(mon_pcm_backend) {mon_pcm_service();hrc_irq_restore(lock);return;}
#if DM32_LAB_DIAGNOSTICS
    uint32_t now=hrc_micros(),step_started=now;
    bool measure_step=mon_running;
    if(mon_routed && mon_spk_last_us) {
        uint32_t gap=now-mon_spk_last_us;if(gap>mon_spk_gap_us)mon_spk_gap_us=gap;
    }
    mon_perf_bin *perf=mon_pushes ? mon_perf_at(now) : NULL;
    if(perf && mon_routed && mon_spk_last_us) {
        uint32_t gap=now-mon_spk_last_us;if(gap>perf->max_service)perf->max_service=gap;
        if(!(hrc7000_rd(dev,C7_AUDIO_CONTROL)&C7_AUDIO_RING_PLAY))++perf->route_missing;
    }
    mon_spk_last_us=mon_routed ? now : 0;
    if(mon_running && !mon_failed) {
        const int16_t *chunk=mon_pcm_peek(&monitor);
        if(chunk) {
            mon_empty_since=0;
            if(!mon_routed) {board.audio->speaker_pcm(true);mon_routed=true;}
            // Bound the work per tick even when a mock/empty FIFO accepts forever.
            for(unsigned n=0;n<mon_fifo_limit && chunk && mon_running && !mon_failed;++n) {
                if(!hrc7000_prompt_push(dev,chunk)) {++mon_full;if(perf)++perf->full;break;}
                uint32_t pushed=hrc_micros();
                if(mon_pushes) {
                    uint32_t gap=pushed-mon_last_push;
                    if(gap>mon_push_gap) {mon_push_gap=gap;mon_worst_at=pushed-mon_first_push;mon_worst_queue=mon_count(monitor.pcm_head,monitor.pcm_tail,MON_PCM_FRAMES);}
                    perf=mon_perf_at(pushed);
                    if(gap>perf->max_gap)perf->max_gap=gap;
                } else {mon_first_push=pushed;perf=&mon_perf[0];}
                ++perf->pushes;
                mon_last_push=pushed;++mon_pushes;
                mon_pcm_commit(&monitor);
                // A chunk and its queue commit stay atomic, but let recorder/timer
                // IRQs run between chunks. Recheck fault state before another write.
                hrc_irq_restore(lock);lock=hrc_irq_save();
                chunk=mon_pcm_peek(&monitor);
            }
        } else if(mon_routed) {
            if(perf)++perf->empty;
            if(!mon_empty_since)mon_empty_since=hrc_micros();
            if(hrc_micros()-mon_empty_since>=40000u) {board.audio->speaker_pcm(false);mon_routed=false;}
        }
    } else if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
    uint32_t cost=hrc_micros()-step_started;
    if(measure_step) {
        if(cost>mon_step_max_us)mon_step_max_us=cost;
        mon_step_total_us+=cost;++mon_step_calls;
    }
#endif
    hrc_irq_restore(lock);
}
// Timer only wakes the higher-priority task: no codec, FIFO, board or UART work in ISR.
static void mon_speaker_tick(void) {
    hrc_timer_ack(SPEAKER_TIMER);
    if(mon_running && !mon_failed && mon_timer_us && mon_task_handle) {
        ++mon_timer_ticks;
        BaseType_t woken=pdFALSE;
        vTaskNotifyGiveFromISR(mon_task_handle,&woken);
        portYIELD_FROM_ISR(woken);
    }
}
static void mon_speaker_task(void *arg) {
    (void)arg;
    for(;;) {
#if DM32_TRUNK_SUBSCRIBER
        if(trunk_rx_feed_selected()) {trunk_rx_feed_service();continue;}
        if(trunk_rx_stream_owned) {
            trunk_rx_stream_service();
            continue;
        }
#endif
        if(mon_timer_us) {
            // One-tick fallback prevents a lost/stopped timer from blocking cleanup.
            uint32_t pending=ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(1));
            if(mon_running && pending>mon_notify_max)mon_notify_max=pending;
            mon_speaker_step();
        } else {mon_speaker_step();vTaskDelay(pdMS_TO_TICKS(mon_service_ms));}
    }
}
static bool mon_frontend_exclusive(void) {
    return !pcm_owner && !native_irq_owned && !digital_dmr.owned
        && !analog_fm.owned && !broadcast.owned && !airband.owned
        && !prepared && !call_active && !hardware_running && !audio_on && !rx_job;
}
static void mon_frontend_close(void) {
    hardware_stop();board.radio->audio(false);board.radio->set_mode(RADIO_MODE_FM);board_rf_safe();
}
static void mon_stop_mode(const char *why,bool retain_frontend) {
    bool was_ready=mon_frontend_ready;
    bool retain=retain_frontend && mon_frontend_exclusive() && !mon_failed
        && !mon_capture_control_only() && !mon_local_tone && !mon_replay
        && (mon_running || was_ready);
    mon_frontend_ready=false;
    mon_render_cancel();
#if DM32_TRUNK_SUBSCRIBER
    trunk_preload_cc_receive_stop();
    if(!trunk_rx_feed_terminal())trunk_rx_feed_release();
#endif
    if(!mon_running) {
        mon_control_only=mon_subscriber_control_only=false;
        // A second known-P25 pause can occur while a channel edit is saved.
        // An ordinary stop must also close an already-retained frontend.
        if(was_ready && !retain)mon_frontend_close();
        mon_frontend_ready=retain;return;
    }
#if DM32_TRUNK_SUBSCRIBER
    trunk_subscriber_return_epoch_end();
    if(++trunk_stream_epoch==0)++trunk_stream_epoch;
    if(trunk_session.running && !trunk_subscriber_handoff())p25_trunking_session_lost(&trunk_session,trunk_now_ms());
#endif
    uint32_t lock=hrc_irq_save();mon_running=false;mon_control_only=mon_subscriber_control_only=false;ui_rssi_valid=false;ui_rssi_due=hrc_micros();mon_reason=why;mon_pcm_disable();
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,hrc_micros());
    mon_have_sync=false;board.power->led(LED_GREEN,false);
    if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
    if(retain) {
        monitor.raw_tail=monitor.raw_head;monitor.pcm_tail=monitor.pcm_head;monitor.pcm_pos=0;
        monitor.playing=monitor.ending=monitor.have_raw=false;
        p25_receive_reset(&monitor.call);p25_voice_policy_init(&monitor.quality);
    }
    hardware_stop();hrc_irq_restore(lock);
    board.radio->audio(false);if(!retain)board.radio->set_mode(RADIO_MODE_FM);board_rf_safe();
    mon_frontend_ready=retain;
}
static void mon_stop(const char *why) {mon_stop_mode(why,false);}
static void mon_stop_retune(const char *why) {mon_stop_mode(why,true);}
static void mon_discard_audio(void) {
    // A newly unknown/encrypted call must not leave old queued speech playing.
    // The peripheral can consume only its already submitted 10-ms half.
    uint32_t lock=hrc_irq_save();
    mon_pcm_disable();
    monitor.discarded_pcm+=mon_count(monitor.pcm_head,monitor.pcm_tail,MON_PCM_FRAMES);
    monitor.pcm_tail=monitor.pcm_head;monitor.pcm_pos=0;
    monitor.playing=false;monitor.ending=false;
    if(mon_routed) {board.audio->speaker_pcm(false);mon_routed=false;}
    hrc_irq_restore(lock);
}
static void mon_reset_voice(void) {
    if(!imbe_bench_init())mon_failed=true;
    p25_voice_policy_init(&monitor.quality);
    memset(monitor.last_good_pcm,0,sizeof monitor.last_good_pcm);
    mon_tone_phase=0;mon_voice_us=0;monitor.last_voice_us=0;
}
static void mon_receive(const p25_rx *frame,void *context) {
    (void)context;++monitor.units;
#if DM32_TRUNK_SUBSCRIBER
    // Observe addressed replies before a passive follower can retune on grants.
    if(mon_control_only || trunk_lab_return_owned()) {trunk_lab_return_receive(frame);return;}
#endif
    // A production control receiver never initializes or consumes voice state.
    // A granted traffic-channel hop uses full mon_start() before delivering it.
    if(mon_subscriber_control_only && (!trunk_enabled || trunk.phase!=P25_TRUNKING_CONTROL))return;
    if(trunk_enabled) {
        // Retuning is deferred until after this demodulator callback. While a
        // return is pending, leave an already-qualified speaker tail intact.
        if(trunk.pending_hz)return;
        if(trunk.phase==P25_TRUNKING_CONTROL) {
            if(trunk.have_nac && frame->nac!=trunk.learned_nac)return;
            if(frame->duid==12u) {
#if DM32_TRUNK_SUBSCRIBER
                // Alternate control metadata is passive following only. It
                // never substitutes for an addressed subscriber response.
                if(trunk_session.running || trunk_system_subscriber)return;
                bool ambt_search=trunk_system_overlay_owned&&trunk_search.phase!=P25_TRUNK_SEARCH_OFF;
                bool ambt_follow=!ambt_search || trunk_search.phase==P25_TRUNK_SEARCH_LOCKED;
#else
                bool ambt_follow=true;
#endif
                uint8_t ambt_opcode=0xffu,ambt_block[12];uint32_t ambt_now=trunk_now_ms();
                p25_trunking_event ambt_event=p25_trunking_consume_ambt(&trunk,frame->frame,
                    frame->frame_bytes,ambt_now,ambt_follow,&ambt_opcode,ambt_block);
                bool ambt_activity=false;
#if DM32_TRUNK_SUBSCRIBER
                if(ambt_search) {
                    if(ambt_event!=P25_TRUNKING_IGNORED && trunk_search.phase==P25_TRUNK_SEARCH_PAUSED
                       &&trunk_stream_epoch!=trunk_search.epoch)
                        (void)p25_trunking_search_resume(&trunk_search,trunk_stream_epoch,ambt_now);
                    (void)p25_trunking_search_observe(&trunk_search,&trunk,ambt_event,
                        ambt_opcode,trunk_stream_epoch,ambt_now);
                    if(ambt_opcode!=0xffu) {
                        // A filtered grant is still real control traffic.
                        // The parser publishes this normalized block only
                        // after native header+packet CRCs pass. Read the
                        // embedded canonical NAC rather than trusting a
                        // caller's duplicate frame metadata.
                        uint16_t ambt_nac=(uint16_t)(((unsigned)frame->frame[6]<<4)
                            |(frame->frame[7]>>4));
                        ambt_activity=p25_trunking_search_activity(&trunk_search,&trunk,
                            ambt_nac,ambt_block,trunk_stream_epoch,ambt_now);
                    }
                }
#endif
                if(ambt_event==P25_TRUNKING_IGNORED && !ambt_activity)return;
                ++trunk_units;mon_have_sync=true;mon_sync_us=hrc_micros();return;
            }
            if(frame->duid!=7u)return;
            p25_tsdu unit;if(!p25_tsdu_decode(frame->frame,frame->frame_bytes,&unit))return;
#if DM32_TRUNK_SUBSCRIBER
            trunk_subscriber_return_control();
#endif
            uint32_t now=trunk_now_ms();++trunk_units;
#if DM32_TRUNK_SUBSCRIBER
            if(trunk_system_overlay_owned && trunk_search.phase==P25_TRUNK_SEARCH_PAUSED
               && !trunk_subscriber_transport_owned() && !trunk_subscriber_menu_paused()
               && trunk_stream_epoch!=trunk_search.epoch)
                (void)p25_trunking_search_resume(&trunk_search,trunk_stream_epoch,now);
#endif
            for(unsigned i=0;i<unit.count;++i) {
                p25_trunking_event mapped;
#if DM32_TRUNK_SUBSCRIBER
                bool search=trunk_system_overlay_owned&&trunk_search.phase!=P25_TRUNK_SEARCH_OFF;
                bool recoverable_loss=search&&trunk_search.phase==P25_TRUNK_SEARCH_LOCKED
                    &&trunk_subscriber_active()&&trunk_session.access.phase!=P25_TRUNK_ACCESS_FAILED;
                bool follow=!search||trunk_search.phase==P25_TRUNK_SEARCH_LOCKED;
                follow=follow&&!trunk_system_logout_requested&&!trunk_subscriber_logout_pending();
                if(trunk_session.running) {
                    // An active subscriber must stay on control while waiting
                    // for its addressed response, not follow another RID's call.
                    if(follow&&trunk_subscriber_active()&&trunk_subscriber_allow_follow())
                        mapped=p25_trunking_consume(&trunk,unit.nac,unit.block[i],now);
                    else mapped=p25_trunking_consume_control(&trunk,unit.nac,unit.block[i],now);
                    if(trunk_subscriber_active())
                        (void)trunk_subscriber_consume_control(unit.nac,receiver_frequency(),unit.block[i],now);
                    else (void)p25_trunking_session_consume_control(&trunk_session,unit.nac,
                        receiver_frequency(),unit.block[i],now);
                } else
#endif
                {
#if DM32_TRUNK_SUBSCRIBER
                    mapped=follow?p25_trunking_consume(&trunk,unit.nac,unit.block[i],now)
                        :p25_trunking_consume_control(&trunk,unit.nac,unit.block[i],now);
#else
                    mapped=p25_trunking_consume(&trunk,unit.nac,unit.block[i],now);
#endif
                }
#if DM32_TRUNK_SUBSCRIBER
                if(search) {
                    unsigned before=trunk_search.phase;
                    (void)p25_trunking_search_observe(&trunk_search,&trunk,mapped,
                        unit.block[i][0]&0x3fu,trunk_stream_epoch,now);
                    (void)p25_trunking_search_activity(&trunk_search,&trunk,unit.nac,
                        unit.block[i],trunk_stream_epoch,now);
                    // Only the native block that actually revoked search lock
                    // can authorize same-carrier recovery of its access fault.
                    // A prior bad-grant MAPPING/AUTH fault is not that proof.
                    if(before==P25_TRUNK_SEARCH_LOCKED&&trunk_search.phase==P25_TRUNK_SEARCH_ACQUIRE)
                        trunk_system_search_revoked=recoverable_loss
                            &&trunk_session.access.phase==P25_TRUNK_ACCESS_FAILED
                            &&(trunk_session.access.reason==P25_TRUNK_ACCESS_SITE_CHANGED
                               ||trunk_session.access.reason==P25_TRUNK_ACCESS_MAPPING);
                    if(trunk_session.access.phase==P25_TRUNK_ACCESS_FAILED
                       &&trunk_session.access.reason!=P25_TRUNK_ACCESS_SITE_CHANGED
                       &&trunk_session.access.reason!=P25_TRUNK_ACCESS_MAPPING)
                        trunk_system_search_revoked=false;
                }
#else
                (void)mapped;
#endif
            }
            mon_have_sync=true;mon_sync_us=hrc_micros();return;
        }
        if(trunk.phase!=P25_TRUNKING_VOICE || frame->nac!=trunk.learned_nac || frame->duid==12u)return;
    }
    // A control unit never creates, ends or authorizes a voice call.
    if(frame->duid==7u)return;
    if(!rx_promiscuous && frame->nac!=control.nac) {++monitor.rejected;return;}
    if(frame->duid==12u) {message_p25_receive(frame);return;}
    monitor.nid_recovered+=frame->nid_corrected!=0;
    p25_call_metadata metadata;
    bool valid=p25_call_decode(frame->frame,frame->duid,&metadata);
    bool completed_tail=monitor.ending && !monitor.call.active;
    p25_receive_event event=p25_receive_update(&monitor.call,frame->nac,frame->duid,
                                              &metadata,valid,hrc_micros());
    if(frame->duid==0u || frame->duid==5u || frame->duid==10u)
        mon_record_rejection(&monitor,frame->duid,&metadata,valid);
    // A terminator has no talkgroup and clears call identity in the policy.
    // It must drain an already-qualified tail, never flush it as an unknown TG.
    bool terminator=frame->duid==3 || frame->duid==15;
    bool group_allowed=terminator || call_selected(&monitor.call);
    if(event.end)radio_history_end(&heard_calls);
    else call_services_p25(event.new_call);
    if(!terminator && group_allowed && !monitor.call.private_call && monitor.call.group_valid && monitor.call.state==P25_RX_CLEAR)
        feature_scan_match_group(monitor.call.group);
    else if(!terminator && group_allowed && monitor.call.private_call && monitor.call.state==P25_RX_CLEAR)
        feature_scan_match_individual();
    if(!group_allowed) {event.voice=false;++monitor.rejected;}
    // Preserve a completed, validated tail when the following clear HDU arrives
    // before the speaker catches up. New codec/identity still reset; encrypted,
    // unknown and unsupported boundaries must never preserve authorization.
    bool keep_tail=group_allowed && completed_tail && event.new_call && frame->duid==0 && valid
        && metadata.classification==P25_CALL_CLEAR && metadata.ess_valid && metadata.mfid_valid;
    if((event.discard && !keep_tail) || !group_allowed)mon_discard_audio();
    if(event.reset)mon_reset_voice();
#if DM32_LAB_DIAGNOSTICS
    if(event.new_call)pcm_trace_init(&monitor.trace,frame->duid==0);
#endif
    if(frame->duid==3 || frame->duid==15) {
        if(trunk_enabled)p25_trunking_end(&trunk,trunk_now_ms());
        ++mon_tdu;
        if(event.end) {
            mon_have_sync=false;mon_voice_us=0;
            p25_voice_policy_init(&monitor.quality);
            memset(monitor.last_good_pcm,0,sizeof monitor.last_good_pcm);
            uint32_t lock=hrc_irq_save();monitor.ending=true;hrc_irq_restore(lock);
        }
        return;
    }
    mon_sync_us=hrc_micros();mon_have_sync=true;
    if(!valid)++monitor.metadata_bad;
    if(frame->duid==0)++mon_hdu;
    if(frame->duid!=5 && frame->duid!=10)return;
    if(frame->duid==5)++mon_ldu1;else ++mon_ldu2;
    if(!event.voice) {
        if(monitor.call.state==P25_RX_ENCRYPTED)++monitor.encrypted_units;
        else if(monitor.call.state==P25_RX_UNSUPPORTED)++monitor.unsupported_units;
        else ++monitor.unqualified_units;
        return;
    }
    if(trunk_enabled && !p25_trunking_voice(&trunk,frame->nac,monitor.call.group,trunk_now_ms()))return;
    for(unsigned i=0;i<9 && !mon_failed;++i) {
        uint8_t bits[11];int16_t pcm[160];p25_voice_quality quality;
        if(!p25_rx_voice_quality(frame->frame,i,bits,&quality)) {mon_failed=true;break;}
        bool had_good=monitor.quality.have_good;
        p25_voice_action action=p25_voice_policy_frame(&monitor.quality,bits,quality.e0,quality.et);
        if(action==P25_VOICE_ACCEPT) {
            imbe_bench_decode_pcm(bits,pcm);memcpy(monitor.last_good_pcm,pcm,sizeof pcm);
            if(!imbe_bench_ready()) {mon_failed=true;break;}
        } else if(action==P25_VOICE_REPEAT) {
            memcpy(pcm,monitor.last_good_pcm,sizeof pcm);++monitor.repeated;
        } else {
            memset(pcm,0,sizeof pcm);memset(monitor.last_good_pcm,0,sizeof monitor.last_good_pcm);
            if(had_good && !imbe_bench_init()) {mon_failed=true;break;} // Once when concealment enters mute.
            ++monitor.muted;
        }
#if DM32_LAB_DIAGNOSTICS
        pcm_trace_record(&monitor.trace,bits,pcm);
        monitor.trace.tone_substituted=mon_output_tone;
        if(mon_output_tone)mon_local_frame(pcm); // Preserve actual decode evidence before substitution.
#endif
        uint32_t lock=hrc_irq_save();
        monitor.ending=false;
        if(mon_audio_enabled && !mon_pcm_push(&monitor,pcm))mon_failed=true;
        ++monitor.voices;monitor.corrected+=quality.et;monitor.last_voice_us=hrc_micros();
        if(action!=P25_VOICE_MUTE)mon_voice_us=monitor.last_voice_us;
        hrc_irq_restore(lock);
    }
}
static bool mon_start_mode(mon_rx_purpose purpose) {
    bool control_only=purpose==MON_RX_LAB_CONTROL;
    bool subscriber_control=purpose==MON_RX_SUBSCRIBER_CONTROL;
    bool capture_only=control_only || subscriber_control;
    bool retained=mon_frontend_ready;
    mon_frontend_ready=false; // A failed/abandoned start cannot carry it onward.
    // An intervening owner invalidates reuse; never stop its peripherals here.
    if(retained && !mon_frontend_exclusive())return false;
    if(retained && (capture_only || mon_failed)) {
        mon_frontend_close();retained=false;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(control_only && (!trunk_lab_return_owned() || !trunk_lab_return_identity()
       || trunk_lab_exchange.phase!=P25_LAB_RX_STARTING || !trunk_lab_return_rf_off()))return false;
    if(subscriber_control && !trunk_subscriber_control_receive_allowed())return false;
    trunk_rx_stream_release();
    trunk_rx_progress_release();
    trunk_rx_feed_release();
#else
    if(capture_only)return false;
#endif
    if(!board.audio || !board.audio->speaker_pcm || !dev || !hooks) {
        if(retained)mon_frontend_close();
        return false;
    }
    if(!capture_only && !mon_task_handle && xTaskCreate(mon_speaker_task,"p25spk",512,NULL,6,&mon_task_handle)!=pdPASS) {
        if(retained)mon_frontend_close();
        return false;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(control_only)trunk_lab_stages.setup_us=hrc_micros();
#endif
    // Same-mode P25 retunes use the board's existing physical-mode shortcut.
    // Always assert DMR here: retaining software state alone is not evidence
    // that an intervening owner left the physical frontend in that mode.
    hardware_stop();board.radio->audio(false);board.radio->set_mode(RADIO_MODE_DMR);
    if(!board.radio->rx(receiver_frequency(),RADIO_BW_12K5,NULL)) {
        board.radio->set_mode(RADIO_MODE_FM);board_rf_safe();return false;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(control_only)trunk_lab_stages.tuned_us=hrc_micros();
#endif
    hardware_stop();hrc7000_fm_rx(dev,false);hrc7000_audio_bits(dev,0,C7_AUDIO_FM_PLAY);
    wr(C7_FM_BANDWIDTH,hrc7000_rd(dev,C7_FM_BANDWIDTH)&~(1u<<6));
#if DM32_LAB_DIAGNOSTICS
    if(!capture_only && mon_replay)mon_init_replay(&monitor);else
#endif
    if(capture_only) {
        // No control frame consumes speaker PCM. Initialize the recorder and
        // decoder state without touching its inactive 15-KiB voice queue.
        memset(&monitor,0,offsetof(p25_monitor,pcm));
        memset((uint8_t *)&monitor+offsetof(p25_monitor,raw_head),0,
            sizeof monitor - offsetof(p25_monitor,raw_head));
        p25_demod_init(&monitor.demod);
    } else mon_init(&monitor);
#if DM32_TRUNK_SUBSCRIBER
    trunk_subscriber_return_epoch_end();
    if(++trunk_stream_epoch==0)++trunk_stream_epoch;
    trunk_sample_tick=0;trunk_last_irq_us=0;
    if(trunk_session.running && !trunk_subscriber_handoff())p25_trunking_session_lost(&trunk_session,trunk_now_ms());
#endif
    monitor.demod.hunt_clock_us=hrc_micros;
    if(!capture_only && !imbe_bench_init()) {
        hardware_stop();board.radio->audio(false);board.radio->set_mode(RADIO_MODE_FM);board_rf_safe();return false;
    }
    mon_tone_phase=0;mon_used=true;mon_failed=false;mon_empty_since=0;
    mon_fault_age=mon_fault_audio=mon_fault_mask=mon_fault_mode=0;
    mon_have_sync=mon_badge_sync=mon_have_nac=false;mon_badge_phase=0;mon_voice_us=0;mon_ui_max_us=mon_spk_last_us=mon_spk_gap_us=0;
    mon_pushes=mon_full=mon_first_push=mon_last_push=mon_push_gap=0;
#if DM32_LAB_DIAGNOSTICS
    memset(mon_perf,0,sizeof mon_perf);mon_perf_index=0;
#endif
    mon_worst_at=mon_worst_queue=0;
    mon_timer_ticks=mon_notify_max=0;mon_hdu=mon_ldu1=mon_ldu2=mon_tdu=0;
    mon_pcm_submitted=mon_pcm_consumed=mon_pcm_irqs=mon_pcm_last=mon_pcm_gap=0;
    mon_pcm_pending=false;
    mon_step_max_us=mon_step_total_us=mon_step_calls=0;
    mon_local_started=hrc_micros();mon_local_frames=0;
    monitor.last_raw_us=hrc_micros();mon_reason=control_only ? "lab_control" : subscriber_control ? "control_receiving" : mon_replay ? "replay_delay" : mon_local_tone ? "local_delay" : "receiving";
    radio_receive_state(&control,mon_enabled,true,false,false);if(!capture_only)screen("HOME");
    uint32_t lock=hrc_irq_save();
    wr(C7_SYS_INTERP_CLEAR,0xffffffffu);mon_control_only=control_only;mon_subscriber_control_only=subscriber_control;mon_running=true;ui_rssi_valid=false;ui_rssi_due=hrc_micros();
    radio_signal_configure(&ui_strength,RADIO_SIGNAL_OFF,0,hrc_micros());
    if(!capture_only && mon_pcm_backend)hrc_irq_register(IRQ_PCM_RD,mon_pcm_irq);
#if DM32_TRUNK_SUBSCRIBER
    if(subscriber_control)trunk_subscriber_return_enable();
#endif
    wr(C7_SYS_INTERP_MASK,1u<<14);hrc_irq_enable(IRQ_MODEM_SYS,true);
#if DM32_TRUNK_SUBSCRIBER
    if(control_only)trunk_lab_stages.irq_us=hrc_micros();
#endif
    if(!capture_only && mon_timer_us && !mon_pcm_backend) {
        hrc_irq_register(IRQ_TIMER4,mon_speaker_tick);
        hrc_timer_ack(SPEAKER_TIMER);hrc_irq_enable(IRQ_TIMER4,true);
        hrc_timer_periodic(SPEAKER_TIMER,mon_timer_us);
    }
    hrc_irq_restore(lock);
    return true;
}
static bool mon_start(void) {return mon_start_mode(MON_RX_VOICE);}
#if DM32_TRUNK_SUBSCRIBER
static bool mon_start_control(void) {return mon_start_mode(MON_RX_LAB_CONTROL);}
static bool mon_start_subscriber_control(void) {return mon_start_mode(MON_RX_SUBSCRIBER_CONTROL);}
#endif
#if DM32_OMAHA_RX_ONLY
#define trunk_subscriber_start trunk_subscriber_start_saved
#endif
#include "p25_trunking_live.h"
#if DM32_OMAHA_RX_ONLY
#undef trunk_subscriber_start
static bool trunk_subscriber_start(const p25_trunking_session_config *config) {
    if(!DM32_OMAHA_RX_ONLY)return trunk_subscriber_start_saved(config);
    (void)config;return false;
}
#endif
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_subscriber_menu_paused(void) {
    return menu_open && menu_page==MENU_TRUNK_ACTIVE && trunk_subscriber_active()
        && trunk_subscriber_io.receive_follow && !trunk_subscriber_transport_owned();
}
#endif
#include "p25_rx_progress_live.h"
#include "p25_rx_stream_live.h"
#include "p25_rx_feed_live.h"
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_rx_feed_defer_display(void) {
    // Retain the finite fallback for hosts without the cooperative display.
    // The target queues redraws normally and services bounded stripes instead.
    return !radio_gfx_deferred()&&trunk_rx_feed_selected()
        &&trunk_rx_feed.sample_limit&&!trunk_rx_feed_terminal();
}
#endif
static void trunk_stop(const char *why) {
#if DM32_TRUNK_SUBSCRIBER
    memset(&passive_receive_recovery,0,sizeof passive_receive_recovery);
    p25_trunking_search_stop(&trunk_search);
    trunk_system_search_revoked=false;
    trunk_system_logout_requested=false;trunk_system_subscriber=false;
    if(menu_page==MENU_TRUNK_ACTIVE)menu_open=false;
    trunk_preload_cc_receive_stop();
    trunk_rx_feed_release();
    trunk_rx_stream_release();
    trunk_rx_progress_release();
    trunk_access_stop();
#endif
    if(!trunk_enabled) {trunk_system_restore();return;}
    trunk_enabled=false;trunk_receiver_hz=0;trunk_reason=why;
    p25_trunking_stop(&trunk);radio_history_end(&heard_calls);
    mon_stop("trunk_stopped");
    session_enabled=armed=false;ptt_release_required=true;ptt_release_seen=false;
    trunk_system_restore();
}
static bool trunk_start(void) {
    if(trunk_enabled || !normal_mode || !features_ready || !feature_p25()
       || radio_channel_get_private(channel_record) || !channel_in_band(frequency,false)
       || call_active || prepared || rx_job || apps_active() || cps_link || cps_active
       || broadcast_show || airband_show || control.state==RADIO_FAULT) {
        reason="trunk_unavailable";return false;
    }
    if(!feature_stop_scan(true))return false;
    feature_pause();
    if(!p25_trunking_init(&trunk,frequency,136000000u,480000000u,
                         rx_promiscuous ? P25_TRUNKING_NAC_ANY : (uint16_t)control.nac))return false;
    if(rx_tg_filter) {
        uint8_t descriptor[32]={0};
        // A field profile must not depend on the tester's conventional scan
        // list (which can legitimately be an empty talkgroup list).
        if(!DM32_OMAHA_RX_ONLY)feature_scan_description(descriptor);
        if(descriptor[0] && descriptor[12]==1u) {
            uint16_t groups[P25_CS_TG_CAPACITY];uint8_t record[32];
            unsigned count=descriptor[22],key=p25_cs_scan_key(global_record[12]);
            if(!count || count>P25_TRUNKING_GROUPS) {reason="empty_scan_list";return false;}
            for(unsigned part=0;part<4;++part) {
                if(!p25_cs_read(&channel_store,key+2u+part,record)) {reason="channel_read_failed";return false;}
                for(unsigned i=0;i<16;++i)groups[part*16u+i]=feature_u16(record+2u*i);
            }
            if(!p25_trunking_set_groups(&trunk,groups,count))return false;
        } else {
            uint16_t group=(uint16_t)control.talkgroup;
            if(!p25_trunking_set_groups(&trunk,&group,1))return false;
        }
    }
    trunk_receiver_hz=frequency;trunk_units=0;trunk_clock_us=hrc_micros();
    trunk_clock_ms=trunk_clock_carry=0;trunk_reason="control";trunk_enabled=true;
    session_enabled=armed=false;mon_enabled=true;
    ptt_release_required=true;ptt_release_seen=false;
    radio_complete(&control,false);normal_permission();
    if(!mon_start()) {trunk_stop("setup_failed");reason="trunk_tune_failed";return false;}
    reason="trunk_receiving";return true;
}
static void trunk_system_restore(void) {
#if DM32_TRUNK_SUBSCRIBER
    if(!trunk_system_overlay_owned || trunk_system_overlay_staging)return;
    // All transmit/receiver owners have been stopped before restoring this
    // snapshot. Neither the temporary system channel nor its RID is saved.
    trunk_system_overlay_owned=false;
    memcpy(channel_record,trunk_system_saved.channel,32);
    control=trunk_system_saved.control;
    rx_promiscuous=trunk_system_saved.promiscuous;rx_tg_filter=trunk_system_saved.tg_filter;
    feature_apply();
    radio_complete(&control,false);mon_enabled=channel_in_band(frequency,false);
    normal_permission();trunk_system_name[0]=0;
#endif
}
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_system_attach(void) {
    if(DM32_OMAHA_RX_ONLY)return false;
    const p25_trunking_search_config *identity=&trunk_search.config;
    p25_trunking_session_config config={
        .subscriber={.wacn=identity->wacn,.system=identity->system,.radio_id=control.source_id,
            .group=(uint16_t)control.talkgroup,.nac=identity->nac,.rfss=identity->rfss,.site=identity->site,
            .min_hz=136000000u,.max_hz=480000000u,.tot_ms=feature_tx_tot()*1000u},
        .control_rx_hz=frequency,.slot_tolerance_ticks=3u,.slot_max_age_ticks=300u,
        .actuation_ticks=0u,.burst_ticks=P25_TRUNK_SESSION_ISP_TICKS,.end_guard_ticks=24u,
        .max_start_delay_ticks=0u,.contention_skip=(uint8_t)((control.source_id^hrc_micros())&31u),
        .contention_wait_ticks=P25_TRUNK_SLOT_MAX_WAIT_TICKS};
    return trunk_subscriber_start(&config);
}
#endif
static bool trunk_system_load_selected(unsigned selection,p25_cs_trunk_system *out) {
#if DM32_OMAHA_RX_ONLY
    return dm32_omaha_system(selection,out);
#else
    return p25_cs_trunk_load(&channel_store,selection,out);
#endif
}
static bool trunk_system_select(unsigned selection) {
    if(DM32_OMAHA_RX_ONLY)return false;
    p25_cs_trunk_system system;
    if(selection>P25_CS_TRUNK_SYSTEMS || (selection && !trunk_system_load_selected(selection,&system))) {
        reason="trunk_system_missing";return false;
    }
    global_record[28]=(uint8_t)selection;
    if(!selection)global_record[29]=0;
    pref_state="pending";reason="trunk_system_selected";return true;
}
static unsigned trunk_system_group(void) {
    p25_cs_trunk_system system;
    return trunk_system_load_selected(global_record[28],&system) ? system.talkgroup:0u;
}
static bool trunk_system_save_group(uint16_t group) {
    if(DM32_OMAHA_RX_ONLY)return false;
    unsigned selection=global_record[28];uint8_t descriptor[32];
    if(!group || !selection || selection>P25_CS_TRUNK_SYSTEMS || trunk_enabled
       || !p25_cs_read(&channel_store,p25_cs_trunk_key(selection-1u),descriptor)
       || !descriptor[0])return false;
    p25_cs_put16(descriptor+26,group);
    return p25_cs_trunk_descriptor_valid(descriptor)
        && feature_commit(p25_cs_trunk_key(selection-1u),descriptor,true);
}
static bool trunk_system_start_selected(void) {
    if(!global_record[28])return trunk_start();
#if DM32_TRUNK_SUBSCRIBER
    p25_cs_trunk_system system;
    if(!trunk_system_load_selected(global_record[28],&system)) {
        reason="trunk_system_missing";return false;
    }
    if(!normal_mode || !features_ready || editing || menu_open || cps_link || cps_active
       || call_active || prepared || apps_active() || rx_job || ptt_release_required
       || !hrc_pin_read(PIN_PTT) || control.state==RADIO_FAULT
       || !channel_in_band(system.control_hz[0],false)) {
        reason="trunk_unavailable";return false;
    }
    if(!feature_stop_scan(true))return false;
    feature_pause();preferences_poll(false);trunk_subscriber_failure_clear();
    unsigned power=feature_tx_power();
    trunk_system_saved.control=control;memcpy(trunk_system_saved.channel,channel_record,32);
    trunk_system_saved.promiscuous=rx_promiscuous;trunk_system_saved.tg_filter=rx_tg_filter;
    trunk_system_overlay_owned=trunk_system_overlay_staging=true;
    memcpy(trunk_system_name,system.name,sizeof trunk_system_name);
    memset(channel_record,0,32);
    pref_put(channel_record,system.control_hz[0]);pref_put(channel_record+4,system.control_hz[0]);
    p25_cs_put16(channel_record+8,system.nac);p25_cs_put16(channel_record+10,system.talkgroup);
    channel_record[12]=P25_CS_OCCUPIED|P25_CS_TG_FILTER|(system.mode ? 0u:P25_CS_RX_ONLY);
    memcpy(channel_record+14,system.name,12);
    (void)radio_functions_set_power(channel_record,power);
    frequency=control.tx_frequency=system.control_hz[0];control.split=false;
    control.nac=system.nac;control.talkgroup=system.talkgroup;
    control.source_id=system.source_id ? system.source_id:pref_get(global_record);
    rx_promiscuous=false;rx_tg_filter=true;radio_complete(&control,false);
    bool started=trunk_start();
    trunk_system_overlay_staging=false;
    passive_receive_recovery.selection=global_record[28];
    passive_receive_recovery.revision=channel_store.revision;
    if(!started && !strcmp(reason,"trunk_tune_failed") && passive_receive_recovery_queue(0u,"receive_setup_retry"))return true;
    if(started && !p25_trunking_set_groups(&trunk,&system.talkgroup,1u))started=false;
    if(started) {
        trunk_system_search_revoked=false;
        trunk_system_idle_recoveries=0;
        p25_trunking_search_config config={.min_hz=136000000u,.max_hz=480000000u,
            .wacn=system.wacn,.system=system.system_id,.nac=system.nac,
            .rfss=system.rfss,.site=system.site,.count=system.control_count};
        memcpy(config.control_hz,system.control_hz,sizeof config.control_hz);
        p25_trunking_search_action first;uint32_t now=trunk_now_ms();
        started=p25_trunking_search_start(&trunk_search,&config,now)
            &&p25_trunking_search_take_tune(&trunk_search,&first,now)
            &&p25_trunking_search_tune_result(&trunk_search,first.id,true,trunk_stream_epoch,trunk_now_ms());
        trunk_system_subscriber=!DM32_OMAHA_RX_ONLY && system.mode==P25_CS_TRUNK_EXPERIMENTAL;
        if(started && trunk_system_subscriber)started=trunk_system_attach();
    }
    if(!started) {trunk_stop("system_start_failed");trunk_system_restore();reason="trunk_unavailable";}
    return started;
#else
    reason="trunk_unavailable";return false;
#endif
}
static void trunk_system_boot_poll(bool down) {
    if(trunk_system_boot_checked || !normal_mode || !features_ready || down || ptt_release_required
       || editing || menu_open || rx_lab || cps_link || cps_active || apps_active()
       || call_active || prepared)return;
    trunk_system_boot_checked=true;
    if(global_record[29] && global_record[28]) {
        (void)trunk_system_start_selected();screen("HOME");
    }
}
#if DM32_TRUNK_SUBSCRIBER
#if DM32_OMAHA_RX_ONLY
static bool omaha_control_candidate_bind(unsigned index,uint32_t hz) {
    uint16_t expected_nac=0;uint8_t expected_site=0;const char *name=NULL;
    if(mon_running || trunk_search.phase!=P25_TRUNK_SEARCH_TUNING
       || index>=DM32_OMAHA_CONTROL_COUNT || index!=trunk_search.index
       || trunk_search.config.control_hz[index]!=hz
       || !dm32_omaha_candidate(index,hz,&expected_nac,&expected_site,&name))return false;
    // No recorder can publish here. The caller resets the complete bandplan,
    // site/network map and decoder before the next real receive epoch starts.
    trunk_search.config.wacn=0xbee00u;trunk_search.config.system=0xb8fu;
    trunk_search.config.nac=expected_nac;trunk_search.config.rfss=1u;
    trunk_search.config.site=expected_site;
    control.nac=expected_nac;control.talkgroup=3075u;
    feature_put16(channel_record+8,expected_nac);feature_put16(channel_record+10,3075u);
    memset(channel_record+14,0,12);snprintf((char *)channel_record+14,12,"%.11s",name);
    snprintf(trunk_system_name,sizeof trunk_system_name,"%.12s",name);
    snprintf(channel_label,sizeof channel_label,"%.12s / RX only",name);
    owner_tx_inhibit=true;rx_promiscuous=false;rx_tg_filter=true;
    return true;
}
#endif
static bool passive_receive_recovery_context(void) {
    unsigned selection=global_record[28];
    if(!trunk_system_overlay_owned || trunk_system_subscriber || trunk_session.running
       || trunk_subscriber_active() || !selection || selection!=passive_receive_recovery.selection
       || channel_store.revision!=passive_receive_recovery.revision)return false;
#if DM32_OMAHA_RX_ONLY
    if(selection!=1u || !global_record[29])return false;
#endif
    return true;
}
static bool passive_receive_recovery_system(p25_cs_trunk_system *system) {
    return passive_receive_recovery_context() && trunk_system_load_selected(global_record[28],system)
        && system->mode==P25_CS_TRUNK_RX_ONLY;
}
static bool passive_receive_recovery_queue(unsigned index,const char *why) {
    p25_cs_trunk_system system;
    if(passive_receive_recovery.pending || !passive_receive_recovery_system(&system)
       || index>=system.control_count
       || !normal_mode || !features_ready || !feature_p25()
       || controller_runtime_owned() || !board.power->switch_on() || control.state==RADIO_FAULT
       || call_active || prepared || hardware_running || audio_on || radio_busy(&control)
       || digital_dmr.owned || analog_fm.owned || apps_active() || cps_link || cps_active
       || rx_job || rx_sampling || editing || rx_lab)return false;
    uint32_t now_us=hrc_micros();
    if(index!=passive_receive_recovery.index
       ||(mon_running && passive_receive_recovery.started_us
          && now_us-passive_receive_recovery.started_us>=5000000u))passive_receive_recovery.attempts=0;
    uint32_t delay_us=500000u;
    if(++passive_receive_recovery.attempts>2u) {
        index=(index+1u)%system.control_count;passive_receive_recovery.attempts=0;
        delay_us=2000000u;
    }
    trunk_access_stop();mon_stop("receive_recovery");radio_history_end(&heard_calls);
    p25_trunking_search_stop(&trunk_search);p25_trunking_stop(&trunk);
    passive_receive_recovery.index=(uint8_t)index;passive_receive_recovery.started_us=0;
    passive_receive_recovery.due_us=now_us+delay_us;passive_receive_recovery.pending=true;
    trunk_enabled=true;trunk_system_subscriber=false;mon_enabled=false;
    control.cancel=false;radio_inhibit(&control,true);radio_receive_state(&control,false,false,false,false);
    trunk_reason=why;reason="receive_recovering";screen("HOME");return true;
}
static void passive_receive_recovery_poll(bool down) {
    if(!passive_receive_recovery.pending)return;
    // Never revive receiver ownership after an explicit stop, power switch,
    // loader entry, unrelated fault or another owner's admission.
    p25_cs_trunk_system system;
    if(!trunk_enabled || !passive_receive_recovery_context() || !normal_mode || !features_ready
       || !board.power->switch_on() || (menu_open && !DM32_OMAHA_RX_ONLY)
       || controller_runtime_owned() || control.state==RADIO_FAULT
       || call_active || prepared || hardware_running || audio_on || radio_busy(&control)
       || digital_dmr.owned || analog_fm.owned || apps_active() || cps_link || cps_active
       || rx_job || rx_sampling || editing || rx_lab) {
        passive_receive_recovery.pending=false;mon_enabled=false;
        if(control.state==RADIO_FAULT) {
            trunk_stop("receive_recovery_fault");mon_enabled=false;radio_complete(&control,true);
        }
        return;
    }
    if(down || (int32_t)(hrc_micros()-passive_receive_recovery.due_us)<0)return;
    // Saved descriptors are read once per attempted recovery, not every 1 ms
    // of the quiet delay. Selection/revision ownership is checked above.
    if(!passive_receive_recovery_system(&system)) {
        passive_receive_recovery.pending=false;mon_enabled=false;return;
    }
    unsigned index=passive_receive_recovery.index;
    p25_trunking_search_config config={.min_hz=136000000u,.max_hz=480000000u,
        .wacn=system.wacn,.system=system.system_id,.nac=system.nac,
        .rfss=system.rfss,.site=system.site,.count=system.control_count};
    memcpy(config.control_hz,system.control_hz,sizeof config.control_hz);
    p25_trunking_search_action action={0};uint32_t now_ms=trunk_now_ms();
    bool okay=index<system.control_count && p25_trunking_search_start(&trunk_search,&config,now_ms);
    if(okay) {
        trunk_search.index=(uint8_t)index;
        okay=p25_trunking_search_take_tune(&trunk_search,&action,now_ms);
#if DM32_OMAHA_RX_ONLY
        if(okay)okay=omaha_control_candidate_bind(action.index,action.hz);
#else
        if(okay) {
            control.nac=system.nac;control.talkgroup=system.talkgroup;
            feature_put16(channel_record+8,system.nac);feature_put16(channel_record+10,system.talkgroup);
            channel_record[12]|=P25_CS_RX_ONLY;
            memcpy(channel_record+14,system.name,12);
            memcpy(trunk_system_name,system.name,sizeof trunk_system_name);
            rx_promiscuous=false;rx_tg_filter=true;
        }
#endif
    }
    if(okay) {
        frequency=control.tx_frequency=action.hz;control.split=false;
        pref_put(channel_record,action.hz);pref_put(channel_record+4,action.hz);trunk_receiver_hz=action.hz;
        okay=channel_in_band(action.hz,false)
            &&p25_trunking_init(&trunk,action.hz,136000000u,480000000u,(uint16_t)control.nac);
        uint16_t group=system.talkgroup;if(okay)okay=p25_trunking_set_groups(&trunk,&group,1u);
        mon_enabled=true;if(okay)okay=mon_start();
        okay=p25_trunking_search_tune_result(&trunk_search,action.id,okay,trunk_stream_epoch,trunk_now_ms()) && okay;
    }
    passive_receive_recovery.pending=false;
    if(!okay) {
        // One attempted restart per poll. A further failure is queued with its
        // own delay, not recursively executed in this controller pass.
        if(!passive_receive_recovery_queue(index,"receive_setup_retry")) {
            bool faulted=control.state==RADIO_FAULT;
            trunk_stop("receive_recovery_cancelled");mon_enabled=false;
            if(faulted)radio_complete(&control,true);
        }
        return;
    }
    passive_receive_recovery.started_us=hrc_micros();
    trunk_reason="control_recovered";reason="trunk_receiving";screen("HOME");
}
static bool trunk_system_search_poll(void) {
    if(!trunk_system_overlay_owned || trunk_search.phase==P25_TRUNK_SEARCH_OFF)return false;
    uint32_t now=trunk_now_ms();
    bool away=trunk.phase==P25_TRUNKING_VOICE || trunk_subscriber_transport_owned() || !mon_running;
    if(away) {
        if(trunk_search.phase!=P25_TRUNK_SEARCH_PAUSED)
            (void)p25_trunking_search_suspend(&trunk_search,now);
        return false;
    }
    // A granted retune and departure take precedence over searching. A new
    // control candidate must never be selected underneath either RF owner.
    if(trunk.pending_hz || trunk_system_logout_requested || trunk_subscriber_logout_pending())return false;
    if(!hrc_pin_read(PIN_PTT)) {ptt_release_required=true;ptt_release_seen=false;return false;}
    if(trunk_search.phase==P25_TRUNK_SEARCH_PAUSED) {
        if(!p25_trunking_search_resume(&trunk_search,trunk_stream_epoch,now))return false;
    }
    p25_trunking_search_poll(&trunk_search,now,false);
    if(trunk_search.phase==P25_TRUNK_SEARCH_FAILED) {
        trunk_stop("control_search_failed");reason="trunk_search_failed";return true;
    }
    const p25_trunking_access *access=&trunk_session.access;
    // A first REGISTER can expire without ever obtaining a coherent inbound
    // opportunity. Reacquire once, after a quiet cooldown; never turn sent
    // requests, network rejection or transport faults into endless retries.
    // serial==0 proves that no action has ever been issued, including an
    // earlier exchange whose attempts/registration flags were later cleared.
    bool initial_idle=trunk_system_idle_recoveries==0u
        &&access->phase==P25_TRUNK_ACCESS_FAILED&&access->reason==P25_TRUNK_ACCESS_TIMEOUT
        &&!access->serial&&!access->attempts&&!access->registered&&!access->affiliated
        &&!access->outstanding&&!access->outstanding_id&&!access->queued
        &&!access->want_voice&&!access->voice_running&&!access->voice.valid
        &&now-access->phase_ms>=3000u&&!trunk_subscriber_failure.cause
        &&trunk_subscriber_io.phase==SUB_IO_IDLE&&!trunk_subscriber_io.action.id
        &&!trunk_subscriber_backend.suspended&&!trunk_subscriber_backend.receive_suspended
        &&!trunk_subscriber_backend.reacquiring&&!trunk_subscriber_io.receive_follow
        &&!trunk_subscriber_io.receive_returning&&trunk_subscriber_permission();
    bool identity_recovery=trunk_system_search_revoked
        &&(access->reason==P25_TRUNK_ACCESS_SITE_CHANGED||access->reason==P25_TRUNK_ACCESS_MAPPING);
    if(trunk_search.phase==P25_TRUNK_SEARCH_LOCKED && (identity_recovery||initial_idle) && trunk_system_subscriber
       && trunk_subscriber_active() && trunk_session.access.phase==P25_TRUNK_ACCESS_FAILED
       && !menu_open && !editing && !(board.input->scan()&ptt_mask)
       && !trunk_subscriber_handoff() && !trunk_subscriber_backend.inflight
       && !call_active && !prepared && !hardware_running) {
        // Search may recover the configured site on this carrier before its
        // dwell expires. Access faults remain latched, so merely re-locking
        // cannot revive attachment or authorize a fresh request. Rebuild the
        // stopped policy and both maps behind a new real RX epoch instead.
        if(!p25_trunking_search_suspend(&trunk_search,now)) {
            trunk_stop("control_recovery_failed");reason="trunk_search_failed";return true;
        }
        if(initial_idle)++trunk_system_idle_recoveries;
        trunk_system_search_revoked=false;
        trunk_access_stop();mon_stop_retune("control_recovery");radio_history_end(&heard_calls);
        control.tx_frequency=frequency;control.split=false;trunk_receiver_hz=frequency;
        bool okay=p25_trunking_init(&trunk,frequency,136000000u,480000000u,(uint16_t)control.nac);
        uint16_t group=(uint16_t)control.talkgroup;
        if(okay)okay=p25_trunking_set_groups(&trunk,&group,1u);
        mon_enabled=true;
        if(okay)okay=mon_start();
        if(okay)okay=p25_trunking_search_resume(&trunk_search,trunk_stream_epoch,trunk_now_ms());
        if(okay)okay=trunk_system_attach();
        if(!okay) {
            trunk_stop("control_recovery_failed");reason="trunk_unavailable";return true;
        }
        trunk_reason="control_reacquiring";ptt_release_required=true;ptt_release_seen=false;
        return true;
    }
    p25_trunking_search_action next;
    if(!p25_trunking_search_take_tune(&trunk_search,&next,now))return false;
    trunk_system_search_revoked=false;
    // Retire attachment and all old-carrier action/reply leases first. The
    // saved conventional profile is still owned by the system overlay.
    trunk_access_stop();mon_stop_retune("control_search");radio_history_end(&heard_calls);
    bool candidate_valid=true;
#if DM32_OMAHA_RX_ONLY
    candidate_valid=omaha_control_candidate_bind(next.index,next.hz);
#endif
    frequency=control.tx_frequency=next.hz;control.split=false;
    pref_put(channel_record,next.hz);pref_put(channel_record+4,next.hz);
    trunk_receiver_hz=next.hz;
    bool okay=candidate_valid && channel_in_band(next.hz,false)
        &&p25_trunking_init(&trunk,next.hz,136000000u,480000000u,(uint16_t)control.nac);
    uint16_t group=(uint16_t)control.talkgroup;
    if(okay)okay=p25_trunking_set_groups(&trunk,&group,1u);
    mon_enabled=true;
    if(okay)okay=mon_start();
    if(!p25_trunking_search_tune_result(&trunk_search,next.id,okay,trunk_stream_epoch,trunk_now_ms())) {
#if DM32_TRUNK_SUBSCRIBER
        if(passive_receive_recovery_queue(next.index,"receive_setup_retry"))return true;
#endif
        trunk_stop("control_search_failed");reason="trunk_search_failed";return true;
    }
    if(!okay) {
#if DM32_TRUNK_SUBSCRIBER
        if(passive_receive_recovery_queue(next.index,"receive_setup_retry"))return true;
#endif
        mon_stop("control_tune_failed");trunk_stop("control_tune_failed");reason="trunk_tune_failed";return true;
    }
#if DM32_TRUNK_SUBSCRIBER
    passive_receive_recovery.index=next.index;passive_receive_recovery.attempts=0;
    passive_receive_recovery.started_us=hrc_micros();
#endif
    if(trunk_system_subscriber&&!trunk_system_attach()) {
        trunk_stop("control_attach_failed");reason="trunk_unavailable";return true;
    }
    trunk_reason="control_search";ptt_release_required=true;ptt_release_seen=false;
    return true;
}
#endif
static bool trunk_system_menu_action(unsigned action,bool down) {
    if(DM32_OMAHA_RX_ONLY) {(void)action;(void)down;return true;}
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_menu_paused()) {
        if(down) {ptt_release_required=true;ptt_release_seen=false;return true;}
        if(action==ACT_NAV_UP)menu_item=(menu_item+2u)%3u;
        else if(action==ACT_NAV_DOWN)menu_item=(menu_item+1u)%3u;
        else if(action==ACT_BACK || action==ACT_SELECT) {
            unsigned chosen=action==ACT_BACK ? 0u:menu_item;
            if(chosen==2u) {trunk_stop("operator");reason="listening";screen("HOME");return true;}
            menu_open=false;
            if(chosen==1u) {
                trunk_system_logout_requested=true;trunk_system_logout_keys_released=false;
                trunk_system_logout_deadline=trunk_now_ms()+5000u;
            }
            if(!mon_start()) {trunk_stop("menu_return_failed");reason="trunk_tune_failed";}
            else trunk_subscriber_receive_return();
            screen("HOME");return true;
        } else {trunk_stop("operator");return false;}
        screen("HOME");return true;
    }
    if(!trunk_subscriber_active())return false;
    if(action==ACT_SELECT&&!down&&!menu_open&&!editing&&trunk.phase==P25_TRUNKING_CONTROL
       &&!trunk.pending_hz&&trunk_subscriber_allow_follow()
       &&trunk_subscriber_receive_begin()) {
        mon_stop("subscriber_menu");menu_open=true;menu_page=MENU_TRUNK_ACTIVE;menu_item=0;
        screen("HOME");return true;
    }
    trunk_stop("operator");
#else
    (void)action;(void)down;
#endif
    return false;
}
static void trunk_poll(bool down) {
#if DM32_TRUNK_SUBSCRIBER
    if(passive_receive_recovery.pending) {passive_receive_recovery_poll(down);return;}
#endif
    if(!trunk_enabled)return;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_logout_finished()) {
        bool sent=trunk_subscriber_logout_succeeded();
        trunk_stop(sent?"logout_sent":"logout_failed");reason=sent?"trunk_logout_sent":"trunk_logout_failed";return;
    }
    if(trunk_system_logout_requested) {
        if((int32_t)(trunk_now_ms()-trunk_system_logout_deadline)>=0) {
            trunk_stop("logout_timeout");reason="trunk_logout_failed";return;
        }
        ptt_release_required=true;ptt_release_seen=false;
        if(!trunk_subscriber_logout_pending()&&trunk_system_logout_keys_released&&trunk_session.site_qualified)
            (void)trunk_subscriber_begin_logout();
        down=false;
    }
    if(trunk_system_search_poll())return;
    // The subscriber owns its deliberate RX-off handoff and physical PTT.
    // Passive following's held-PTT/receiver-paused rules do not apply there.
    if(trunk_subscriber_active()) {
        bool acquired=!trunk_system_overlay_owned||trunk_search.phase==P25_TRUNK_SEARCH_LOCKED;
        if(acquired||trunk_subscriber_handoff()||trunk_subscriber_logout_pending())trunk_subscriber_poll(down);
        if(trunk_subscriber_active() && !trunk_subscriber_transport_owned()
           && !trunk_system_logout_requested&&!trunk_subscriber_logout_pending()
           && ((acquired&&trunk_subscriber_allow_follow()) || trunk.phase==P25_TRUNKING_VOICE || trunk.pending_hz))
            trunk_follow_poll();
        return;
    }
#endif
    if(down) {ptt_release_required=true;ptt_release_seen=false;}
    if(!normal_mode || !feature_p25() || !mon_enabled
#if DM32_TRUNK_SUBSCRIBER
       || (!mon_running && !trunk_rx_progress_owned && !trunk_rx_stream_owned&&!trunk_rx_feed_selected())
#else
       || !mon_running
#endif
       || control.state==RADIO_FAULT
       || rx_job || editing || (menu_open && !DM32_OMAHA_RX_ONLY) || rx_lab || cps_link || cps_active || apps_active()) {
        trunk_stop("receiver_paused");return;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_progress_owned || trunk_rx_stream_owned)return;
    if(trunk_preload_cc_active())return;
    if(trunk_rx_feed_terminal()||(trunk_rx_feed_selected()&&trunk_rx_feed.sample_limit))return;
    if(trunk_session.running) {trunk_access_poll(down);return;}
#endif
    // Saved receive-only systems also wait for their exact configured site;
    // ordinary current-channel passive following retains its existing policy.
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_system_overlay_owned&&trunk_search.phase!=P25_TRUNK_SEARCH_LOCKED
       &&trunk.phase!=P25_TRUNKING_VOICE&&!trunk.pending_hz)return;
#endif
    trunk_follow_poll();
}
static void trunk_follow_poll(void) {
    uint32_t now=trunk_now_ms();
    p25_trunking_poll(&trunk,now);
    if(trunk.phase==P25_TRUNKING_STOPPED) {
#if DM32_TRUNK_SUBSCRIBER
        if(passive_receive_recovery_queue(trunk_search.index,"receive_setup_retry"))return;
#endif
        trunk_stop("tune_timeout");reason="trunk_tune_failed";return;
    }
    uint32_t hz;if(!p25_trunking_tune_request(&trunk,&hz))return;
    if(hz==trunk.control_hz) {
        uint32_t lock=hrc_irq_save();
        bool queued=monitor.pcm_head!=monitor.pcm_tail || mon_pcm_pending || mon_routed;
        hrc_irq_restore(lock);
        // Preserve normal speech tails; an absent IRQ cannot pin a traffic
        // channel forever. User cancellation/fault/encryption still flushes.
        if(queued && (uint32_t)(now-trunk.tune_requested_ms)<600u)return;
    }
    if(!channel_in_band(hz,false)) {
        p25_trunking_tune_result(&trunk,false,now);trunk_stop("range");reason="trunk_tune_failed";return;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_active() && hz!=trunk.control_hz && !trunk_subscriber_receive_begin())return;
#endif
    mon_stop_retune("trunk_retune");radio_history_end(&heard_calls);trunk_receiver_hz=hz;
    bool ok=mon_start();p25_trunking_tune_result(&trunk,ok,trunk_now_ms());
    if(!ok) {
#if DM32_TRUNK_SUBSCRIBER
        if(passive_receive_recovery_queue(trunk_search.index,"receive_setup_retry"))return;
#endif
        trunk_stop("tune_failed");reason="trunk_tune_failed";return;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_subscriber_active() && hz==trunk.control_hz)trunk_subscriber_receive_return();
#endif
    trunk_reason=trunk.phase==P25_TRUNKING_CONTROL ? "control" : "voice";
    screen("HOME");
}
static int trunk_status_row(unsigned row,char *line,size_t capacity) {
#if DM32_OMAHA_RX_ONLY
    if(row)return -1;
    return snprintf(line,capacity,"TRUNK profile=" DM32_OMAHA_PROFILE_MARKER " rx_only=1 enabled=%u phase=%u reason=%s control_hz=%lu receiver_hz=%lu pending_hz=%lu grants=%lu nac=%03X system=%03X rfss=%u site=%u group=%u\r\n",
        (unsigned)trunk_enabled,(unsigned)trunk.phase,trunk_reason,(unsigned long)trunk.control_hz,
        (unsigned long)receiver_frequency(),(unsigned long)trunk.pending_hz,(unsigned long)trunk.grants,
        trunk.learned_nac,trunk.system_id,trunk.rfss,trunk.site,trunk.group);
#endif
#if DM32_TRUNK_SUBSCRIBER
    if(row==2u) {
        const p25_voice_receipt *v=&trunk_subscriber_voice_receipt;
        return snprintf(line,capacity,
            "TRUNK_TX valid=%u action=%lu state=%u timing_reason=%u stop_reason=%u flags=%u captured=%u encoded=%u published=%u consumed=%u underruns=%u pcm_overflow=%u driver_loss=%u mic_peak=%u mic_mean_abs=%u max_encode_us=%u max_gap_us=%lu\r\n",
            (unsigned)((v->flags&P25_VOICE_RECEIPT_VALID)!=0u),(unsigned long)v->action_id,
            (unsigned)v->state,(unsigned)v->timing_reason,(unsigned)v->stop_reason,(unsigned)v->flags,
            (unsigned)v->captured,(unsigned)v->encoded,(unsigned)v->published,(unsigned)v->consumed,
            (unsigned)v->underruns,(unsigned)v->pcm_overflow,(unsigned)v->driver_loss,(unsigned)v->peak,
            (unsigned)v->mic_mean_abs,(unsigned)v->max_encode_us,(unsigned long)v->max_gap_us);
    }
    if(row==1u) {
        uint32_t lock=hrc_irq_save();trunk_subscriber_failure_record failure=trunk_subscriber_failure;
        hrc_irq_restore(lock);
        // For io_fault=context, io_delay is the negative first-failed guard
        // code; other failure causes retain their signed microsecond value.
        // Bounded fields need at most 436 bytes including CRLF (437 with NUL),
        // within the existing 448-byte telemetry row; no extra row is needed.
        return snprintf(line,capacity,
        "TRUNK_ACCESS enabled=%u phase=%u gate=%u site=%u registered=%u affiliated=%u sample_origin_qualified=0 start_edge_qualified=0 backend_qualified=0 epoch=%lu lane_epoch=%lu status=%u sample_tick_hex=%08lX%08lX irq_us=%lu actuation_ticks=%u burst_ticks=%u io_fault=%s io_phase=%u io_native=%u io_pubs=%u io_delay=%ld prep_us=%lu sw_us=%lu access_reason=%u attempts=%u\r\n",
        (unsigned)trunk_session.running,(unsigned)trunk_session.access.phase,(unsigned)trunk_session.gate,
        (unsigned)trunk_session.site_qualified,(unsigned)trunk_session.access.registered,(unsigned)trunk_session.access.affiliated,
        (unsigned long)trunk_stream_epoch,(unsigned long)monitor.demod.lane_epoch,
        (unsigned)trunk_session.slot.status,(unsigned long)(trunk_sample_tick>>32),(unsigned long)(uint32_t)trunk_sample_tick,(unsigned long)trunk_last_irq_us,
        trunk_session.config.actuation_ticks,trunk_session.config.burst_ticks,
        trunk_subscriber_failure_name(failure.cause),(unsigned)failure.phase,
        (unsigned)failure.native_count,(unsigned)failure.publications,(long)failure.delay_us,
        (unsigned long)failure.prepare_us,(unsigned long)failure.switch_us,
        (unsigned)trunk_session.access.reason,(unsigned)trunk_session.access.attempts);
    }
#endif
    if(row)return -1;
    return snprintf(line,capacity,"TRUNK enabled=%u phase=%u reason=%s control_hz=%lu receiver_hz=%lu pending_hz=%lu units=%lu grants=%lu nac=%03X system=%03X rfss=%u site=%u group=%u tune_failures=%lu\r\n",
        (unsigned)trunk_enabled,(unsigned)trunk.phase,trunk_reason,(unsigned long)trunk.control_hz,
        (unsigned long)receiver_frequency(),(unsigned long)trunk.pending_hz,(unsigned long)trunk_units,
        (unsigned long)trunk.grants,trunk.learned_nac,trunk.system_id,trunk.rfss,trunk.site,trunk.group,
        (unsigned long)trunk.tune_failures);
}
static void trunk_status(void) {telemetry_request(TELEMETRY_TRUNK);}
static void mon_poll(bool down) {
#if DM32_OMAHA_RX_ONLY
    // The dedicated profile has no conventional fallback owner. Boot starts
    // its named follower directly; an explicit stop must stay stopped.
    if(!trunk_enabled)return;
#endif
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_feed_selected()) {trunk_rx_feed_poll(down);return;}
    if(trunk_rx_stream_owned) {trunk_rx_stream_poll(down);return;}
    if(trunk_rx_progress_owned) {trunk_rx_progress_poll(down);return;}
#endif
    if(down || !mon_enabled || rx_job || call_active || prepared || editing || (menu_open && !message_menu_active() && !DM32_OMAHA_RX_ONLY) || rx_lab
       || cps_link || cps_active || (normal_mode && !feature_p25()) || control.state==RADIO_FAULT) {
        if(mon_local_tone || mon_replay)mon_enabled=false;
        if(mon_running)mon_stop(down ? "ptt" : "paused");
        return;
    }
    if(!channel_in_band(frequency,false))return;
    if(!mon_running) {
        if(!mon_start()) {
            mon_enabled=false;mon_reason="setup_failed";
            if(normal_mode) {reason="rx_setup_failed";radio_complete(&control,true);radio_inhibit(&control,true);}
            screen("HOME");
        }
        return;
    }
    // Snapshot time and the ISR-owned timestamp atomically. Otherwise an IRQ
    // between these reads can make last_raw_us newer than now and underflow.
    uint32_t lock=hrc_irq_save();
    uint32_t input_age=hrc_micros()-monitor.last_raw_us;
    bool input_failed=mon_failed;
    hrc_irq_restore(lock);
    if(input_failed || input_age>200000u) {
        mon_fault_age=input_age;mon_fault_audio=hrc7000_rd(dev,C7_AUDIO_CONTROL);
        mon_fault_mask=hrc7000_rd(dev,C7_SYS_INTERP_MASK);mon_fault_mode=hrc7000_rd(dev,C7_WORK_MODE);
#if DM32_TRUNK_SUBSCRIBER
        if(passive_receive_recovery_queue(trunk_search.index,input_failed ? "queue_or_input_fault":"input_timeout"))return;
#endif
        mon_enabled=false;mon_stop(input_failed ? "queue_or_input_fault" : "input_timeout");
        if(normal_mode) {reason=mon_reason;session_enabled=false;radio_complete(&control,true);radio_inhibit(&control,true);}
        screen("HOME");return;
    }
    uint8_t block[512];uint64_t sample_tick=0;uint32_t irq_us=0;lock=hrc_irq_save();
    bool have=mon_raw_pop_timed(&monitor,block,&sample_tick,&irq_us);hrc_irq_restore(lock);
#if DM32_LAB_DIAGNOSTICS
    if(!mon_capture_control_only() && (mon_local_tone || mon_replay)) {
        uint32_t age=hrc_micros()-mon_local_started;
        if(age>=20000000u) {
            unsigned goal=mon_replay ? pcm_trace_kept(&monitor.trace) : 300u;
            while(mon_local_frames<goal) {
                lock=hrc_irq_save();
                bool room=mon_count(monitor.pcm_head,monitor.pcm_tail,MON_PCM_FRAMES)<MON_PREFILL;
                hrc_irq_restore(lock);if(!room)break;
                int16_t pcm[160];
                if(mon_replay) {
                    uint32_t seq=monitor.trace.frames-goal+mon_local_frames;
                    memcpy(pcm,monitor.trace.pcm[seq%PCM_TRACE_FRAMES],sizeof pcm);
                } else mon_local_frame(pcm);
                lock=hrc_irq_save();mon_pcm_push(&monitor,pcm);++mon_local_frames;hrc_irq_restore(lock);
            }
            lock=hrc_irq_save();
            if(mon_local_frames==goal)monitor.ending=true;
            bool done=monitor.played==goal && !mon_routed;
            hrc_irq_restore(lock);
            mon_reason=mon_replay ? "replay_pcm" : "local_tone";
            if(done || age>=30000000u) {
                mon_enabled=false;mon_stop(done ? (mon_replay ? "replay_complete" : "local_complete") : "local_timeout");screen("HOME");
            }
        }
        return; // Discard RF samples: playback does not demodulate or decode.
    }
#endif
    if(have) {
        uint32_t start=hrc_micros();
#if DM32_TRUNK_SUBSCRIBER
        uint32_t acquisition_epoch=trunk_stream_epoch;
        uint32_t acquisition_before=monitor.demod.acquisitions;
        trunk_preload_cc_block(sample_tick,irq_us,true);
        trunk_subscriber_block(sample_tick,irq_us,true);
#endif
        unsigned i=0;
        for(;i<256 && !mon_failed;++i) {
            int16_t sample=(int16_t)((unsigned)block[2*i]*256+block[2*i+1]);
#if DM32_TRUNK_SUBSCRIBER
            if(trunk_enabled) {
                trunk_sample_tick=sample_tick+i*P25_DEMOD_INPUT_STEP_TICKS;trunk_last_irq_us=irq_us;
                (void)p25_demod_push_at(&monitor.demod,sample,trunk_sample_tick,trunk_stream_epoch,
                    mon_receive,trunk_access_status_symbol,NULL);
            } else
#endif
            p25_demod_push(&monitor.demod,sample,mon_receive,NULL);
        }
#if DM32_TRUNK_SUBSCRIBER
        trunk_preload_cc_block(0,0,false);
        trunk_subscriber_block(0,0,false);
        if(trunk_system_overlay_owned && trunk_enabled && mon_running && !mon_failed
           && acquisition_epoch==trunk_stream_epoch) {
            // Continuous fresh recorder input can shorten an empty candidate's
            // probe. Sync evidence only preserves its original full dwell;
            // search still needs native, matching identity/maps to lock.
            uint32_t observed_us=hrc_micros();
            (void)p25_trunking_search_input(&trunk_search,acquisition_epoch,sample_tick,i,
                (observed_us-irq_us)/1000u,monitor.demod.acquisitions!=acquisition_before,
                trunk_now_ms());
        }
#endif
        uint32_t elapsed=hrc_micros()-start;if(elapsed>monitor.max_block_us)monitor.max_block_us=elapsed;
    }
    if(!mon_capture_control_only() && monitor.call.active && hrc_micros()-monitor.call.last_unit_us>600000u) {
        radio_history_end(&heard_calls);p25_receive_reset(&monitor.call);mon_reset_voice();mon_have_sync=false;
        lock=hrc_irq_save();monitor.ending=true;hrc_irq_restore(lock);
    }
    mon_indicator();
}
static int mon_status_row(unsigned row,char *line,size_t capacity) {
    switch(row) {
    case 0u: {
        return snprintf(line,capacity,"RXBACKEND mode=%s submitted_samples=%lu consumed_samples=%lu irqs=%lu pending=%u max_irq_gap_us=%lu\r\n",
                mon_pcm_backend ? "PCM" : "FIFO",(unsigned long)mon_pcm_submitted,(unsigned long)mon_pcm_consumed,
                (unsigned long)mon_pcm_irqs,(unsigned)mon_pcm_pending,(unsigned long)mon_pcm_gap);
    }
    case 1u: {
        return snprintf(line,capacity,"RXMON enabled=%u running=%u reason=%s raw=%lu raw_high=%lu pcm_high=%lu raw_overflow=%lu pcm_overflow=%lu gaps=%lu units=%lu voices=%lu played=%lu starved=%lu corrected=%lu rejected=%lu max_block_us=%lu spk_stack_free=%lu\r\n",
                (unsigned)mon_enabled,(unsigned)mon_running,mon_reason,(unsigned long)monitor.raw_blocks,
                (unsigned long)monitor.raw_high,(unsigned long)monitor.pcm_high,(unsigned long)monitor.raw_overflow,
                (unsigned long)monitor.pcm_overflow,(unsigned long)monitor.gaps,(unsigned long)monitor.units,
                (unsigned long)monitor.voices,(unsigned long)monitor.played,(unsigned long)monitor.starved,
                (unsigned long)monitor.corrected,(unsigned long)monitor.rejected,(unsigned long)monitor.max_block_us,
                mon_task_handle ? (unsigned long)(uxTaskGetStackHighWaterMark(mon_task_handle)*sizeof(StackType_t)) : 0ul);
    }
    case 2u: {
        return snprintf(line,capacity,"RXCALL active=%u state=%u nac=%03x group_valid=%u group=%u source_valid=%u source=%lu ess_valid=%u algid=%02x keyid=%u status=%s reject=%s reject_duid=%u mfid=%02x lco=%02x svc=%02x opts=%02x meta_flags=%02x reject_alg=%02x\r\n",
                (unsigned)monitor.call.active,(unsigned)monitor.call.state,monitor.call.nac,
                (unsigned)monitor.call.group_valid,monitor.call.group,(unsigned)monitor.call.source_valid,
                (unsigned long)monitor.call.source,(unsigned)monitor.call.ess_valid,monitor.call.algid,
                monitor.call.keyid,p25_receive_label(&monitor.call),mon_reject_label(monitor.rejection.reason),
                monitor.rejection.duid,monitor.rejection.mfid,monitor.rejection.lco,
                monitor.rejection.service,monitor.rejection.options,monitor.rejection.flags,monitor.rejection.algid);
    }
    case 3u: {
        return snprintf(line,capacity,"RXQUALITY nid_recovered_units=%lu metadata_bad=%lu encrypted_units=%lu unsupported_units=%lu unqualified_units=%lu repeated=%lu muted=%lu discarded_pcm=%lu\r\n",
                (unsigned long)monitor.nid_recovered,(unsigned long)monitor.metadata_bad,
                (unsigned long)monitor.encrypted_units,(unsigned long)monitor.unsupported_units,
                (unsigned long)monitor.unqualified_units,(unsigned long)monitor.repeated,
                (unsigned long)monitor.muted,(unsigned long)monitor.discarded_pcm);
    }
    case 4u: {
        uint32_t bad_nid=0,syncs=0,frames=0,bad_input=0;
        uint32_t lock=hrc_irq_save();
        for(unsigned lane=0;lane<10;++lane) {
            const p25_rx *rx=&monitor.demod.lane[lane].rx;
            bad_nid+=rx->bad_nid;syncs+=rx->syncs;frames+=rx->frames;bad_input+=rx->bad_input;
        }
        uint32_t acquisitions=monitor.demod.acquisitions,sync_tests=monitor.demod.sync_tests;
        uint32_t candidates=monitor.demod.fec_candidates,skipped=monitor.demod.fec_skipped;
        hrc_irq_restore(lock);
        return snprintf(line,capacity,"RXFRAME hdu=%lu ldu1=%lu ldu2=%lu tdu=%lu sync_hyp=%lu bad_nid_hyp=%lu acquisitions=%lu sync_tests=%lu fec_candidates=%lu fec_skipped=%lu frames_hyp=%lu bad_input_hyp=%lu\r\n",
                (unsigned long)mon_hdu,(unsigned long)mon_ldu1,(unsigned long)mon_ldu2,(unsigned long)mon_tdu,
                (unsigned long)syncs,(unsigned long)bad_nid,(unsigned long)acquisitions,(unsigned long)sync_tests,
                (unsigned long)candidates,(unsigned long)skipped,(unsigned long)frames,(unsigned long)bad_input);
    }
    case 5u: {
        int32_t phase_min=monitor.demod.lane[0].next_q16,phase_max=phase_min;
        int32_t period_min=monitor.demod.lane[0].period_q16,period_max=period_min;
        for(unsigned i=1;i<10;++i) {
            const p25_demod_lane *l=&monitor.demod.lane[i];
            if(l->next_q16<phase_min)phase_min=l->next_q16;
            if(l->next_q16>phase_max)phase_max=l->next_q16;
            if(l->period_q16<period_min)period_min=l->period_q16;
            if(l->period_q16>period_max)period_max=l->period_q16;
        }
        uint32_t lock=hrc_irq_save();
        uint32_t parser_calls=monitor.demod.parser_fec_calls,parser_us=monitor.demod.parser_fec_us;
        uint32_t parser_max=monitor.demod.parser_fec_max_us,arbitration_us=monitor.demod.fec_us;
        hrc_irq_restore(lock);
        return snprintf(line,capacity,"RXHUNT rearms=%lu idle_ticks=%u history_ticks=%u cost_us=%lu max_us=%lu phase_min_q16=%ld phase_max_q16=%ld period_min_q16=%ld period_max_q16=%ld parser_fec_calls=%lu parser_fec_us=%lu parser_fec_max_us=%lu arbitration_fec_us=%lu\r\n",
                (unsigned long)monitor.demod.hunt_rearms,monitor.demod.idle_ticks,monitor.demod.hunt_filled,
                (unsigned long)monitor.demod.hunt_us,(unsigned long)monitor.demod.hunt_max_us,
                (long)phase_min,(long)phase_max,(long)period_min,(long)period_max,
                (unsigned long)parser_calls,(unsigned long)parser_us,(unsigned long)parser_max,(unsigned long)arbitration_us);
    }
    case 6u: {
#if DM32_TRUNK_SUBSCRIBER
        uint32_t lock=hrc_irq_save();
        uint32_t sys_calls=trunk_rx_stream_irq_work[0].calls,sys_us=trunk_rx_stream_irq_work[0].total_us;
        uint32_t sys_max=trunk_rx_stream_irq_work[0].max_us,timer_calls=trunk_rx_stream_irq_work[1].calls;
        uint32_t timer_us=trunk_rx_stream_irq_work[1].total_us,timer_max=trunk_rx_stream_irq_work[1].max_us;
        hrc_irq_restore(lock);
        return snprintf(line,capacity,"RXMON_IO audio_enabled=%u routed=%u fault_age_us=%lu fault_audio=%08lx fault_mask=%08lx fault_mode=%08lx irq_sys_calls=%lu irq_sys_us=%lu irq_sys_max_us=%lu irq_timer_calls=%lu irq_timer_us=%lu irq_timer_max_us=%lu\r\n",
                (unsigned)mon_audio_enabled,(unsigned)mon_routed,(unsigned long)mon_fault_age,
                (unsigned long)mon_fault_audio,(unsigned long)mon_fault_mask,(unsigned long)mon_fault_mode,
                (unsigned long)sys_calls,(unsigned long)sys_us,(unsigned long)sys_max,
                (unsigned long)timer_calls,(unsigned long)timer_us,(unsigned long)timer_max);
#else
        return snprintf(line,capacity,"RXMON_IO audio_enabled=%u routed=%u fault_age_us=%lu fault_audio=%08lx fault_mask=%08lx fault_mode=%08lx\r\n",
                (unsigned)mon_audio_enabled,(unsigned)mon_routed,(unsigned long)mon_fault_age,
                (unsigned long)mon_fault_audio,(unsigned long)mon_fault_mask,(unsigned long)mon_fault_mode);
#endif
    }
    case 7u: {
#if DM32_TRUNK_SUBSCRIBER
        uint32_t lock=hrc_irq_save();
        uint32_t irq_us=trunk_rx_stream_work.irq_overlap_us,irq_max=trunk_rx_stream_work.irq_overlap_max_us;
        uint32_t emit_calls=trunk_rx_stream_work.emit_calls,emit_us=trunk_rx_stream_work.emit_total_us;
        uint32_t emit_max=trunk_rx_stream_work.emit_max_us;
        hrc_irq_restore(lock);
        return snprintf(line,capacity,"RXMON_UI sync=%u max_flush_us=%lu max_speaker_gap_us=%lu worker_irq_us=%lu worker_irq_max_us=%lu emit_calls=%lu emit_us=%lu emit_max_us=%lu display_steps=%lu max_display_step_us=%lu display_pending=%u cooperative=%u\r\n",
                (unsigned)mon_sync_active(hrc_micros()),(unsigned long)mon_ui_max_us,(unsigned long)mon_spk_gap_us,
                (unsigned long)irq_us,(unsigned long)irq_max,(unsigned long)emit_calls,(unsigned long)emit_us,(unsigned long)emit_max,
                (unsigned long)ui_display_steps,(unsigned long)ui_display_max_us,
                (unsigned)radio_gfx_pending(),(unsigned)radio_gfx_deferred());
#else
        return snprintf(line,capacity,"RXMON_UI sync=%u max_flush_us=%lu max_speaker_gap_us=%lu display_steps=%lu max_display_step_us=%lu display_pending=%u cooperative=%u\r\n",
                (unsigned)mon_sync_active(hrc_micros()),(unsigned long)mon_ui_max_us,(unsigned long)mon_spk_gap_us,
                (unsigned long)ui_display_steps,(unsigned long)ui_display_max_us,
                (unsigned)radio_gfx_pending(),(unsigned)radio_gfx_deferred());
#endif
    }
    case 8u: {
        return snprintf(line,capacity,"RXFIFO mode=%s service_ms=%u timer_us=%u local=%u replay=%u tone_hz=%u generated=%lu chunks=%lu full=%lu span_us=%lu max_push_gap_us=%lu\r\n",
                mon_fifo_limit==1 ? "SINGLE" : "BURST",mon_timer_us ? 0u : mon_service_ms,mon_timer_us,(unsigned)mon_local_tone,(unsigned)mon_replay,mon_tone_hz,(unsigned long)mon_local_frames,
                (unsigned long)mon_pushes,(unsigned long)mon_full,(unsigned long)(mon_pushes ? mon_last_push-mon_first_push : 0),
                (unsigned long)mon_push_gap);
    }
    case 9u:
#if DM32_LAB_DIAGNOSTICS
        return snprintf(line,capacity,"RXTRACE frames=%lu kept=%u payloads=%lu hash=%08lx from_hdu=%u output=%s recorded_output=%s\r\n",
                (unsigned long)monitor.trace.frames,pcm_trace_kept(&monitor.trace),
                (unsigned long)(monitor.trace.frames<PCM_TRACE_PAYLOADS ? monitor.trace.frames : PCM_TRACE_PAYLOADS),
                (unsigned long)monitor.trace.hash,(unsigned)monitor.trace.from_hdu,mon_output_tone ? "TONE" : "DECODED",monitor.trace.tone_substituted ? "TONE" : "DECODED");
#else
        return 0;
#endif
    default:return -1;
    }
}

#if DM32_LAB_DIAGNOSTICS
static void rx_bench_yield(void) {vTaskDelay(pdMS_TO_TICKS(1));}
static bool txdiag_number(const char *key,unsigned *value) {
    size_t n=strlen(key);
    if(strncmp(command,key,n))return false;
    const char *s=command+n;
    size_t length=strlen(s);
    if(length<1 || length>2)return false;
    unsigned result=0;
    for(unsigned i=0;i<length;++i) {
        if(s[i]<'0' || s[i]>'9')return false;
        result=result*10u+(unsigned)(s[i]-'0');
    }
    *value=result;return true;
}
#endif
#include "p25_pcm_applet.h"
static void parse_command(bool down) {
#if DM32_OMAHA_RX_ONLY
    if(!strcmp(command,"PROFILE")) {
        if(telemetry_pending()) {command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return;}
        send("PROFILE " DM32_OMAHA_PROFILE_MARKER " rx_only=1 persistent_writes=0\r\n");return;
    }
    if(strcmp(command,"STATUS") && strcmp(command,"TRUNK STATUS") && strcmp(command,"TRUNK TIMING")) {
        send("ERR fixed Omaha receive-only profile; use STATUS or PROFILE\r\n");return;
    }
#endif
    bool status_request=!strcmp(command,"STATUS") || !strcmp(command,"TRUNK PROBE STATUS") || !strcmp(command,"TRUNK STATUS") || !strcmp(command,"TRUNK ACCESS STATUS") || !strcmp(command,"TRUNK TIMING")
        || !strcmp(command,"TRUNK FEED STATUS")
        || !strcmp(command,"TRUNK RXPROGRESS STATUS") || !strcmp(command,"TRUNK RXPROGRESS DUMP")
        || !strcmp(command,"TRUNK RXSTREAM STATUS") || !strcmp(command,"TRUNK RXSTREAM DUMP")
        || !strcmp(command,"TRUNK RXORIGIN STATUS") || !strcmp(command,"TRUNK RXORIGIN DUMP")
        || !strcmp(command,"TRUNK RXEARLY STATUS") || !strcmp(command,"TRUNK RXEARLY DUMP")
        || !strcmp(command,"TRUNK PROBE PRELOAD STATUS") || !strcmp(command,"TRUNK VOICE STATUS")
        || !strcmp(command,"TRUNK PTT STATUS") || !strcmp(command,"TRUNK JOIN STATUS");
    bool probe_stopping=!strcmp(command,"TRUNK PROBE STOP") || !strcmp(command,"TRUNK PROBE PRELOAD STOP");
    bool stopping=!strcmp(command,"STOP") || probe_stopping || !strcmp(command,"TRUNK STOP") || !strcmp(command,"TRUNK RXPROGRESS STOP")
        || !strcmp(command,"TRUNK RXSTREAM STOP") || !strcmp(command,"TRUNK RXORIGIN STOP")
        || !strcmp(command,"TRUNK RXEARLY STOP")
        || !strcmp(command,"TRUNK PTT STOP") || !strcmp(command,"TRUNK JOIN STOP");
    bool defer_reply=command_critical_pass || command_tx_critical(down) || telemetry_pending();
    if(telemetry_pending() && !status_request && !stopping) {
        // Callers must await the current response terminator. Refuse before
        // CPS/PCM/app ownership, baud or saved settings can change.
        command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return;
    }
    // A STOP for another finite schema must not truncate this owner's dump
    // before the schema-specific command parser can reject it.
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_stream_owned&&stopping
       &&((!strcmp(command,"TRUNK RXSTREAM STOP")&&trunk_rx_stream.marker_schema!=0u)
       ||(!strcmp(command,"TRUNK RXORIGIN STOP")&&trunk_rx_stream.marker_schema!=1u)
       ||(!strcmp(command,"TRUNK RXEARLY STOP")&&trunk_rx_stream.marker_schema!=2u))) {
        if(telemetry_pending()) {command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return;}
        send("ERR receive witness schema differs; use its matching STOP\r\n");return;
    }
#endif
    if(stopping)telemetry_abort_after_row();
#if DM32_TRUNK_SUBSCRIBER
    if(stopping) {trunk_preload_cc_cancel();trunk_lab_return_cancel();}
    if(trunk_preload_cc_active() && strcmp(command,"STATUS")
       && strcmp(command,"TRUNK TIMING")
       && strcmp(command,"TRUNK PROBE PRELOAD STATUS") && !stopping) {
        trunk_preload_cc_cancel();
        send("ERR stop CCSTART first\r\n");return;
    }
    if(trunk_lab_attach_selected() && strcmp(command,"STATUS") && strcmp(command,"TRUNK JOIN STATUS")
       && strcmp(command,"TRUNK TIMING")
       && strcmp(command,"TRUNK PTT STATUS") && strcmp(command,"TRUNK VOICE STATUS")
       && strcmp(command,"TRUNK PROBE PRELOAD STATUS") && !stopping) {
        send("ERR stop TRUNK JOIN first\r\n");return;
    }
    if(trunk_lab_ptt_selected() && strcmp(command,"STATUS") && strcmp(command,"TRUNK PTT STATUS")
       && strcmp(command,"TRUNK TIMING")
       && strcmp(command,"TRUNK PTT ARM") && strcmp(command,"TRUNK VOICE STATUS")
       && strcmp(command,"TRUNK PROBE PRELOAD STATUS") && strcmp(command,"TRUNK JOIN STATUS") && !stopping) {
        send("ERR stop TRUNK PTT first\r\n");return;
    }
    if(trunk_lab_return_owned() && strcmp(command,"STATUS")
       && strcmp(command,"TRUNK TIMING")
       && strcmp(command,"TRUNK PROBE PRELOAD STATUS")
       && strcmp(command,"TRUNK VOICE STATUS")
       && strcmp(command,"TRUNK PTT STATUS")
       && strcmp(command,"TRUNK JOIN STATUS")
       && !(trunk_preload_warmed() && !strncmp(command,"TRUNK PROBE PRELOAD FIRE",24))) {
        send("ERR stop lab return first\r\n");return;
    }
    // The finite stream borrows raw/PCM storage and the speaker worker. Refuse
    // ownership changes before CPS, applet or PCM parsers can touch that arena.
    if(trunk_rx_stream_owned && strcmp(command,"STATUS") && strcmp(command,"STOP")
       && strcmp(command,"TRUNK TIMING")
       && strcmp(command,"TRUNK STOP") && strcmp(command,"TRUNK RXSTREAM STATUS")
       && strcmp(command,"TRUNK RXSTREAM DUMP") && strcmp(command,"TRUNK RXSTREAM STOP")
       && strcmp(command,"TRUNK RXORIGIN STATUS") && strcmp(command,"TRUNK RXORIGIN DUMP")
       && strcmp(command,"TRUNK RXORIGIN STOP")
       && strcmp(command,"TRUNK RXEARLY STATUS") && strcmp(command,"TRUNK RXEARLY DUMP")
       && strcmp(command,"TRUNK RXEARLY STOP")) {
        send(trunk_rx_early_owned()?"ERR stop TRUNK RXEARLY first\r\n":
            trunk_rx_origin_owned()?"ERR stop TRUNK RXORIGIN first\r\n":"ERR stop TRUNK RXSTREAM first\r\n");return;
    }
#endif
    if(probe_stopping) {
        trunk_probe_cancel();command_deferred|=COMMAND_DEFER_STOP_ACK;return;
    }
#if DM32_TRUNK_SUBSCRIBER
    if(!strcmp(command,"TRUNK PTT STOP") || !strcmp(command,"TRUNK JOIN STOP")) {command_deferred|=COMMAND_DEFER_STOP_ACK;return;}
    if(trunk_lab_attach_command(command,down))return;
    if(trunk_lab_ptt_command(command,down))return;
    if(!strcmp(command,"TRUNK VOICE STATUS")) {telemetry_request(TELEMETRY_LABVOICE);return;}
    // A warmed diagnostic is prepared but RF is off. Only its bounded status
    // and token-matched launch may bypass the ordinary prepared-TX busy gate.
    if(trunk_preload_warmed()
       && (!strcmp(command,"TRUNK PROBE PRELOAD STATUS")
           || !strncmp(command,"TRUNK PROBE PRELOAD FIRE",24))) {
        (void)trunk_preload_command(command,down);return;
    }
#endif
    if((command_critical_pass || command_tx_critical(down)) && strcmp(command,"STOP")) {
        command_deferred|=!strcmp(command,"STATUS") ? COMMAND_DEFER_STATUS
            : !strncmp(command,"CPS MSG ",8) ? COMMAND_DEFER_MESSAGE : COMMAND_DEFER_BUSY;
        return;
    }
    if(!strncmp(command,"TRUNK",5)) {
        if(call_active || prepared || hardware_running || rx_sampling) {command_deferred|=COMMAND_DEFER_BUSY;return;}
#if DM32_TRUNK_SUBSCRIBER
        if(trunk_rx_feed_command(command,down))return;
        if(trunk_rx_stream_command(command,down) || trunk_rx_progress_command(command,down)
           || trunk_preload_command(command,down))return;
#endif
        if(trunk_probe_command(command,down))return;
#if DM32_TRUNK_SUBSCRIBER
        if(!strcmp(command,"TRUNK TIMING")) {telemetry_request(TELEMETRY_RETURN);return;}
        if(!strcmp(command,"TRUNK ACCESS STATUS")) {trunk_status();return;}
        if(!strcmp(command,"TRUNK ACCESS START") && !down && !editing && !menu_open && !cps_link && !cps_active) {
            bool ok=trunk_access_start();screen("HOME");
            send(ok ? "OK TRUNK ACCESS timing observation; RF backend unqualified\r\n"
                    : "ERR TRUNK ACCESS idle lab P25 control 440.075/NAC293 required\r\n");return;
        }
#endif
        if(!strcmp(command,"TRUNK STATUS"))trunk_status();
        else if(!strcmp(command,"TRUNK STOP")) {trunk_stop("operator");normal_permission();screen("HOME");command_deferred|=COMMAND_DEFER_TRUNK_STOP_ACK;}
        else if(!strcmp(command,"TRUNK START") && !down && !editing && !menu_open && !cps_link && !cps_active) {
            bool ok=trunk_start();screen("HOME");send(ok ? "OK TRUNK START; passive Phase 1\r\n" : "ERR TRUNK choose idle P25 control channel\r\n");
        } else send("ERR TRUNK START | STOP | STATUS; release PTT\r\n");
        return;
    }
    // Starting CPS relinquishes the volatile follower even for metadata reads.
    if(trunk_enabled && !strncmp(command,"CPS ",4))trunk_stop("programming");
    if(trunk_enabled && strcmp(command,"STATUS") && strcmp(command,"STOP") && strcmp(command,"RADIO")) {
        send("ERR stop Trunk RX first\r\n");return;
    }
    // CPS keeps a clean wire and exclusive ownership of the serial protocol.
    // Stop a micro-app before processing any CPS request, including metadata.
    if(!strncmp(command,"CPS ",4) && apps_active())apps_stop(true);
    if(feature_cps(down))return;
    if(cps_link || cps_active) {
        if(!strncmp(command,"APP",3) || !strncmp(command,"app",3)) {send("APP ERROR programming session active\r\n");return;}
    } else {
        if(pcm_command(command))return;
        bool was_active=apps_active();
        if(radio_applets_command(&applets,command)) {
            if(was_active!=apps_active())screen("HOME");
            return;
        }
        if(applet_owns_radio && strcmp(command,"APP HELP") && strcmp(command,"app help")) {
            send("APP ERROR use APP STATUS or APP STOP while script/install owns radio\r\n");return;
        }
        radio_microapp_kind_t before=microapps.active;
        if(radio_microapps_command(&microapps,command)) {
            if(before!=microapps.active)screen("HOME");
            return;
        }
    }
    if(apps_active()) {
        if(!strcmp(command,"STOP") || !strcmp(command,"RADIO")) {
            apps_stop(true);send("OK RADIO; app stopped\r\n");screen("HOME");
        } else send("APP ERROR use APP HELP or APP STOP\r\n");
        return;
    }
    if(airband_show && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        send("ERR airband AM active; return to radio first\r\n");return;
    }
    if(airband_show && !strcmp(command,"STOP")) {
        airband_leave(down);if(defer_reply)command_deferred|=COMMAND_DEFER_STOP_ACK;else send("OK STOP\r\n");return;
    }
    if(broadcast_show && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        send("ERR broadcast FM active; return to radio first\r\n");return;
    }
    if(broadcast_show && !strcmp(command,"STOP")) {
        broadcast_leave(down);if(defer_reply)command_deferred|=COMMAND_DEFER_STOP_ACK;else send("OK STOP\r\n");return;
    }
#if !DM32_LAB_DIAGNOSTICS
    if(!strncmp(command,"RX",2) || !strncmp(command,"TXSOURCE",8) || !strncmp(command,"TXPAIRS",7)
       || !strncmp(command,"TXALIGN",7) || !strncmp(command,"TXWRITER",8) || !strncmp(command,"TXDAC",5)
       || !strncmp(command,"ARM",3) || !strncmp(command,"SESSION",7)) {
        send("ERR UNAVAILABLE; lab diagnostics disabled\r\n");return;
    }
#endif
    if((cps_link || cps_active) && strcmp(command,"STATUS") && strcmp(command,"STOP")) {send("ERR programming session active\r\n");return;}
    if(digital_dmr.owned && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        if(down || call_active || hardware_running) {send("ERR DMR call active\r\n");return;}
        radio_dmr_stop(&digital_dmr);
    }
    if(analog_fm.owned && strcmp(command,"STATUS") && strcmp(command,"STOP")) {
        if(down || call_active || hardware_running) {send("ERR FM call active\r\n");return;}
        p25_fm_stop(&analog_fm);
    }
    if(!strcmp(command,"RADIO")) {
        if(down || call_active || prepared || rx_job || editing || menu_open) {send("ERR RADIO requires idle/PTT released\r\n");return;}
        (void)normal_resume();send("OK RADIO; owner TX inhibit retained\r\n");return;
    }
#if DM32_LAB_DIAGNOSTICS
    if(!strncmp(command,"TXSOURCE",8) || !strncmp(command,"TXPAIRS",7) || !strncmp(command,"TXALIGN",7)
       || !strncmp(command,"TXWRITER",8) || !strncmp(command,"TXDAC",5)) {
        if(down || armed || session_enabled || call_active || prepared || mon_enabled || mon_running
           || rx_job || rx_sampling || editing || menu_open || rx_lab) {
            send("ERR stop RX/TX session and release PTT before TX diagnostics\r\n");return;
        }
        unsigned value;
        if(!strcmp(command,"TXWRITER DUP") || !strcmp(command,"TXWRITER ALT0") || !strcmp(command,"TXWRITER ALT1")) {
            tx_writer=!strcmp(command,"TXWRITER ALT0") ? TX_WRITER_ALT0 : !strcmp(command,"TXWRITER ALT1") ? TX_WRITER_ALT1 : TX_WRITER_DUP;
            send("OK TXWRITER\r\n");
        } else if(!strcmp(command,"TXDAC KEEP") || !strcmp(command,"TXDAC RESTORE")) {
            tx_dac_restore=!strcmp(command,"TXDAC RESTORE");send("OK TXDAC\r\n");
        } else if(!strcmp(command,"TXSOURCE MIC") || !strcmp(command,"TXSOURCE FIXED1011")) {
            tx_fixed=!strcmp(command,"TXSOURCE FIXED1011");
            if(!tx_fixed)tx_startup_extra=0;
            send("OK TXSOURCE\r\n");
        } else if(txdiag_number("TXPAIRS ",&value) && value>=1 && value<=28) {
            tx_pairs=value;send("OK TXPAIRS\r\n");
        } else if(txdiag_number("TXALIGN ",&value) && value<=LIVE_STARTUP_EXTRA_MAX_BYTES) {
            tx_startup_extra=value;send("OK TXALIGN\r\n");
        } else {send("ERR TXSOURCE MIC|FIXED1011 | TXPAIRS 1..28 | TXALIGN 0..35 | TXWRITER DUP|ALT0|ALT1 | TXDAC KEEP|RESTORE\r\n");return;}
        normal_mode=false;radio_inhibit(&control,true);screen("HOME");return;
    }
    if(!strncmp(command,"RXBACKEND ",10)) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down || armed || session_enabled
           || (strcmp(command,"RXBACKEND FIFO") && strcmp(command,"RXBACKEND PCM"))) {
            send("ERR RXBACKEND FIFO|PCM; stopped RX/TX session required\r\n");return;
        }
        mon_pcm_disable();mon_pcm_backend=!strcmp(command,"RXBACKEND PCM");
        send("OK RXBACKEND\r\n");return;
    }
    if(!strncmp(command,"RXTIMER ",8)) {
        unsigned us;char extra;
        if(sscanf(command,"RXTIMER %u %c",&us,&extra)!=1 || (us!=250 && us!=500)
           || mon_enabled || mon_running || rx_job || call_active || prepared || down) {
            send("ERR RXTIMER 250|500; stopped RX/TX required\r\n");return;
        }
        mon_timer_us=us;send("OK RXTIMER\r\n");return;
    }
    if(!strncmp(command,"RXSERVICE ",10)) {
        unsigned ms;char extra;
        if(sscanf(command,"RXSERVICE %u %c",&ms,&extra)!=1 || (ms!=1 && ms!=2)
           || pdMS_TO_TICKS(ms)==0 || mon_enabled || mon_running || rx_job || call_active || prepared || down) {
            send("ERR RXSERVICE 1|2; stopped RX/TX required\r\n");return;
        }
        mon_timer_us=0;mon_service_ms=ms;send("OK RXSERVICE\r\n");return;
    }
    if(!strcmp(command,"RXPERF")) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXPERF\r\n");return;}
        char line[256];
        snprintf(line,sizeof line,"RXPERF service_ms=%u timer_us=%u ticks=%lu notify_max=%lu step_max_us=%lu step_total_us=%lu step_calls=%lu worst_at_us=%lu worst_queue_frames=%lu bins=32\r\n",mon_timer_us ? 0u : mon_service_ms,mon_timer_us,(unsigned long)mon_timer_ticks,(unsigned long)mon_notify_max,(unsigned long)mon_step_max_us,(unsigned long)mon_step_total_us,(unsigned long)mon_step_calls,(unsigned long)mon_worst_at,(unsigned long)mon_worst_queue);send(line);
        for(unsigned i=0;i<32;++i) {
            const mon_perf_bin *p=&mon_perf[i];
            if(!p->pushes && !p->full && !p->empty)continue;
            snprintf(line,sizeof line,"RXPERF_BIN second=%u pushes=%lu full=%lu max_gap_us=%lu max_service_us=%lu empty=%lu route_missing=%lu\r\n",i,(unsigned long)p->pushes,(unsigned long)p->full,(unsigned long)p->max_gap,(unsigned long)p->max_service,(unsigned long)p->empty,(unsigned long)p->route_missing);send(line);
        }
        send("OK RXPERF\r\n");return;
    }
    if(!strncmp(command,"RXTONE ",7)) {
        unsigned hz;char extra;
        if(sscanf(command,"RXTONE %u %c",&hz,&extra)!=1 || (hz!=997 && hz!=1000 && hz!=1011)
           || mon_enabled || mon_running || rx_job || call_active || prepared || down) {
            send("ERR RXTONE 997|1000|1011; stopped RX/TX required\r\n");return;
        }
        mon_tone_hz=hz;mon_tone_phase=0;send("OK RXTONE\r\n");return;
    }
    if(!strcmp(command,"RXOUTPUT DECODED") || !strcmp(command,"RXOUTPUT TONE")) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXOUTPUT\r\n");return;}
        mon_output_tone=!strcmp(command,"RXOUTPUT TONE");send("OK RXOUTPUT\r\n");screen("HOME");return;
    }
    if(!strncmp(command,"RXPCM ",6) || !strncmp(command,"RXBITS ",7)) {
        unsigned index,slice;char extra;
        if(mon_enabled || mon_running || !mon_used || rx_job || call_active || prepared || down) {
            send("ERR trace download requires stopped RX/TX and monitor evidence\r\n");return;
        }
        char line[192];
        if(!strncmp(command,"RXPCM ",6)) {
            if(sscanf(command,"RXPCM %u %u %c",&index,&slice,&extra)!=2 || index>=pcm_trace_kept(&monitor.trace) || slice>=5) {
                send("ERR RXPCM <retained-frame> <slice 0..4>\r\n");return;
            }
            uint32_t seq=monitor.trace.frames-pcm_trace_kept(&monitor.trace)+index;
            const int16_t *samples=&monitor.trace.pcm[seq%PCM_TRACE_FRAMES][slice*32];
            int n=snprintf(line,sizeof line,"RXPCM %u %u %lu ",index,slice,(unsigned long)seq);
            for(unsigned i=0;i<32;++i) {uint16_t x=(uint16_t)samples[i];n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x%02x",x&255u,x>>8);}
            snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);
        } else {
            if(sscanf(command,"RXBITS %u %c",&index,&extra)!=1 || index>=monitor.trace.frames || index>=PCM_TRACE_PAYLOADS) {
                send("ERR RXBITS <payload-index>\r\n");return;
            }
            int n=snprintf(line,sizeof line,"RXBITS %u ",index);
            for(unsigned i=0;i<11;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x",monitor.trace.payload[index][i]);
            snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);
        }
        return;
    }
    if(!strcmp(command,"RXFIFO SINGLE") || !strcmp(command,"RXFIFO BURST")) {
        if(mon_enabled || mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXFIFO\r\n");return;}
        mon_fifo_limit=!strcmp(command,"RXFIFO SINGLE") ? 1 : 8;send("OK RXFIFO\r\n");return;
    }
    if(!strcmp(command,"RXAUDIO ON") || !strcmp(command,"RXAUDIO OFF")) {
        if(mon_running || rx_job || call_active || prepared || down) {send("ERR stop RX/TX before RXAUDIO\r\n");return;}
        mon_audio_enabled=!strcmp(command,"RXAUDIO ON");send("OK RXAUDIO\r\n");screen("HOME");return;
    }
    if(!strcmp(command,"RXMON OFF")) {mon_enabled=false;mon_stop("disabled");send("OK RXMON OFF\r\n");screen("HOME");return;}
    if(!strncmp(command,"RXMON ",6)) {
        unsigned long hz;char mode[8],extra;
        if(sscanf(command,"RXMON %lu %7s %c",&hz,mode,&extra)!=2 || (strcmp(mode,"CLEAR") && strcmp(mode,"LOCAL") && strcmp(mode,"REPLAY"))
           || hz>480000000u || !channel_in_band((uint32_t)hz,false) || down || rx_job || call_active || prepared) {
            send("ERR RXMON <Hz> CLEAR/LOCAL/REPLAY | RXMON OFF; idle/PTT released\r\n");return;
        }
        if(!strcmp(mode,"REPLAY") && (mon_running || mon_enabled || !mon_used || !pcm_trace_kept(&monitor.trace))) {send("ERR REPLAY requires stopped retained PCM\r\n");return;}
        if(strcmp(mode,"CLEAR") && !mon_audio_enabled) {send("ERR playback requires RXAUDIO ON\r\n");return;}
        if(mon_running)mon_stop("retune");
        mon_local_tone=!strcmp(mode,"LOCAL");mon_replay=!strcmp(mode,"REPLAY");
        normal_mode=false;session_enabled=false;armed=false;radio_inhibit(&control,true);frequency=(uint32_t)hz;if(!control.split)control.tx_frequency=frequency;
        menu_open=editing=rx_lab=false;mon_enabled=true;mon_reason="ready";
        screen("HOME");send(mon_replay ? "OK RXMON REPLAY; 20s delay; retained tail once; TX inhibited\r\n" : mon_local_tone ? "OK RXMON LOCAL; 20s delay; 6s tone; TX inhibited\r\n" : "OK RXMON CLEAR; NAC filter; all talkgroups; TX inhibited\r\n");return;
    }
    if(mon_running && strcmp(command,"STOP") && strcmp(command,"STATUS")) {
        send("ERR stop RX monitor before diagnostics or TX configuration\r\n");return;
    }
    if(!strcmp(command,"RXDEMOD CLEAR") || !strcmp(command,"RXDEMOD CLEAR PROFILE")) {
        if(mon_used || down || rx_job || rx_sampling || call_active || prepared || hardware_running
            || rxcap.count!=RXCAP_BLOCKS || rxcap.gaps || rxcap.repeats || rxcap.invalid) {
            send("ERR RXDEMOD stopped complete gap-free known-clear capture required\r\n");return;
        }
        hardware_stop();armed=false;session_enabled=false;control.inhibit=true;
        send("OK RXDEMOD known-clear bench; RF and speaker off\r\n");
        if(!imbe_bench_init()) {send("ERR codec owner\r\n");return;}
        p25_receive_result result;
        p25_receive_bench_profile(&rxcap.data[0][0],RXCAP_BLOCKS*RXCAP_BYTES/2,(uint16_t)control.nac,
            hrc_micros,imbe_bench_decode_pcm,rx_bench_yield,&result,strstr(command," PROFILE")!=NULL);
        char line[320];
        snprintf(line,sizeof line,"RXDEMOD units=%lu voices=%lu corrected=%lu hash=%08lx elapsed_us=%lu active_us=%lu decode_us=%lu max_decode_us=%lu max_block_us=%lu state_bytes=%lu stack_free_bytes=%lu\r\n",
            (unsigned long)result.units,(unsigned long)result.voices,(unsigned long)result.corrected,
            (unsigned long)result.pcm_hash,(unsigned long)result.elapsed_us,(unsigned long)result.active_us,(unsigned long)result.decode_us,
            (unsigned long)result.max_decode_us,(unsigned long)result.max_block_us,(unsigned long)result.state_bytes,
            (unsigned long)(uxTaskGetStackHighWaterMark(NULL)*sizeof(StackType_t)));
        send(line);
        snprintf(line,sizeof line,"RXSTAGES profiled=%u fir_us=%lu symbol_us=%lu sync_us=%lu fec_us=%lu sync_tests=%lu fec_candidates=%lu fec_skipped=%lu\r\n",
            strstr(command," PROFILE")!=NULL,(unsigned long)result.fir_us,(unsigned long)result.symbol_us,
            (unsigned long)result.sync_us,(unsigned long)result.fec_us,(unsigned long)result.sync_tests,
            (unsigned long)result.fec_candidates,(unsigned long)result.fec_skipped);
        send(line);return;
    }
#endif
    if(!strncmp(command,"CHANNEL ",8)) {
        unsigned long rx,tx,nac,tg,id,gain;char extra;
        if(down || editing || menu_open || mon_enabled || mon_running || rx_job || call_active || prepared || armed || session_enabled) {send("ERR stop RX/TX before CHANNEL\r\n");return;}
        if(sscanf(command,"CHANNEL %lu %lu %lu %lu %lu %lu %c",&rx,&tx,&nac,&tg,&id,&gain,&extra)!=6) {send("ERR CHANNEL rx tx nac_decimal tg id mic_db\r\n");return;}
        p25_preferences p={(uint32_t)rx,(uint32_t)tx,(uint32_t)nac,(uint32_t)tg,(uint32_t)id,rx!=tx,(uint32_t)gain,owner_tx_inhibit,rx_promiscuous};
        if(rx>UINT32_MAX || tx>UINT32_MAX || nac>UINT32_MAX || tg>UINT32_MAX || id>UINT32_MAX || gain>UINT32_MAX || !pref_values(&p) || !channel_in_band(p.rx,false) || !channel_in_band(p.tx,true)) {send("ERR invalid channel\r\n");return;}
        frequency=p.rx;control.tx_frequency=p.tx;control.nac=p.nac;control.talkgroup=p.tg;control.source_id=p.id;control.split=p.split;mic_gain_db=p.mic_db;
        normal_mode=false;radio_inhibit(&control,true);pref_state="pending";preferences_poll(false);screen("HOME");send("OK CHANNEL; TX inhibited\r\n");return;
    }
    if(!strcmp(command,"STOP")) {
        trunk_stop("cancelled");
        if(cps_active)p25_cs_abort(&channel_store);
        cps_active=cps_link=false;feature_stop_scan(true);
        if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
        if(analog_fm.owned)p25_fm_stop(&analog_fm);
        normal_mode=false;session_enabled=false;mon_enabled=false;mon_stop("cancelled");
    }
    if(!strcmp(command,"STOP") && rx_job)rx_end("cancelled");
    if(!strcmp(command,"STOP")) {
        radio_inhibit(&control,true);menu_open=false;editing=false;digit_count=0;
        fail("cancelled");cleanup();screen("DISARMED");
        if(defer_reply)command_deferred|=COMMAND_DEFER_STOP_ACK;
        else send("OK STOP\r\n");
        return;
    }
    if(!strcmp(command,"STATUS")) { status(); return; }
#if DM32_LAB_DIAGNOSTICS
    if(!strncmp(command,"RXPROFILE ",10)) {
        unsigned profile;char extra;
        if(sscanf(command,"RXPROFILE %u %c",&profile,&extra)!=1 || profile>7 || down
           || rx_job || call_active || prepared) {send("ERR RXPROFILE 0..7; bit0=wide bit1=bypass bit2=DMR RF; idle only\r\n");return;}
        rx_profile=profile;send("OK RXPROFILE\r\n");return;
    }
    if(!strcmp(command,"RXMETA")) {
        if(rx_job || call_active) {send("ERR RXMETA stopped capture only\r\n");return;}
        char line[300];snprintf(line,sizeof line,"RXMETA profile=%u samples=%u max_poll_us=%lu work=%08lx rf=%08lx bw=%08lx audio=%08lx phase=%08lx spk_source=%u mic_path=%u\r\n",
            rx_capture_profile,rx_signal_count,(unsigned long)rx_signal_max_us,
            (unsigned long)rx_reg_work,(unsigned long)rx_reg_rf,(unsigned long)rx_reg_bw,
            (unsigned long)rx_reg_audio,(unsigned long)rx_reg_phase,(unsigned)rx_pin_source,(unsigned)rx_pin_mic);send(line);return;
    }
    if(!strncmp(command,"RXSIGNAL ",9)) {
        unsigned index;char extra;
        if(sscanf(command,"RXSIGNAL %u %c",&index,&extra)!=1 || rx_job || call_active
           || index>=rx_signal_count) {send("ERR RXSIGNAL index; stopped capture only\r\n");return;}
        char line[100];snprintf(line,sizeof line,"RXSIGNAL %u %lu %d %u\r\n",index,
            (unsigned long)rx_signals[index].us,(int)rx_signals[index].dbm,rx_signals[index].noise);send(line);return;
    }
    if(!strncmp(command,"RXCAP ",6)) {
        unsigned long hz,delay;char extra;
        if(sscanf(command,"RXCAP %lu %lu %c",&hz,&delay,&extra)!=2 || delay>30000u
           || hz>480000000u || !channel_in_band((uint32_t)hz,false) || down || rx_job
           || call_active || prepared || !dev || !hooks) {send("ERR RXCAP <Hz> <delay_ms 0..30000>; idle/PTT released\r\n");return;}
        mon_enabled=false;mon_used=false;memset(&rx_storage,0,sizeof rx_storage);
        armed=false;radio_inhibit(&control,true);hardware_stop();
        board.radio->audio(false);board.radio->set_mode((rx_profile&4u) ? RADIO_MODE_DMR : RADIO_MODE_FM);
        if(!board.radio->rx((uint32_t)hz,(rx_profile&1u) ? RADIO_BW_25K : RADIO_BW_12K5,NULL)) {rx_end("tune_failed");send("ERR RXCAP tune\r\n");return;}
        // DMR frontend, but no DMR slot engine: retain only the FM PCM recorder.
        // Board DMR setup applies its existing RF register table and DMR bandwidth.
        hardware_stop();
        if(rx_profile&4u) {
            hrc7000_fm_rx(dev,(rx_profile&1u)!=0);
            hrc7000_audio_bits(dev,0,C7_AUDIO_FM_PLAY);
        }
        // C7000 FM_BANDWIDTH bit 6 is the audio band-pass enable.
        // Diagnostic-only bypass after normal RX setup; normal RX/TX reprograms it.
        if(rx_profile&2u)wr(C7_FM_BANDWIDTH,hrc7000_rd(dev,C7_FM_BANDWIDTH)&~(1u<<6));
        rx_capture_profile=rx_profile;
        board_rf_safe();wr(C7_SYS_INTERP_MASK,0);
        rx_hz=(uint32_t)hz;rx_due=hrc_micros()+(uint32_t)delay*1000u;
        rx_reason="waiting";rx_job=true;menu_open=editing=false;rx_lab=true;
        screen("INFO");send("OK RXCAP scheduled; PA off; download after recording\r\n");return;
    }
    if(!strncmp(command,"RXREAD ",7)) {
        unsigned block,slice;char extra;
        if(sscanf(command,"RXREAD %u %u %c",&block,&slice,&extra)!=2 || rx_job || call_active
           || mon_used || block>=rxcap.count || slice>=8) {send("ERR RXREAD <block> <slice 0..7>; stopped capture only\r\n");return;}
        char line[220];int n=snprintf(line,sizeof line,"RXDATA %u %u %lu %u ",block,slice,
                                    (unsigned long)rxcap.times[block],rxcap.halves[block]);
        for(unsigned i=0;i<64;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02x",rxcap.data[block][slice*64+i]);
        snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);return;
    }
    unsigned long hz; char action[16],consent[16],extra;
    if(sscanf(command,"%15s %lu %15s %c",action,&hz,consent,&extra)!=3
       || (strcmp(action,"ARM") && strcmp(action,"SESSION")) || strcmp(consent,"ALLOW_RF")
       || hz>480000000ul || !channel_in_band((uint32_t)hz,true) || down || call_active || prepared || rx_job
       || !bf_cal_valid() || board.power->battery_mv()<board.battery_critical_mv) {
        send("ERR use STATUS | STOP | ARM/SESSION <Hz> ALLOW_RF; release PTT\r\n"); return;
    }
    normal_mode=false;mon_enabled=false;radio_complete(&control,false); menu_open=rx_lab=false; editing=false; digit_count=0; frequency=control.tx_frequency=(uint32_t)hz; control.split=false; arm_until=hrc_micros()+ARM_US;
    radio_inhibit(&control,false);
    session_enabled=!strcmp(action,"SESSION"); armed=!session_enabled;
    reason=session_enabled ? "session_ready" : "armed";
    screen(session_enabled ? "SESSION READY" : "ARMED / UNPLUG CABLE");
    send(session_enabled ? "OK LIVE SESSION; fresh PTT per call; STOP or power off ends\r\n"
                         : "OK LIVE ARMED 30s; unplug cable then fresh PTT\r\n");
#else
    send("ERR use RADIO | STATUS | STOP | CPS\r\n");
#endif
}
static void command_deferred_flush(bool down) {
    if(!command_deferred || command_tx_critical(down) || call_active || prepared || hardware_running || rx_sampling)return;
    if(telemetry_pending()) {
        if(command_deferred&COMMAND_DEFER_STATUS) {
            command_deferred&=~COMMAND_DEFER_STATUS;status();
        }
        return; // Complete the current response/partial row before any ACK.
    }
    // At most one short response per pass, regardless of the request count.
    if(command_deferred&COMMAND_DEFER_STOP_ACK) {
        command_deferred&=~COMMAND_DEFER_STOP_ACK;send("OK STOP\r\n");return;
    }
    if(command_deferred&COMMAND_DEFER_TRUNK_STOP_ACK) {
        command_deferred&=~COMMAND_DEFER_TRUNK_STOP_ACK;send("OK TRUNK STOP\r\n");return;
    }
    if(command_deferred&COMMAND_DEFER_MESSAGE) {
        command_deferred&=~COMMAND_DEFER_MESSAGE;send("CPS MSG ERR BUSY\r\n");return;
    }
    if(command_deferred&COMMAND_DEFER_TELEMETRY_BUSY) {
        command_deferred&=~COMMAND_DEFER_TELEMETRY_BUSY;send("ERR STATUS pending; retry\r\n");return;
    }
    unsigned pending=command_deferred;command_deferred_reset();
    if(pending&COMMAND_DEFER_STATUS)status();
    else if(pending&COMMAND_DEFER_BUSY)send("ERR DMR call active; request ignored\r\n");
}
#include "p25_runtime_update.h"
static bool controller_runtime_owned(void) {
#if DM32_RUNTIME_STUB_ENTRY
    return p25_stub_entry_owned(&runtime_update);
#else
    return false;
#endif
}
static void commands(bool down) {
    bool critical=command_tx_critical(down);
    command_critical_pass=critical;
    uint8_t b[32]; size_t n=board.host_port->read(b,sizeof b);
    for(size_t i=0;i<n;++i) {
#if DM32_RUNTIME_STUB_ENTRY
        // One UART owner: native binary framing is recognized at a request
        // boundary, and every byte in a partial frame stays out of ASCII/CPS.
        if((!command_used && !command_overflow) || p25_stub_entry_owned(&runtime_update)
           || p25_stub_entry_in_frame(&runtime_update,hal_millis())) {
            if(p25_stub_entry_feed(&runtime_update,&b[i],1,hal_millis())) {
                if(p25_stub_entry_owned(&runtime_update)) {command_used=0;command_overflow=false;}
                continue;
            }
        }
        if(p25_stub_entry_owned(&runtime_update)) {
            if(b[i]==3u || ((b[i]=='\r' || b[i]=='\n') && command_used==4u && !memcmp(command,"STOP",4)))
                p25_stub_entry_abort(&runtime_update);
            if(b[i]=='\r' || b[i]=='\n' || b[i]==3u)command_used=0;
            else if(b[i]>=32u && b[i]<127u && command_used<4u)command[command_used++]=(char)b[i];
            continue;
        }
#endif
        if(b[i]==3u) {
            if(DM32_OMAHA_RX_ONLY) {command_used=0;command_overflow=false;continue;}
            command_used=0;command_overflow=false;
            telemetry_abort_after_row();
#if DM32_TRUNK_SUBSCRIBER
            trunk_lab_return_cancel();
#endif
            if(trunk_probe.active) {trunk_probe_cancel();command_deferred|=COMMAND_DEFER_STOP_ACK;}
            if(trunk_enabled) {trunk_stop("operator");normal_permission();command_deferred|=COMMAND_DEFER_TRUNK_STOP_ACK;screen("HOME");}
            if(apps_active()) {apps_stop(true);send("APP STOPPED\r\n");screen("HOME");}
        } else if(b[i]==8u || b[i]==127u) {
            if(command_used && !command_overflow)--command_used;
        } else if(b[i]=='\n' || b[i]=='\r') {
            if(command_used || command_overflow) {
                command[command_used]=0;
                if(command_overflow) {
                    if(critical || command_tx_critical(down))command_deferred|=COMMAND_DEFER_BUSY;
                    else if(telemetry_pending())command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;
                    else send("ERR command too long\r\n");
                } else if(!strcmp(command,"STATUS")) {
                    if(critical || command_tx_critical(down))command_deferred|=COMMAND_DEFER_STATUS;
                    else status(); // Queue now so a later command in this batch cannot change owners.
                }
                else parse_command(down);
            }
            command_used=0; command_overflow=false;
        } else if(b[i]>=32 && b[i]<127 && !command_overflow) {
            if(command_used+1<sizeof command) command[command_used++]=(char)b[i]; else command_overflow=true;
        }
    }
    // STOP may have ended the call in this pass. Its acknowledgement waits for
    // the next pass instead of introducing UART work into that critical pass.
    command_critical_pass=false;
#if DM32_RUNTIME_STUB_ENTRY
    if(p25_stub_entry_owned(&runtime_update))return;
#endif
    if(!critical)command_deferred_flush(down);
}
static void controller_receive_checkpoint(void) {
#if DM32_TRUNK_SUBSCRIBER
    if(!trunk_rx_feed_selected() || trunk_rx_feed_terminal())return;
#if DM32_RUNTIME_STUB_ENTRY
    if(p25_stub_entry_owned(&runtime_update))return;
#endif
    if(call_active || prepared || hardware_running || audio_on
       || digital_dmr.tx_armed || digital_dmr.data_armed)return;
    // PTT admission/cancellation belongs to normal_tick_work. An inhibited or
    // already-held key must not turn a receive-only checkpoint into a cancel.
    (void)trunk_rx_feed_drain(false);
#endif
}
// The hardware loop and host adapter exercise exactly the same ordering.
static void normal_tick_work(uint32_t keys,bool *was_down,bool *dirty) {
    bool down=(keys&ptt_mask)!=0,old_arm=armed,old_session=session_enabled;
#if DM32_RUNTIME_STUB_ENTRY
    if(p25_stub_entry_owned(&runtime_update)) {
        commands(down);runtime_update_poll();*was_down=down;*dirty=false;return;
    }
#endif
    if(dmr_hard_timeout) {
        radio_dmr_stop(&digital_dmr);dmr_hard_timeout=false;
        call_active=hardware_running=false;control.cancel=false;
        radio_complete(&control,false);reason="time_limit";
        ptt_release_required=true;ptt_release_seen=false;
    }
    bool release_changed=ptt_release_poll(down);
#if DM32_TRUNK_SUBSCRIBER
    if(!(keys&~ptt_mask))trunk_system_logout_keys_released=true;
    // Invalidate the frozen lab owner before local input changes a channel/menu.
    if(keys&~ptt_mask) {
        trunk_preload_cc_cancel();trunk_lab_return_cancel();
        if(trunk_subscriber_active()&&(trunk_subscriber_transport_owned()
           ||trunk_subscriber_logout_pending()||(trunk_system_logout_requested&&trunk_system_logout_keys_released)))
            trunk_stop("operator");
    }
#endif
    bool keypad_allowed=feature_keys(keys);
    keypad_poll(keypad_allowed ? keys : keys&ptt_mask);
    if(board.input->encoder) {
        int step=board.input->encoder();
        if(step) {
#if DM32_TRUNK_SUBSCRIBER
            trunk_preload_cc_cancel();
            trunk_lab_return_cancel();
            if(trunk_subscriber_active())trunk_stop("operator");
#endif
            bool woke=radio_ux_activity(&radio_lights,hrc_micros(),true);
            if(!woke && keypad_allowed && !down)local_encoder(step);
        }
    }
    if(armed && (int32_t)(hrc_micros()-arm_until)>=0) {
        armed=false;if(!normal_mode && !session_enabled)radio_inhibit(&control,true);reason="arm_expired";
    }
    if(!pcm_owner)commands(down); // Binary PCM bytes must never enter the ASCII/Ctrl-C parser.
#if DM32_RUNTIME_STUB_ENTRY
    if(p25_stub_entry_owned(&runtime_update)) {
        runtime_update_poll();*was_down=down;*dirty=false;return;
    }
#endif
    if(apps_active()) {
        // This receive-only app consumes PTT transitions without forwarding
        // them. Require release before a later return to the ordinary radio.
        if(down) {ptt_release_required=true;ptt_release_seen=false;}
        apps_poll();feature_lights();*was_down=down;
        board.power->led(LED_RED,pcm_owner && pcm_engine.tx_started && hardware_running);
        if(radio_service_due(&power_sample_us,hrc_micros(),RADIO_POWER_PERIOD_US) && !board.power->switch_on()) {
            apps_stop(false);hardware_stop();board.power->latch(false);
        }
        return;
    }
    if(cps_link && hrc_micros()-cps_activity_us>=(cps_active ? 60000000u : 3000000u)) {
        if(cps_active)p25_cs_abort(&channel_store);
        cps_active=cps_link=false;reason="listening";screen("HOME");
    }
    if(airband_show) {
        uint32_t now=hrc_micros();
        if(down) {airband_leave(true);*was_down=true;feature_lights();return;}
        bool open=airband.audio_open;
        if(airband.running)(void)radio_airband_poll(&airband,now);
        ui_meters_poll();feature_lights();
        board.power->led(LED_RED,false);board.power->led(LED_GREEN,airband.audio_open);
        if(open!=airband.audio_open || (int32_t)(now-airband_due)>=0) {
            airband_due=now+200000u;airband_screen();
        }
        *was_down=down;
        if(radio_service_due(&power_sample_us,now,RADIO_POWER_PERIOD_US) && !board.power->switch_on()) {
            radio_airband_stop(&airband);airband_show=false;
            hardware_stop();board.power->latch(false);
        }
        return;
    }
    if(broadcast_show) {
        uint32_t now=hrc_micros();
        if(down) {
            broadcast_leave(true);*was_down=true;
            feature_lights();return;
        }
        if(broadcast.owned && (int32_t)(now-broadcast_due)>=0) {
            broadcast_due=now+100000u;
            bool busy=broadcast.busy,had_status=broadcast.have_status;
            bool stereo=broadcast.status.stereo;uint32_t khz=broadcast.khz;
            bool ok=radio_broadcast_poll(&broadcast);
            if(ok && !broadcast.busy && radio_functions_get_broadcast_khz(global_record)!=broadcast.khz) {
                (void)radio_functions_set_broadcast_khz(global_record,broadcast.khz);pref_state="pending";
            }
            if(!ok || busy!=broadcast.busy || had_status!=broadcast.have_status
               || stereo!=broadcast.status.stereo || khz!=broadcast.khz)broadcast_screen();
        }
        preferences_poll(down);ui_meters_poll();feature_lights();
        board.power->led(LED_RED,false);board.power->led(LED_GREEN,false);
        *was_down=down;
        if(radio_service_due(&power_sample_us,now,RADIO_POWER_PERIOD_US) && !board.power->switch_on()) {
            radio_broadcast_stop(&broadcast);broadcast_show=false;
            hardware_stop();board.power->latch(false);
        }
        return;
    }
    rx_poll(down);normal_permission();
#if DM32_TRUNK_SUBSCRIBER
    trunk_lab_attach_poll(down);
    trunk_lab_ptt_poll(down);
#endif
    const char *old_pref_state=pref_state;preferences_poll(down);
    if(old_pref_state!=pref_state)screen("HOME");
    if(normal_mode && !radio_busy(&control) && control.state!=RADIO_FAULT) {
        if(editing || (menu_open && !message_menu_active() && !DM32_OMAHA_RX_ONLY) || rx_lab || cps_link || cps_active)control.state=RADIO_RX_PAUSED;
        else radio_receive_state(&control,mon_enabled,feature_dmr() ? digital_dmr.running : feature_fm() ? analog_fm.running : mon_running,false,false);
    }
    // Inhibited or already-held PTT does not interrupt reception.
    bool scan_reply=channel_scan.running && normal_mode && !owner_tx_inhibit
        && bf_cal_valid() && board.power->battery_mv()>=board.battery_critical_mv
        && ptt_fresh_request(down,*was_down);
    if((scan_reply || ptt_start_requested(down,*was_down)) && !feature_stop_scan(true)) {
        // A reply must never fall back to another talkgroup when the matched
        // memory could not be loaded. Preserve the base profile, cancel TX and
        // require explicit channel recovery before another transmission.
        bool unmatched=!strcmp(reason,"scan_reply_unmatched");
        radio_complete(&control,!unmatched);
        if(!unmatched)radio_inhibit(&control,true);
        ptt_release_required=true;ptt_release_seen=false;
        if(!unmatched)reason="channel_read_failed";
    }
#if DM32_TRUNK_SUBSCRIBER
    bool lab_return_deaf=trunk_lab_return_poll(down);
#else
    bool lab_return_deaf=false;
#endif
    if(normal_mode && feature_dmr())feature_dmr_tick(down);
    else if(normal_mode && feature_fm())feature_fm_tick(down,*was_down);
    else if(!lab_return_deaf
#if DM32_TRUNK_SUBSCRIBER
        && !trunk_subscriber_transport_owned()
#endif
        )mon_poll(ptt_start_requested(down,*was_down));
#if DM32_TRUNK_SUBSCRIBER
    trunk_preload_cc_poll(down);
#endif
    trunk_poll(down);
    trunk_system_boot_poll(down);
    // Process pending receiver input before deciding that a scan dwell elapsed.
    // A first qualifying P25 unit at the deadline must be allowed to hold RX.
    feature_scan_poll();
    call_services_poll();
    message_radio_poll(down);
    controller_receive_checkpoint();
    ui_lab_transition_poll();
    controller_receive_checkpoint();
    ui_meters_poll();
    controller_receive_checkpoint();
    if(normal_mode && feature_dmr())dmr_indicator();
    if(display_ok && normal_mode && feature_fm() && analog_fm.running && !call_active && !editing && !menu_open && !rx_lab) {
        p25_ui_view view=ui_view(0);uint32_t token=ui_header_token(&view);
        if(token!=ui_header_shown) {gfx_frame_begin();p25_ui_header(&view);gfx_flush();ui_header_shown=token;}
    }
    if(release_changed)home_hint_refresh();
    if((old_arm!=armed || old_session!=session_enabled) && !call_active)screen("HOME");
    if((!normal_mode || feature_p25()) && ptt_start_requested(down,*was_down)
       && radio_request_tx(&control,down,*was_down,true)) {
        // Existing RF-off preview precedes microphone admission. Do not leave
        // LISTENING queued on the panel while all TX-time stripes are paused.
        bool deferred=radio_gfx_deferred();radio_gfx_defer(false);
        screen("VOICE CALL");radio_gfx_defer(deferred);*dirty=true;
        if(!begin_capture())fail("setup_failed");
    }
    *was_down=down;
#if DM32_TRUNK_SUBSCRIBER
    if(!trunk_lab_voice_owned() && !trunk_subscriber_transport_owned())
#endif
    if(!normal_mode || feature_p25())poll_call(down && !control.cancel);
    if(!call_active && *dirty) {
        cleanup();if(!normal_mode)status();screen("HOME");*dirty=false;
    }
    if(!call_active && !digital_dmr.owned)board_rf_safe();
    board.power->led(LED_RED,hardware_running);
    feature_lights();
    if(radio_service_due(&power_sample_us,hrc_micros(),RADIO_POWER_PERIOD_US)
       && !board.power->switch_on()) {
        trunk_stop("power_off");
        mon_enabled=false;if(digital_dmr.owned)radio_dmr_stop(&digital_dmr);
        mon_stop("power_off");if(analog_fm.owned)p25_fm_stop(&analog_fm);if(rx_job)rx_end("power_off");
        fail("power_off");cleanup();board.power->latch(false);
    }
}
static void ui_display_poll(bool down) {
    if(!display_ok || !radio_gfx_deferred() || !radio_gfx_pending())return;
#if DM32_RUNTIME_STUB_ENTRY
    if(p25_stub_entry_owned(&runtime_update))return;
#endif
    // A held-at-boot PTT must still be able to display its release warning.
    // Admitted PTT and all active voice/data feeders take precedence over LCD.
    if((down && !ptt_release_required) || command_tx_critical(down)
       || call_active || prepared || hardware_running || audio_on
       || (rx_sampling && !apps_active()) || digital_dmr.tx_armed || digital_dmr.data_armed)return;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_rx_stream_owned || trunk_rx_progress_owned || mon_control_only
       || trunk_preload_warmed() || trunk_lab_return_defer_ui())return;
    if(trunk_rx_feed_selected()) {
        // Normal radio policy already handled PTT above. A held/inhibited key
        // must not become a new receive-stop request merely because UI ran.
        (void)trunk_rx_feed_drain(false);
        if(trunk_rx_feed_handoff_fault || trunk_rx_feed_backlog()
           || trunk_rx_feed_frame_head!=trunk_rx_feed_frame_tail
           || trunk_rx_feed_status_head!=trunk_rx_feed_status_tail || trunk.pending_hz)return;
    } else
#endif
    if(mon_running && monitor.raw_head!=monitor.raw_tail)return;
    if(same_running && same_rx.audio.head!=same_rx.audio.tail)return;
    if(pcm_owner && (pcm_engine.config.operations==RADIO_PCM_TX
       || pcm_engine.rx.head!=pcm_engine.rx.tail))return;
    // One controller pass, at most eight row hashes and two physical rows.
    // The graphics core returns and releases the display/keypad bus each time.
    uint32_t begin=hrc_micros();(void)radio_gfx_step(2u,8u);
    uint32_t elapsed=hrc_micros()-begin;++ui_display_steps;
    if(elapsed>ui_display_max_us)ui_display_max_us=elapsed;
#if DM32_TRUNK_SUBSCRIBER
    // Consume anything published while the higher-priority decoder preempted
    // this stripe. This helper never renders or recursively calls graphics.
    if(trunk_rx_feed_selected())(void)trunk_rx_feed_drain(false);
#endif
}
static void normal_tick(uint32_t keys,bool *was_down,bool *dirty) {
    controller_receive_checkpoint();
    normal_tick_work(keys,was_down,dirty);
    controller_receive_checkpoint();
    ui_display_poll((keys&ptt_mask)!=0);
    controller_receive_checkpoint();
    // This wrapper covers every early return without moving UART work ahead
    // of physical PTT, RF cutoff, receiver draining or owner cleanup.
    telemetry_poll((keys&ptt_mask)!=0);
}
static void live_task(void *arg) {
    (void)arg; board_rf_safe(); board_init(); board_rf_safe();
    board.input->init(); board.radio->init(); board.radio->audio(false);
    radio_dmr_hal dmr_hal={.radio=board.radio,.modem=board.dmr,.audio=board.audio,.vocoder=board.vocoder,
        .acquire=dmr_acquire,.release=dmr_release,.clock_us=dmr_clock_us,.tx_diag=dmr_native_tx_diag,.machine_tx_begin=dmr_machine_tx_begin};
    radio_dmr_init(&digital_dmr,&dmr_hal);
    apps_init();
    if(!radio_codec_bind_dmr(&rx_storage,sizeof rx_storage)) {board_rf_safe();vTaskDelete(NULL);return;}
    preferences_restore();
    board.display->init(); display_ok=gfx_init(board.display);radio_gfx_defer(true);board.display->set_backlight(80);
    for(unsigned i=0;i<board.keymap_len;++i) if(board.keymap[i].short_action==ACT_PTT) ptt_mask|=1u<<board.keymap[i].bit;
    if(!dev || !hooks || !ptt_mask || !board.host_port || !board.host_port->start()) {
        board_rf_safe(); vTaskDelete(NULL); return;
    }
    p25_irqs_install();
    hrc_irq_register(IRQ_TIMER6,isr_hard_stop);hrc_irq_enable(IRQ_TIMER6,true);
    hardware_stop();
    key_candidate=key_stable=board.input->scan(); key_changed_at=hrc_micros();
#if DM32_RUNTIME_STUB_ENTRY
    (void)runtime_update_init();
#endif
    uint32_t sampled_keys=key_stable,key_sample_us=key_changed_at;
    power_sample_us=key_changed_at;
    bool was_down=(key_stable&ptt_mask)!=0, dirty=false;
    boot_policy();screen("HOME");status();
    for(;;) {
        if(radio_service_due(&key_sample_us,hrc_micros(),RADIO_INPUT_PERIOD_US))
            sampled_keys=board.input->scan();
        normal_tick(sampled_keys,&was_down,&dirty);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}
void __wrap_app_start(void) {
#if CONFIG_CRASH_LOG
    crash_init();
#endif
    // Native DMR audio runs at priority 5 and must preempt controller/LCD work.
    if(xTaskCreate(live_task,"p25live",4096,NULL,RADIO_CONTROL_PRIORITY,NULL)!=pdPASS) { board_rf_safe(); for(;;) {} }
}
