// SPDX-License-Identifier: GPL-3.0-or-later
// Included after channel features. All mailbox and serial staging is task-owned.
#ifndef P25_MESSAGE_SERVICES_H
#define P25_MESSAGE_SERVICES_H
static radio_mailbox mailbox;
// Exclusive finite P25 packet scratch: mailbox TX or the explicit lab probe.
static uint8_t message_packet[P25_DATA_FRAME_BYTES];
static uint32_t message_active_id,message_host_serial,message_ui_serial;
static struct {
    radio_message message;
    uint32_t touched_ms;
    uint8_t length,format,channel[32];
    bool ack,active;
    uint8_t written[10];
} message_stage;
static bool message_menu_active(void) {
    return menu_open && (menu_page==MENU_MESSAGES || menu_page==MENU_MESSAGE_LIST
        || menu_page==MENU_MESSAGE_VIEW || menu_page==MENU_MESSAGE_COMPOSE);
}
static bool message_tx_permission(void) {
    return !trunk_enabled && normal_mode && features_ready && !owner_tx_inhibit && !(channel_record[12]&16u)
        && !control.inhibit && control.state!=RADIO_FAULT && control.tx_enabled
        && !ptt_release_required && !rx_job && !rx_lab && !broadcast_show && !airband_show
        && hrc_pin_read(PIN_PTT)
        && !cps_active && !cps_link && !editing && feature_tx_settings_valid()
        && bf_cal_valid() && channel_in_band(control.tx_frequency,true)
        && board.power->battery_mv()>=board.battery_critical_mv;
}
static bool message_format_valid(unsigned protocol,unsigned kind,unsigned format,bool ack) {
    return (protocol==RADIO_PROTOCOL_P25 ? kind==RADIO_CALL_INDIVIDUAL && format==0u && !ack
        : protocol==RADIO_PROTOCOL_DMR && format<=2u && (!ack || (kind==RADIO_CALL_INDIVIDUAL && format!=2u)));
}
static radio_mail_item *message_enqueue(const radio_message *m,unsigned format,bool ack,const uint8_t profile[32]) {
    radio_mail_item *old=radio_mail_token(&mailbox,m->token);
    if(old)return radio_mail_same(old,m,format,ack) ? old : NULL;
    if(!radio_message_valid(m) || !message_format_valid(m->protocol,m->kind,format,ack)
       || !message_tx_permission() || m->source!=control.source_id
       || m->protocol!=(feature_dmr() ? RADIO_PROTOCOL_DMR : feature_p25() ? RADIO_PROTOCOL_P25 : 0u)
       || memcmp(profile,channel_record,32))return NULL;
    radio_mail_item *item=radio_mail_insert(&mailbox,m,RADIO_MAIL_QUEUED,(uint8_t)format,hal_millis());
    if(item) {item->ack=ack;memcpy(item->channel,profile,32);}return item;
}
static void message_cps_error(const char *code) {char line[48];snprintf(line,sizeof line,"CPS MSG ERR %s\r\n",code);send(line);}
static bool message_cps(bool down) {
    if(!strcmp(command,"CPS LIVE")) {
        if(cps_active || call_active || prepared || down) {feature_cps_error("BUSY");return true;}
        if(cps_link) {cps_link=false;(void)normal_resume();screen("HOME");}
        send("CPS OK LIVE\r\n");return true;
    }
    if(strncmp(command,"CPS MSG ",8))return false;
    if(cps_active) {message_cps_error("TRANSACTION");return true;}
    char line[120],extra;
    if(!strcmp(command,"CPS MSG HELLO")) {
        if(cps_link) {cps_link=false;(void)normal_resume();screen("HOME");}
        radio_message_capabilities p=radio_message_capability(RADIO_PROTOCOL_P25),d=radio_message_capability(RADIO_PROTOCOL_DMR);
        snprintf(line,sizeof line,"CPS MSG HELLO 1 serial=%lu count=%u capacity=%u max=%u p25=%u%u%u dmr=%u%u%u\r\n",
            (unsigned long)mailbox.serial,mailbox.count,RADIO_MAIL_CAPACITY,RADIO_MESSAGE_TEXT_BYTES,
            p.receive,p.transmit,p.acknowledgments,d.receive,d.transmit,d.acknowledgments);send(line);return true;
    }
    uint32_t index,offset;char id_text[12],offset_text[12],numbers[6][12];
    if(sscanf(command,"CPS MSG LIST %11s %c",id_text,&extra)==1) {
        if(!feature_number(id_text,10,0,false,&index)) {message_cps_error("INVALID");return true;}
        if(index>=mailbox.count) {message_cps_error("NOT_FOUND");return true;}
        const radio_mail_item *m=&mailbox.items[index];
        snprintf(line,sizeof line,"CPS MSG ITEM %lu %u %u %lu %lu %s %u %u %u %lu %lu %u\r\n",
            (unsigned long)m->id,m->message.protocol,m->message.kind,(unsigned long)m->message.source,
            (unsigned long)m->message.destination,radio_mail_state_name(m->state),m->format,m->unread,
            (unsigned)strlen(m->message.text),(unsigned long)m->stamp,(unsigned long)m->message.token,m->truncated ? 1u : 0u);
        send(line);return true;
    }
    uint32_t id;
    if(sscanf(command,"CPS MSG GET %11s %11s %c",id_text,offset_text,&extra)==2) {
        if(!feature_number(id_text,10,0,true,&id) || !feature_number(offset_text,10,0,false,&offset)) {message_cps_error("INVALID");return true;}
        radio_mail_item *m=radio_mail_find(&mailbox,id);
        if(!m) {message_cps_error("NOT_FOUND");return true;}
        size_t len=strlen(m->message.text);
        if(offset>=len) {message_cps_error("OFFSET");return true;}
        unsigned count=(unsigned)(len-offset);if(count>32u)count=32u;
        int n=snprintf(line,sizeof line,"CPS MSG TEXT %lu %u ",(unsigned long)id,(unsigned)offset);
        for(unsigned i=0;i<count;++i)n+=snprintf(line+n,sizeof line-(unsigned)n,"%02X",(unsigned char)m->message.text[offset+i]);
        snprintf(line+n,sizeof line-(unsigned)n,"\r\n");send(line);return true;
    }
    const char *verb=!strncmp(command,"CPS MSG READ ",13) ? "READ" : !strncmp(command,"CPS MSG DELETE ",15) ? "DELETE" : NULL;
    if(verb) {
        const char *p=command+(!strcmp(verb,"READ") ? 13u : 15u);
        if(sscanf(p,"%11s %c",id_text,&extra)!=1 || !feature_number(id_text,10,0,true,&id)) {message_cps_error("ID");return true;}
        radio_mail_item *m=radio_mail_find(&mailbox,id);
        if(!m) {message_cps_error("NOT_FOUND");return true;}
        if(!strcmp(verb,"DELETE") ? !radio_mail_delete(&mailbox,id) : !radio_mail_read(&mailbox,id)) {message_cps_error("BUSY");return true;}
        snprintf(line,sizeof line,"CPS MSG OK %s %lu\r\n",verb,(unsigned long)id);send(line);return true;
    }
    uint32_t token,protocol,kind,destination,ack,format,length;
    if(sscanf(command,"CPS MSG BEGIN %11s %11s %11s %11s %11s %11s %11s %c",id_text,numbers[0],numbers[1],numbers[2],numbers[3],numbers[4],numbers[5],&extra)==7) {
        if(call_active || prepared || down || !hrc_pin_read(PIN_PTT)) {message_cps_error("BUSY");return true;}
        if(!feature_number(id_text,10,0,true,&token) || !feature_number(numbers[0],10,0,false,&protocol)
           || !feature_number(numbers[1],10,0,false,&kind) || !feature_number(numbers[2],10,0,true,&destination)
           || !feature_number(numbers[3],10,0,false,&ack) || !feature_number(numbers[4],10,0,false,&format)
           || !feature_number(numbers[5],10,0,true,&length) || length>RADIO_MESSAGE_TEXT_BYTES
           || ack>1u || !radio_address_valid(protocol,kind,destination) || !message_format_valid(protocol,kind,format,ack!=0)) {
            message_cps_error("INVALID");return true;
        }
        if(message_stage.active && message_stage.message.token!=token
           && hal_millis()-message_stage.touched_ms<30000u) {message_cps_error("BUSY");return true;}
        memset(&message_stage,0,sizeof message_stage);message_stage.active=true;
        message_stage.message=(radio_message){.protocol=(uint8_t)protocol,.kind=(uint8_t)kind,
            .source=control.source_id,.destination=destination,.token=token};
        message_stage.length=(uint8_t)length;message_stage.format=(uint8_t)format;message_stage.ack=ack!=0;
        memcpy(message_stage.channel,channel_record,32);message_stage.touched_ms=hal_millis();
        snprintf(line,sizeof line,"CPS MSG OK BEGIN %lu\r\n",(unsigned long)token);send(line);return true;
    }
    char hex[65];
    if(sscanf(command,"CPS MSG PUT %11s %11s %64s %c",id_text,offset_text,hex,&extra)==3) {
        if(!feature_number(offset_text,10,0,false,&offset)) {message_cps_error("OFFSET");return true;}
        if(!feature_number(id_text,10,0,true,&token) || !message_stage.active || token!=message_stage.message.token
           || hal_millis()-message_stage.touched_ms>=30000u) {message_cps_error("EXPIRED");return true;}
        size_t count=strlen(hex)/2u;uint8_t bytes[32];
        if(!count || strlen(hex)!=count*2u || offset>=message_stage.length || count>message_stage.length-offset
           || !feature_hex(hex,bytes,(unsigned)count)) {message_cps_error("TEXT");return true;}
        for(unsigned i=0;i<count;++i)if(bytes[i]<32u || bytes[i]>126u) {message_cps_error("TEXT");return true;}
        for(unsigned i=0;i<count;++i) {
            unsigned pos=offset+i;message_stage.message.text[pos]=(char)bytes[i];message_stage.written[pos/8u]|=(uint8_t)(1u<<(pos%8u));
        }
        message_stage.touched_ms=hal_millis();
        snprintf(line,sizeof line,"CPS MSG OK PUT %lu %u\r\n",(unsigned long)token,(unsigned)offset);send(line);return true;
    }
    verb=!strncmp(command,"CPS MSG SEND ",13) ? "SEND" : !strncmp(command,"CPS MSG CANCEL ",15) ? "CANCEL" : NULL;
    if(verb) {
        if(sscanf(command+(!strcmp(verb,"SEND") ? 13u : 15u),"%11s %c",id_text,&extra)!=1 || !feature_number(id_text,10,0,true,&token)) {message_cps_error("TOKEN");return true;}
        if(!strcmp(verb,"CANCEL")) {
            if(message_stage.active && message_stage.message.token==token)message_stage.active=false;
            snprintf(line,sizeof line,"CPS MSG OK CANCEL %lu\r\n",(unsigned long)token);send(line);return true;
        }
        radio_mail_item *m=radio_mail_token(&mailbox,token);
        if(!message_stage.active || message_stage.message.token!=token) {
            if(!m) {message_cps_error("EXPIRED");return true;}
        } else {
            if(hal_millis()-message_stage.touched_ms>=30000u) {message_stage.active=false;message_cps_error("EXPIRED");return true;}
            for(unsigned i=0;i<message_stage.length;++i)if(!(message_stage.written[i/8u]&(1u<<(i%8u)))) {message_cps_error("INCOMPLETE");return true;}
            if(down || !hrc_pin_read(PIN_PTT) || call_active || prepared) {message_cps_error("BUSY");return true;}
            m=message_enqueue(&message_stage.message,message_stage.format,message_stage.ack,message_stage.channel);
            if(!m) {message_cps_error("REFUSED");return true;}
            message_stage.active=false;
        }
        snprintf(line,sizeof line,"CPS MSG OK SEND %lu %lu\r\n",(unsigned long)token,(unsigned long)m->id);send(line);return true;
    }
    message_cps_error("COMMAND");return true;
}
#endif
