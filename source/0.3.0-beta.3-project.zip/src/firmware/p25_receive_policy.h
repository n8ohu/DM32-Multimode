// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_RECEIVE_POLICY_H
#define P25_RECEIVE_POLICY_H
#include "p25_call.h"
#include <string.h>

// Selection (NAC/PROM) happens before this policy. PROM never bypasses metadata
// integrity or supported clear voice qualification. No identity or ESS crosses
// a boundary. Individual destinations are unit IDs, never 16-bit talkgroups.
typedef enum {
    P25_RX_WAIT_METADATA, P25_RX_CLEAR, P25_RX_ENCRYPTED,
    P25_RX_UNSUPPORTED, P25_RX_BAD_METADATA
} p25_receive_class;
typedef struct {
    uint32_t source,last_unit_us,last_identity_us;
    uint16_t nac,group,keyid;
    uint8_t algid,mfid,last_duid;
    bool active,ess_valid,lc_valid,group_valid,source_valid;
    bool header_unsupported,lc_encrypted,lc_unsupported;
    p25_receive_class state;
    uint32_t destination;
    uint8_t service_options;
    bool private_call,destination_valid,emergency;
} p25_receive_policy;
typedef struct {bool reset,new_call,voice,end,discard;} p25_receive_event;

static inline void p25_receive_reset(p25_receive_policy *s) {memset(s,0,sizeof *s);}
static inline const char *p25_receive_label(const p25_receive_policy *s) {
    return s->state==P25_RX_CLEAR ? (s->private_call ? "CLEAR INDIVIDUAL" : "CLEAR GROUP") : s->state==P25_RX_ENCRYPTED ? "ENCRYPTED / MUTED"
        : s->state==P25_RX_UNSUPPORTED ? "UNSUPPORTED / MUTED"
        : s->state==P25_RX_BAD_METADATA ? "BAD METADATA / MUTED" : "WAIT CALL METADATA";
}
// Selection is separate from clear/encrypted qualification. PROM bypasses NAC,
// TG and local-unit selection in the caller, but never permits encrypted audio.
// Scan-list group selection may replace the final group comparison in callers.
static inline bool p25_receive_selected(const p25_receive_policy *s,bool prom,
        uint32_t local_id,bool filter_group,uint16_t group) {
    if(!s->active || !s->lc_valid || !s->source_valid)return false;
    if(s->private_call)return s->destination_valid && (prom || s->destination==local_id);
    return s->group_valid && (prom || !filter_group || s->group==group);
}
static inline void p25_receive_clear_identity(p25_receive_policy *s) {
    s->lc_valid=s->source_valid=s->group_valid=s->destination_valid=false;
    s->source=s->group=s->destination=0;
    s->private_call=s->emergency=false;s->service_options=0;
}
static inline p25_receive_event p25_receive_update(p25_receive_policy *s,uint16_t nac,
        uint8_t duid,const p25_call_metadata *m,bool valid,uint32_t now) {
    p25_receive_event event={false,false,false,false,false};
    if(duid==3 || duid==15) {
        // A foreign NAC's terminator cannot end the selected call in PROM.
        if(s->active && s->nac==nac) {p25_receive_reset(s);event.end=true;}
        return event;
    }
    if(duid!=0 && duid!=5 && duid!=10)return event;
    bool fresh=!s->active || s->nac!=nac || now-s->last_unit_us>600000u || duid==0;
    if(fresh) {p25_receive_reset(s);s->active=true;s->nac=nac;event.reset=event.new_call=event.discard=true;}
    p25_receive_class previous=s->state;
    bool prior_clear_ess=s->ess_valid && s->algid==0x80;
    s->last_unit_us=now;
    if(duid==0) {
        if(valid && m->ess_valid && m->group_valid && m->mfid_valid) {
            s->ess_valid=true;s->algid=m->algid;s->keyid=m->keyid;
            s->group=m->group;s->group_valid=true;s->mfid=m->mfid;
            s->header_unsupported=m->classification!=P25_CALL_CLEAR && m->classification!=P25_CALL_ENCRYPTED;
        } else s->state=P25_RX_BAD_METADATA;
    } else if(duid==5) {
        if(!valid || !m->lc_valid) {
            p25_receive_clear_identity(s);s->state=P25_RX_BAD_METADATA;
        } else if(m->classification==P25_CALL_ANCILLARY) {
            // A recognized auxiliary LC can accompany this call's speech;
            // it cannot create/repair identity or crypto authorization. Keep
            // the original identity/services, and do not renew its age here.
            // The 600-ms bound allows one normal auxiliary pair, not an
            // indefinitely renewed call based only on unrelated channel LC.
            bool continuity=!fresh && previous==P25_RX_CLEAR && prior_clear_ess
                && s->lc_valid && s->source_valid && !s->header_unsupported
                && !s->lc_encrypted && !s->lc_unsupported && s->last_duid==10u
                && now-s->last_identity_us<=600000u && p25_call_ancillary(m)
                && (s->private_call?s->destination_valid:s->group_valid)
                && (m->lco!=9u || m->source==s->source);
            if(!continuity) {
                p25_receive_clear_identity(s);s->lc_unsupported=true;
                event.discard=true;
            }
        } else {
            bool individual=m->lco==3;
            // HDU group=0 is not an individual destination. Its first LCO 3
            // establishes the destination without discarding the fresh ESS.
            bool changed=(s->lc_valid && s->private_call!=individual)
                || (s->group_valid && !individual && (!m->group_valid || s->group!=m->group))
                || (s->destination_valid && (!m->destination_valid || s->destination!=m->destination))
                || (s->source_valid && (!m->source_valid || s->source!=m->source));
            // A different call without HDU, or a missing ESS unit, cannot inherit
            // a previous clear authorization. Wait for fresh ESS before audio.
            if(changed || (!fresh && s->last_duid==5)) {
                s->ess_valid=false;s->algid=0;s->keyid=0;event.reset=event.discard=true;
                if(changed) {event.new_call=true;s->header_unsupported=false;}
            }
            s->lc_valid=true;s->group_valid=m->group_valid;s->source_valid=m->source_valid;
            s->private_call=individual;s->destination_valid=m->destination_valid;
            s->group=m->group_valid?m->group:0;s->source=m->source_valid?m->source:0;
            s->destination=m->destination_valid?m->destination:0;s->mfid=m->mfid;
            s->service_options=m->service_options;
            s->last_identity_us=now;
            s->emergency=m->mfid_valid && p25_call_standard_mfid(m->mfid) && !m->standard_format && !m->protected_flag
                && (m->lco==0 || m->lco==3) && (m->service_options&0x80)!=0;
            s->lc_encrypted=m->classification==P25_CALL_ENCRYPTED || m->protected_flag || (m->service_options&0x40);
            s->lc_unsupported=(m->classification!=P25_CALL_CLEAR && m->classification!=P25_CALL_ENCRYPTED)
                || (m->classification==P25_CALL_CLEAR && (!m->mfid_valid || !p25_call_standard_mfid(m->mfid) || (m->lco!=0 && m->lco!=3)
                    || m->protected_flag || m->standard_format || m->lc_options || (m->service_options&0x30)
                    || !(individual ? m->destination_valid : m->group_valid) || !m->source_valid
                    || (individual ? m->group_valid : m->destination_valid)));
        }
    } else {
        if(!valid || !m->ess_valid || (m->classification!=P25_CALL_CLEAR && m->classification!=P25_CALL_ENCRYPTED)) {
            s->ess_valid=false;s->algid=0;s->keyid=0;s->state=P25_RX_BAD_METADATA;
        } else {
            if(!fresh && s->last_duid==10) {
                p25_receive_clear_identity(s);event.reset=event.discard=true;
            }
            s->ess_valid=true;s->algid=m->algid;s->keyid=m->keyid;
        }
    }
    // Compute classification from independently validated ESS and call type.
    // Bad metadata is shown until the missing portion is recovered.
    if(s->header_unsupported || s->lc_unsupported)s->state=P25_RX_UNSUPPORTED;
    else if((s->ess_valid && s->algid!=0x80) || s->lc_encrypted)s->state=P25_RX_ENCRYPTED;
    else if(s->ess_valid && s->lc_valid && s->source_valid
        && (s->private_call?s->destination_valid:s->group_valid))s->state=P25_RX_CLEAR;
    else if(s->state!=P25_RX_BAD_METADATA)s->state=P25_RX_WAIT_METADATA;
    if((previous==P25_RX_CLEAR && s->state!=P25_RX_CLEAR)
        || s->state==P25_RX_ENCRYPTED || s->state==P25_RX_UNSUPPORTED || s->state==P25_RX_BAD_METADATA)event.discard=true;
    if(previous!=P25_RX_CLEAR && s->state==P25_RX_CLEAR)event.reset=true;
    s->last_duid=duid;
    // LDU2 carries ESS for the next voice pair. A newly clear ESS must not
    // authorize this LDU2 under an unknown/encrypted previous crypto state.
    // A newly encrypted ESS mutes immediately, before any PCM is synthesized.
    event.voice=duid!=0 && s->state==P25_RX_CLEAR && (duid!=10 || prior_clear_ess);
    return event;
}
#endif
