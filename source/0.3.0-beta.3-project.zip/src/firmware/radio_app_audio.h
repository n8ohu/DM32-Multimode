// SPDX-License-Identifier: GPL-3.0-or-later
// One ISR producer, one task consumer. No allocation, printing or DSP in ISR.
#ifndef RADIO_APP_AUDIO_H
#define RADIO_APP_AUDIO_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#define RADIO_APP_AUDIO_BLOCKS 8u
#define RADIO_APP_AUDIO_SAMPLES 256u
typedef struct {
    int16_t pcm[RADIO_APP_AUDIO_SAMPLES];
    bool gap;
} radio_app_audio_block;
typedef struct {
    radio_app_audio_block block[RADIO_APP_AUDIO_BLOCKS];
    volatile uint8_t head,tail;
    uint8_t last_half;
    bool have_half,pending_gap;
    uint32_t last_us;
    volatile uint32_t blocks,dropped,gaps;
} radio_app_audio;

static inline void radio_app_audio_init(radio_app_audio *q) {memset(q,0,sizeof *q);}
static inline bool radio_app_audio_push(radio_app_audio *q,volatile const uint8_t *ram,unsigned half,uint32_t now) {
    if(half!=1u && half!=2u) {++q->gaps;q->pending_gap=true;return false;}
    if(q->have_half && (half==q->last_half || now-q->last_us>48000u)) {
        ++q->gaps;q->pending_gap=true;
    }
    q->have_half=true;q->last_half=(uint8_t)half;q->last_us=now;
    unsigned next=(q->head+1u)%RADIO_APP_AUDIO_BLOCKS;
    if(next==q->tail) {++q->dropped;q->pending_gap=true;return false;}
    radio_app_audio_block *b=&q->block[q->head];
    unsigned offset=(half-1u)*512u;
    // C7000 FM recorder RAM is big-endian (unlike its speaker prompt FIFO).
    // Match the native hrc7000_fm_rx_audio and the validated P25 capture reader.
    for(unsigned i=0;i<RADIO_APP_AUDIO_SAMPLES;++i)
        b->pcm[i]=(int16_t)((uint16_t)ram[offset+2u*i]<<8|(uint16_t)ram[offset+2u*i+1u]);
    b->gap=q->pending_gap;q->pending_gap=false;
    __asm__ volatile("" ::: "memory");
    q->head=(uint8_t)next;++q->blocks;return true;
}
// Keep this slot owned until commit. The ISR cannot overwrite it while DSP or
// serial output preempts the consumer. Caller must not hold a pointer on stop.
static inline const radio_app_audio_block *radio_app_audio_peek(const radio_app_audio *q) {
    if(q->tail==q->head)return NULL;
    __asm__ volatile("" ::: "memory");
    return &q->block[q->tail];
}
static inline void radio_app_audio_commit(radio_app_audio *q) {
    __asm__ volatile("" ::: "memory");
    q->tail=(uint8_t)((q->tail+1u)%RADIO_APP_AUDIO_BLOCKS);
}
#endif
