// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_applets.h"
#include <stdio.h>
#include <string.h>

typedef struct {const char *p;unsigned n;} app_token;
static bool eq(app_token t,const char *s) {
    unsigned i=0;for(;i<t.n && s[i];++i) {
        char c=t.p[i];if(c>='a' && c<='z')c=(char)(c-'a'+'A');
        if(c!=s[i])return false;
    }
    return i==t.n && !s[i];
}
static bool number(app_token t,uint32_t *out) {
    uint32_t v=0;if(!t.n || t.n>10u)return false;
    for(unsigned i=0;i<t.n;++i) {
        unsigned d=(unsigned char)t.p[i]-'0';if(d>9u || v>(UINT32_MAX-d)/10u)return false;
        v=v*10u+d;
    }
    *out=v;return true;
}
static void emit(radio_applets *a,const char *s) {if(a->hal.emit)a->hal.emit(a->context,s);}
static uint32_t now_ms(radio_applets *a) {return a->hal.millis ? a->hal.millis(a->context) : 0u;}
static bool acquire(radio_applets *a) {
    if(a->owned)return false;
    if(!a->hal.acquire || !a->hal.release || !a->hal.acquire(a->context))return false;
    a->owned=true;a->activity_ms=now_ms(a);return true;
}
static void release(radio_applets *a) {
    bool was=a->owned;a->owned=a->running=a->begin_pending=a->finishing=false;a->operation=APPLET_OP_NONE;
    if(was)a->hal.release(a->context);
}
static bool package_read(void *context,uint32_t off,void *out,size_t n) {
    radio_applets *a=context;
    return n<=UINT32_MAX && radio_applet_store_read(&a->store,a->slot-1u,off,out,(uint32_t)n);
}
static bool staged_read(void *context,uint32_t off,void *out,size_t n) {
    radio_applets *a=context;
    return n<=UINT32_MAX && radio_applet_store_stage_read(&a->store,off,out,(uint32_t)n);
}
static bool validate_stage(void *context,uint32_t length) {
    radio_applets *a=context;radio_applet_package p;radio_applet_error error;
    return radio_applet_vm_validate(staged_read,a,&p,&error) && p.total_bytes==length;
}
static void fail(radio_applets *a,const char *message) {
    radio_applet_vm_stop(&a->vm);radio_applet_store_abort(&a->store);release(a);emit(a,message);
}
static bool store_available(const radio_applets *a) {
    return a->store.state==RADIO_APPLET_STORE_READY || a->store.state==RADIO_APPLET_STORE_FOREIGN;
}
void radio_applets_init(radio_applets *a,const radio_applet_store_io *io,const radio_applets_hal *hal,void *context) {
    memset(a,0,sizeof *a);if(hal)a->hal=*hal;a->context=context;
    (void)radio_applet_store_open(&a->store,io);
}
bool radio_applets_active(const radio_applets *a) {return a && a->owned;}
void radio_applets_stop(radio_applets *a) {
    if(!a)return;
    radio_applet_vm_stop(&a->vm);radio_applet_store_abort(&a->store);release(a);
}
void radio_applets_slot_label(radio_applets *a,unsigned slot,char *name,size_t name_size,char *detail,size_t detail_size) {
    snprintf(name,name_size,"Slot %u",slot);
    if(!slot || slot>RADIO_APPLET_STORE_SLOTS) {snprintf(detail,detail_size,"Invalid slot");return;}
    if(!store_available(a)) {snprintf(detail,detail_size,"Select to check applet storage");return;}
    const radio_applet_slot_info *s=&a->store.slots[slot-1u];
    if(!s->present) {snprintf(detail,detail_size,"Empty / install over serial");return;}
    uint8_t h[RADIO_APPLET_HEADER_BYTES];
    if(!radio_applet_store_read(&a->store,slot-1u,0,h,sizeof h) || memcmp(h,"DAPP",4)) {
        snprintf(detail,detail_size,"Invalid package");return;
    }
    char safe[24];unsigned n=0;
    while(n<23u && h[32u+n]>=32u && h[32u+n]<=126u) {safe[n]=(char)h[32u+n];++n;}
    safe[n]=0;
    if(n)snprintf(name,name_size,"%s",safe);
    snprintf(detail,detail_size,"Slot %u / %lu bytes / r%lu",slot,(unsigned long)s->length,(unsigned long)s->revision);
}
static void catalogue(radio_applets *a) {
    emit(a,"APP STORE slots=8 bank_bytes=65536 partition_bytes=1048576 max_package=32768");
    if(a->store.state==RADIO_APPLET_STORE_FOREIGN)emit(a,"APP STORE READ_ONLY foreign_data");
    for(unsigned i=1;i<=RADIO_APPLET_STORE_SLOTS;++i) {
        char line[128],name[32],detail[64];const radio_applet_slot_info *s=&a->store.slots[i-1u];
        if(s->present) {
            radio_applets_slot_label(a,i,name,sizeof name,detail,sizeof detail);
            snprintf(line,sizeof line,"APP SLOT %u name=%s size=%lu seq=%lu",i,name,(unsigned long)s->length,(unsigned long)s->revision);
        } else snprintf(line,sizeof line,"APP SLOT %u EMPTY",i);
        emit(a,line);
    }
    emit(a,"APP OK STORE STATUS");
}
bool radio_applets_catalogue(radio_applets *a) {
    if(a->owned) {emit(a,"APP ERROR stop applet before listing storage");return false;}
    if(store_available(a)) {catalogue(a);return true;}
    if(a->store.state!=RADIO_APPLET_STORE_SCANNING) {emit(a,"APP ERROR applet storage unavailable");return false;}
    if(!acquire(a)) {emit(a,"APP ERROR radio busy");return false;}
    a->operation=APPLET_OP_CATALOGUE;return true;
}
static bool launch(radio_applets *a) {
    if(!a->store.slots[a->slot-1u].present) {fail(a,"APP ERROR empty applet slot");return false;}
    radio_applet_vm_init(&a->vm,package_read,a,&a->hal.services,a->context);
    radio_applet_error error;
    if(!radio_applet_vm_start(&a->vm,&error)) {fail(a,"APP ERROR invalid applet package");return false;}
    a->running=true;a->operation=APPLET_OP_NONE;
    char line[48];snprintf(line,sizeof line,"APP OK RUN %u",a->slot);emit(a,line);return true;
}
bool radio_applets_run(radio_applets *a,unsigned slot) {
    if(!slot || slot>RADIO_APPLET_STORE_SLOTS) {emit(a,"APP ERROR slot must be 1..8");return false;}
    if(!store_available(a) && a->store.state!=RADIO_APPLET_STORE_SCANNING) {emit(a,"APP ERROR applet storage unavailable");return false;}
    if(!acquire(a)) {emit(a,"APP ERROR stop current app or radio busy");return false;}
    a->slot=slot;
    if(a->store.state==RADIO_APPLET_STORE_SCANNING) {a->operation=APPLET_OP_RUN;return true;}
    return launch(a);
}
static bool begin_install(radio_applets *a) {
    if(a->store.state==RADIO_APPLET_STORE_FOREIGN) {fail(a,"APP ERROR foreign data in applet partition; no erase performed");return false;}
    const radio_applet_slot_info *s=&a->store.slots[a->slot-1u];
    if(!radio_applet_store_begin(&a->store,a->slot-1u,a->pending_size,a->pending_crc,s->committed ? s->revision : 0u)) {
        fail(a,"APP ERROR cannot begin applet install");return false;
    }
    a->begin_pending=true;return true;
}
void radio_applets_poll(radio_applets *a) {
    if(!a || !a->owned)return;
    if(a->running) {
        radio_applet_state state=radio_applet_vm_tick(&a->vm,now_ms(a));
        if(state==RADIO_APPLET_FINISHED) {
            if(!a->finishing) {a->finishing=true;a->activity_ms=now_ms(a);}
            if(a->hal.output_pending && a->hal.output_pending(a->context) && now_ms(a)-a->activity_ms<1000u)return;
            release(a);emit(a,"APP DONE");
        }
        else if(state==RADIO_APPLET_FAULT) {
            char line[96];snprintf(line,sizeof line,"APP ERROR runtime %s",radio_applet_vm_error_name(a->vm.error));
            fail(a,line);
        }
        return;
    }
    if(radio_applet_store_busy(&a->store) && a->store.state!=RADIO_APPLET_STORE_WRITING) {
        if(!radio_applet_store_step(&a->store)) {fail(a,"APP ERROR applet storage operation failed; previous revision retained");return;}
        a->activity_ms=now_ms(a);return;
    }
    if(a->store.state==RADIO_APPLET_STORE_ERROR) {fail(a,"APP ERROR applet storage failed");return;}
    if(a->operation==APPLET_OP_CATALOGUE) {release(a);catalogue(a);return;}
    if(a->operation==APPLET_OP_RUN) {(void)launch(a);return;}
    if(a->operation==APPLET_OP_INSTALL) {
        if(a->store.state==RADIO_APPLET_STORE_READY || a->store.state==RADIO_APPLET_STORE_FOREIGN) {(void)begin_install(a);return;}
        if(a->store.state==RADIO_APPLET_STORE_WRITING && a->begin_pending) {
            a->begin_pending=false;emit(a,"APP OK INSTALL BEGIN");
        }
    } else if(a->operation==APPLET_OP_COMMIT) {release(a);emit(a,"APP OK INSTALL COMMIT");return;}
    else if(a->operation==APPLET_OP_REMOVE) {
        unsigned slot=a->slot;release(a);char line[48];snprintf(line,sizeof line,"APP OK REMOVE %u",slot);emit(a,line);return;
    }
    if(now_ms(a)-a->activity_ms>30000u)fail(a,"APP ERROR install timed out; previous revision retained");
}
static unsigned hex_digit(char c) {
    if(c>='0' && c<='9')return (unsigned)(c-'0');
    if(c>='a' && c<='f')return (unsigned)(c-'a'+10);
    if(c>='A' && c<='F')return (unsigned)(c-'A'+10);
    return 16u;
}
bool radio_applets_command(radio_applets *a,const char *line) {
    app_token t[7];unsigned n=0,len=0,pos=0;
    if(!a || !line)return false;
    while(line[len] && len<=119u)++len;
    if(len>119u)return false;
    while(pos<len) {
        while(pos<len && (line[pos]==' ' || line[pos]=='\t' || line[pos]=='\r' || line[pos]=='\n'))++pos;
        if(pos==len)break;
        if(n==7u)return false;
        unsigned start=pos;while(pos<len && line[pos]!=' ' && line[pos]!='\t' && line[pos]!='\r' && line[pos]!='\n')++pos;
        t[n++]=(app_token){line+start,pos-start};
    }
    if(!n)return false;
    if(eq(t[0],"APPS") && n==1u) {
        emit(a,"SAME - NOAA SAME header decoder (receive only)");(void)radio_applets_catalogue(a);return true;
    }
    if(!eq(t[0],"APP") || n<2u)return false;
    if(eq(t[1],"HELP")) {
        emit(a,"APP STORE STATUS | APP RUN <1..8> | APP REMOVE <1..8>");
        emit(a,"APP INSTALL BEGIN/DATA/COMMIT/ABORT (use dm32-applet.py)");
        emit(a,"APP PCM OPEN RAW|VOICE FM|NFM|P25|DMR RX|TX Hz (use dm32-pcm.py)");
        emit(a,"APP SAME START [Hz] | STATUS | LAST | WATCH ON/OFF");
        emit(a,"APP STATUS | APP STOP (restore normal radio operation)");return true;
    }
    if(eq(t[1],"STOP") && n==2u && a->owned) {
        radio_applets_stop(a);emit(a,"APP STOPPED; normal radio operation restored");return true;
    }
    if(eq(t[1],"STATUS") && n==2u) {
        char text[96];snprintf(text,sizeof text,"APP STATUS slot=%u running=%u operation=%u state=%u instructions=%lu",
            a->slot,a->running,(unsigned)a->operation,(unsigned)a->vm.state,(unsigned long)a->vm.instructions);emit(a,text);return true;
    }
    if(eq(t[1],"STORE")) {
        if(n==3u && eq(t[2],"STATUS"))(void)radio_applets_catalogue(a);
        else emit(a,"APP ERROR syntax: APP STORE STATUS");
        return true;
    }
    if(eq(t[1],"RUN") || eq(t[1],"REMOVE")) {
        uint32_t slot;
        if(n!=3u || !number(t[2],&slot) || !slot || slot>8u) {emit(a,"APP ERROR slot must be 1..8");return true;}
        if(eq(t[1],"RUN")) {(void)radio_applets_run(a,slot);return true;}
        if(a->store.state!=RADIO_APPLET_STORE_READY) {emit(a,"APP ERROR list storage first; foreign data is read-only");return true;}
        if(!acquire(a)) {emit(a,"APP ERROR stop current app or radio busy");return true;}
        a->slot=slot;const radio_applet_slot_info *s=&a->store.slots[slot-1u];
        if(!radio_applet_store_remove(&a->store,slot-1u,s->committed ? s->revision : 0u))fail(a,"APP ERROR remove failed");
        else a->operation=APPLET_OP_REMOVE;
        return true;
    }
    if(!eq(t[1],"INSTALL"))return false;
    if(n==3u && eq(t[2],"ABORT")) {radio_applets_stop(a);emit(a,"APP OK INSTALL ABORT");return true;}
    if(n==6u && eq(t[2],"BEGIN")) {
        uint32_t slot,size,crc;
        if(!number(t[3],&slot) || slot<1u || slot>8u || !number(t[4],&size) || size<RADIO_APPLET_HEADER_BYTES
           || size>RADIO_APPLET_MAX_BYTES || !number(t[5],&crc)) {emit(a,"APP ERROR invalid install slot, size or CRC");return true;}
        if(!store_available(a) && a->store.state!=RADIO_APPLET_STORE_SCANNING) {emit(a,"APP ERROR applet storage unavailable");return true;}
        if(!acquire(a)) {emit(a,"APP ERROR stop current app or radio busy");return true;}
        a->slot=slot;a->pending_size=size;a->pending_crc=crc;a->operation=APPLET_OP_INSTALL;
        if(store_available(a))(void)begin_install(a);
        return true;
    }
    if(a->operation!=APPLET_OP_INSTALL || a->store.state!=RADIO_APPLET_STORE_WRITING || a->begin_pending) {
        emit(a,"APP ERROR no writable install session");return true;
    }
    a->activity_ms=now_ms(a);
    if(n==5u && eq(t[2],"DATA")) {
        uint32_t offset;uint8_t bytes[RADIO_APPLET_STORE_WRITE_MAX];unsigned count=t[4].n/2u;
        if(!number(t[3],&offset) || !count || count>sizeof bytes || (t[4].n&1u)) {emit(a,"APP ERROR invalid data chunk");return true;}
        for(unsigned i=0;i<count;++i) {
            unsigned high=hex_digit(t[4].p[2u*i]),low=hex_digit(t[4].p[2u*i+1u]);
            if(high>15u || low>15u) {emit(a,"APP ERROR invalid hex");return true;}
            bytes[i]=(uint8_t)(high*16u+low);
        }
        if(!radio_applet_store_write(&a->store,offset,bytes,count)) {emit(a,"APP ERROR offset or data conflict");return true;}
        char text[48];snprintf(text,sizeof text,"APP OK INSTALL DATA %lu",(unsigned long)a->store.written);emit(a,text);return true;
    }
    if(n==3u && eq(t[2],"COMMIT")) {
        if(!radio_applet_store_commit(&a->store,validate_stage,a))fail(a,"APP ERROR incomplete install");
        else a->operation=APPLET_OP_COMMIT;
        return true;
    }
    emit(a,"APP ERROR syntax: APP INSTALL BEGIN/DATA/COMMIT/ABORT");return true;
}
