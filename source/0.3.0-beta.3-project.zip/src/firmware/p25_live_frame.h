// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_LIVE_FRAME_H
#define P25_LIVE_FRAME_H
#include <stdint.h>
#include <stdbool.h>
typedef struct {
    uint8_t hdu[99],ldu1[216],ldu2[216],tdu[18];
} p25_channel_frames;
// Precompute fixed clear-group control fields before starting audio/RF.
// Width validation only; callers apply channel policy separately.
bool p25_channel_build(p25_channel_frames *out,uint32_t nac,uint32_t tg,uint32_t source);
// Individual calls carry a 24-bit unit destination in LCO 3. Their HDU group
// field is zero; it never truncates the destination into a talkgroup identity.
// The original group factory remains byte-for-byte compatible.
bool p25_channel_build_call(p25_channel_frames *out,uint32_t nac,uint32_t tg,
                           uint32_t source,bool private_call,uint32_t destination);
// Clear group service options (emergency/priority) for an exact grant. Other
// service bits are refused with unchanged output; no permission is conveyed.
bool p25_channel_build_group_options(p25_channel_frames *out,uint32_t nac,uint32_t tg,
                                    uint32_t source,uint8_t options);
void p25_live_ldu_template(uint8_t out[216],const uint8_t payload[9][11],const uint8_t base[216]);
// Compatibility/default fixture: NAC 0x293, TG/source 1.
// Nine 88-bit payloads -> 216 bytes including FEC, whitening and status bits.
void p25_live_ldu(uint8_t out[216],const uint8_t payload[9][11],bool ldu2);
#endif
