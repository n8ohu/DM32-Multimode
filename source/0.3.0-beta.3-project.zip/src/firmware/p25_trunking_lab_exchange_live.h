// SPDX-License-Identifier: GPL-3.0-or-later
// Volatile laboratory transport observer. No subscriber/access authorization.
#ifndef P25_TRUNKING_LAB_EXCHANGE_LIVE_H
#define P25_TRUNKING_LAB_EXCHANGE_LIVE_H
#include "p25_trunking_lab_exchange.h"

static p25_lab_exchange trunk_lab_exchange;
static volatile bool trunk_lab_return_pending;
static bool trunk_lab_return_cleaning;
// Software stage timestamps, retained with lab_seq. Never sample/air origins.
static volatile struct {
    uint32_t cleanup_us,cleaned_us,setup_us,tuned_us,irq_us,input_irq_us;
    uint32_t resume_us,resume_epoch;
} trunk_lab_stages;
_Static_assert(sizeof trunk_lab_stages==32u,"LAB stage budget changed");
static bool mon_start(void);
static bool mon_start_control(void);
static bool trunk_preload_task_ptt_released(bool down);
static bool trunk_preload_warm_health(void);
static bool trunk_lab_return_owned(void) {
    return trunk_lab_voice_owned() || mon_control_only || trunk_lab_return_pending || p25_lab_exchange_active(&trunk_lab_exchange);
}
static bool trunk_lab_return_defer_ui(void) {
    return trunk_lab_voice_owned() || mon_control_only || trunk_lab_return_cleaning || trunk_lab_return_pending;
}
static void trunk_lab_return_cleanup_trace(bool begin) {
    if((trunk_lab_return_pending || trunk_lab_return_cleaning)
       && trunk_lab_exchange.owner.sequence==trunk_probe.sequence
       && live.timing.state==P25_TX_DONE) {
        if(begin)trunk_lab_stages.cleanup_us=hrc_micros();
        else trunk_lab_stages.cleaned_us=hrc_micros();
    }
}
static void trunk_lab_return_first_input(uint32_t irq_us) {
    if(mon_control_only && monitor.raw_blocks==1u && trunk_lab_exchange.phase==P25_LAB_RX_STARTING
       && trunk_stream_epoch && trunk_stream_epoch!=trunk_lab_exchange.previous_epoch)
        trunk_lab_stages.input_irq_us=irq_us;
}
static uint32_t trunk_lab_return_tag(void) {
    uint32_t value=2166136261u;
    for(unsigned i=0;i<32u;++i)value=(value^channel_record[i])*16777619u;
    for(unsigned i=0;i<32u;++i)value=(value^global_record[i])*16777619u;
    return value ? value : 1u;
}
static p25_lab_exchange_owner trunk_lab_return_owner(void) {
    p25_lab_exchange_owner o={0};
    if(control.talkgroup<1u || control.talkgroup>0xffffu || !trunk_preload_request_matches())return o;
    o.sequence=trunk_probe.sequence;o.owner_tag=trunk_lab_return_tag();
    o.radio_id=control.source_id;o.wacn=TRUNK_PROBE_WACN;o.system=TRUNK_PROBE_SYSTEM;
    o.nac=control.nac;o.group=(uint16_t)control.talkgroup;o.profile=trunk_lab_profile;
    o.control_rx_hz=frequency;o.control_tx_hz=control.tx_frequency;
    o.request=trunk_preload_request_kind(trunk_preload.request);
    if(o.request==P25_LAB_GROUP) {
        o.expected_channel=TRUNK_PRELOAD_GROUP_CHANNEL;o.expected_options=TRUNK_PRELOAD_GROUP_OPTIONS;
    }
    return o;
}
static bool trunk_lab_return_identity(void) {
    p25_lab_exchange_owner owner=trunk_lab_return_owner();
    return p25_lab_exchange_owner_matches(&trunk_lab_exchange,&owner)
        && control.talkgroup==trunk_preload_owner.talkgroup
        && !memcmp(channel_record,trunk_preload_owner.channel,32)
        && !memcmp(global_record,trunk_preload_owner.globals,32)
        && normal_mode && features_ready && feature_p25() && !trunk_enabled
        && trunk_probe_profile_matches() && control.split && !radio_channel_get_private(channel_record)
        && !channel_scan.running && !apps_active() && !pcm_owner && !applet_owns_radio
        && !cps_active && !cps_link && !editing && !menu_open && !rx_lab && !rx_job
        && !broadcast_show && !airband_show && !digital_dmr.owned && !analog_fm.owned
        && dev && hooks && board.audio && board.radio && feature_tx_settings_valid()
        && feature_tx_power()==0u && tx_writer==TX_WRITER_ALT1 && tx_dac_restore
        && !tx_fixed && !control.cancel && !owner_tx_inhibit && control.tx_enabled
        && !(channel_record[12]&16u) && board.power->switch_on() && control.state!=RADIO_FAULT;
}
static void trunk_lab_return_cancel(void) {
    trunk_lab_attach_cancel();
    trunk_lab_ptt_cancel(); // Revoke held-key permission before stopping RF.
    bool owned=trunk_lab_return_owned();
    trunk_lab_voice_cancel();
    if(!owned) {trunk_lab_ptt_cancel_off();trunk_lab_attach_cancel_off();return;}
    trunk_lab_return_pending=false;
    p25_lab_exchange_cancel(&trunk_lab_exchange,P25_LAB_OWNER);
    // Revoke the pending action first. A control-only monitor keeps ownership
    // until mon_stop below; shared probe cleanup clears its active flag first.
    if(trunk_probe.active)trunk_probe_cancel();
    if(mon_running)mon_stop("lab_return_cancelled");
    board_rf_safe();ptt_release_required=true;ptt_release_seen=false;
    trunk_lab_ptt_cancel_off();
    trunk_lab_attach_cancel_off();
}
static bool trunk_lab_return_preserve(void) {
    return trunk_lab_attach_preserve() || trunk_lab_voice_preserve() || trunk_lab_return_cleaning || (trunk_lab_return_pending
        && trunk_lab_exchange.owner.sequence==trunk_probe.sequence
        && trunk_probe.result==TRUNK_PROBE_COMPLETE && live.timing.state==P25_TX_DONE);
}
static void trunk_lab_return_cleanup(void) {
    if(!trunk_lab_return_preserve())trunk_lab_return_cancel();
}
static bool trunk_lab_return_prepare(void) {
    p25_lab_exchange_owner owner=trunk_lab_return_owner();
    bool okay=p25_lab_exchange_prepare(&trunk_lab_exchange,&owner,trunk_stream_epoch,trunk_preload.prepare_us);
    if(okay)okay=trunk_lab_voice_prepare(trunk_preload.voice_enabled);
    if(okay)memset((void *)&trunk_lab_stages,0,sizeof trunk_lab_stages);
    return okay;
}
static bool trunk_lab_return_tx_started(void) {
    return !trunk_preload.return_enabled || p25_lab_exchange_tx_started(&trunk_lab_exchange,
        trunk_probe.sequence,trunk_probe.arm_us);
}
static void trunk_lab_return_cutoff(bool success) {
    // IRQ does not tune, start RX, parse a response, or change subscriber state.
    if(success && trunk_preload.return_enabled && trunk_preload.separate_warm
       && trunk_lab_exchange.phase==P25_LAB_TX_ACTIVE
       && trunk_lab_exchange.owner.sequence==trunk_probe.sequence)trunk_lab_return_pending=true;
}
static bool trunk_lab_return_rf_off(void) {
    return !hardware_running && !call_active && !prepared && !message_packet_tx;
}
static bool trunk_lab_return_resume(void) {
    trunk_lab_voice_cancel(); // Release an unspent ON arm after deny/timeout.
    // Terminal observer metadata stays frozen. Ordinary voice reception gets
    // its full codec/PCM initialization only after the exchange has ended.
    mon_stop("lab_control_complete");ptt_release_required=true;ptt_release_seen=false;
    if(!mon_start()) {
        mon_enabled=false;mon_reason="lab_resume_failed";
        radio_complete(&control,true);radio_inhibit(&control,true);board_rf_safe();return true;
    }
    trunk_lab_stages.resume_epoch=trunk_stream_epoch;trunk_lab_stages.resume_us=hrc_micros();
    return true; // Do not process a block from a different epoch this pass.
}
static bool trunk_lab_return_poll(bool down) {
    if(trunk_lab_voice_owned())return trunk_lab_voice_poll(down);
    if(!trunk_lab_return_owned())return false;
    if((!trunk_preload_task_ptt_released(down) && !trunk_lab_ptt_request_held()) || !trunk_lab_return_identity()
       || !trunk_preload_warm_health()) {trunk_lab_return_cancel();return true;}
    if(mon_control_only && !p25_lab_exchange_active(&trunk_lab_exchange)) {
        if(trunk_lab_attach_exchange())return true;
        if(trunk_lab_exchange.phase==P25_LAB_REPLY && trunk_lab_ptt_grant()) {
            // Show the accepted grant before MIC setup can defer display work.
            // This task-only refresh never changes the grant lease; voice_begin
            // still rechecks its age and physical owner before starting RF.
            ui_lab_transition_poll();
            if(trunk_lab_voice_begin())return true;
        }
        if(trunk_lab_exchange.phase==P25_LAB_REPLY || trunk_lab_exchange.phase==P25_LAB_TIMEOUT)
            return trunk_lab_return_resume();
        trunk_lab_return_cancel();return true;
    }
    if(trunk_lab_return_pending) {
        trunk_lab_return_pending=false;
        if(!p25_lab_exchange_tx_done(&trunk_lab_exchange,trunk_probe.sequence,
            live.timing.state==P25_TX_DONE,trunk_preload.cut_irq_us)) {
            trunk_lab_return_cancel();return true;
        }
        trunk_lab_return_cleaning=true;trunk_probe_poll(false);trunk_lab_return_cleaning=false;
        if(trunk_probe.result!=TRUNK_PROBE_COMPLETE || !trunk_lab_return_rf_off()
           || !p25_lab_exchange_begin_return(&trunk_lab_exchange,trunk_probe.sequence,
               trunk_lab_return_rf_off(),hrc_micros())) {
            trunk_lab_return_cancel();return true;
        }
        // Existing monitor initialization discards all old samples/lanes and
        // invalidates the previous slot/session epoch. No old lease survives.
        board_rf_safe();mon_enabled=true;
        if(!mon_start_control()) {p25_lab_exchange_cancel(&trunk_lab_exchange,P25_LAB_TRANSPORT);
            mon_enabled=false;board_rf_safe();return true;}
    }
    // The fresh-PHY ISR may commit PREPARED -> TX_ACTIVE. Sample the task
    // clock and inspect that epoch together: an older sample paired with a
    // newer tx_started_us would wrap unsigned elapsed time into an expiry.
    // Only this bounded state/deadline check is locked, not RX or cleanup.
    uint32_t lock=hrc_irq_save();
    p25_lab_exchange_poll(&trunk_lab_exchange,hrc_micros());
    hrc_irq_restore(lock);
    if(!p25_lab_exchange_active(&trunk_lab_exchange)) {
        if(trunk_lab_attach_exchange())return true;
        if(trunk_probe.active)trunk_probe_cancel();
        if(mon_control_only && trunk_lab_exchange.phase==P25_LAB_TIMEOUT)return trunk_lab_return_resume();
        board_rf_safe();return true;
    }
    if(trunk_lab_exchange.phase==P25_LAB_RX_STARTING) {
        if(!mon_running || mon_failed || trunk_stream_epoch==trunk_lab_exchange.previous_epoch) {
            trunk_lab_return_cancel();return true;
        }
        // A configured recorder is insufficient: observe a fresh input block.
        if(monitor.raw_blocks && !p25_lab_exchange_rx_ready(&trunk_lab_exchange,trunk_probe.sequence,
            trunk_lab_return_rf_off(),trunk_stream_epoch,hrc_micros())) {
            trunk_lab_return_cancel();return true;
        }
    }
    if(trunk_lab_exchange.phase==P25_LAB_WAIT_REPLY
       && (!mon_running || mon_failed || trunk_stream_epoch!=trunk_lab_exchange.rx_epoch)) {
        trunk_lab_return_cancel();return true;
    }
    // The ordinary monitor must consume fresh input during RX_STARTING/WAIT.
    return !mon_running;
}
static void trunk_lab_return_receive(const p25_rx *frame) {
    if(!frame || !trunk_lab_return_owned() || !mon_running || mon_failed
       || !trunk_lab_return_identity() || frame->duid!=7u)return;
    if(trunk_lab_exchange.phase==P25_LAB_RX_STARTING && monitor.raw_blocks)
        (void)p25_lab_exchange_rx_ready(&trunk_lab_exchange,trunk_probe.sequence,
            trunk_lab_return_rf_off(),trunk_stream_epoch,hrc_micros());
    p25_tsdu unit;if(!p25_tsdu_decode(frame->frame,frame->frame_bytes,&unit))return;
    for(unsigned i=0;i<unit.count;++i)(void)p25_lab_exchange_consume(&trunk_lab_exchange,
        trunk_probe.sequence,trunk_lab_return_tag(),trunk_stream_epoch,unit.nac,
        receiver_frequency(),unit.block[i],hrc_micros());
}
#endif
