// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_tsdu.h"
#include "p25_rx.h"
#include "p25_data_fec.h"
#include <string.h>

static uint64_t tsdu_nid(uint16_t value) {
    static const uint64_t g[16]={
        0x8000cd930bdd3b2a,0x4000ab5a8e33a6be,0x2000983e4cc4e874,0x10004c1f2662743a,
        0x0800eb9c98ec0136,0x0400b85d47ab3bb0,0x02005c2ea3d59dd8,0x01002e1751eaceec,
        0x0080170ba8f56776,0x0040c616dfa78890,0x0020630b6fd3c448,0x00103185b7e9e224,
        0x000818c2dbf4f112,0x0004c1f2662743a2,0x0002ad6a38ce9afb,0x00019b2617ba7657};
    uint64_t result=0;
    for(unsigned i=0;i<16u;++i)if(value&(0x8000u>>i))result^=g[i];
    return result;
}
static void tsdu_put(uint8_t *frame,unsigned data,unsigned dibit) {
    unsigned i=data+data/35u;
    frame[i/4u]|=(uint8_t)(dibit<<(6u-2u*(i%4u)));
}
size_t p25_tsdu_encode(uint8_t *out,size_t capacity,uint16_t nac,
                      const uint8_t blocks[][P25_TSDU_BLOCK_BYTES],unsigned count,
                      uint8_t status) {
    if(!out || !blocks || nac>0xfffu || !count || count>P25_TSDU_MAX_BLOCKS || status>3u)return 0;
    unsigned symbols=p25_tsdu_frame_symbols(count);size_t bytes=symbols/4u;
    if(bytes>capacity)return 0;
    for(unsigned b=0;b<count;++b) {
        uint16_t crc=p25_data_crc16(blocks[b],10u);
        if(((blocks[b][0]&0x80u)!=0)!=(b==count-1u) ||
           blocks[b][10]!=(uint8_t)(crc>>8) || blocks[b][11]!=(uint8_t)crc)return 0;
    }
    uint8_t frame[P25_TSDU_MAX_FRAME_BYTES]={0};
    const uint64_t sync=UINT64_C(0x5575f5ff77ff),encoded=tsdu_nid((uint16_t)((nac<<4)|7u));
    for(unsigned i=0;i<24u;++i)tsdu_put(frame,i,(unsigned)((sync>>(46u-2u*i))&3u));
    for(unsigned i=0;i<32u;++i)tsdu_put(frame,24u+i,(unsigned)((encoded>>(62u-2u*i))&3u));
    for(unsigned b=0;b<count;++b) {
        uint8_t raw[98];unsigned previous=0;
        for(unsigned i=0;i<49u;++i) {
            unsigned value=i<48u?(blocks[b][i/4u]>>(6u-2u*(i%4u)))&3u:0;
            unsigned pair=p25_data_trellis[previous][value];
            raw[i*2u]=(uint8_t)(pair>>2);raw[i*2u+1u]=(uint8_t)(pair&3u);previous=value;
        }
        for(unsigned i=0;i<98u;++i)tsdu_put(frame,56u+b*98u+i,raw[p25_data_interleave_index(i)]);
    }
    for(unsigned i=35u;i<symbols;i+=36u)frame[i/4u]|=(uint8_t)(status<<(6u-2u*(i%4u)));
    memcpy(out,frame,bytes);return bytes;
}

bool p25_tsdu_decode_block(const uint8_t *frame,size_t bytes,unsigned index,
                          uint8_t out[P25_TSDU_BLOCK_BYTES]) {
    if(!frame || !out || index>=P25_TSDU_MAX_BLOCKS || bytes>P25_TSDU_MAX_FRAME_BYTES
       || bytes*4u<p25_tsdu_block_end_symbols(index))return false;
    uint8_t block[P25_TSDU_BLOCK_BYTES];
    if(!p25_data_decode_block(frame,bytes,index,block))return false;
    uint16_t crc=p25_data_crc16(block,10u);
    if(block[10]!=(uint8_t)(crc>>8) || block[11]!=(uint8_t)crc)return false;
    memcpy(out,block,sizeof block);return true;
}
bool p25_tsdu_decode(const uint8_t *frame,size_t bytes,p25_tsdu *out) {
    static const uint8_t sync[6]={0x55,0x75,0xf5,0xff,0x77,0xff};
    if(!frame || !out || bytes<45u || bytes>P25_TSDU_MAX_FRAME_BYTES
       || memcmp(frame,sync,sizeof sync))return false;
    uint64_t nid=0;
    for(unsigned i=24u;i<57u;++i)if(i!=35u)
        nid=(nid<<2)|p25_data_get_dibit(frame,i);
    p25_tsdu value={0};uint8_t duid;unsigned corrected;
    if(!p25_rx_nid_decode(nid,&value.nac,&duid,&corrected) || duid!=7u)return false;
    for(unsigned i=0;i<P25_TSDU_MAX_BLOCKS;++i) {
        if(!p25_tsdu_decode_block(frame,bytes,i,value.block[i]))return false;
        if(value.block[i][0]&0x80u) {
            value.count=(uint8_t)(i+1u);
            if(bytes*4u!=p25_tsdu_frame_symbols(value.count))return false;
            *out=value;return true;
        }
    }
    return false;
}
