// SPDX-License-Identifier: GPL-3.0-or-later
// Finite experimental recorder stream. Continuity is not RF timing authority.
#ifndef P25_RX_STREAM_H
#define P25_RX_STREAM_H
#include "p25_rx_progress.h"
#define P25_RX_STREAM_CHUNK 16u
#define P25_RX_STREAM_HALF 256u
#define P25_RX_STREAM_RING_ROWS 128u
#define P25_RX_STREAM_RING_BYTES 8192u
#define P25_RX_STREAM_MAX_HALVES 64u
#define P25_RX_STREAM_HALF_BYTES 48u
#define P25_RX_STREAM_MARK_BYTES 32u
#define P25_RX_STREAM_MAX_MARKS 384u
#define P25_RX_STREAM_ORIGIN_MARK_BYTES 64u
#define P25_RX_STREAM_ORIGIN_MAX_MARKS 192u
#define P25_RX_STREAM_ORIGIN_MAX_SAMPLES 8192u
#define P25_RX_STREAM_EARLY_MARK_BYTES 64u
#define P25_RX_STREAM_EARLY_MAX_MARKS 192u
#define P25_RX_STREAM_EARLY_MAX_SAMPLES 4096u
#define P25_RX_STREAM_LEDGER_BYTES 15360u
#define P25_RX_STREAM_TIMEOUT_US 4000000u
_Static_assert(P25_RX_STREAM_MAX_HALVES*P25_RX_STREAM_HALF_BYTES
    +P25_RX_STREAM_MAX_MARKS*P25_RX_STREAM_MARK_BYTES==P25_RX_STREAM_LEDGER_BYTES,
    "Ordinary RX stream ledger layout changed");
_Static_assert(P25_RX_STREAM_MAX_HALVES*P25_RX_STREAM_HALF_BYTES
    +P25_RX_STREAM_ORIGIN_MAX_MARKS*P25_RX_STREAM_ORIGIN_MARK_BYTES==P25_RX_STREAM_LEDGER_BYTES,
    "Origin events must reuse the existing RX stream ledger");
_Static_assert(P25_RX_STREAM_MAX_HALVES*P25_RX_STREAM_HALF_BYTES
    +P25_RX_STREAM_EARLY_MAX_MARKS*P25_RX_STREAM_EARLY_MARK_BYTES==P25_RX_STREAM_LEDGER_BYTES,
    "Early events must reuse the existing RX stream ledger");
enum { P25_RX_STREAM_IDLE,P25_RX_STREAM_WAIT,P25_RX_STREAM_RUNNING,
    P25_RX_STREAM_DRAINING,P25_RX_STREAM_COMPLETE,P25_RX_STREAM_FAULT,
    P25_RX_STREAM_CANCELLED,P25_RX_STREAM_TIMEOUT };
enum {
    P25_RX_STREAM_META=1u,P25_RX_STREAM_IRQ_READ=2u,P25_RX_STREAM_TORN=4u,
    P25_RX_STREAM_CHANGED=8u,P25_RX_STREAM_SEQUENCE=16u,
    P25_RX_STREAM_COMPARE_META=32u,P25_RX_STREAM_COMPARE_IRQ=64u,
    P25_RX_STREAM_OVERWRITTEN=128u,P25_RX_STREAM_COMPARE_TORN=256u,
    P25_RX_STREAM_MISMATCH=512u,P25_RX_STREAM_CLOCK=1024u,
    P25_RX_STREAM_UNPAIRED=2048u,P25_RX_STREAM_RING_FULL=4096u,
    P25_RX_STREAM_VERIFIED=8192u
};
typedef struct {
    int16_t samples[16];
    uint64_t first_sample;
    uint32_t read_begin_us,read_end_us,origin_irq_us,origin_irq_count;
    uint16_t sample_offset,flags;
    uint8_t target_half,reserved[3];
} p25_rx_stream_chunk;
typedef struct {
    uint64_t first_sample;
    uint32_t origin_irq_us,completion_irq_us,published_hash,completed_hash,origin_irq_count;
    uint16_t early_samples,tail_samples,verified_chunks,mismatch_chunks,flags,max_read_us;
    uint32_t max_queue_us,last_delivery_us;
} p25_rx_stream_half;
typedef struct {
    unsigned char *ring,*ledger;
    uint32_t armed_us,last_step_us,stream_epoch;
    volatile uint32_t irq_serial,irq_count,last_irq_us;
    volatile uint16_t completed_halves,halves;
    volatile uint8_t last_half,state;
    uint16_t limit_halves,guard_us;
    volatile uint32_t produced,consumed,verified;
    uint16_t faults,markers;
    bool finalized,have_step;
    uint8_t marker_bytes,marker_schema;
} p25_rx_stream;
void p25_rx_stream_init(p25_rx_stream *s);
bool p25_rx_stream_active(const p25_rx_stream *s);
bool p25_rx_stream_start(p25_rx_stream *s,void *ring,size_t ring_bytes,
    void *ledger,size_t ledger_bytes,unsigned samples,unsigned guard_us,uint32_t epoch,uint32_t now);
// Separate finite witness schema1. The same ledger holds up to192 64-byte
// events; ordinary start()/marker() retain their384-row,32-byte ABI.
bool p25_rx_stream_origin_start(p25_rx_stream *s,void *ring,size_t ring_bytes,
    void *ledger,size_t ledger_bytes,unsigned samples,unsigned guard_us,uint32_t epoch,uint32_t now);
// Explicit schema2 pre-NID witness, at most4096 samples. It neither changes
// schema1 nor allocates another arena; its192 canonical events are64 bytes.
bool p25_rx_stream_early_start(p25_rx_stream *s,void *ring,size_t ring_bytes,
    void *ledger,size_t ledger_bytes,unsigned samples,unsigned guard_us,uint32_t epoch,uint32_t now);
// IRQ publishes bounded metadata only. First completion is discarded; ordinal
// zero belongs to the opposite half which begins filling at that boundary.
void p25_rx_stream_irq(p25_rx_stream *s,unsigned completed_half,uint32_t now);
// One double-read candidate OR one completed-half word comparison. Never
// finalizes all ledger rows, demodulates, allocates, or invokes radio callbacks.
bool p25_rx_stream_step(p25_rx_stream *s,const p25_rx_progress_io *io,uint32_t now);
// Caller serializes pop with the producer. Rows remain retained after pop until
// comparison too; ring reuse requires BOTH consumption and verification.
bool p25_rx_stream_pop(p25_rx_stream *s,p25_rx_stream_chunk *out,uint32_t now);
void p25_rx_stream_cancel(p25_rx_stream *s);
void p25_rx_stream_finalize(p25_rx_stream *s); // task only, at most64 rows
bool p25_rx_stream_half_read(const p25_rx_stream *s,unsigned index,p25_rx_stream_half *out);
// Marker bytes are already canonical <QIIIH6BI. Task only, fails closed on full.
bool p25_rx_stream_marker(p25_rx_stream *s,const unsigned char marker[32]);
// Bytes must already be canonical p25_rx_origin schema1. Task-only storage;
// this API cannot append to or reinterpret an ordinary32-byte capture.
bool p25_rx_stream_origin_marker(p25_rx_stream *s,const unsigned char marker[64]);
// Bytes must already be canonical p25_rx_early schema2. Task-only storage;
// appending to ordinary32 or RXORIGIN schema1 is refused without mutation.
bool p25_rx_stream_early_marker(p25_rx_stream *s,const unsigned char marker[64]);
#endif
