// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_search.h"
#include "p25_data_fec.h"
#include <limits.h>
#include <string.h>

_Static_assert(sizeof(p25_trunking_search)<=128u,"Control search state exceeds budget");
enum {SEEN_SITE=1u,SEEN_NETWORK=2u};
static void fail(p25_trunking_search *s,p25_trunking_search_reason reason) {
    s->phase=P25_TRUNK_SEARCH_FAILED;s->reason=reason;s->allow_tune=false;s->seen=0;
}
static bool clock_step(p25_trunking_search *s,uint32_t now) {
    // All policy horizons are below 2^31. Ordinary uint32 wrap is valid;
    // backward time or an unobservable >=half-range gap is not extrapolated.
    if(now-s->last_poll_ms>(uint32_t)INT32_MAX) {fail(s,P25_TRUNK_SEARCH_CLOCK);return false;}
    s->last_poll_ms=now;return true;
}
static void acquire(p25_trunking_search *s,uint32_t now) {
    s->phase=P25_TRUNK_SEARCH_ACQUIRE;s->started_ms=now;s->seen=0;
    s->site_ms=s->network_ms=s->last_control_ms=0;s->manual_pause=false;
    s->probe_next_tick=0;s->probe_last_ms=0;s->probe_samples=0;
    s->probe_input=s->probe_evidence=false;
}
static void next(p25_trunking_search *s,uint32_t now) {
    s->index=(uint8_t)((s->index+1u)%s->config.count);
    s->phase=P25_TRUNK_SEARCH_TUNE_READY;s->started_ms=now;s->seen=0;
}
static bool identity_fresh(const p25_trunking_search *s,uint32_t now) {
    return now-s->site_ms<P25_TRUNK_SEARCH_IDENTITY_MS
        &&now-s->network_ms<P25_TRUNK_SEARCH_IDENTITY_MS;
}
bool p25_trunking_search_start(p25_trunking_search *s,
    const p25_trunking_search_config *config,uint32_t now) {
    if(!s||!config||s->phase!=P25_TRUNK_SEARCH_OFF||!config->count
       ||config->count>P25_TRUNK_SEARCH_CONTROLS||!config->min_hz
       ||config->min_hz>config->max_hz||config->wacn>0xfffffu
       ||config->system>0xfffu||config->nac>0xfffu)return false;
    for(unsigned i=0;i<P25_TRUNK_SEARCH_CONTROLS;++i) {
        uint32_t hz=config->control_hz[i];
        if(i>=config->count) {if(hz)return false;continue;}
        if(hz<config->min_hz||hz>config->max_hz)return false;
        for(unsigned j=0;j<i;++j)if(hz==config->control_hz[j])return false;
    }
    uint32_t serial=s->serial;
    memset(s,0,sizeof *s);s->config=*config;s->serial=serial;
    s->phase=P25_TRUNK_SEARCH_TUNE_READY;s->last_poll_ms=s->started_ms=s->gate_ms=now;
    s->allow_tune=true;return true;
}
void p25_trunking_search_poll(p25_trunking_search *s,uint32_t now,bool busy) {
    if(!s||s->phase==P25_TRUNK_SEARCH_OFF||s->phase==P25_TRUNK_SEARCH_FAILED||!clock_step(s,now))return;
    s->gate_ms=now;s->allow_tune=!busy;
    if(s->phase==P25_TRUNK_SEARCH_TUNING) {
        if(now-s->started_ms>=P25_TRUNK_SEARCH_TUNE_MS)fail(s,P25_TRUNK_SEARCH_TUNE_TIMEOUT);
        return;
    }
    if(busy) {
        if(s->phase!=P25_TRUNK_SEARCH_PAUSED) {
            s->resume_phase=(uint8_t)s->phase;s->phase=P25_TRUNK_SEARCH_PAUSED;s->manual_pause=false;
        }
        s->allow_tune=false;return;
    }
    if(s->phase==P25_TRUNK_SEARCH_PAUSED) {
        if(s->manual_pause) {s->allow_tune=false;return;}
        if(s->resume_phase==P25_TRUNK_SEARCH_TUNE_READY)s->phase=P25_TRUNK_SEARCH_TUNE_READY;
        else acquire(s,now);
    }
    bool empty_probe=s->config.count>1u&&!s->probe_evidence&&s->probe_input
        &&s->probe_samples>=P25_TRUNK_SEARCH_PROBE_SAMPLES
        &&now-s->probe_last_ms<=P25_TRUNK_SEARCH_INPUT_FRESH_MS
        &&now-s->started_ms>=P25_TRUNK_SEARCH_PROBE_MS;
    uint32_t dwell=s->probe_evidence?P25_TRUNK_SEARCH_ACQUIRE_MS:P25_TRUNK_SEARCH_DWELL_MS;
    if((s->phase==P25_TRUNK_SEARCH_ACQUIRE
            &&(now-s->started_ms>=dwell||empty_probe))
       ||(s->phase==P25_TRUNK_SEARCH_LOCKED
            &&(now-s->last_control_ms>=P25_TRUNK_SEARCH_LOSS_MS||!identity_fresh(s,now))))
        next(s,now);
}
bool p25_trunking_search_take_tune(p25_trunking_search *s,
    p25_trunking_search_action *out,uint32_t now) {
    if(!s||!out||s->phase!=P25_TRUNK_SEARCH_TUNE_READY||!s->allow_tune||now!=s->gate_ms)return false;
    if(!clock_step(s,now))return false;
    if(s->serial==UINT32_MAX) {fail(s,P25_TRUNK_SEARCH_SERIAL);return false;}
    p25_trunking_search_action value={.id=++s->serial,
        .hz=s->config.control_hz[s->index],.index=s->index};
    s->phase=P25_TRUNK_SEARCH_TUNING;s->started_ms=now;s->allow_tune=false;*out=value;return true;
}
bool p25_trunking_search_tune_result(p25_trunking_search *s,uint32_t id,
    bool success,uint32_t epoch,uint32_t now) {
    if(!s||s->phase!=P25_TRUNK_SEARCH_TUNING||!id||id!=s->serial||!clock_step(s,now))return false;
    if(now-s->started_ms>=P25_TRUNK_SEARCH_TUNE_MS) {fail(s,P25_TRUNK_SEARCH_TUNE_TIMEOUT);return false;}
    if(success&&(!epoch||epoch==s->epoch))return false;
    if(success) {s->epoch=epoch;acquire(s,now);}
    else next(s,now);
    s->allow_tune=false;return true;
}
bool p25_trunking_search_input(p25_trunking_search *s,uint32_t epoch,
    uint64_t first_tick,unsigned samples,uint32_t age,bool evidence,uint32_t now) {
    if(!s||s->phase!=P25_TRUNK_SEARCH_ACQUIRE||!epoch||epoch!=s->epoch
       ||!clock_step(s,now))return false;
    if(!samples||samples>800u||age>P25_TRUNK_SEARCH_INPUT_FRESH_MS
       ||first_tick>UINT64_MAX-(uint64_t)samples*6u) {
        s->probe_input=false;s->probe_samples=0;return false;
    }
    if(!s->probe_input||first_tick!=s->probe_next_tick
       ||now-s->probe_last_ms>P25_TRUNK_SEARCH_INPUT_FRESH_MS)s->probe_samples=0;
    unsigned count=s->probe_samples+samples;
    s->probe_samples=(uint16_t)(count>P25_TRUNK_SEARCH_PROBE_SAMPLES
        ?P25_TRUNK_SEARCH_PROBE_SAMPLES:count);
    s->probe_next_tick=first_tick+(uint64_t)samples*6u;
    s->probe_last_ms=now;s->probe_input=true;s->probe_evidence|=evidence;
    return true;
}
static bool identity(const p25_trunking_search *s,const p25_trunking *map) {
    return map->have_site&&map->have_network&&map->wacn==s->config.wacn
        &&map->system_id==s->config.system&&map->rfss==s->config.rfss&&map->site==s->config.site;
}
static bool mapping(const p25_trunking_search *s,const p25_trunking *map) {
    uint32_t site_hz,network_hz,hz=s->config.control_hz[s->index];
    return s->seen==(SEEN_SITE|SEEN_NETWORK)
        &&p25_trunking_frequency(map,s->site_channel,&site_hz)
        &&p25_trunking_frequency(map,s->network_channel,&network_hz)
        &&site_hz==hz&&network_hz==hz;
}
static void mismatch(p25_trunking_search *s,uint32_t now) {
    s->seen=0;
    if(s->phase==P25_TRUNK_SEARCH_LOCKED)acquire(s,now);
}
bool p25_trunking_search_observe(p25_trunking_search *s,const p25_trunking *map,
    p25_trunking_event event,uint8_t opcode,uint32_t epoch,uint32_t now) {
    if(!s||!map||(s->phase!=P25_TRUNK_SEARCH_ACQUIRE&&s->phase!=P25_TRUNK_SEARCH_LOCKED)
       ||!epoch||epoch!=s->epoch||!clock_step(s,now))return false;
    // A delayed callback cannot acquire after the finite collection window
    // merely because the task has not run its ordinary poll yet.
    if(s->phase==P25_TRUNK_SEARCH_ACQUIRE&&now-s->started_ms>=P25_TRUNK_SEARCH_ACQUIRE_MS) {
        next(s,now);return false;
    }
    uint32_t hz=s->config.control_hz[s->index];
    if(map->phase!=P25_TRUNKING_CONTROL||map->pending_hz||map->control_hz!=hz
       ||map->receiver_hz!=hz||!map->have_nac||map->learned_nac!=s->config.nac)return false;
    if(s->phase==P25_TRUNK_SEARCH_LOCKED&&(!identity(s,map)||!mapping(s,map))) {
        mismatch(s,now);return false;
    }
    if(event==P25_TRUNKING_SITE&&opcode==0x3au) {
        if(!map->have_site||map->system_id!=s->config.system
           ||map->rfss!=s->config.rfss||map->site!=s->config.site) {mismatch(s,now);return false;}
        s->seen|=SEEN_SITE;s->site_ms=now;s->site_channel=map->control_channel;
    } else if(event==P25_TRUNKING_SITE&&opcode==0x3bu) {
        if(!map->have_network||map->wacn!=s->config.wacn||map->system_id!=s->config.system) {
            mismatch(s,now);return false;
        }
        s->seen|=SEEN_NETWORK;s->network_ms=now;s->network_channel=map->control_channel;
    } else if(event==P25_TRUNKING_BANDPLAN&&(opcode==0x33u||opcode==0x34u||opcode==0x3du)) {
        // A real accepted identifier is evidence of P25 even before both
        // identity broadcasts arrive. It grants bounded dwell, never LOCK.
        s->probe_evidence=true;
        if(!identity(s,map))return true;
    } else return false;
    // These already passed the native CRC, carrier, NAC and applicable
    // identity checks above. Their extra acquisition effect is bounded dwell.
    s->probe_evidence=true;
    if(s->phase==P25_TRUNK_SEARCH_LOCKED) {
        if(!identity(s,map)||!mapping(s,map)) {mismatch(s,now);return false;}
        s->last_control_ms=now;return true;
    }
    if(s->seen==(SEEN_SITE|SEEN_NETWORK)&&identity(s,map)&&mapping(s,map)
       &&now-s->site_ms<P25_TRUNK_SEARCH_ACQUIRE_MS&&now-s->network_ms<P25_TRUNK_SEARCH_ACQUIRE_MS) {
        s->phase=P25_TRUNK_SEARCH_LOCKED;s->last_control_ms=now;
    }
    return true;
}
bool p25_trunking_search_activity(p25_trunking_search *s,const p25_trunking *map,
    uint16_t nac,const uint8_t block[12],uint32_t epoch,uint32_t now) {
    if(!s||!map||!block||s->phase!=P25_TRUNK_SEARCH_LOCKED||!epoch||epoch!=s->epoch
       ||nac!=s->config.nac||!clock_step(s,now))return false;
    uint32_t hz=s->config.control_hz[s->index];
    if(map->phase!=P25_TRUNKING_CONTROL||map->pending_hz||map->control_hz!=hz
       ||map->receiver_hz!=hz||!map->have_nac||map->learned_nac!=nac)return false;
    if(!identity(s,map)||!mapping(s,map)) {mismatch(s,now);return false;}
    if(!identity_fresh(s,now)||(block[0]&0x40u)||block[1])return false;
    uint16_t crc=p25_data_crc16(block,10u);
    if(block[10]!=(uint8_t)(crc>>8)||block[11]!=(uint8_t)crc)return false;
    s->last_control_ms=now;return true;
}
bool p25_trunking_search_suspend(p25_trunking_search *s,uint32_t now) {
    if(!s||(s->phase!=P25_TRUNK_SEARCH_ACQUIRE&&s->phase!=P25_TRUNK_SEARCH_LOCKED
       &&s->phase!=P25_TRUNK_SEARCH_PAUSED)||!s->epoch||!clock_step(s,now))return false;
    if(s->phase!=P25_TRUNK_SEARCH_PAUSED) {s->resume_phase=(uint8_t)s->phase;s->phase=P25_TRUNK_SEARCH_PAUSED;}
    s->manual_pause=true;s->allow_tune=false;s->seen=0;return true;
}
bool p25_trunking_search_resume(p25_trunking_search *s,uint32_t epoch,uint32_t now) {
    if(!s||s->phase!=P25_TRUNK_SEARCH_PAUSED||!s->manual_pause||!epoch||epoch==s->epoch
       ||!clock_step(s,now))return false;
    s->epoch=epoch;acquire(s,now);s->allow_tune=false;return true;
}
void p25_trunking_search_stop(p25_trunking_search *s) {
    if(!s)return;
    uint32_t serial=s->serial;memset(s,0,sizeof *s);s->serial=serial;
}
