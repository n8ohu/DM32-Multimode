// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit one-shot laboratory packets. REGISTER retains ordinary startup;
// BURST uses an explicitly configured finite timer window. Neither is qualified slotted
// access or an automatically operating subscriber. Timer epochs are software
// events: actual first/last RF bits and PA ramps require an SDR measurement.
#ifndef P25_TRUNKING_PROBE_H
#define P25_TRUNKING_PROBE_H
#include "p25_trunking_isp.h"
#include "p25_trunking_burst.h"
#include "p25_trunking_lab.h"
// Legacy aliases remain fixed for existing receive fixtures; active probes use
// the exact explicitly selected/frozen catalog record below.
#define TRUNK_PROBE_RX_HZ 440075000u
#define TRUNK_PROBE_TX_HZ 445075000u
#define TRUNK_PROBE_NAC P25_TRUNK_LAB_NAC
#define TRUNK_PROBE_WACN P25_TRUNK_LAB_WACN
#define TRUNK_PROBE_SYSTEM P25_TRUNK_LAB_SYSTEM
#define TRUNK_PROBE_LIMIT_US 2000000u
// Volatile selection only: reset always returns to the legacy tuple. Selecting
// a record never tunes the radio, saves a channel or enables subscriber access.
static volatile uint8_t trunk_lab_profile=P25_TRUNK_LAB_LEGACY5M;
typedef enum {TRUNK_PROBE_IDLE,TRUNK_PROBE_ACTIVE,TRUNK_PROBE_COMPLETE,
              TRUNK_PROBE_CANCELLED,TRUNK_PROBE_FAILED} trunk_probe_result;
enum {PROBE_ARM=1u,PROBE_BOUNDARY=2u,PROBE_RF_IRQ=4u,PROBE_PA=8u,PROBE_END=16u};
static volatile struct {
    uint32_t sequence,radio_id,arm_us,first_boundary_us,last_boundary_us;
    uint32_t rf_irq_us,pa_us,end_us,blocks;
    p25_tx_reason timing_reason;
    trunk_probe_result result;
    uint8_t seen,lab_profile;
    bool active;
} trunk_probe;
_Static_assert(sizeof trunk_probe<100u,"Trunk lab probe trace exceeds its budget");
static bool trunk_probe_profile_matches(void) {
    unsigned frozen=trunk_probe.active ? trunk_probe.lab_profile : trunk_lab_profile;
    return p25_trunking_lab_frozen_matches(trunk_lab_profile,frozen,
        frequency,control.tx_frequency,control.nac);
}
// Volatile laboratory calibration only. No default enables a short burst.
static p25_trunking_burst_config trunk_burst_config;
static p25_trunking_burst_plan trunk_burst_plan;
static volatile struct {
    uint32_t rf_epoch_us,pa_deadline_us,pa_irq_us,pa_late_us,cut_deadline_us,cut_irq_us,cut_late_us,safe_us;
    uint32_t boundary_us[8];
    uint8_t boundary_source[8],trace_count;
    bool configured,short_mode,guarded,rf_anchored;
} trunk_burst;
static bool start_probe_short_rf(void);
static bool trunk_probe_short_active(void) {return trunk_probe.active && trunk_burst.short_mode;}
static void trunk_probe_short_timer_stop(void) {
    trunk_burst.guarded=false;
    hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,false);
}
static bool trunk_probe_short_guard_arm(void) {
    if(!trunk_probe_short_active() || hardware_running || !trunk_burst.configured)return false;
    trunk_burst.guarded=true;trunk_burst.rf_anchored=false;
    trunk_burst.cut_deadline_us=hrc_micros()+260000u;
    hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,true);
    hrc_timer_oneshot(TIMER_BOARD,260000u);return true;
}
static bool trunk_probe_short_permitted(void) {
    // IRQ-side gates contain no LCD, serial, codec or battery ADC operations.
    // The task checks the complete profile/permission/battery policy as well.
    return trunk_probe_short_active() && hardware_running && trunk_burst.guarded
        && normal_mode && !trunk_enabled && !control.cancel && control.tx_enabled
        && !control.inhibit && !owner_tx_inhibit && control.state!=RADIO_FAULT
        && trunk_probe_profile_matches()
        && control.source_id==trunk_probe.radio_id && hrc_pin_read(PIN_PTT);
}
static void trunk_probe_short_abort_irq(const char *why,p25_tx_reason code) {
    board_rf_safe(); // Register-only RAM hook before any RF-chip bus/retune.
    trunk_burst.safe_us=hrc_micros();
    p25_test_tx_abort(&live.timing,code);reason=why;
    hardware_stop();call_active=false;pcmq.accepting=false;
}
// The ordinary REGISTER path shares the voice ISR. Its caller checks this
// before either generic RF-switch or PA operation; voice has no probe owner.
static bool trunk_probe_irq_profile_valid(void) {
    if(!trunk_probe.active || trunk_probe_profile_matches())return true;
    trunk_probe_short_abort_irq("probe_profile_changed",P25_TX_CANCELLED);return false;
}
static void trunk_probe_short_cutoff(void) {
    hrc_timer_ack(TIMER_BOARD);
    if(!trunk_probe_short_active() || !hardware_running || !trunk_burst.guarded)return;
    uint32_t now=hrc_micros();trunk_burst.cut_irq_us=now;
    board_rf_safe();trunk_burst.safe_us=hrc_micros();
    trunk_burst.cut_late_us=(int32_t)(now-trunk_burst.cut_deadline_us)>=0 ? now-trunk_burst.cut_deadline_us : 0u;
    bool permitted=trunk_probe_short_permitted();
    bool done=permitted && trunk_burst.rf_anchored && (trunk_probe.seen&PROBE_PA)
        && (int32_t)(now-trunk_burst.cut_deadline_us)>=0
        && trunk_burst.cut_late_us<=500u
        && live.timing.blocks==trunk_burst_plan.transport_bytes/P25_TRUNK_BURST_BLOCK_BYTES;
    if(done) {live.timing.state=P25_TX_DONE;live.timing.reason=P25_TX_OK;reason="complete";}
    else {
        p25_test_tx_abort(&live.timing,!permitted ? P25_TX_CANCELLED :
            trunk_burst.rf_anchored && trunk_burst.cut_late_us>500u ? P25_TX_LATE : P25_TX_TIMEOUT);
        reason="probe_short_cutoff";
    }
    hardware_stop();call_active=false;pcmq.accepting=false;
}
static void trunk_probe_short_pa(void) {
    hrc_timer_ack(TIMER_PA);hrc_timer_stop(TIMER_PA);
    if(!trunk_probe_short_active() || !hardware_running || !trunk_burst.guarded)return;
    uint32_t now=hrc_micros();
    trunk_burst.pa_irq_us=now;
    trunk_burst.pa_late_us=(int32_t)(now-trunk_burst.pa_deadline_us)>=0 ? now-trunk_burst.pa_deadline_us : 0u;
    if(!trunk_burst.rf_anchored || !trunk_probe_short_permitted()
       || (int32_t)(now-trunk_burst.pa_deadline_us)<0
       || now-trunk_burst.pa_deadline_us>500u
       || (int32_t)(now-trunk_burst.cut_deadline_us)>=0) {
        trunk_probe_short_abort_irq("probe_short_pa_deadline",P25_TX_LATE);return;
    }
    if(trunk_probe.seen&PROBE_PA)return;
    hooks->pa_on();tx_dac.pa=DAC_PD_CTRL;tx_dac.seen|=TX_DAC_PA;
    trunk_probe.pa_us=hrc_micros();trunk_probe.seen|=PROBE_PA;
}
static void trunk_probe_short_rf_irq(void) {
    if(!trunk_probe_short_active() || !hardware_running || !trunk_burst.guarded)return;
    if(trunk_burst.rf_anchored)return; // A later RF IRQ cannot extend a lease.
    uint32_t now=hrc_micros();
    if(!trunk_probe_short_permitted() || (int32_t)(now-trunk_burst.cut_deadline_us)>=0) {
        trunk_probe_short_abort_irq("probe_short_rf_deadline",P25_TX_CANCELLED);return;
    }
    trunk_probe.rf_irq_us=now;trunk_probe.seen|=PROBE_RF_IRQ;
    trunk_burst.rf_epoch_us=now;trunk_burst.rf_anchored=true;
    trunk_burst.pa_deadline_us=now+trunk_burst_plan.pa_after_rf_us;
    trunk_burst.cut_deadline_us=now+trunk_burst_plan.cut_after_rf_us;
    // Arm the independent RF kill before any RF/PA enable operation.
    hrc_timer_oneshot(TIMER_BOARD,trunk_burst_plan.cut_after_rf_us);
    pa_started=true;hooks->rf_switch(true);
    uint32_t after=hrc_micros();
    if(!trunk_probe_short_permitted() || (int32_t)(after-trunk_burst.pa_deadline_us)>=0) {
        trunk_probe_short_abort_irq("probe_short_rf_setup_late",P25_TX_LATE);return;
    }
    hrc_timer_oneshot(TIMER_PA,trunk_burst.pa_deadline_us-after);
}
static void trunk_probe_hardware_end(void) {
    if(trunk_probe.active && hardware_running && !(trunk_probe.seen&PROBE_END)) {
        trunk_probe.end_us=hrc_micros();trunk_probe.seen|=PROBE_END;
    }
}
static void trunk_probe_boundary(uint32_t now,unsigned source) {
    if(!trunk_probe.active)return;
    if(!(trunk_probe.seen&PROBE_BOUNDARY))trunk_probe.first_boundary_us=now;
    trunk_probe.last_boundary_us=now;trunk_probe.seen|=PROBE_BOUNDARY;++trunk_probe.blocks;
    if(trunk_burst.trace_count<8u) {
        unsigned at=trunk_burst.trace_count++;
        trunk_burst.boundary_us[at]=now;trunk_burst.boundary_source[at]=(uint8_t)source;
    }
}
static void trunk_probe_short_boundary(uint32_t now,unsigned source) {
    if(!trunk_probe_short_active() || !hardware_running || !trunk_burst.guarded)return;
    p25_test_tx *t=&live.timing;
    if(!p25_test_tx_active(t))return;
    if(t->have_boundary) {
        uint32_t gap=now-t->last_boundary_us;
        if(gap<15000u) {++t->duplicate_irqs;return;}
        if(gap>33000u) {
            ++t->late_irqs;trunk_probe_short_abort_irq("probe_short_boundary_late",P25_TX_LATE);return;
        }
        if(gap>t->max_gap_us)t->max_gap_us=gap;
    }
    if(!trunk_probe_short_permitted() || (int32_t)(now-trunk_burst.cut_deadline_us)>=0) {
        trunk_probe_short_abort_irq("probe_short_boundary_gate",P25_TX_CANCELLED);return;
    }
    // Keep the unique PHY heartbeat current even after the last publication;
    // a calibration window may deliberately outlive the finite data buffer.
    t->last_boundary_us=now;t->have_boundary=true;
    if(t->blocks>=trunk_burst_plan.transport_bytes/P25_TRUNK_BURST_BLOCK_BYTES) {
        // No new slot after the final finite RAM publication. Timer 5 alone
        // ends RF; a whole-slot drain never decides the requested last bit.
        hrc7000_wr(dev,C7_LAYER2_TXRX_CTRL,0);return;
    }
    uint8_t block[P25_TRUNK_BURST_BLOCK_BYTES];
    if(!p25_trunking_burst_render(&trunk_burst_plan,message_packet,t->blocks,block)) {
        trunk_probe_short_abort_irq("probe_short_render",P25_TX_CANCELLED);return;
    }
    unsigned offset=tx_write_half ? P25_TRUNK_BURST_BLOCK_BYTES : 0u;
    for(unsigned i=0;i<P25_TRUNK_BURST_BLOCK_BYTES;++i)dev->buf[offset+i]=block[i];
    tx_write_half^=1u;
    t->last_boundary_us=now;t->have_boundary=true;t->state=P25_TX_STREAMING;
    t->offset+=P25_TRUNK_BURST_BLOCK_BYTES;++t->blocks;
    trunk_probe_boundary(now,source);
    hrc7000_wr(dev,C7_LAYER2_TXRX_CTRL,0x80);
}
static void trunk_probe_rf_irq(void) {
    if(trunk_probe.active && !(trunk_probe.seen&PROBE_RF_IRQ)) {
        trunk_probe.rf_irq_us=hrc_micros();trunk_probe.seen|=PROBE_RF_IRQ;
    }
}
static void trunk_probe_pa(void) {
    if(trunk_probe.active && !(trunk_probe.seen&PROBE_PA)) {
        trunk_probe.pa_us=hrc_micros();trunk_probe.seen|=PROBE_PA;
    }
}
// Called after the shared cleanup has killed RF and released board TX. It also
// handles generic STOP, hard fault and power-off paths without leaving a packet
// purpose or borrowed scratch pointer owned by a completed probe.
static void trunk_probe_cleanup(void) {
    if(!trunk_probe.active)return;
    trunk_probe.timing_reason=live.timing.reason;
    if(trunk_probe.result==TRUNK_PROBE_ACTIVE) {
        trunk_probe.result=live.timing.state==P25_TX_DONE ? TRUNK_PROBE_COMPLETE :
            !strcmp(reason,"cancelled") ? TRUNK_PROBE_CANCELLED : TRUNK_PROBE_FAILED;
    }
    trunk_probe.active=false;message_packet_tx=false;
    trunk_probe_short_timer_stop();
    live.packet=NULL;live.packet_length=live.packet_pos=0;
    ptt_release_required=true;ptt_release_seen=false;
}
static bool trunk_probe_context(void) {
    return normal_mode && features_ready && feature_p25() && !trunk_enabled
        && trunk_probe_profile_matches()
        && control.split && control.nac==TRUNK_PROBE_NAC && control.source_id
        && control.source_id<0xffffffu && !radio_channel_get_private(channel_record)
        && !channel_scan.running && !apps_active() && !pcm_owner && !applet_owns_radio
        && !cps_active && !cps_link && !editing && !menu_open && !rx_lab && !rx_job
        && !broadcast_show && !airband_show && !digital_dmr.owned && !analog_fm.owned
        && dev && hooks && board.audio && board.radio && feature_tx_settings_valid()
        && feature_tx_power()==0u && tx_writer==TX_WRITER_ALT1 && tx_dac_restore
        && !tx_fixed && !control.cancel && board.power->switch_on()
        && bf_cal_valid() && channel_in_band(frequency,false)
        && channel_in_band(control.tx_frequency,true)
        && (message_tx_permission()
#if DM32_TRUNK_SUBSCRIBER
            || trunk_lab_ptt_request_permission()
            || trunk_lab_attach_request_permission()
            || trunk_preload_cc_request_permission()
#endif
        );
}
static bool trunk_probe_mailbox_idle(void) {
    if(message_packet_tx || message_active_id || message_stage.active)return false;
    for(unsigned i=0;i<mailbox.count;++i)
        if(mailbox.items[i].state==RADIO_MAIL_QUEUED || mailbox.items[i].state==RADIO_MAIL_SENDING)return false;
    return true;
}
static void trunk_probe_finish(trunk_probe_result result,const char *why) {
    if(!trunk_probe.active)return;
    trunk_probe.result=result;
    uint32_t lock=hrc_irq_save();
    if(result!=TRUNK_PROBE_COMPLETE)p25_test_tx_abort(&live.timing,P25_TX_CANCELLED);
    hardware_stop();call_active=false;pcmq.accepting=false;message_packet_tx=false;
    reason=why;hrc_irq_restore(lock);
    cleanup();normal_permission();
    if(display_ok)screen("HOME");
}
static void trunk_probe_cancel(void) {
    trunk_probe_finish(TRUNK_PROBE_CANCELLED,"cancelled");
}
static bool trunk_probe_start_mode(bool down,bool short_mode) {
    // Every ownership/identity/permission refusal precedes prepare_p25_tx(),
    // which would otherwise stop the monitor before checking its own gates.
    if(trunk_probe.active || down || !hrc_pin_read(PIN_PTT) ||
       (board.input->scan()&ptt_mask) || call_active || prepared || hardware_running
       || radio_busy(&control) || rx_sampling || armed || session_enabled || !trunk_probe_mailbox_idle()
       || (short_mode && !trunk_burst.configured) || !trunk_probe_context() || (mon_running &&
           (mon_sync_active(hrc_micros()) || monitor.call.active || monitor.playing ||
            mon_routed || mon_pcm_pending || monitor.pcm_head!=monitor.pcm_tail)))return false;
    uint8_t block[1][12];
    if(!p25_trunking_isp_register(block[0],TRUNK_PROBE_WACN,TRUNK_PROBE_SYSTEM,control.source_id)
       || p25_tsdu_encode(message_packet,sizeof message_packet,TRUNK_PROBE_NAC,
           (const uint8_t (*)[12])block,1,P25_TRUNKING_ISP_STATUS)!=45u)return false;
    uint32_t sequence=trunk_probe.sequence+1u;
    memset((void *)&trunk_probe,0,sizeof trunk_probe);
    trunk_probe.sequence=sequence ? sequence : 1u;trunk_probe.radio_id=control.source_id;
    trunk_probe.lab_profile=trunk_lab_profile;
    trunk_probe.active=true;trunk_probe.result=TRUNK_PROBE_ACTIVE;
    trunk_burst.short_mode=short_mode;trunk_burst.guarded=false;trunk_burst.rf_anchored=false;
    trunk_burst.trace_count=0;trunk_burst.rf_epoch_us=trunk_burst.pa_deadline_us=0;
    trunk_burst.pa_irq_us=trunk_burst.pa_late_us=0;
    trunk_burst.cut_deadline_us=trunk_burst.cut_irq_us=trunk_burst.cut_late_us=trunk_burst.safe_us=0;
    if(!prepare_p25_tx(true)) {
        trunk_probe_finish(TRUNK_PROBE_FAILED,"probe_setup_failed");return false;
    }
    p25_live_tx_init(&live);
    if(short_mode)message_packet[P25_TRUNK_BURST_PREFIX_BYTES-1u]&=0xf0u;
    if(!p25_live_tx_set_packet(&live,message_packet,short_mode ? P25_TRUNK_BURST_PREFIX_BYTES : 45u) ||
       !p25_live_tx_set_rf_limit(&live,TRUNK_PROBE_LIMIT_US)) {
        trunk_probe_finish(TRUNK_PROBE_FAILED,"probe_setup_failed");return false;
    }
    memset(&pcmq,0,sizeof pcmq);message_packet_tx=true;
    control.cancel=false;control.state=RADIO_TX_PREPARE;
    call_active=true;capture_started=hrc_micros();call_soft_limit_us=TRUNK_PROBE_LIMIT_US;
    // This acknowledgment is emitted with the PA off, before the time-critical
    // feeder starts. All further command replies wait until probe cleanup.
    send(short_mode ? "OK TRUNK PROBE BURST finite lab calibration; RF timing unqualified\r\n" :
        "OK TRUNK PROBE REGISTER single lab packet; ordinary preamble; access timing unqualified\r\n");
    if(!trunk_probe_context() || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)) {
        trunk_probe_cancel();return false;
    }
    reason="probe_running";trunk_probe.arm_us=hrc_micros();trunk_probe.seen|=PROBE_ARM;
    if(short_mode)(void)start_probe_short_rf();else start_rf();
    if(!hardware_running) {trunk_probe_finish(TRUNK_PROBE_FAILED,"probe_setup_failed");return false;}
    return true;
}
static bool trunk_probe_start(bool down) {return trunk_probe_start_mode(down,false);}
#if DM32_TRUNK_SUBSCRIBER
static bool trunk_preload_warmed(void);
static void trunk_preload_warm_poll(bool down);
#endif
static void trunk_probe_poll(bool down) {
    if(!trunk_probe.active)return;
#if DM32_TRUNK_SUBSCRIBER
    if(trunk_preload_warmed()) {trunk_preload_warm_poll(down);return;}
#endif
    if(!call_active || !hardware_running) {
        bool okay=live.timing.state==P25_TX_DONE;
        trunk_probe_finish(okay ? TRUNK_PROBE_COMPLETE : TRUNK_PROBE_FAILED,okay ? "complete" : "probe_failed");return;
    }
    bool held=false;
#if DM32_TRUNK_SUBSCRIBER
    held=trunk_lab_ptt_request_held();
#endif
    if(((down || !hrc_pin_read(PIN_PTT)) && !held) || control.cancel || !trunk_probe_context()
       || control.source_id!=trunk_probe.radio_id) {
        trunk_probe_cancel();return;
    }
    p25_test_tx_poll_limit(&live.timing,hrc_micros(),true,TRUNK_PROBE_LIMIT_US);
    if(!p25_test_tx_active(&live.timing)) {
        bool okay=live.timing.state==P25_TX_DONE;
        trunk_probe_finish(okay ? TRUNK_PROBE_COMPLETE : TRUNK_PROBE_FAILED,okay ? "complete" : "probe_failed");
    }
}
static int trunk_probe_status_row(unsigned row,char *line,size_t capacity) {
    unsigned profile=trunk_probe.sequence ? trunk_probe.lab_profile : trunk_lab_profile;
    const p25_trunking_lab_profile *lab=p25_trunking_lab_get(profile);
    if(row==0u)return snprintf(line,capacity,"TRUNKPROBE active=%u sequence=%lu result=%u timing=%u radio_id=%lu rx_hz=%lu tx_hz=%lu nac=293 wacn=ABCDE system=123 wire_bytes=%u preamble_bytes=%u limit_us=%u access_timing=unqualified profile=%s selected_profile=%s\r\n",
        (unsigned)trunk_probe.active,(unsigned long)trunk_probe.sequence,(unsigned)trunk_probe.result,
        (unsigned)trunk_probe.timing_reason,(unsigned long)trunk_probe.radio_id,
        (unsigned long)(lab ? lab->control_rx_hz:0u),(unsigned long)(lab ? lab->control_tx_hz:0u),
        trunk_burst.short_mode ? 40u : 45u,
        trunk_burst.short_mode ? (unsigned)trunk_burst_plan.lead_bytes : 240u,TRUNK_PROBE_LIMIT_US,
        p25_trunking_lab_name(profile),p25_trunking_lab_name(trunk_lab_profile));
    if(row==1u)return snprintf(line,capacity,"TRUNKPROBE_MODE mode=%s configured=%u lead_bytes=%u valid_bits=316 prefix_bytes=40 transport_bytes=%u packet_after_rf_us=%lu pa_lead_us=%u end_trim_us=%d pa_after_rf_us=%lu cut_after_rf_us=%lu rf_timing=unqualified\r\n",
        trunk_burst.short_mode ? "BURST" : "REGISTER",(unsigned)trunk_burst.configured,
        (unsigned)trunk_burst_config.lead_bytes,(unsigned)trunk_burst_plan.transport_bytes,
        (unsigned long)trunk_burst_config.packet_after_rf_us,(unsigned)trunk_burst_config.pa_lead_us,
        (int)trunk_burst_config.end_trim_us,(unsigned long)trunk_burst_plan.pa_after_rf_us,
        (unsigned long)trunk_burst_plan.cut_after_rf_us);
    if(row==2u)return snprintf(line,capacity,"TRUNKPROBE_CUTOFF rf_epoch_us=%lu pa_deadline_us=%lu pa_irq_us=%lu pa_late_us=%lu cut_deadline_us=%lu cut_irq_us=%lu cut_late_us=%lu safe_us=%lu guarded=%u timestamps=software_not_air\r\n",
        (unsigned long)trunk_burst.rf_epoch_us,(unsigned long)trunk_burst.pa_deadline_us,
        (unsigned long)trunk_burst.pa_irq_us,(unsigned long)trunk_burst.pa_late_us,
        (unsigned long)trunk_burst.cut_deadline_us,(unsigned long)trunk_burst.cut_irq_us,(unsigned long)trunk_burst.cut_late_us,
        (unsigned long)trunk_burst.safe_us,(unsigned)trunk_burst.guarded);
    if(row>=3u && row<11u) {
        unsigned i=row-3u;if(i>=trunk_burst.trace_count)return 0;
        return snprintf(line,capacity,"TRUNKPROBE_BOUNDARY index=%u us=%lu delta_us=%lu source=%u source_names=PHY1_TX2_RX3\r\n",
            i,(unsigned long)trunk_burst.boundary_us[i],
            (unsigned long)(i ? trunk_burst.boundary_us[i]-trunk_burst.boundary_us[i-1u] : 0u),
            (unsigned)trunk_burst.boundary_source[i]);
    }
    if(row==11u)return snprintf(line,capacity,"TRUNKPROBE_IRQ seen=%u arm_us=%lu first_boundary_us=%lu last_boundary_us=%lu rf_irq_us=%lu pa_us=%lu end_us=%lu blocks=%lu timestamps=software_not_air\r\n",
        (unsigned)trunk_probe.seen,(unsigned long)trunk_probe.arm_us,
        (unsigned long)trunk_probe.first_boundary_us,(unsigned long)trunk_probe.last_boundary_us,
        (unsigned long)trunk_probe.rf_irq_us,(unsigned long)trunk_probe.pa_us,
        (unsigned long)trunk_probe.end_us,(unsigned long)trunk_probe.blocks);
    return -1;
}
static void trunk_probe_status(void) {telemetry_request(TELEMETRY_PROBE);}
static bool trunk_probe_config_parse(const char *s,p25_trunking_burst_config *out) {
    int32_t v[4];
    for(unsigned i=0;i<4u;++i) {
        bool negative=false;uint32_t n=0;
        if(i==3u && *s=='-') {negative=true;++s;}
        if(*s<'0' || *s>'9')return false;
        do {
            unsigned digit=(unsigned)(*s++-'0');
            if(n>(1000000u-digit)/10u)return false;
            n=n*10u+digit;
        } while(*s>='0' && *s<='9');
        v[i]=negative ? -(int32_t)n : (int32_t)n;
        if(i<3u) {if(*s++!=' ')return false;}
        else if(*s)return false;
    }
    if(v[0]<72 || v[0]>240 || v[1]<30000 || v[1]>220000
       || v[2]<0 || v[2]>2000 || v[3]<-2000 || v[3]>2000)return false;
    p25_trunking_burst_config c={(uint16_t)v[0],(uint32_t)v[1],(uint16_t)v[2],(int16_t)v[3]};
    p25_trunking_burst_plan plan;
    if(!p25_trunking_burst_plan_make(&plan,&c))return false;
    *out=c;return true;
}
static bool trunk_probe_command(const char *cmd,bool down) {
    if(strncmp(cmd,"TRUNK PROBE",11))return false;
    if(!strcmp(cmd,"TRUNK PROBE PROFILE")) {
        const p25_trunking_lab_profile *lab=p25_trunking_lab_get(trunk_lab_profile);
        char line[160];snprintf(line,sizeof line,"TRUNKLAB profile=%s rx_hz=%lu tx_hz=%lu volatile=1 access_timing=unqualified\r\n",
            p25_trunking_lab_name(trunk_lab_profile),(unsigned long)(lab ? lab->control_rx_hz:0u),
            (unsigned long)(lab ? lab->control_tx_hz:0u));send(line);return true;
    }
    if(!strncmp(cmd,"TRUNK PROBE PROFILE ",20)) {
        uint8_t profile;
        bool idle=normal_mode && features_ready && !trunk_enabled && !trunk_probe.active
            && !call_active && !prepared && !hardware_running && !radio_busy(&control)
            && !rx_sampling && !armed && !session_enabled && !down && ptt_mask && hrc_pin_read(PIN_PTT)
            && !(board.input->scan()&ptt_mask) && !channel_scan.running && !apps_active()
            && !pcm_owner && !applet_owns_radio && !cps_active && !cps_link && !editing && !menu_open
            && !rx_lab && !rx_job && !broadcast_show && !airband_show
            && !digital_dmr.owned && !analog_fm.owned && trunk_probe_mailbox_idle();
#if DM32_TRUNK_SUBSCRIBER
        idle=idle && !trunk_rx_progress_owned && !trunk_rx_stream_owned;
#endif
        if(!idle || !p25_trunking_lab_parse(cmd+20,&profile)) {
            send("ERR TRUNK PROBE PROFILE idle only: LEGACY5M | COMMONIQ1M; release PTT; no tune/save\r\n");return true;
        }
        trunk_lab_profile=profile;
        send("OK TRUNK PROBE PROFILE volatile; no tune/save; existing RF caps unchanged\r\n");return true;
    }
    if(!strcmp(cmd,"TRUNK PROBE STATUS")) {trunk_probe_status();return true;}
    if(!strcmp(cmd,"TRUNK PROBE STOP")) {trunk_probe_cancel();send("OK TRUNK PROBE STOP\r\n");return true;}
    if(!strncmp(cmd,"TRUNK PROBE CONFIG ",19)) {
        p25_trunking_burst_config config;p25_trunking_burst_plan plan;
        if(trunk_probe.active || call_active || prepared || hardware_running || down || !hrc_pin_read(PIN_PTT)
           || !trunk_probe_config_parse(cmd+19,&config) || !p25_trunking_burst_plan_make(&plan,&config)) {
            send("ERR TRUNK PROBE CONFIG idle only: lead72..240 packet_after_rf_us30000..220000 pa_lead_us0..2000 end_trim_us-2000..2000\r\n");return true;
        }
        trunk_burst_config=config;trunk_burst_plan=plan;trunk_burst.configured=true;
        send("OK TRUNK PROBE CONFIG volatile lab calibration; RF timing unqualified\r\n");return true;
    }
    if(!strcmp(cmd,"TRUNK PROBE REGISTER") || !strcmp(cmd,"TRUNK PROBE BURST")) {
        bool short_mode=!strcmp(cmd,"TRUNK PROBE BURST");
        if(!(short_mode ? trunk_probe_start_mode(down,true) : trunk_probe_start(down)))
            send("ERR TRUNK PROBE requires idle TX-enabled selected lab profile P25 NAC293; release PTT; BURST requires CONFIG\r\n");
        return true;
    }
    send("ERR TRUNK PROBE REGISTER | PROFILE [LEGACY5M|COMMONIQ1M] | CONFIG lead packet_after_rf_us pa_lead_us end_trim_us | BURST | STATUS | STOP\r\n");return true;
}
#endif
