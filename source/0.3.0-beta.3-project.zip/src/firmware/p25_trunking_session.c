// SPDX-License-Identifier: GPL-3.0-or-later
#include "p25_trunking_session.h"
#include "p25_tsdu.h"
#include <string.h>

static bool control_action(p25_trunking_access_action_type type) {
    return type==P25_TRUNK_ACTION_REGISTER || type==P25_TRUNK_ACTION_AFFILIATE
        || type==P25_TRUNK_ACTION_GROUP_REQUEST || type==P25_TRUNK_ACTION_DEREGISTER;
}
static bool cleanup_phase(const p25_trunking_session *s) {
    return s->access.phase==P25_TRUNK_ACCESS_DRAIN || s->access.phase==P25_TRUNK_ACCESS_RETURN;
}
static bool request_phase(const p25_trunking_session *s) {
    return s->access.phase==P25_TRUNK_ACCESS_REGISTER || s->access.phase==P25_TRUNK_ACCESS_AFFILIATE
        || s->access.phase==P25_TRUNK_ACCESS_REQUEST || s->access.phase==P25_TRUNK_ACCESS_DEREGISTER;
}
static void revoke(p25_trunking_session *s) {
    s->have_poll=s->opportunity=s->fit=false;s->access.action_eligible=false;
}
static bool voice_map_current(p25_trunking_session *s,uint32_t now) {
    if(!s->access.voice.valid) {s->have_voice_channel=false;return true;}
    uint32_t rx,tx;
    if(!s->have_voice_channel || !p25_trunking_channel_pair(&s->map,s->voice_channel,0,false,&rx,&tx)
       || rx!=s->access.voice.rx_hz || tx!=s->access.voice.tx_hz) {
        p25_trunking_access_fault(&s->access,P25_TRUNK_ACCESS_MAPPING,now);return false;
    }
    return true;
}
static p25_trunking_session_gate site_validate(const p25_trunking_session *s,uint32_t now,
    p25_trunking_access_site *out) {
    if(!s->have_network || !s->have_site || !s->map.have_network || !s->map.have_site
       || now-s->network_ms>=P25_TRUNK_ACCESS_SITE_MS || now-s->site_ms>=P25_TRUNK_ACCESS_SITE_MS) {
        return P25_TRUNK_SESSION_WAIT_SITE;
    }
    const p25_trunking_access_config *c=&s->config.subscriber;
    if(s->map.wacn!=c->wacn || s->map.system_id!=c->system || s->map.learned_nac!=c->nac
       || s->map.rfss!=c->rfss || s->map.site!=c->site) {
        return P25_TRUNK_SESSION_IDENTITY;
    }
    uint32_t rx,tx,network_rx,network_tx;
    if(!p25_trunking_channel_pair(&s->map,s->site_channel,0,false,&rx,&tx)
       || !p25_trunking_channel_pair(&s->map,s->network_channel,0,false,&network_rx,&network_tx)
       || rx!=s->config.control_rx_hz || network_rx!=rx || network_tx!=tx) {
        return P25_TRUNK_SESSION_MAPPING;
    }
    p25_trunking_access_site value={.wacn=c->wacn,.system=c->system,.nac=c->nac,.rfss=c->rfss,.site=c->site,
        .control_rx_hz=rx,.control_tx_hz=tx,.fdma=true,.control_pair_valid=true};
    *out=value;return P25_TRUNK_SESSION_READY;
}
static bool site_view(p25_trunking_session *s,uint32_t now,p25_trunking_access_site *out) {
    p25_trunking_session_gate gate=site_validate(s,now,out);
    s->site_qualified=gate==P25_TRUNK_SESSION_READY;
    if(!s->site_qualified)s->gate=gate;
    return s->site_qualified;
}
void p25_trunking_session_init(p25_trunking_session *s) {if(s)memset(s,0,sizeof *s);}
void p25_trunking_session_stop(p25_trunking_session *s) {
    if(!s)return;
    // Keep action generations monotonic across explicit restart, so a delayed
    // completion from an old stopped session cannot acknowledge a new action.
    uint32_t serial=s->access.serial;memset(s,0,sizeof *s);s->access.serial=serial;
}
bool p25_trunking_session_start(p25_trunking_session *s,
    const p25_trunking_session_config *config,uint32_t now) {
    if(!s || !config || s->running || s->access.outstanding || s->access.voice_running
       || config->contention_skip>P25_TRUNK_SLOT_MAX_BACKOFF || !config->contention_wait_ticks
       || config->contention_wait_ticks>P25_TRUNK_SLOT_MAX_WAIT_TICKS
       || config->burst_ticks<P25_TRUNK_SESSION_ISP_TICKS)return false;
    p25_trunking_session value={0};value.config=*config;value.access.serial=s->access.serial;
    if(!p25_trunking_init(&value.map,config->control_rx_hz,config->subscriber.min_hz,
            config->subscriber.max_hz,config->subscriber.nac)
       || !p25_trunking_access_start(&value.access,&config->subscriber,now)
       || !p25_trunking_slot_init(&value.slot,config->slot_tolerance_ticks,config->slot_max_age_ticks))return false;
    value.running=true;value.gate=P25_TRUNK_SESSION_WAIT_SITE;*s=value;return true;
}
bool p25_trunking_session_consume_control(p25_trunking_session *s,uint16_t nac,
    uint32_t carrier_hz,const uint8_t block[12],uint32_t now) {
    if(!s || !s->running || !block || nac!=s->config.subscriber.nac || carrier_hz!=s->config.control_rx_hz)return false;
    p25_trunking_event mapped=p25_trunking_consume_control(&s->map,nac,block,now);
    p25_trunking_osp event;bool parsed=p25_trunking_osp_parse(block,&event);
    if(mapped==P25_TRUNKING_IGNORED && !parsed)return false;
    revoke(s);
    unsigned opcode=block[0]&0x3fu;
    if(mapped==P25_TRUNKING_SITE && opcode==0x3au) {
        s->have_site=true;s->site_ms=now;s->site_channel=s->map.control_channel;
    } else if(mapped==P25_TRUNKING_SITE && opcode==0x3bu) {
        s->have_network=true;s->network_ms=now;s->network_channel=s->map.control_channel;
    }
    p25_trunking_access_site site;
    bool qualified=site_view(s,now,&site);
    if(!qualified) {
        if(s->access.have_site && (s->gate==P25_TRUNK_SESSION_IDENTITY || s->gate==P25_TRUNK_SESSION_MAPPING))
            p25_trunking_access_fault(&s->access,s->gate==P25_TRUNK_SESSION_IDENTITY ?
                P25_TRUNK_ACCESS_SITE_CHANGED : P25_TRUNK_ACCESS_MAPPING,now);
        return true;
    }
    if(parsed && event.type==P25_TRUNK_OSP_UNSUPPORTED && (!event.target || event.target==0xffffffu
       || event.target==s->config.subscriber.radio_id)) {
        p25_trunking_access_fault(&s->access,P25_TRUNK_ACCESS_AUTH,now);
        p25_trunking_slot_backoff_cancel(&s->backoff);return true;
    }
    // Metadata can refresh an already attached policy. The initial transition
    // out of WAIT_SITE is reserved for poll's explicitly qualified backend.
    if(s->access.have_site && !p25_trunking_access_site_update(&s->access,&site,now))return true;
    if(!voice_map_current(s,now))return true;
    if(parsed) {
        p25_trunking_access_pair pair={0};
        if(event.type==P25_TRUNK_OSP_GROUP_GRANT)
            pair.valid=p25_trunking_channel_pair(&s->map,event.channel,0,false,&pair.rx_hz,&pair.tx_hz);
        p25_trunking_access_phase before=s->access.phase;
        bool accepted=p25_trunking_access_consume(&s->access,&event,nac,carrier_hz,&pair,now);
        if(accepted && event.type==P25_TRUNK_OSP_GROUP_GRANT && s->access.phase==P25_TRUNK_ACCESS_GRANTED) {
            s->voice_channel=event.channel;s->have_voice_channel=true;
        }
        if(before!=s->access.phase)p25_trunking_slot_backoff_cancel(&s->backoff);
    }
    return true;
}
bool p25_trunking_session_select_group(p25_trunking_session *s,uint16_t group,uint32_t now) {
    p25_trunking_access_site site;
    if(!s || !s->running || s->access.config.group!=s->config.subscriber.group
       || site_validate(s,now,&site)!=P25_TRUNK_SESSION_READY
       || s->access.site.wacn!=site.wacn || s->access.site.system!=site.system
       || s->access.site.nac!=site.nac || s->access.site.rfss!=site.rfss || s->access.site.site!=site.site
       || s->access.site.control_rx_hz!=site.control_rx_hz || s->access.site.control_tx_hz!=site.control_tx_hz
       || !s->access.site.fdma || !s->access.site.control_pair_valid)return false;
    bool changed=group!=s->access.config.group;
    if(!p25_trunking_access_select_group(&s->access,group,now))return false;
    if(!changed)return true;
    s->config.subscriber.group=group;revoke(s);p25_trunking_slot_backoff_cancel(&s->backoff);
    s->have_voice_channel=false;s->voice_channel=0;s->gate=P25_TRUNK_SESSION_STALE;
    return true;
}
bool p25_trunking_session_observe(p25_trunking_session *s,const p25_trunking_slot_observation *observation) {
    if(!s || !s->running)return false;
    revoke(s);
    bool valid=p25_trunking_slot_observe(&s->slot,observation);
    if(!valid || !s->slot.have_boundary)p25_trunking_slot_backoff_cancel(&s->backoff);
    return valid;
}
static bool static_fit(const p25_trunking_session *s) {
    return (uint32_t)s->config.actuation_ticks+s->config.burst_ticks+s->config.end_guard_ticks<=P25_TRUNK_SLOT_MIN_TICKS
        && s->config.actuation_ticks<=s->config.max_start_delay_ticks;
}
static void session_poll(p25_trunking_session *s,uint32_t now,
    const p25_trunking_session_clock *clock,bool physical_tx_allowed,bool ptt_down,
    bool nominal,const p25_trunking_slot_boundary_view *anchor) {
    if(!s || !s->running)return;
    bool had_clock=s->have_clock;
    p25_trunking_session_clock previous=s->clock;
    revoke(s);s->experimental_poll=nominal;s->gate_ms=now;s->gate_tick=clock ? clock->now_tick : 0;
    bool changed=clock && (clock->stream_epoch!=previous.stream_epoch || clock->lane_epoch!=previous.lane_epoch);
    if(changed) {s->clock_fault=false;s->have_boundary_used=false;p25_trunking_slot_backoff_cancel(&s->backoff);}
    if(clock && had_clock && !changed && clock->now_tick<previous.now_tick) {
        s->clock_fault=true;p25_trunking_slot_lost(&s->slot);p25_trunking_slot_backoff_cancel(&s->backoff);
    }
    if(clock) {s->clock=*clock;s->have_clock=true;}
    s->clock_qualified=clock && clock->origin_qualified && clock->rate_qualified && !s->clock_fault;
    s->start_edge_qualified=clock && clock->start_edge_qualified;
    s->have_poll=true;
    p25_trunking_access_site site;bool qualified=site_view(s,now,&site);
    bool capable=nominal || (s->clock_qualified && s->start_edge_qualified && static_fit(s));
    if(s->access.phase==P25_TRUNK_ACCESS_WAIT_SITE && qualified && capable && physical_tx_allowed) {
        if(p25_trunking_access_site_update(&s->access,&site,now))s->activated=true;
    }
    if(s->access.have_site && qualified)
        (void)p25_trunking_access_site_update(&s->access,&site,now);
    if(s->access.have_site && qualified)(void)voice_map_current(s,now);
    // Losing backend qualification invalidates a prepared RF operation. Before
    // any operation was issued it is safe to return to passive site learning.
    if(!capable && s->access.phase!=P25_TRUNK_ACCESS_WAIT_SITE && !cleanup_phase(s)
       && s->access.phase!=P25_TRUNK_ACCESS_FAILED) {
        if(s->access.outstanding || s->access.voice_running)
            p25_trunking_access_fault(&s->access,P25_TRUNK_ACCESS_TRANSPORT,now);
        else {
            p25_trunking_access_stop(&s->access);
            (void)p25_trunking_access_start(&s->access,&s->config.subscriber,now);
        }
        p25_trunking_slot_backoff_cancel(&s->backoff);
    }
    // A never-activated diagnostic session has no qualified site in the access
    // policy and cannot take an RF action. Let its PTT housekeeping continue
    // while RX-only/inhibit/battery permission is denied; report that separate
    // gate without manufacturing a failed subscriber transaction. Once the
    // policy activates, the native hard revocation path remains mandatory,
    // including after a capability loss returns the policy to WAIT_SITE.
    bool passive=!s->activated && s->access.phase==P25_TRUNK_ACCESS_WAIT_SITE
        && !s->access.have_site && !s->access.registered && !s->access.affiliated
        && !s->access.outstanding && !s->access.voice_running;
    if(nominal)p25_trunking_access_poll_nominal(&s->access,now,ptt_down,physical_tx_allowed||passive,false);
    else p25_trunking_access_poll(&s->access,now,ptt_down,physical_tx_allowed || passive,false);
    if(cleanup_phase(s)) {s->gate=P25_TRUNK_SESSION_READY;return;}
    if(!physical_tx_allowed) {s->gate=P25_TRUNK_SESSION_PHYSICAL_PERMISSION;return;}
    if(s->access.phase==P25_TRUNK_ACCESS_FAILED) {s->gate=P25_TRUNK_SESSION_FAILED;return;}
    if(!qualified)return;
    if(!nominal&&!s->clock_qualified) {s->gate=P25_TRUNK_SESSION_TIMING_UNQUALIFIED;return;}
    if(!nominal&&!s->start_edge_qualified) {s->gate=P25_TRUNK_SESSION_START_EDGE_UNQUALIFIED;return;}
    if(!nominal&&!static_fit(s)) {s->gate=P25_TRUNK_SESSION_DOES_NOT_FIT;return;}
    if(s->access.phase==P25_TRUNK_ACCESS_GRANTED) {s->gate=P25_TRUNK_SESSION_READY;return;}
    if(!request_phase(s) || s->access.outstanding) {s->gate=P25_TRUNK_SESSION_READY;return;}
    if(nominal) {
        if(!clock||!anchor||s->clock_fault||!s->slot.coherent||!s->slot.have_boundary
           ||s->slot.boundary_tick!=anchor->boundary_tick
           ||anchor->stream_epoch!=clock->stream_epoch||anchor->lane_epoch!=clock->lane_epoch
           ||s->slot.stream_epoch!=anchor->stream_epoch||s->slot.lane_epoch!=anchor->lane_epoch
           ||clock->now_tick<anchor->boundary_tick||clock->now_tick-anchor->boundary_tick>2304u
           ||(s->have_boundary_used&&s->last_boundary_used==anchor->boundary_tick)) {
            s->gate=P25_TRUNK_SESSION_NO_PHASE;return;
        }
        memset(&s->budget,0,sizeof s->budget);s->budget.observed=*anchor;
        // No RF start/end is projected by this policy layer. Its job names a
        // retained actual boundary for the separately guarded native backend.
        s->opportunity=true;s->gate=P25_TRUNK_SESSION_READY;
        p25_trunking_access_poll_nominal(&s->access,now,ptt_down,physical_tx_allowed,true);return;
    }
    p25_trunking_slot_phase_view phase;
    if(!p25_trunking_slot_phase(&s->slot,clock->now_tick,&phase)
       || phase.stream_epoch!=clock->stream_epoch || phase.lane_epoch!=clock->lane_epoch) {
        p25_trunking_slot_backoff_cancel(&s->backoff);s->gate=P25_TRUNK_SESSION_NO_PHASE;return;
    }
    if(s->backoff_serial!=s->access.serial) {p25_trunking_slot_backoff_cancel(&s->backoff);s->backoff_serial=s->access.serial;}
    if(!s->backoff.active) {
        if(!p25_trunking_slot_backoff_arm(&s->backoff,&s->slot,clock->now_tick,
                s->config.contention_skip,s->config.contention_wait_ticks)) {
            s->gate=P25_TRUNK_SESSION_NO_PHASE;return;
        }
    }
    p25_trunking_slot_boundary_view boundary;
    if(!p25_trunking_slot_backoff_take(&s->backoff,&s->slot,clock->now_tick,&boundary)) {
        s->gate=P25_TRUNK_SESSION_BACKOFF;return;
    }
    if((s->have_boundary_used && boundary.boundary_tick==s->last_boundary_used)
       || !p25_trunking_slot_fit(&s->slot,clock->now_tick,s->config.actuation_ticks,
            s->config.burst_ticks,s->config.end_guard_ticks,&s->budget)
       || s->budget.projected_start_tick-boundary.boundary_tick>s->config.max_start_delay_ticks) {
        s->gate=P25_TRUNK_SESSION_DOES_NOT_FIT;return;
    }
    s->opportunity=s->fit=true;s->gate=P25_TRUNK_SESSION_READY;
    // The access policy's stored idle bit remains a same-poll-only lease.
    p25_trunking_access_poll(&s->access,now,ptt_down,physical_tx_allowed,true);
}
void p25_trunking_session_poll(p25_trunking_session *s,uint32_t now,
    const p25_trunking_session_clock *clock,bool physical_tx_allowed,bool ptt_down) {
    session_poll(s,now,clock,physical_tx_allowed,ptt_down,false,NULL);
}
void p25_trunking_session_poll_nominal(p25_trunking_session *s,uint32_t now,
    const p25_trunking_session_clock *clock,bool physical_tx_allowed,bool ptt_down,
    const p25_trunking_slot_boundary_view *anchor) {
    session_poll(s,now,clock,physical_tx_allowed,ptt_down,true,anchor);
}
static bool same_clock(const p25_trunking_session_clock *a,const p25_trunking_session_clock *b) {
    return a && b && a->now_tick==b->now_tick && a->stream_epoch==b->stream_epoch && a->lane_epoch==b->lane_epoch
        && a->origin_qualified && a->rate_qualified && a->start_edge_qualified;
}
static bool session_take(p25_trunking_session *s,p25_trunking_session_action *out,
    uint32_t now,const p25_trunking_session_clock *clock,bool nominal) {
    if(!s || !s->running || !out || !s->have_poll)return false;
    bool cleanup=cleanup_phase(s);
    bool clock_matches=nominal ? clock&&clock->now_tick==s->clock.now_tick
        &&clock->stream_epoch==s->clock.stream_epoch&&clock->lane_epoch==s->clock.lane_epoch
        : same_clock(clock,&s->clock)&&s->clock_qualified&&s->start_edge_qualified;
    if(!cleanup && (s->experimental_poll!=nominal||now!=s->gate_ms||!clock_matches
       ||s->gate!=P25_TRUNK_SESSION_READY)) {
        revoke(s);p25_trunking_slot_backoff_cancel(&s->backoff);return false;
    }
    if(request_phase(s) && (!s->opportunity || (!nominal&&!s->fit)))return false;
    p25_trunking_session_action value={0};
    if(!p25_trunking_access_take(&s->access,&value.access,now))return false;
    value.lease_ms=now;value.lease_tick=clock ? clock->now_tick : 0;
    value.stream_epoch=s->clock.stream_epoch;value.lane_epoch=s->clock.lane_epoch;
    if(control_action(value.access.type)) {
        uint8_t block[1][12];bool made=value.access.type==P25_TRUNK_ACTION_REGISTER ?
            p25_trunking_isp_register(block[0],s->config.subscriber.wacn,s->config.subscriber.system,value.access.radio_id)
            : value.access.type==P25_TRUNK_ACTION_AFFILIATE ?
            p25_trunking_isp_affiliate(block[0],s->config.subscriber.system,value.access.group,value.access.radio_id)
            : value.access.type==P25_TRUNK_ACTION_GROUP_REQUEST ?
            p25_trunking_isp_group_request(block[0],value.access.group,value.access.radio_id,0)
            : p25_trunking_isp_deregister(block[0],s->config.subscriber.wacn,s->config.subscriber.system,value.access.radio_id);
        if(!made || p25_tsdu_encode(value.tsdu,sizeof value.tsdu,value.access.nac,
                (const uint8_t (*)[12])block,1,P25_TRUNKING_ISP_STATUS)!=sizeof value.tsdu) {
            (void)p25_trunking_access_result(&s->access,value.access.id,false,now);revoke(s);return false;
        }
        value.budget=s->budget;value.valid_bits=P25_TRUNK_SESSION_ISP_BITS;value.wire_bytes=sizeof value.tsdu;
        s->last_boundary_used=s->budget.observed.boundary_tick;s->have_boundary_used=true;
    }
    revoke(s);p25_trunking_slot_backoff_cancel(&s->backoff);*out=value;return true;
}
bool p25_trunking_session_take(p25_trunking_session *s,p25_trunking_session_action *out,
    uint32_t now,const p25_trunking_session_clock *clock) {return session_take(s,out,now,clock,false);}
bool p25_trunking_session_take_nominal(p25_trunking_session *s,p25_trunking_session_action *out,
    uint32_t now,const p25_trunking_session_clock *clock) {return session_take(s,out,now,clock,true);}
bool p25_trunking_session_result(p25_trunking_session *s,uint32_t id,bool success,uint32_t now) {
    if(!s || !s->running)return false;
    revoke(s);p25_trunking_slot_backoff_cancel(&s->backoff);
    bool accepted=p25_trunking_access_result(&s->access,id,success,now);
    if(accepted)p25_trunking_slot_lost(&s->slot);
    return accepted;
}
void p25_trunking_session_lost(p25_trunking_session *s,uint32_t now) {
    if(!s || !s->running)return;
    revoke(s);p25_trunking_slot_lost(&s->slot);p25_trunking_slot_backoff_cancel(&s->backoff);
    s->have_site=s->have_network=s->site_qualified=false;
    s->map.have_site=s->map.have_network=false;memset(s->map.band,0,sizeof s->map.band);
    p25_trunking_access_fault(&s->access,P25_TRUNK_ACCESS_SITE_LOST,now);s->gate=P25_TRUNK_SESSION_WAIT_SITE;
}
