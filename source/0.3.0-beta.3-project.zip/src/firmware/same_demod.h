// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef SAME_DEMOD_H
#define SAME_DEMOD_H
#include <stddef.h>
#include <stdint.h>

// NOAA SAME at 8000 samples/s, signed linear PCM. This is AFSK, not UART:
// 520.8333 bits/s, 2083.3333 Hz = 1, 1562.5 Hz = 0, LSB first, no stop bits.
// A callback starts with three recovered 0xAB bytes after preamble acquisition.
// It supplies raw eight-bit bytes; header validation/repeat voting is separate.
typedef void (*same_demod_byte_fn)(void *context, uint8_t byte);
typedef struct {
    same_demod_byte_fn emit;
    void *context;
    int32_t product[16][4];
    int32_t sum[4];
    uint32_t mark_phase, space_phase;
    int32_t dc;
    uint32_t bits, bytes, acquisitions;
    uint32_t shift;
    int32_t symbol_phase;
    uint16_t quiet_samples;
    uint8_t ring, filled, last_bit, have_bit, locked, byte, byte_bits;
} same_demod;

void same_demod_init(same_demod *demod, same_demod_byte_fn emit, void *context);
// Drop partial symbols/bytes on an input discontinuity; preserve callback/stats.
void same_demod_reset(same_demod *demod);
void same_demod_feed(same_demod *demod, const int16_t *pcm, size_t count);
#endif
