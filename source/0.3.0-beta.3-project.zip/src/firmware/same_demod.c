// SPDX-License-Identifier: GPL-3.0-or-later
#include "same_demod.h"
#include <string.h>

// A 16-sample quadrature matched window is approximately one bit. Oscillator
// phase is Q0.32; sine amplitudes are Q10. All arithmetic is fixed point.
static const int16_t sine_quarter[65] = {
    0,25,50,75,100,125,150,175,200,224,249,273,297,321,345,369,
    392,415,438,460,483,505,526,548,569,590,610,630,650,669,688,706,
    724,742,759,775,792,807,822,837,851,865,878,891,903,915,926,936,
    946,955,964,972,980,987,993,999,1004,1009,1013,1016,1019,1021,
    1023,1024,1024
};
enum { SYMBOL = 3932, HALF_SYMBOL = SYMBOL / 2, QUIET_RESET = 256 };

static int32_t sine(uint32_t phase)
{
    unsigned p = phase >> 24;
    unsigned i = p & 63u;
    int32_t value = sine_quarter[(p & 64u) ? 64u - i : i];
    return (p & 128u) ? -value : value;
}

void same_demod_init(same_demod *d, same_demod_byte_fn emit, void *context)
{
    memset(d, 0, sizeof *d);
    d->emit = emit;
    d->context = context;
}

void same_demod_reset(same_demod *d)
{
    same_demod_byte_fn emit = d->emit;
    void *context = d->context;
    uint32_t bits = d->bits, bytes = d->bytes, acquisitions = d->acquisitions;
    same_demod_init(d, emit, context);
    d->bits = bits;
    d->bytes = bytes;
    d->acquisitions = acquisitions;
}

static void output_byte(same_demod *d, uint8_t byte)
{
    ++d->bytes;
    if (d->emit) d->emit(d->context, byte);
}

static void output_bit(same_demod *d, unsigned bit)
{
    ++d->bits;
    d->shift = ((d->shift >> 1) | (bit << 23)) & 0xffffffu;
    // Keep seeking preamble even after acquisition: voice or a nonzero pause
    // can advance the bit clock without preserving byte alignment. A fresh
    // three-byte sync realigns once; an already aligned AB takes the ordinary
    // one-byte path, avoiding duplicate emissions at overlapping matches.
    if (d->shift == 0xabababu && (!d->locked || d->byte_bits != 7)) {
        d->locked = 1;
        d->byte_bits = 0;
        d->byte = 0;
        ++d->acquisitions;
        output_byte(d, 0xab);
        output_byte(d, 0xab);
        output_byte(d, 0xab);
        return;
    }
    if (!d->locked) return;
    d->byte = (uint8_t)((d->byte >> 1) | (bit << 7));
    if (++d->byte_bits == 8) {
        output_byte(d, d->byte);
        d->byte_bits = 0;
    }
}

static void push(same_demod *d, int16_t sample)
{
    int32_t x, wave[4], part;
    int32_t mark_i, mark_q, space_i, space_q;
    uint32_t mark, space, high, low;
    unsigned i, bit;
    int32_t before, error;

    // Remove DC before correlation, with a 16-ms time constant. Scaling bounds
    // every multiply and sum even across a full-scale DC step.
    d->dc += (((int32_t)sample * 256) - d->dc) >> 7;
    x = ((int32_t)sample - (d->dc >> 8)) >> 3;
    wave[0] = sine(d->mark_phase);
    wave[1] = sine(d->mark_phase + 0x40000000u);
    wave[2] = sine(d->space_phase);
    wave[3] = sine(d->space_phase + 0x40000000u);
    d->mark_phase += 1118481067u;
    d->space_phase += 838860800u;
    for (i = 0; i < 4; ++i) {
        part = x * wave[i];
        d->sum[i] += part - d->product[d->ring][i];
        d->product[d->ring][i] = part;
    }
    d->ring = (uint8_t)((d->ring + 1u) & 15u);
    if (d->filled < 16) { ++d->filled; return; }
    mark_i = d->sum[0] >> 13;
    mark_q = d->sum[1] >> 13;
    space_i = d->sum[2] >> 13;
    space_q = d->sum[3] >> 13;
    mark = (uint32_t)(mark_i * mark_i) + (uint32_t)(mark_q * mark_q);
    space = (uint32_t)(space_i * space_i) + (uint32_t)(space_q * space_q);
    bit = mark > space;
    high = bit ? mark : space;
    low = bit ? space : mark;
    if (high < 16u || high < low + low / 4u) {
        if (d->quiet_samples < QUIET_RESET) ++d->quiet_samples;
        if (d->quiet_samples == QUIET_RESET) {
            // Avoid repeatedly clearing/rebuilding the matched filter in quiet.
            d->locked = d->have_bit = d->byte_bits = 0;
            d->shift = 0;
        }
    } else d->quiet_samples = 0;
    if (d->quiet_samples >= QUIET_RESET) return;

    // The rolling filter delays transitions by half a bit. Its sign crosses at
    // that delayed symbol boundary; recover the clock from these crossings and
    // sample midway between them. Corrections track small transmitter drift.
    if (d->have_bit && bit != d->last_bit && high >= 16u) {
        error = d->symbol_phase;
        if (error > HALF_SYMBOL) error -= SYMBOL;
        d->symbol_phase -= error / 2;
        if (d->symbol_phase < 0) d->symbol_phase += SYMBOL;
        if (d->symbol_phase >= SYMBOL) d->symbol_phase -= SYMBOL;
    }
    d->last_bit = (uint8_t)bit;
    d->have_bit = 1;
    before = d->symbol_phase;
    d->symbol_phase += 256;
    if (before < HALF_SYMBOL && d->symbol_phase >= HALF_SYMBOL)
        output_bit(d, bit);
    if (d->symbol_phase >= SYMBOL) d->symbol_phase -= SYMBOL;
}

void same_demod_feed(same_demod *d, const int16_t *pcm, size_t count)
{
    size_t i;
    if (!d || (!pcm && count)) return;
    for (i = 0; i < count; ++i) push(d, pcm[i]);
}
