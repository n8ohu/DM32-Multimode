// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_pcm_fm_tx.h"
#include <string.h>

static radio_pcm_fm_state fault(radio_pcm_fm_tx *tx,radio_pcm_fm_error error) {
    tx->error=error;tx->state=RADIO_PCM_FM_FAULT;
    if(tx->hal.unkey)tx->hal.unkey(tx->context);
    return tx->state;
}
void radio_pcm_fm_tx_init(radio_pcm_fm_tx *tx,const radio_pcm_fm_hal *hal,void *context) {
    if(!tx)return;
    memset(tx,0,sizeof *tx);if(hal)tx->hal=*hal;tx->context=context;
}
bool radio_pcm_fm_tx_start(radio_pcm_fm_tx *tx,bool wide,uint32_t now) {
    if(!tx || tx->routed || tx->state==RADIO_PCM_FM_RUNNING || tx->state==RADIO_PCM_FM_DRAINING)return false;
    if(!tx->hal.pop || !tx->hal.eof || !tx->hal.prompt_push || !tx->hal.route || !tx->hal.unkey) {
        (void)fault(tx,RADIO_PCM_FM_BAD_HAL);return false;
    }
    tx->peak=wide ? RADIO_PCM_FM_PEAK_WIDE : RADIO_PCM_FM_PEAK_NARROW;
    tx->have_frame=false;tx->position=0;tx->frames=tx->chunks=tx->clipped=tx->full=0;
    tx->max_gap_us=tx->max_cost_us=0;tx->last_service=tx->last_push=now;tx->drain_started=0;
    tx->error=RADIO_PCM_FM_OK;
    if(!tx->hal.route(tx->context,true)) {(void)fault(tx,RADIO_PCM_FM_ROUTE);return false;}
    tx->routed=true;tx->state=RADIO_PCM_FM_RUNNING;return true;
}
radio_pcm_fm_state radio_pcm_fm_tx_service(radio_pcm_fm_tx *tx,uint32_t now) {
    if(!tx)return RADIO_PCM_FM_FAULT;
    if(tx->state!=RADIO_PCM_FM_RUNNING && tx->state!=RADIO_PCM_FM_DRAINING)return tx->state;
    uint32_t start=tx->hal.clock_us ? tx->hal.clock_us(tx->context) : now;
    uint32_t gap=now-tx->last_service;tx->last_service=now;
    if(gap>tx->max_gap_us)tx->max_gap_us=gap;
    if(gap>RADIO_PCM_FM_MAX_GAP_US)return fault(tx,RADIO_PCM_FM_SERVICE_GAP);
    if(tx->state==RADIO_PCM_FM_DRAINING) {
        if(now-tx->drain_started>=RADIO_PCM_FM_DRAIN_US) {
            tx->state=RADIO_PCM_FM_DONE;tx->hal.unkey(tx->context);
        }
        return tx->state;
    }
    for(unsigned chunks=0;chunks<RADIO_PCM_FM_MAX_CHUNKS;++chunks) {
        if(!tx->have_frame) {
            if(tx->hal.eof(tx->context)) {tx->state=RADIO_PCM_FM_DRAINING;tx->drain_started=now;break;}
            if(!tx->hal.pop(tx->context,tx->frame))return fault(tx,RADIO_PCM_FM_SOURCE);
            ++tx->frames;tx->position=0;tx->have_frame=true;
            for(unsigned i=0;i<RADIO_PCM_FM_FRAME_SAMPLES;++i) {
                if(tx->frame[i]>tx->peak) {tx->frame[i]=tx->peak;++tx->clipped;}
                else if(tx->frame[i]<-tx->peak) {tx->frame[i]=(int16_t)-tx->peak;++tx->clipped;}
            }
        }
        if(!tx->hal.prompt_push(tx->context,tx->frame+tx->position)) {++tx->full;break;}
        ++tx->chunks;tx->position+=RADIO_PCM_FM_FIFO_SAMPLES;tx->last_push=now;
        if(tx->position==RADIO_PCM_FM_FRAME_SAMPLES)tx->have_frame=false;
    }
    uint32_t cost=tx->hal.clock_us ? tx->hal.clock_us(tx->context)-start : 0u;
    if(cost>tx->max_cost_us)tx->max_cost_us=cost;
    if(cost>RADIO_PCM_FM_MAX_COST_US)return fault(tx,RADIO_PCM_FM_SERVICE_COST);
    if(tx->state==RADIO_PCM_FM_RUNNING && now-tx->last_push>=RADIO_PCM_FM_STALL_US)
        return fault(tx,RADIO_PCM_FM_FIFO_STALL);
    return tx->state;
}
void radio_pcm_fm_tx_stop(radio_pcm_fm_tx *tx) {
    if(!tx)return;
    if(tx->state!=RADIO_PCM_FM_IDLE || tx->routed) {
        if(tx->hal.unkey)tx->hal.unkey(tx->context);
        if(tx->routed && tx->hal.route)(void)tx->hal.route(tx->context,false);
    }
    tx->routed=false;tx->have_frame=false;tx->position=0;tx->state=RADIO_PCM_FM_IDLE;
}
