// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_APPLETS_H
#define RADIO_APPLETS_H
#include "radio_applet_store.h"
#include "radio_applet_vm.h"

typedef struct {
    bool (*acquire)(void *context);
    void (*release)(void *context);
    void (*emit)(void *context,const char *line);
    bool (*output_pending)(void *context);
    uint32_t (*millis)(void *context);
    radio_applet_services services;
} radio_applets_hal;

typedef enum {APPLET_OP_NONE,APPLET_OP_CATALOGUE,APPLET_OP_INSTALL,
              APPLET_OP_COMMIT,APPLET_OP_REMOVE,APPLET_OP_RUN} radio_applet_operation;
typedef struct {
    radio_applet_store store;
    radio_applet_vm vm;
    radio_applets_hal hal;
    void *context;
    radio_applet_operation operation;
    uint32_t activity_ms,pending_size,pending_crc;
    unsigned slot;
    bool owned,running,begin_pending,finishing;
} radio_applets;

void radio_applets_init(radio_applets *,const radio_applet_store_io *,const radio_applets_hal *,void *context);
bool radio_applets_active(const radio_applets *);
// Only installable applet commands are consumed; native APP SAME commands pass
// through to the existing dispatcher. All callbacks run in the main task.
bool radio_applets_command(radio_applets *,const char *line);
bool radio_applets_run(radio_applets *,unsigned slot); // User-facing slots 1..8.
bool radio_applets_catalogue(radio_applets *);
void radio_applets_poll(radio_applets *);
void radio_applets_stop(radio_applets *);
void radio_applets_slot_label(radio_applets *,unsigned slot,char *name,size_t name_size,char *detail,size_t detail_size);
#endif
