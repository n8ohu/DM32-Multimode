// SPDX-License-Identifier: GPL-3.0-or-later
// Canonical finite RX-origin witness events. No clock or RF qualification.
#ifndef P25_RX_ORIGIN_H
#define P25_RX_ORIGIN_H
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>

#define P25_RX_ORIGIN_SCHEMA 1u
#define P25_RX_ORIGIN_EVENT_BYTES 64u
#define P25_RX_ORIGIN_MAX_SAMPLES 8192u
enum {P25_RX_ORIGIN_STATUS=1u,P25_RX_ORIGIN_UNIT=2u,P25_RX_ORIGIN_FAULT=3u};
enum {P25_RX_ORIGIN_SELECTED=1u,P25_RX_ORIGIN_QUALIFIED=2u,P25_RX_ORIGIN_NATIVE_CRC=4u};
enum {P25_RX_ORIGIN_LANE_LOSS=1u,P25_RX_ORIGIN_SAMPLE_GAP=2u,
    P25_RX_ORIGIN_RETUNE=3u,P25_RX_ORIGIN_STOP=4u,P25_RX_ORIGIN_OVERFLOW=5u,
    P25_RX_ORIGIN_CONTEXT_LOST=6u};

typedef struct {
    // STATUS: original decoder status END. UNIT: current input tick at frame
    // callback delivery, NEVER an inferred frame sync/end. FAULT: zero/unknown.
    uint64_t event_tick;
    uint32_t cpu_us,stream_epoch,lane_epoch;
    uint32_t read_begin_us,read_end_us,origin_irq_us,origin_irq_count;
    uint32_t delivery_input_ordinal;
    uint16_t chunk_first_sample,nac,source_flags;
    uint8_t type,duid,status,lane,evidence,block_descriptor;
    // UNIT: actual received native-CRC TSBK. STATUS: all zero. FAULT: reason
    // 1..6 in byte0, remaining bytes zero; source origin is explicitly unknown.
    uint8_t data[12];
} p25_rx_origin_event;
_Static_assert(sizeof(p25_rx_origin_event)==64u,"RX-origin encoder value grew beyond64 bytes");

static inline void p25_rx_origin_put16(unsigned char *p,uint16_t value) {
    p[0]=(unsigned char)value;p[1]=(unsigned char)(value>>8);
}
static inline void p25_rx_origin_put32(unsigned char *p,uint32_t value) {
    p25_rx_origin_put16(p,(uint16_t)value);p25_rx_origin_put16(p+2,(uint16_t)(value>>16));
}
static inline bool p25_rx_origin_encode(unsigned char out[64],const p25_rx_origin_event *event) {
    if(!out||!event)return false;
    // A local value also permits an overlapping destination. Invalid events
    // leave all destination bytes unchanged; validation never samples a clock.
    p25_rx_origin_event e=*event;
    if(e.type==P25_RX_ORIGIN_FAULT) {
        if(e.event_tick||e.read_begin_us||e.read_end_us||e.origin_irq_us||e.origin_irq_count
           ||e.delivery_input_ordinal||e.chunk_first_sample||e.nac||e.source_flags
           ||e.duid||e.status||e.lane!=255u||e.evidence||e.block_descriptor
           ||e.data[0]<P25_RX_ORIGIN_LANE_LOSS||e.data[0]>P25_RX_ORIGIN_CONTEXT_LOST)return false;
        for(unsigned i=1u;i<12u;++i)if(e.data[i])return false;
    } else {
        if((e.type!=P25_RX_ORIGIN_STATUS&&e.type!=P25_RX_ORIGIN_UNIT)||e.duid!=7u
           ||e.nac>0xfffu||e.source_flags||e.chunk_first_sample>=P25_RX_ORIGIN_MAX_SAMPLES
           ||e.chunk_first_sample%16u||e.delivery_input_ordinal<e.chunk_first_sample
           ||e.delivery_input_ordinal-e.chunk_first_sample>=16u
           ||e.origin_irq_count!=(uint32_t)e.chunk_first_sample/256u+1u
           ||(uint32_t)(e.read_end_us-e.read_begin_us)>INT32_MAX
           ||(uint32_t)(e.cpu_us-e.read_end_us)>INT32_MAX)return false;
        if(e.type==P25_RX_ORIGIN_STATUS) {
            if(!e.status||e.status>3u||e.evidence>3u||e.block_descriptor
               ||((e.evidence&P25_RX_ORIGIN_QUALIFIED)&&!(e.evidence&P25_RX_ORIGIN_SELECTED))
               ||((e.evidence&P25_RX_ORIGIN_SELECTED)?e.lane>=10u:e.lane!=255u)
               ||e.event_tick>(uint64_t)e.delivery_input_ordinal*6u)return false;
            for(unsigned i=0;i<12u;++i)if(e.data[i])return false;
        } else {
            unsigned count=e.block_descriptor>>4,index=e.block_descriptor&15u;
            if(e.evidence!=P25_RX_ORIGIN_NATIVE_CRC||e.lane!=255u||e.status
               ||!count||count>3u||index>=count
               ||e.event_tick!=(uint64_t)e.delivery_input_ordinal*6u)return false;
        }
    }
    p25_rx_origin_put32(out,(uint32_t)e.event_tick);
    p25_rx_origin_put32(out+4,(uint32_t)(e.event_tick>>32));
    p25_rx_origin_put32(out+8,e.cpu_us);p25_rx_origin_put32(out+12,e.stream_epoch);
    p25_rx_origin_put32(out+16,e.lane_epoch);p25_rx_origin_put32(out+20,e.read_begin_us);
    p25_rx_origin_put32(out+24,e.read_end_us);p25_rx_origin_put32(out+28,e.origin_irq_us);
    p25_rx_origin_put32(out+32,e.origin_irq_count);p25_rx_origin_put16(out+36,e.chunk_first_sample);
    p25_rx_origin_put16(out+38,e.nac);out[40]=e.type;out[41]=e.duid;out[42]=e.status;
    out[43]=e.lane;p25_rx_origin_put16(out+44,e.source_flags);out[46]=e.evidence;
    out[47]=e.block_descriptor;
    for(unsigned i=0;i<12u;++i)out[48u+i]=e.data[i];
    p25_rx_origin_put32(out+60,e.delivery_input_ordinal);return true;
}
#endif
