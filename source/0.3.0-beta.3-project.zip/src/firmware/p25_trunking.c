// SPDX-License-Identifier: GPL-3.0-or-later
// Standard TSBK field orientation cross-checked with pinned OP25 trunking.py.
#include "p25_trunking.h"
#include "p25_data_fec.h"
#include <string.h>

static bool in_range(const p25_trunking *t,uint64_t hz) {
    return hz>=t->min_hz && hz<=t->max_hz;
}
bool p25_trunking_init(p25_trunking *t,uint32_t control_hz,uint32_t min_hz,
                      uint32_t max_hz,uint16_t nac) {
    if(!t || !min_hz || min_hz>max_hz || control_hz<min_hz || control_hz>max_hz ||
       (nac>0xfffu && nac!=P25_TRUNKING_NAC_ANY))return false;
    memset(t,0,sizeof *t);t->control_hz=control_hz;t->receiver_hz=control_hz;
    t->min_hz=min_hz;t->max_hz=max_hz;t->configured_nac=nac;
    t->learned_nac=nac;t->have_nac=nac!=P25_TRUNKING_NAC_ANY;
    t->phase=P25_TRUNKING_CONTROL;return true;
}
bool p25_trunking_set_groups(p25_trunking *t,const uint16_t *groups,unsigned count) {
    if(!t || count>P25_TRUNKING_GROUPS || (count && !groups))return false;
    for(unsigned i=0;i<count;++i)if(!groups[i])return false;
    // memmove permits a caller to shorten its existing in-object allowlist.
    if(count)memmove(t->groups,groups,count*sizeof *groups);
    t->group_count=(uint8_t)count;return true;
}
bool p25_trunking_frequency(const p25_trunking *t,uint16_t channel,uint32_t *hz) {
    if(!t || !hz)return false;
    const p25_trunking_band *b=&t->band[channel>>12];
    uint64_t frequency=(uint64_t)b->base_hz+(channel&0xfffu)*(uint64_t)b->spacing_hz;
    if(!b->valid || !b->fdma || !in_range(t,frequency))return false;
    *hz=(uint32_t)frequency;return true;
}
bool p25_trunking_input_frequency(const p25_trunking *t,uint16_t channel,uint32_t *hz) {
    uint32_t downlink;
    if(!hz || !p25_trunking_frequency(t,channel,&downlink)
       || !t->band[channel>>12].tx_valid)return false;
    int64_t frequency=(int64_t)downlink+t->band[channel>>12].tx_offset_hz;
    if(frequency<=0 || frequency>UINT32_MAX || !in_range(t,(uint64_t)frequency))return false;
    *hz=(uint32_t)frequency;return true;
}
bool p25_trunking_channel_pair(const p25_trunking *t,uint16_t downlink_channel,
    uint16_t uplink_channel,bool explicit_uplink,uint32_t *rx_hz,uint32_t *tx_hz) {
    uint32_t downlink,uplink;
    if(!rx_hz || !tx_hz || rx_hz==tx_hz || !p25_trunking_frequency(t,downlink_channel,&downlink)
       || !t->band[downlink_channel>>12].tx_valid
       || !(explicit_uplink ? p25_trunking_frequency(t,uplink_channel,&uplink)
                            : p25_trunking_input_frequency(t,downlink_channel,&uplink))
       || (explicit_uplink && !t->band[uplink_channel>>12].tx_valid))return false;
    *rx_hz=downlink;*tx_hz=uplink;return true;
}
static bool selected(const p25_trunking *t,uint16_t group) {
    if(!group)return false;
    if(!t->group_count)return true;
    for(unsigned i=0;i<t->group_count;++i)if(t->groups[i]==group)return true;
    return false;
}
static void request(p25_trunking *t,uint32_t hz,uint32_t now) {
    t->pending_hz=hz;t->tune_requested_ms=now;
}
static bool grant(p25_trunking *t,uint16_t channel,uint16_t group,uint32_t source,
                  uint8_t options,uint32_t now) {
    uint32_t hz;
    // Encryption/service metadata is still qualified independently on voice.
    // Grant updates have no options; they cannot override voice mute policy.
    if((options&0x70u) || !selected(t,group) ||
       !p25_trunking_frequency(t,channel,&hz) || hz==t->control_hz)return false;
    t->voice_channel=channel;t->group=group;t->source=source;
    t->service_options=options;++t->grants;t->have_voice=false;
    request(t,hz,now);return true;
}
static p25_trunking_event consume(p25_trunking *t,uint16_t nac,
                                  const uint8_t block[12],uint32_t now_ms,bool follow) {
    if(!t || !block || t->phase!=P25_TRUNKING_CONTROL || t->pending_hz || nac>0xfffu ||
       (t->have_nac && nac!=t->learned_nac) || (block[0]&0x40u) || block[1])return P25_TRUNKING_IGNORED;
    uint16_t crc=p25_data_crc16(block,10);
    if(block[10]!=(uint8_t)(crc>>8) || block[11]!=(uint8_t)crc)return P25_TRUNKING_IGNORED;
    uint64_t arg=0;for(unsigned i=2;i<10;++i)arg=(arg<<8)|block[i];
    unsigned opcode=block[0]&0x3fu;
    p25_trunking_event event=P25_TRUNKING_IGNORED;
    if(opcode==0x34u || opcode==0x3du || opcode==0x33u) {
        unsigned id=(unsigned)(arg>>60),spacing=(unsigned)((arg>>32)&0x3ffu);
        uint64_t base=(arg&UINT64_C(0xffffffff))*5u;
        // Clear an earlier mapping if the identifier changes to TDMA/invalid.
        p25_trunking_band *b=&t->band[id];memset(b,0,sizeof *b);
        unsigned channel_type=(unsigned)((arg>>56)&0xfu);
        // IDEN_UP_TDMA type1 is a single-slot 12.5-kHz FDMA carrier. The
        // opcode alone does not make a mapping TDMA. Other types remain
        // unsupported and must revoke any earlier mapping for this ID.
        if(opcode==0x33u&&channel_type!=1u)event=P25_TRUNKING_UNSUPPORTED;
        else if(spacing && base && base<=UINT32_MAX) {
            b->base_hz=(uint32_t)base;b->spacing_hz=spacing*125u;
            bool vu=opcode!=0x3du;
            unsigned raw=(unsigned)((arg>>42)&(vu ? 0x3fffu : 0x1ffu));
            unsigned sign=vu ? 0x2000u : 0x100u;
            unsigned scale=vu ? b->spacing_hz : 250000u;
            int32_t offset=(int32_t)((raw&(sign-1u))*scale);
            b->tx_offset_hz=(raw&sign) ? offset : -offset;
            unsigned bandwidth=(unsigned)((arg>>(opcode==0x34u ? 56u : 51u))
                                          &(opcode==0x34u ? 0xfu : 0x1ffu));
            b->tx_valid=opcode==0x33u || bandwidth==(opcode==0x34u ? 5u : 100u);
            b->valid=b->fdma=true;event=P25_TRUNKING_BANDPLAN;
        } else if(!follow)event=P25_TRUNKING_UNSUPPORTED;
    } else if(opcode==0x3au) {
        uint16_t system=(uint16_t)((arg>>40)&0xfffu);
        if(((t->have_site || t->have_network) && t->system_id!=system) ||
           (t->have_site && (t->rfss!=(uint8_t)(arg>>32) || t->site!=(uint8_t)(arg>>24))))
            memset(t->band,0,sizeof t->band);
        t->system_id=system;t->rfss=(uint8_t)(arg>>32);t->have_site=true;
        t->site=(uint8_t)(arg>>24);t->control_channel=(uint16_t)(arg>>8);
        event=P25_TRUNKING_SITE;
    } else if(opcode==0x3bu) {
        uint32_t wacn=(uint32_t)((arg>>36)&0xfffffu);uint16_t system=(uint16_t)((arg>>24)&0xfffu);
        if(((t->have_site || t->have_network) && t->system_id!=system) ||
           (t->have_network && t->wacn!=wacn))memset(t->band,0,sizeof t->band);
        t->wacn=wacn;t->system_id=system;t->have_network=true;
        t->control_channel=(uint16_t)(arg>>8);event=P25_TRUNKING_SITE;
    } else if(follow && opcode==0x00u) {
        if(grant(t,(uint16_t)(arg>>40),(uint16_t)(arg>>24),(uint32_t)(arg&0xffffffu),
                 (uint8_t)(arg>>56),now_ms))event=P25_TRUNKING_GRANT;
    } else if(follow && opcode==0x02u) {
        if(grant(t,(uint16_t)(arg>>48),(uint16_t)(arg>>32),0,0,now_ms) ||
           grant(t,(uint16_t)(arg>>16),(uint16_t)arg,0,0,now_ms))event=P25_TRUNKING_GRANT;
    } else if(follow && opcode==0x03u) {
        if(grant(t,(uint16_t)(arg>>32),(uint16_t)arg,0,(uint8_t)(arg>>56),now_ms))event=P25_TRUNKING_GRANT;
    }
    if(event!=P25_TRUNKING_IGNORED) {
        t->learned_nac=nac;t->have_nac=true;t->last_control_ms=now_ms;
    }
    return event;
}
p25_trunking_event p25_trunking_consume(p25_trunking *t,uint16_t nac,
                                      const uint8_t block[12],uint32_t now_ms) {
    return consume(t,nac,block,now_ms,true);
}
p25_trunking_event p25_trunking_consume_control(p25_trunking *t,uint16_t nac,
                                              const uint8_t block[12],uint32_t now_ms) {
    return consume(t,nac,block,now_ms,false);
}
p25_trunking_event p25_trunking_consume_ambt(p25_trunking *t,const uint8_t *frame,
    size_t bytes,uint32_t now_ms,bool follow,uint8_t *opcode,uint8_t validated_block[12]) {
    if(!t || !opcode)return P25_TRUNKING_IGNORED;
    uint8_t header[12],payload[24],block[12]={0};
    if(!p25_data_ambt_integrity(frame,bytes,header,payload))return P25_TRUNKING_IGNORED;
    uint64_t nid=0;
    for(unsigned i=24u;i<57u;++i)if(i!=35u)nid=(nid<<2)|p25_data_get_dibit(frame,i);
    uint16_t nac=(uint16_t)(nid>>52),system=(uint16_t)(((header[4]&15u)<<8)|header[5]);
    *opcode=header[7];block[0]=(uint8_t)(0x80u|header[7]);
    if(header[7]==0x3bu) {
        // One data block: WACN20, reserved4, channel-T16, channel-R16, SSC8.
        uint32_t wacn=((uint32_t)payload[0]<<12)|((uint32_t)payload[1]<<4)|(payload[2]>>4);
        uint64_t arg=((uint64_t)wacn<<36)|((uint64_t)system<<24)
            |((uint64_t)(((unsigned)payload[3]<<8)|payload[4])<<8)|payload[7];
        for(unsigned i=0;i<8u;++i)block[9u-i]=(uint8_t)(arg>>(i*8u));
    } else if(header[7]==0x3au) {
        // One data block: RFSS8, site8, channel-T16, channel-R16, SSC8, reserved8.
        uint64_t arg=((uint64_t)system<<40)|((uint64_t)payload[0]<<32)
            |((uint64_t)payload[1]<<24)|((uint64_t)(((unsigned)payload[2]<<8)|payload[3])<<8)
            |payload[6];
        for(unsigned i=0;i<8u;++i)block[9u-i]=(uint8_t)(arg>>(i*8u));
    } else {
        // One data block after the header carries channel-T/R and group.
        // The header LLID is the source; only downlink-T is used for passive RX.
        block[2]=header[8];block[3]=payload[2];block[4]=payload[3];
        block[5]=payload[6];block[6]=payload[7];
        memcpy(block+7,header+3,3u);
    }
    uint16_t crc=p25_data_crc16(block,10u);block[10]=(uint8_t)(crc>>8);block[11]=(uint8_t)crc;
    if(validated_block)memcpy(validated_block,block,12u);
    return consume(t,nac,block,now_ms,follow);
}
bool p25_trunking_tune_request(const p25_trunking *t,uint32_t *hz) {
    if(!t || !hz || !t->pending_hz || t->phase==P25_TRUNKING_STOPPED)return false;
    *hz=t->pending_hz;return true;
}
void p25_trunking_tune_result(p25_trunking *t,bool success,uint32_t now_ms) {
    if(!t || !t->pending_hz || t->phase==P25_TRUNKING_STOPPED)return;
    if(!success) {++t->tune_failures;p25_trunking_stop(t);return;}
    t->receiver_hz=t->pending_hz;t->pending_hz=0;
    t->phase=t->receiver_hz==t->control_hz ? P25_TRUNKING_CONTROL : P25_TRUNKING_VOICE;
    t->voice_started_ms=t->last_voice_ms=now_ms;t->have_voice=false;
    if(t->phase==P25_TRUNKING_CONTROL)t->source=t->group=t->voice_channel=t->service_options=0;
}
bool p25_trunking_voice(p25_trunking *t,uint16_t nac,uint16_t group,uint32_t now_ms) {
    if(!t || t->phase!=P25_TRUNKING_VOICE || t->pending_hz ||
       nac!=t->learned_nac || group!=t->group)return false;
    t->have_voice=true;t->last_voice_ms=now_ms;return true;
}
void p25_trunking_end(p25_trunking *t,uint32_t now_ms) {
    if(t && t->phase==P25_TRUNKING_VOICE && !t->pending_hz)request(t,t->control_hz,now_ms);
}
void p25_trunking_poll(p25_trunking *t,uint32_t now_ms) {
    if(!t || t->phase==P25_TRUNKING_STOPPED)return;
    if(t->pending_hz) {
        if((uint32_t)(now_ms-t->tune_requested_ms)>=P25_TRUNKING_ACQUIRE_MS) {
            ++t->tune_failures;p25_trunking_stop(t);
        }
    } else if(t->phase==P25_TRUNKING_VOICE &&
             ((uint32_t)(now_ms-t->voice_started_ms)>=P25_TRUNKING_MAX_VOICE_MS ||
              (t->have_voice ? (uint32_t)(now_ms-t->last_voice_ms)>=P25_TRUNKING_IDLE_MS :
                              (uint32_t)(now_ms-t->voice_started_ms)>=P25_TRUNKING_ACQUIRE_MS)))
        request(t,t->control_hz,now_ms);
}
void p25_trunking_stop(p25_trunking *t) {
    if(t) {t->phase=P25_TRUNKING_STOPPED;t->pending_hz=0;t->have_voice=false;}
}
