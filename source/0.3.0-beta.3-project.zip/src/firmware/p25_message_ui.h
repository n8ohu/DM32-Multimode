// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_MESSAGE_UI_H
#define P25_MESSAGE_UI_H
static radio_message message_draft;
static radio_text_input message_input;
static uint32_t message_selected;
static uint8_t message_format=2;
static bool message_inbox=true,message_text_edit,message_to_edit,message_send_review,message_ack;
static char message_to_digits[9];
static unsigned message_to_count;
static const char *message_notice="";
static const char *message_format_name(unsigned format) {return format==0 ? "Motorola TMS" : format==1 ? "ETSI short text" : "ETSI IP text";}
static radio_mail_item *message_list_item(unsigned index) {
    for(unsigned i=0;i<mailbox.count;++i)if((mailbox.items[i].state==RADIO_MAIL_RECEIVED)==message_inbox)
        {if(!index--)return &mailbox.items[i];}
    return NULL;
}
static unsigned message_menu_count(void) {
    if(menu_page==MENU_MESSAGES)return 3u;
    if(menu_page==MENU_MESSAGE_COMPOSE)return 6u;
    if(menu_page==MENU_MESSAGE_VIEW)return 2u;
    unsigned n=0;while(message_list_item(n))++n;return n ? n : 1u;
}
static void message_compose(const radio_mail_item *reply) {
    memset(&message_draft,0,sizeof message_draft);memset(&message_input,0,sizeof message_input);
    message_draft.protocol=feature_dmr() ? RADIO_PROTOCOL_DMR : RADIO_PROTOCOL_P25;
    message_draft.kind=feature_dmr() && !radio_channel_get_private(channel_record) ? RADIO_CALL_GROUP : RADIO_CALL_INDIVIDUAL;
    message_draft.source=control.source_id;
    message_draft.destination=feature_dmr() || radio_channel_get_private(channel_record) ? radio_channel_get_destination(channel_record) : 1u;
    message_format=feature_dmr() ? 2u : 0u;message_ack=false;
    if(reply) {
        if(reply->message.protocol!=message_draft.protocol || memcmp(reply->channel,channel_record,8)
           || (feature_p25() ? feature_u16(reply->channel+8)!=control.nac
               : radio_channel_get_color_code(reply->channel)!=radio_channel_get_color_code(channel_record)
                 || radio_channel_get_timeslot(reply->channel)!=radio_channel_get_timeslot(channel_record))) {
            message_notice="Select the received channel first";return;
        }
        message_draft.kind=RADIO_CALL_INDIVIDUAL;message_draft.destination=reply->message.source;
        message_format=reply->format;
    }
    message_text_edit=message_to_edit=message_send_review=false;message_notice="";
    menu_page=MENU_MESSAGE_COMPOSE;menu_item=0;
}
static void message_menu_row(unsigned item,char *label,size_t label_n,char *value,size_t value_n) {
    if(menu_page==MENU_MESSAGES) {
        const char *names[]={"Inbox","Outbox","New message"};snprintf(label,label_n,"%s",names[item]);
        if(item==0)snprintf(value,value_n,"%u unread / power session",radio_mail_unread(&mailbox));
        else if(item==1)snprintf(value,value_n,"Sent, delivered and failed");
        else snprintf(value,value_n,"%s / current channel",feature_mode_name());
    } else if(menu_page==MENU_MESSAGE_LIST) {
        radio_mail_item *m=message_list_item(item);
        if(!m) {snprintf(label,label_n,"%s is empty",message_inbox ? "Inbox" : "Outbox");snprintf(value,value_n,"Messages clear on power off");return;}
        uint32_t id=message_inbox ? m->message.source : m->message.destination;char name[25];
        (void)radio_contact_name(call_contacts,RADIO_CONTACT_CAPACITY,m->message.protocol,message_inbox ? RADIO_CALL_INDIVIDUAL : m->message.kind,id,name);
        if(name[0])snprintf(label,label_n,"%s%.24s",m->unread ? "* " : "",name);
        else snprintf(label,label_n,"%s%s %lu",m->unread ? "* " : "",message_inbox ? "From" : "To",(unsigned long)id);
        snprintf(value,value_n,"%s / %.22s",radio_mail_state_name(m->state),m->message.text);
    } else if(menu_page==MENU_MESSAGE_COMPOSE) {
        const char *names[]={"Destination","Call path","Text format","Message","Delivery confirmation","Send message"};
        snprintf(label,label_n,"%s",names[item]);
        if(item==0) {char name[25];(void)radio_contact_name(call_contacts,RADIO_CONTACT_CAPACITY,message_draft.protocol,message_draft.kind,message_draft.destination,name);
            snprintf(value,value_n,"%lu %s",(unsigned long)message_draft.destination,name);}
        else if(item==1)snprintf(value,value_n,"%s",message_draft.kind ? "Individual radio" : "DMR group");
        else if(item==2)snprintf(value,value_n,"%s",message_format_name(message_format));
        else if(item==3)snprintf(value,value_n,"%.40s",message_input.text[0] ? message_input.text : "Enter text on keypad");
        else if(item==4)snprintf(value,value_n,"%s",message_ack ? "Requested" : "Not requested / unconfirmed");
        else snprintf(value,value_n,"Review before transmitting");
    }
}
static bool message_ui_draw(void) {
    if(!message_menu_active() || (menu_page!=MENU_MESSAGE_VIEW && !message_text_edit && !message_to_edit && !message_send_review))return false;
    char line[80];gfx_text(&font_12x24,8,44,message_send_review ? "Send message?" : message_to_edit ? "Destination ID" : message_text_edit ? "Message text" : "Message",P25_UI_FG);
    const radio_mail_item *m=radio_mail_find(&mailbox,message_selected);
    const char *text=message_input.text;
    if(menu_page==MENU_MESSAGE_VIEW) {
        if(!m) {gfx_text(&font_8x16,8,92,"Message no longer stored",P25_UI_AMBER);return true;}
        text=m->message.text;
        snprintf(line,sizeof line,"%s %s %lu",m->message.protocol==RADIO_PROTOCOL_P25 ? "P25" : "DMR",m->state==RADIO_MAIL_RECEIVED ? "from" : "to",
            (unsigned long)(m->state==RADIO_MAIL_RECEIVED ? m->message.source : m->message.destination));
        p25_ui_text(&font_8x16,8,80,204,line,P25_UI_CYAN);
        snprintf(line,sizeof line,"%s / %s",radio_mail_state_name(m->state),message_format_name(m->format));
        p25_ui_text(&font_6x12,8,102,204,line,P25_UI_MUTED);
    } else if(message_to_edit) {
        gfx_text(&font_12x24,8,100,message_to_count ? message_to_digits : "_",P25_UI_CYAN);
        gfx_text(&font_6x12,8,148,message_draft.kind ? "Unit ID 1-16777215" : "Group ID 1-16777215",P25_UI_MUTED);
        gfx_text(&font_6x12,8,276,"Digits: ID   *: erase",P25_UI_MUTED);
        gfx_text(&font_6x12,8,294,"OK: accept   Back: cancel",P25_UI_CYAN);return true;
    } else {
        snprintf(line,sizeof line,"%s %s %lu",message_draft.protocol==RADIO_PROTOCOL_P25 ? "P25" : "DMR",message_draft.kind ? "to" : "TG",(unsigned long)message_draft.destination);
        p25_ui_text(&font_8x16,8,80,204,line,P25_UI_CYAN);
        p25_ui_text(&font_6x12,8,102,204,message_format_name(message_format),P25_UI_MUTED);
    }
    size_t len=strlen(text),start=0;
    for(unsigned row=0;row<6 && start<len;++row) {
        size_t end=start+25u;if(end>len)end=len;
        if(end<len && text[end]!=' ')for(size_t split=end;split>start;--split)
            if(text[split-1u]==' ') {end=split-1u;break;}
        if(end==start) {++start;--row;continue;}
        memcpy(line,text+start,end-start);line[end-start]=0;
        gfx_text(&font_8x16,8,120+(int)row*17,line,P25_UI_FG);
        start=end;while(start<len && text[start]==' ')++start;
    }
    if(message_send_review) {
        gfx_text(&font_6x12,8,236,"Uses the current channel and power",P25_UI_AMBER);
        gfx_text(&font_8x16,8,274,"OK: send   Back: cancel",P25_UI_CYAN);
    } else if(message_text_edit) {
        snprintf(line,sizeof line,"%u / 80 characters",(unsigned)len);gfx_text(&font_6x12,8,232,line,P25_UI_MUTED);
        gfx_text(&font_6x12,8,256,"2-9: letters  0: space  1: .?!",P25_UI_MUTED);
        gfx_text(&font_6x12,8,274,"*: erase  Right: next character",P25_UI_MUTED);
        gfx_text(&font_6x12,8,294,"OK: done  Back: return",P25_UI_CYAN);
    } else {
        if(m->truncated)gfx_text(&font_6x12,8,224,"Limited to 80 display characters",P25_UI_AMBER);
        gfx_text(&font_8x16,8,256,menu_item ? "Reply    > Delete" : "> Reply    Delete",P25_UI_CYAN);
        p25_ui_text(&font_6x12,8,280,204,message_notice,P25_UI_AMBER);
        gfx_text(&font_6x12,8,294,"Up/Down: choose  OK: open  Back",P25_UI_MUTED);
    }
    return true;
}
static bool message_ui_action(unsigned action,bool down) {
    if(!message_menu_active())return false;
    if(down || call_active || prepared) {if(action==ACT_BACK)control.cancel=true;return true;}
    if(message_text_edit) {
        if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9)(void)radio_text_key(&message_input,action-ACT_DIGIT_0,hal_millis());
        else if(action==ACT_QUICK)radio_text_erase(&message_input);
        else if(action==ACT_NAV_RIGHT || action==ACT_CONTEXT)message_input.pending=false;
        else if(action==ACT_SELECT || action==ACT_BACK) {message_text_edit=false;message_input.pending=false;}
    } else if(message_to_edit) {
        if(action>=ACT_DIGIT_0 && action<=ACT_DIGIT_9 && message_to_count<8u) {message_to_digits[message_to_count++]=(char)('0'+action-ACT_DIGIT_0);message_to_digits[message_to_count]=0;}
        else if(action==ACT_QUICK && message_to_count)message_to_digits[--message_to_count]=0;
        else if(action==ACT_BACK)message_to_edit=false;
        else if(action==ACT_SELECT) {
            uint32_t id=0;for(unsigned i=0;i<message_to_count;++i)id=id*10u+(unsigned)(message_to_digits[i]-'0');
            if(radio_address_valid(message_draft.protocol,message_draft.kind,id)) {message_draft.destination=id;message_to_edit=false;}
        }
    } else if(message_send_review) {
        if(action==ACT_BACK)message_send_review=false;
        else if(action==ACT_SELECT) {
            do {++message_host_serial;}while(!message_host_serial || radio_mail_token(&mailbox,message_host_serial));
            message_draft.token=message_host_serial;memcpy(message_draft.text,message_input.text,sizeof message_draft.text);
            radio_mail_item *m=message_enqueue(&message_draft,message_format,message_ack,channel_record);
            message_send_review=false;
            if(m) {message_selected=m->id;message_inbox=false;menu_page=MENU_MESSAGE_VIEW;menu_item=0;message_notice="Queued / waiting for clear channel";}
            else message_notice="Cannot send: channel, TX or mailbox";
        }
    } else if(action==ACT_BACK) {
        if(menu_page==MENU_MESSAGES) {menu_page=MENU_MEMORY;menu_item=7;}
        else if(menu_page==MENU_MESSAGE_VIEW) {menu_page=MENU_MESSAGE_LIST;menu_item=0;}
        else {menu_page=MENU_MESSAGES;menu_item=0;}
    } else if(action==ACT_NAV_UP || action==ACT_NAV_DOWN) {
        unsigned count=message_menu_count();menu_item=(menu_item+(action==ACT_NAV_UP ? count-1u : 1u))%count;
    } else if(action==ACT_SELECT) {
        if(menu_page==MENU_MESSAGES) {
            if(menu_item==2) {if(feature_fm())message_notice="Select a digital channel";else message_compose(NULL);}
            else {message_inbox=menu_item==0;menu_page=MENU_MESSAGE_LIST;menu_item=0;}
        } else if(menu_page==MENU_MESSAGE_LIST) {
            radio_mail_item *m=message_list_item(menu_item);
            if(m) {message_selected=m->id;(void)radio_mail_read(&mailbox,m->id);menu_page=MENU_MESSAGE_VIEW;menu_item=0;message_notice="";}
        } else if(menu_page==MENU_MESSAGE_VIEW) {
            radio_mail_item *m=radio_mail_find(&mailbox,message_selected);
            if(menu_item) {if(radio_mail_delete(&mailbox,message_selected)) {menu_page=MENU_MESSAGE_LIST;menu_item=0;}else message_notice="Wait for transmission to finish";}
            else if(m && m->state==RADIO_MAIL_RECEIVED)message_compose(m);
            else message_notice="Reply is available for received text";
        } else if(menu_page==MENU_MESSAGE_COMPOSE) {
            if(menu_item==0) {message_to_edit=true;message_to_count=0;message_to_digits[0]=0;}
            else if(menu_item==1 && message_draft.protocol==RADIO_PROTOCOL_DMR) {message_draft.kind^=1u;message_ack=false;}
            else if(menu_item==2 && message_draft.protocol==RADIO_PROTOCOL_DMR) {message_format=(uint8_t)((message_format+1u)%3u);message_ack=false;}
            else if(menu_item==3)message_text_edit=true;
            else if(menu_item==4 && message_draft.protocol==RADIO_PROTOCOL_DMR && message_draft.kind && message_format!=2u)message_ack=!message_ack;
            else if(menu_item==5 && message_input.text[0])message_send_review=true;
        }
    }
    screen("MESSAGES");return true;
}
#endif
