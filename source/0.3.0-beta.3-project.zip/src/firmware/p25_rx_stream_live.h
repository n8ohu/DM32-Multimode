// SPDX-License-Identifier: GPL-3.0-or-later
// Finite lab RX stream, borrowing monitor.raw/pcm exclusively. No RF dispatch.
#ifndef P25_RX_STREAM_LIVE_H
#define P25_RX_STREAM_LIVE_H
#if DM32_TRUNK_SUBSCRIBER
#include "p25_rx_stream.h"
#include "p25_rx_origin.h"
#include "p25_rx_early.h"
static p25_rx_stream trunk_rx_stream;
static volatile bool trunk_rx_stream_timer_running;
static bool trunk_rx_stream_dump;
static uint16_t trunk_rx_stream_readout_halves,trunk_rx_stream_readout_markers;
static uint8_t trunk_rx_stream_readout_state;
static struct {
    uint32_t calls,total_us,max_us,yields;
    uint32_t irq_overlap_us,irq_overlap_max_us,emit_calls,emit_total_us,emit_max_us;
} trunk_rx_stream_work;
// Scope is these owned IRQ handler bodies, not all interrupt/RTOS overhead.
// The platform's interrupt entry disables nesting, so these totals do not overlap.
static volatile struct {
    uint32_t calls,total_us,max_us;
} trunk_rx_stream_irq_work[2]; // 0=SYS,1=Timer5
static void trunk_rx_stream_irq_cost(unsigned kind,uint32_t begin) {
    if(!trunk_rx_stream_owned||kind>=2u)return;
    uint32_t elapsed=hrc_micros()-begin;
    ++trunk_rx_stream_irq_work[kind].calls;
    trunk_rx_stream_irq_work[kind].total_us+=elapsed;
    if(elapsed>trunk_rx_stream_irq_work[kind].max_us)
        trunk_rx_stream_irq_work[kind].max_us=elapsed;
}
static struct {
    uint32_t produced,consumed,verified,stream_epoch,units,carrier_hz;
    uint32_t worker_calls,worker_total_us,worker_max_us,worker_yields;
    uint16_t samples,guard_us,faults;
    uint8_t schema;
} trunk_rx_stream_readout;
static uint32_t trunk_rx_origin_carrier_hz;
typedef struct {
    const p25_rx_stream_chunk *chunk;
    uint32_t input_ordinal;
} trunk_rx_origin_context;
static bool trunk_rx_origin_owned(void) {
    return trunk_rx_stream_owned&&trunk_rx_stream.marker_schema==1u;
}
static bool trunk_rx_early_owned(void) {
    return trunk_rx_stream_owned&&trunk_rx_stream.marker_schema==2u;
}
static bool trunk_rx_witness_owned(void) {
    return trunk_rx_origin_owned()||trunk_rx_early_owned();
}
static bool trunk_rx_witness_encode(unsigned char bytes[64],const p25_rx_origin_event *event) {
    return trunk_rx_early_owned()?p25_rx_early_encode(bytes,event):p25_rx_origin_encode(bytes,event);
}
static void trunk_rx_witness_store(const unsigned char bytes[64]) {
    if(trunk_rx_early_owned())(void)p25_rx_stream_early_marker(&trunk_rx_stream,bytes);
    else (void)p25_rx_stream_origin_marker(&trunk_rx_stream,bytes);
}
static void trunk_rx_origin_fault(unsigned fault_reason) {
    if(!trunk_rx_witness_owned())return;
    p25_rx_origin_event event={.cpu_us=hrc_micros(),
        .stream_epoch=trunk_rx_stream.stream_epoch,.lane_epoch=monitor.demod.lane_epoch,
        .type=P25_RX_ORIGIN_FAULT,.lane=255u};
    event.data[0]=(unsigned char)fault_reason;
    unsigned char bytes[64];
    if(!trunk_rx_witness_encode(bytes,&event))return;
    uint32_t lock=hrc_irq_save();
    trunk_rx_witness_store(bytes);hrc_irq_restore(lock);
}
static bool trunk_rx_origin_source(p25_rx_origin_event *event,void *context) {
    const trunk_rx_origin_context *source=context;
    if(!source||!source->chunk||source->chunk->first_sample>(trunk_rx_early_owned()?4080u:8176u)
       ||source->input_ordinal<source->chunk->first_sample
       ||source->input_ordinal-source->chunk->first_sample>=16u) {
        trunk_rx_origin_fault(P25_RX_ORIGIN_CONTEXT_LOST);
        p25_rx_stream_cancel(&trunk_rx_stream);return false;
    }
    const p25_rx_stream_chunk *chunk=source->chunk;
    event->cpu_us=hrc_micros();event->read_begin_us=chunk->read_begin_us;
    event->read_end_us=chunk->read_end_us;event->origin_irq_us=chunk->origin_irq_us;
    event->origin_irq_count=chunk->origin_irq_count;
    event->chunk_first_sample=(uint16_t)chunk->first_sample;
    event->source_flags=chunk->flags;event->delivery_input_ordinal=source->input_ordinal;
    return true;
}
static void trunk_rx_origin_publish(const p25_rx_origin_event *event) {
    unsigned char bytes[64];
    if(!trunk_rx_witness_encode(bytes,event)) {
        trunk_rx_origin_fault(P25_RX_ORIGIN_CONTEXT_LOST);
        p25_rx_stream_cancel(&trunk_rx_stream);return;
    }
    uint32_t lock=hrc_irq_save();
    trunk_rx_witness_store(bytes);hrc_irq_restore(lock);
}
static const char *trunk_rx_stream_state_name(unsigned state) {
    switch(state) {
    case P25_RX_STREAM_WAIT:return "waiting";
    case P25_RX_STREAM_RUNNING:return "recording";
    case P25_RX_STREAM_DRAINING:return "draining";
    case P25_RX_STREAM_COMPLETE:return "complete";
    case P25_RX_STREAM_FAULT:return "fault";
    case P25_RX_STREAM_CANCELLED:return "cancelled";
    case P25_RX_STREAM_TIMEOUT:return "timeout";
    default:return "idle";
    }
}
static bool trunk_rx_stream_timer_active(void) {return trunk_rx_stream_timer_running;}
static void trunk_rx_stream_timer_stop(void) {
    if(!trunk_rx_stream_timer_running)return;
    trunk_rx_stream_timer_running=false;
    hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,false);
}
static void trunk_rx_stream_irq(unsigned half,uint32_t now) {
    if(trunk_rx_stream_owned)p25_rx_stream_irq(&trunk_rx_stream,half,now);
}
static void trunk_rx_stream_timer_tick(void) {
    hrc_timer_ack(TIMER_BOARD);
    if(!trunk_rx_stream_timer_running)return;
    if(!trunk_rx_stream_owned||!trunk_enabled||!mon_enabled||!mon_running||mon_failed
       ||control.cancel||!dev||!dev->buf) {
        p25_rx_stream_cancel(&trunk_rx_stream);trunk_rx_stream_timer_stop();return;
    }
    p25_rx_progress_io io={.context=(void *)(dev->buf+C7_FM_RX_AUDIO),
        .read_byte=trunk_rx_progress_byte,.clock_us=trunk_rx_progress_clock,
        .half_pending=trunk_rx_progress_half_pending};
    bool published=p25_rx_stream_step(&trunk_rx_stream,&io,hrc_micros());
    if(published&&mon_task_handle) {
        BaseType_t woken=pdFALSE;vTaskNotifyGiveFromISR(mon_task_handle,&woken);
        portYIELD_FROM_ISR(woken);
    }
    if(!p25_rx_stream_active(&trunk_rx_stream))trunk_rx_stream_timer_stop();
    else hrc_timer_oneshot(TIMER_BOARD,500u);
}
static void trunk_rx_stream_frame(const p25_rx *frame,void *context) {
    if(!trunk_rx_stream_owned||(!p25_rx_stream_active(&trunk_rx_stream)
       &&trunk_rx_stream.state!=P25_RX_STREAM_DRAINING))return;
    // Deliberately exclude mon_receive/passive consume: neither voice audio,
    // grant following, addressed session actions nor retuning is allowed here.
    if(frame->duid!=7u||(!trunk_rx_witness_owned()&&frame->nac!=TRUNK_PROBE_NAC))return;
    uint32_t begin=hrc_micros();
    p25_tsdu unit;bool decoded=p25_tsdu_decode(frame->frame,frame->frame_bytes,&unit);
    uint32_t elapsed=hrc_micros()-begin;
    ++trunk_rx_stream_work.emit_calls;trunk_rx_stream_work.emit_total_us+=elapsed;
    if(elapsed>trunk_rx_stream_work.emit_max_us)trunk_rx_stream_work.emit_max_us=elapsed;
    if(!decoded)return;
    if(trunk_rx_witness_owned()) {
        for(unsigned i=0;i<unit.count;++i) {
            p25_rx_origin_event event={.stream_epoch=trunk_rx_stream.stream_epoch,
                .lane_epoch=monitor.demod.lane_epoch,.nac=frame->nac,
                .type=P25_RX_ORIGIN_UNIT,.duid=7u,.lane=255u,
                .evidence=P25_RX_ORIGIN_NATIVE_CRC,
                .block_descriptor=(uint8_t)((unit.count<<4)|i)};
            if(!trunk_rx_origin_source(&event,context))return;
            // This is callback INPUT time, not a reconstructed frame end or FSW.
            event.event_tick=(uint64_t)event.delivery_input_ordinal*6u;
            memcpy(event.data,unit.block[i],sizeof event.data);
            trunk_rx_origin_publish(&event);
        }
    }
    if(frame->nac!=TRUNK_PROBE_NAC)return;
    ++trunk_units;
    for(unsigned i=0;i<unit.count;++i)
        (void)p25_trunking_consume_control(&trunk,unit.nac,unit.block[i],hrc_micros()/1000u);
}
static void trunk_rx_stream_status(const p25_demod_status *status,void *context) {
    if(!trunk_rx_stream_owned||!status)return;
    if(trunk_rx_witness_owned()) {
        if(!status->status||!status->selected||status->duid!=7u) {
            trunk_rx_origin_fault(P25_RX_ORIGIN_LANE_LOSS);return;
        }
        p25_rx_origin_event event={.event_tick=status->sample_tick,
            .stream_epoch=status->stream_epoch,.lane_epoch=status->lane_epoch,
            .nac=status->nac,.type=P25_RX_ORIGIN_STATUS,.duid=status->duid,
            .status=status->status,.lane=status->lane,
            .evidence=(uint8_t)((status->selected?P25_RX_ORIGIN_SELECTED:0u)
                |(status->qualified?P25_RX_ORIGIN_QUALIFIED:0u))};
        if(trunk_rx_origin_source(&event,context))trunk_rx_origin_publish(&event);
        return;
    }
    unsigned char bytes[32]={0};
    for(unsigned i=0;i<8u;++i)bytes[i]=(unsigned char)(status->sample_tick>>(8u*i));
    uint32_t words[3]={hrc_micros(),status->stream_epoch,status->lane_epoch};
    for(unsigned w=0;w<3u;++w)for(unsigned i=0;i<4u;++i)
        bytes[8u+4u*w+i]=(unsigned char)(words[w]>>(8u*i));
    bytes[20]=(unsigned char)status->nac;bytes[21]=(unsigned char)(status->nac>>8);
    bytes[22]=status->status;bytes[23]=status->lane;
    bytes[24]=(unsigned char)status->qualified;bytes[25]=(unsigned char)status->selected;
    // Timer cannot modify marker storage. Protect the small state/count update
    // against terminal faults while preserving the original demod timestamp.
    uint32_t lock=hrc_irq_save();(void)p25_rx_stream_marker(&trunk_rx_stream,bytes);hrc_irq_restore(lock);
}
static void trunk_rx_stream_early(const p25_demod_status *status,void *context) {
    if(!trunk_rx_early_owned()||!status)return;
    // This NAC/DUID is inherited from the prior CRC-valid selected lane. The
    // current NID has NOT been checked. Never feed this to the slot/session gate.
    p25_rx_origin_event event={.event_tick=status->sample_tick,
        .stream_epoch=status->stream_epoch,.lane_epoch=status->lane_epoch,
        .nac=status->nac,.type=P25_RX_EARLY_STATUS,.duid=status->duid,
        .status=status->status,.lane=status->lane,
        .evidence=(uint8_t)((status->selected?P25_RX_ORIGIN_SELECTED:0u)
            |(status->qualified?P25_RX_ORIGIN_QUALIFIED:0u))};
    if(trunk_rx_origin_source(&event,context))trunk_rx_origin_publish(&event);
}
static void trunk_rx_stream_worker(void) {
    if(!trunk_rx_stream_owned)return;
    p25_rx_stream_chunk chunk;
    uint32_t lock=hrc_irq_save();
    uint32_t begin=hrc_micros();
    uint32_t irq_begin=trunk_rx_stream_irq_work[0].total_us+trunk_rx_stream_irq_work[1].total_us;
    bool have=p25_rx_stream_pop(&trunk_rx_stream,&chunk,begin);
    hrc_irq_restore(lock);
    if(have) {
        trunk_rx_origin_context source={.chunk=&chunk};
        for(unsigned i=0;i<16u;++i) {
            // A producer fault revokes this epoch immediately. No discontinuous
            // input is restamped or silently bridged into the demodulator.
            if(!p25_rx_stream_active(&trunk_rx_stream)
               &&trunk_rx_stream.state!=P25_RX_STREAM_DRAINING)break;
            source.input_ordinal=(uint32_t)chunk.first_sample+i;
            bool continuous;
            if(trunk_rx_early_owned())continuous=p25_demod_push_at_observed(&monitor.demod,chunk.samples[i],
                (chunk.first_sample+i)*6u,trunk_rx_stream.stream_epoch,
                trunk_rx_stream_frame,trunk_rx_stream_status,trunk_rx_stream_early,&source);
            else continuous=p25_demod_push_at(&monitor.demod,chunk.samples[i],
                (chunk.first_sample+i)*6u,trunk_rx_stream.stream_epoch,
                trunk_rx_stream_frame,trunk_rx_stream_status,
                trunk_rx_origin_owned()?(void *)&source:NULL);
            if(!continuous&&trunk_rx_witness_owned())trunk_rx_origin_fault(P25_RX_ORIGIN_SAMPLE_GAP);
        }
        // Elapsed worker service includes IRQ preemption and excludes task
        // notification waits/yields. It is not a CPU-utilization measurement.
        lock=hrc_irq_save();
        uint32_t elapsed=hrc_micros()-begin;
        uint32_t overlap=trunk_rx_stream_irq_work[0].total_us+trunk_rx_stream_irq_work[1].total_us-irq_begin;
        hrc_irq_restore(lock);
        ++trunk_rx_stream_work.calls;trunk_rx_stream_work.total_us+=elapsed;
        if(elapsed>trunk_rx_stream_work.max_us)trunk_rx_stream_work.max_us=elapsed;
        trunk_rx_stream_work.irq_overlap_us+=overlap;
        if(overlap>trunk_rx_stream_work.irq_overlap_max_us)trunk_rx_stream_work.irq_overlap_max_us=overlap;
    }
    // At most one chunk of DSP per invocation. Finalization runs in a task,
    // never in Timer5. Main task alone shuts down the receiver/changes UI.
    if(!p25_rx_stream_active(&trunk_rx_stream))p25_rx_stream_finalize(&trunk_rx_stream);
}
static bool trunk_rx_stream_backlog(void) {
    return trunk_rx_stream_owned
        &&(p25_rx_stream_active(&trunk_rx_stream)||trunk_rx_stream.state==P25_RX_STREAM_DRAINING)
        &&trunk_rx_stream.consumed<trunk_rx_stream.produced;
}
static void trunk_rx_stream_service(void) {
    if(!trunk_rx_stream_owned)return;
    // Coalesced notifications represent wakeups, not a one-chunk work budget.
    // Never wait again while the ring already contains work. Bound catch-up by
    // both eight chunks and 14 ms of elapsed service, checked between chunks.
    // One in-flight chunk can exceed the elapsed budget. A remaining backlog
    // must block a tick: taskYIELD alone cannot run the lower-priority controller.
    if(!trunk_rx_stream_backlog())(void)ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(1));
    uint32_t begin=hrc_micros();
    for(unsigned chunk=0;chunk<8u;++chunk) {
        trunk_rx_stream_worker();
        if(!trunk_rx_stream_backlog())return;
        if((uint32_t)(hrc_micros()-begin)>=14000u)break;
    }
    ++trunk_rx_stream_work.yields;
    vTaskDelay(1);
}
static void trunk_rx_stream_release(void) {
    if(!trunk_rx_stream_owned)return;
    if(p25_rx_stream_active(&trunk_rx_stream)||trunk_rx_stream.state==P25_RX_STREAM_DRAINING)
        // The common release path does not establish that RF was retuned.
        trunk_rx_origin_fault(P25_RX_ORIGIN_CONTEXT_LOST);
    telemetry_abort_after_row();
    uint32_t lock=hrc_irq_save();
    trunk_rx_stream_timer_stop();p25_rx_stream_cancel(&trunk_rx_stream);
    monitor.demod.rare_fec_clock_us=NULL;
    // The priority6 worker never blocks inside demod/callbacks. A lower priority
    // controller can run this release only after that invocation returned.
    trunk_rx_stream_owned=false;hrc_irq_restore(lock);
    if(mon_running)mon_stop("rx_stream_stopped");
    p25_rx_stream_finalize(&trunk_rx_stream);
    trunk_rx_stream.ring=NULL;trunk_rx_stream.ledger=NULL;trunk_rx_stream_dump=false;
}
static bool trunk_rx_stream_start_mode(unsigned samples,unsigned guard,bool down,unsigned schema) {
    if(schema>2u||(schema&&(samples<256u||samples>(schema==2u?P25_RX_EARLY_MAX_SAMPLES:P25_RX_ORIGIN_MAX_SAMPLES)||samples%256u)))return false;
    if(trunk_rx_stream_owned||trunk_rx_progress_owned||trunk_enabled||telemetry_pending()
       ||!trunk_rx_progress_context(down))return false;
    if(!trunk_start())return false;
    trunk_rx_feed_release();
    mon_discard_audio();
    uint32_t lock=hrc_irq_save();
    bool ok=schema==2u?p25_rx_stream_early_start(&trunk_rx_stream,(unsigned char *)monitor.raw,sizeof monitor.raw,
        (unsigned char *)monitor.pcm,sizeof monitor.pcm,samples,guard,trunk_stream_epoch,hrc_micros()):
        schema==1u?p25_rx_stream_origin_start(&trunk_rx_stream,(unsigned char *)monitor.raw,sizeof monitor.raw,
        (unsigned char *)monitor.pcm,sizeof monitor.pcm,samples,guard,trunk_stream_epoch,hrc_micros()):
        p25_rx_stream_start(&trunk_rx_stream,(unsigned char *)monitor.raw,sizeof monitor.raw,
        (unsigned char *)monitor.pcm,sizeof monitor.pcm,samples,guard,trunk_stream_epoch,hrc_micros());
    if(ok) {
        trunk_rx_origin_carrier_hz=frequency;
        memset(&trunk_rx_stream_work,0,sizeof trunk_rx_stream_work);
        for(unsigned i=0;i<2u;++i) {
            trunk_rx_stream_irq_work[i].calls=trunk_rx_stream_irq_work[i].total_us=0;
            trunk_rx_stream_irq_work[i].max_us=0;
        }
        monitor.demod.rare_fec_clock_us=hrc_micros;
        trunk_rx_stream_owned=true;trunk_rx_stream_dump=false;
        trunk_rx_stream_timer_running=true;hrc_timer_stop(TIMER_BOARD);
        hrc_irq_enable(IRQ_TIMER5,true);hrc_timer_oneshot(TIMER_BOARD,500u);
    }
    hrc_irq_restore(lock);
    if(!ok) {trunk_stop("rx_stream_setup_failed");return false;}
    trunk_reason="rx_stream_waiting";return true;
}
static void trunk_rx_stream_poll(bool down) {
    if(!trunk_rx_stream_owned)return;
    if(p25_rx_stream_active(&trunk_rx_stream)||trunk_rx_stream.state==P25_RX_STREAM_DRAINING) {
        if(!trunk_rx_progress_context(down)||!trunk_enabled||!mon_enabled||!mon_running||mon_failed
           ||(p25_rx_stream_active(&trunk_rx_stream)&&!trunk_rx_stream_timer_running)) {
            uint32_t lock=hrc_irq_save();trunk_rx_stream_timer_stop();
            p25_rx_stream_cancel(&trunk_rx_stream);hrc_irq_restore(lock);
            ptt_release_required=true;ptt_release_seen=false;
        }
    }
    if(!p25_rx_stream_active(&trunk_rx_stream)&&trunk_rx_stream.state!=P25_RX_STREAM_DRAINING) {
        trunk_rx_stream_timer_stop();p25_rx_stream_finalize(&trunk_rx_stream);
        const char *why=trunk_rx_stream_state_name(trunk_rx_stream.state);
        if(mon_running)mon_stop(why);
        trunk_reason=why;
    }
}
static bool trunk_rx_stream_status_last(unsigned next) {
    return next==2u+(trunk_rx_stream_dump?
        trunk_rx_stream_readout_halves+trunk_rx_stream_readout_markers:0u);
}
static int trunk_rx_stream_status_row(unsigned row,char *line,size_t capacity) {
    bool early=trunk_rx_stream_readout.schema==2u;
    bool witness=early||trunk_rx_stream_readout.schema==P25_RX_ORIGIN_SCHEMA;
    const char *label=early?"RXEARLY":witness?"RXORIGIN":"RXSTREAM";
    if(!row&&witness)return snprintf(line,capacity,
        "%s schema=1 state=%s samples=%u produced=%lu consumed=%lu verified=%lu halves=%u events=%u guard_us=%u stream_epoch=%lu faults=%u half_bytes=48 event_bytes=64 marker_capacity=192 carrier_hz=%lu service=timer500 dump=%u units=%lu worker_calls=%lu worker_total_us=%lu worker_max_us=%lu worker_yields=%lu clock=recorder_unqualified%s\r\n",
        label,
        trunk_rx_stream_state_name(trunk_rx_stream_readout_state),(unsigned)trunk_rx_stream_readout.samples,
        (unsigned long)trunk_rx_stream_readout.produced,(unsigned long)trunk_rx_stream_readout.consumed,
        (unsigned long)trunk_rx_stream_readout.verified,(unsigned)trunk_rx_stream_readout_halves,
        (unsigned)trunk_rx_stream_readout_markers,(unsigned)trunk_rx_stream_readout.guard_us,
        (unsigned long)trunk_rx_stream_readout.stream_epoch,(unsigned)trunk_rx_stream_readout.faults,
        (unsigned long)trunk_rx_stream_readout.carrier_hz,(unsigned)trunk_rx_stream_dump,
        (unsigned long)trunk_rx_stream_readout.units,(unsigned long)trunk_rx_stream_readout.worker_calls,
        (unsigned long)trunk_rx_stream_readout.worker_total_us,(unsigned long)trunk_rx_stream_readout.worker_max_us,
        (unsigned long)trunk_rx_stream_readout.worker_yields,early?" early=prev_crc":"");
    if(!row)return snprintf(line,capacity,
        "RXSTREAM state=%s samples=%u produced=%lu consumed=%lu verified=%lu halves=%u markers=%u guard_us=%u stream_epoch=%lu faults=%u half_bytes=48 marker_bytes=32 service=timer500 dump=%u units=%lu worker_calls=%lu worker_total_us=%lu worker_max_us=%lu worker_yields=%lu clock=recorder_unqualified\r\n",
        trunk_rx_stream_state_name(trunk_rx_stream_readout_state),(unsigned)trunk_rx_stream_readout.samples,
        (unsigned long)trunk_rx_stream_readout.produced,(unsigned long)trunk_rx_stream_readout.consumed,
        (unsigned long)trunk_rx_stream_readout.verified,(unsigned)trunk_rx_stream_readout_halves,
        (unsigned)trunk_rx_stream_readout_markers,(unsigned)trunk_rx_stream_readout.guard_us,
        (unsigned long)trunk_rx_stream_readout.stream_epoch,(unsigned)trunk_rx_stream_readout.faults,
        (unsigned)trunk_rx_stream_dump,(unsigned long)trunk_rx_stream_readout.units,
        (unsigned long)trunk_rx_stream_readout.worker_calls,(unsigned long)trunk_rx_stream_readout.worker_total_us,
        (unsigned long)trunk_rx_stream_readout.worker_max_us,(unsigned long)trunk_rx_stream_readout.worker_yields);
    unsigned halves=trunk_rx_stream_dump?trunk_rx_stream_readout_halves:0u;
    unsigned marks=trunk_rx_stream_dump?trunk_rx_stream_readout_markers:0u;
    if(row<=halves+marks) {
        if(!trunk_rx_stream_owned||!trunk_rx_stream.ledger||p25_rx_stream_active(&trunk_rx_stream)
           ||trunk_rx_stream.state==P25_RX_STREAM_DRAINING)return -1;
        bool marker=row>halves;unsigned index=marker?row-halves-1u:row-1u;
        unsigned bytes=marker?(witness?64u:32u):48u;
        const unsigned char *data=trunk_rx_stream.ledger+(marker?3072u+index*bytes:index*48u);
        int n=snprintf(line,capacity,"%s_%s index=%u data=",label,
            marker?(witness?"EVENT":"MARK"):"HALF",index);
        if(n<0)return n;
        size_t prefix=(size_t)n,total=prefix+bytes*2u+2u;if(total>=capacity)return (int)total;
        static const char hex[]="0123456789ABCDEF";
        for(unsigned i=0;i<bytes;++i) {line[prefix+2u*i]=hex[data[i]>>4];line[prefix+2u*i+1u]=hex[data[i]&15u];}
        line[total-2u]='\r';line[total-1u]='\n';line[total]=0;return (int)total;
    }
    if(row==halves+marks+1u)return snprintf(line,capacity,"%s_END halves=%u %s=%u state=%s\r\n",
        label,
        (unsigned)trunk_rx_stream_readout_halves,witness?"events":"markers",
        (unsigned)trunk_rx_stream_readout_markers,
        trunk_rx_stream_state_name(trunk_rx_stream_readout_state));
    return -1;
}
static bool trunk_rx_stream_command(const char *cmd,bool down) {
    bool origin=!strncmp(cmd,"TRUNK RXORIGIN",14);
    bool early=!strncmp(cmd,"TRUNK RXEARLY",13);
    if(!origin&&!early&&strncmp(cmd,"TRUNK RXSTREAM",14))return false;
    unsigned schema=early?2u:origin?1u:0u;
    const char *operation=cmd+(early?13:14);
    if(!strcmp(operation," STOP")) {
        if(trunk_rx_stream_owned&&schema!=trunk_rx_stream.marker_schema) {
            send("ERR receive witness schema differs; use its matching STOP\r\n");return true;
        }
        if(trunk_rx_witness_owned()) {
            trunk_rx_origin_fault(P25_RX_ORIGIN_STOP);
            uint32_t lock=hrc_irq_save();p25_rx_stream_cancel(&trunk_rx_stream);hrc_irq_restore(lock);
        }
        trunk_stop("rx_stream_operator");normal_permission();
        command_deferred|=COMMAND_DEFER_TRUNK_STOP_ACK;return true;
    }
    if(!strcmp(operation," STATUS")||!strcmp(operation," DUMP")) {
        bool dump=!strcmp(operation," DUMP");
        if(telemetry_pending()) {command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return true;}
        if(schema!=trunk_rx_stream.marker_schema) {
            send("ERR receive witness schema differs; use its matching STATUS or DUMP\r\n");return true;
        }
        if(dump&&(!trunk_rx_stream_owned||!trunk_rx_stream.ledger
           ||p25_rx_stream_active(&trunk_rx_stream)||trunk_rx_stream.state==P25_RX_STREAM_DRAINING)) {
            send(early?"ERR TRUNK RXEARLY DUMP requires a stopped capture; use STATUS or STOP\r\n":
                origin?"ERR TRUNK RXORIGIN DUMP requires a stopped capture; use STATUS or STOP\r\n":
                "ERR TRUNK RXSTREAM DUMP requires a stopped capture; use STATUS or STOP\r\n");return true;
        }
        if(dump) {trunk_rx_stream_timer_stop();p25_rx_stream_finalize(&trunk_rx_stream);}
        uint32_t lock=hrc_irq_save();
        trunk_rx_stream_dump=dump;trunk_rx_stream_readout_halves=trunk_rx_stream.halves;
        trunk_rx_stream_readout_markers=trunk_rx_stream.markers;
        trunk_rx_stream_readout_state=trunk_rx_stream.state;
        trunk_rx_stream_readout.produced=trunk_rx_stream.produced;
        trunk_rx_stream_readout.consumed=trunk_rx_stream.consumed;
        trunk_rx_stream_readout.verified=trunk_rx_stream.verified;
        trunk_rx_stream_readout.stream_epoch=trunk_rx_stream.stream_epoch;
        trunk_rx_stream_readout.units=trunk_units;
        trunk_rx_stream_readout.worker_calls=trunk_rx_stream_work.calls;
        trunk_rx_stream_readout.worker_total_us=trunk_rx_stream_work.total_us;
        trunk_rx_stream_readout.worker_max_us=trunk_rx_stream_work.max_us;
        trunk_rx_stream_readout.worker_yields=trunk_rx_stream_work.yields;
        trunk_rx_stream_readout.samples=(uint16_t)(256u*trunk_rx_stream.limit_halves);
        trunk_rx_stream_readout.guard_us=trunk_rx_stream.guard_us;
        trunk_rx_stream_readout.faults=trunk_rx_stream.faults;
        trunk_rx_stream_readout.schema=trunk_rx_stream.marker_schema;
        trunk_rx_stream_readout.carrier_hz=trunk_rx_origin_carrier_hz;
        hrc_irq_restore(lock);
        telemetry_request(TELEMETRY_RXSTREAM);return true;
    }
    if(!strncmp(operation," START ",7)) {
        const char *text=operation+7;unsigned value[2]={0};bool valid=true;
        for(unsigned i=0;i<2u;++i) {
            if(*text<'0'||*text>'9') {valid=false;break;}
            do {unsigned digit=(unsigned)(*text++-'0');
                if(value[i]>(16384u-digit)/10u) {valid=false;break;}
                value[i]=value[i]*10u+digit;
            } while(*text>='0'&&*text<='9');
            if(!valid)break;
            if(i==0u) {if(*text++!=' ')valid=false;}else if(*text)valid=false;
        }
        if(!valid||value[0]<256u||value[0]>16384u||value[0]%256u||value[1]>8000u
           ||!trunk_rx_stream_start_mode(value[0],value[1],down,schema))
            send(early?"ERR TRUNK RXEARLY START requires idle lab P25 440075000 NAC293; samples256..4096 multiple256 guard_us0..8000; release PTT\r\n":
                origin?"ERR TRUNK RXORIGIN START requires idle lab P25 440075000 NAC293; samples256..8192 multiple256 guard_us0..8000; release PTT\r\n":
                "ERR TRUNK RXSTREAM START requires idle lab P25 440075000 NAC293; samples256..16384 multiple256 guard_us0..8000; release PTT\r\n");
        else send(early?"OK TRUNK RXEARLY START schema=1 early=prev_crc finite receive-only; recorder clock unqualified\r\n":
            origin?"OK TRUNK RXORIGIN START schema=1 finite receive-only; recorder clock unqualified\r\n":
            "OK TRUNK RXSTREAM START finite receive-only; recorder clock unqualified\r\n");
        return true;
    }
    send(early?"ERR TRUNK RXEARLY START samples guard_us | STATUS | DUMP | STOP\r\n":
        origin?"ERR TRUNK RXORIGIN START samples guard_us | STATUS | DUMP | STOP\r\n":
        "ERR TRUNK RXSTREAM START samples guard_us | STATUS | DUMP | STOP\r\n");return true;
}
#endif
#endif
