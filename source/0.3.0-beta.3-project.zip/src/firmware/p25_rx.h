// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_RX_H
#define P25_RX_H
#include <stdint.h>
#include <stdbool.h>
#include "p25_data.h"
// Input is one hard-decision dibit (0..3). No modem assumptions or heap.
// NID recovery is bounded to four TOTAL bits from the complete canonical64-bit
// codeword, including DUID parity (MMDVMHost's bounded-distance policy). All63
// BCH bits must re-encode exactly; the underlying BCH radius is not widened.
#define P25_NID_MAX_CORRECTED 4u
typedef struct {
 uint64_t shift;
 uint8_t frame[P25_DATA_FRAME_BYTES],duid,nid_corrected; // 0..4 corrected NID bits, including parity
 uint16_t symbols,expected,nac,frame_bytes;
 uint32_t syncs,frames,bad_nid,bad_input;
} p25_rx;
void p25_rx_init(p25_rx *r);
void p25_rx_gap(p25_rx *r);
// True at a complete validated frame. All64 NID bits are canonicalized after
// bounded correction; the received status dibit is preserved. Consume before next push.
bool p25_rx_push(p25_rx *r,uint8_t dibit);
// Decode the 64 NID bits after removing the status dibit. Supported DUIDs are
// HDU, simple TDU, LDU1, LDU2, TDULC, bounded TSDU and unconfirmed PDU.
// Outputs change only on success.
bool p25_rx_nid_decode(uint64_t nid,uint16_t *nac,uint8_t *duid,unsigned *corrected);
typedef struct { unsigned e0,et; } p25_voice_quality;
// e0 counts corrections to the first Golay word (the whitening seed), while
// et counts all Golay/Hamming corrections. Counts are not integrity guarantees.
bool p25_rx_voice_quality(const uint8_t ldu[216],unsigned voice,uint8_t payload[11],p25_voice_quality *quality);
// Extract one voice payload from a validated LDU; reports FEC corrections.
// Golay/Hamming can miscorrect errors beyond their radius. No integrity claim.
bool p25_rx_voice(const uint8_t ldu[216],unsigned voice,uint8_t payload[11],unsigned *corrected);
#endif
