// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_APPLET_STORE_H
#define RADIO_APPLET_STORE_H
#include <stdbool.h>
#include <stdint.h>

/* New overlay-only allocation, not universally unused stock storage. It overlaps
 * the upstream open-firmware/ID database tail. Only claim explicitly after a
 * complete foreign-data scan; stock firmware can later overwrite this area.
 * HAL offsets are RELATIVE to [0xE00000,0xF00000), never raw flash addresses. */
#define RADIO_APPLET_STORE_BASE 0xE00000u
#define RADIO_APPLET_STORE_BYTES 0x100000u
#define RADIO_APPLET_STORE_SLOTS 8u
#define RADIO_APPLET_STORE_BANK_BYTES 0x10000u
#define RADIO_APPLET_STORE_ERASE_BYTES 0x1000u
#define RADIO_APPLET_STORE_HEADER_BYTES 64u
#define RADIO_APPLET_STORE_PACKAGE_MAX 32768u
#define RADIO_APPLET_STORE_WRITE_MAX 32u
#define RADIO_APPLET_STORE_SCAN_BYTES 256u

typedef enum {
 RADIO_APPLET_STORE_SCANNING, RADIO_APPLET_STORE_READY,
 RADIO_APPLET_STORE_ERASING, RADIO_APPLET_STORE_HEADER,
 RADIO_APPLET_STORE_WRITING, RADIO_APPLET_STORE_VERIFYING,
 RADIO_APPLET_STORE_FOREIGN, RADIO_APPLET_STORE_ERROR
} radio_applet_store_state;
typedef enum {
 RADIO_APPLET_STORE_OK, RADIO_APPLET_STORE_IO, RADIO_APPLET_STORE_CRC,
 RADIO_APPLET_STORE_VALIDATION, RADIO_APPLET_STORE_CONFLICT
} radio_applet_store_error;

typedef struct {
 void *context;
 uint32_t size, erase_size;
 bool (*read)(void *,uint32_t offset,void *out,uint32_t length);
 bool (*write)(void *,uint32_t offset,const void *data,uint32_t length);
 bool (*erase)(void *,uint32_t offset);
} radio_applet_store_io;
typedef struct {
 uint32_t revision,length,crc;
 uint8_t bank; /* Physical bank within this slot, 0 or 1. */
 bool committed, present; /* A tombstone is committed but not present. */
} radio_applet_slot_info;
/* Called in task context after the complete staged CRC passes. The context can
 * hold a store pointer and use stage_read. Never trust a host validation claim.
 * Validator must not call begin/abort/open or otherwise change store ownership. */
typedef bool (*radio_applet_store_validator)(void *context,uint32_t length);

typedef struct {
 radio_applet_store_io io;
 radio_applet_slot_info slots[RADIO_APPLET_STORE_SLOTS];
 radio_applet_store_state state;
 radio_applet_store_error error;
 uint32_t progress, scan_crc, scan_length, scan_expected_crc, scan_revision;
 uint32_t written, stage_length, stage_crc, stage_revision, verify_crc;
 uint8_t scan_kind, scan_owned, scan_complete, scan_committed, scan_blank;
 uint8_t stage_slot,stage_bank,stage_kind,erase_step;
 bool foreign;
 radio_applet_store_validator validator;
 void *validator_context;
} radio_applet_store;

/* Open only sets up a READ-ONLY scan. step performs at most one 256-byte scan
 * read, one 4-KiB erase, or one small header/commit write per call. No boot-time
 * writes or formatting. A foreign byte in an unowned bank prevents all writes;
 * existing valid packages may still be read once scanning finishes. */
bool radio_applet_store_open(radio_applet_store *,const radio_applet_store_io *);
bool radio_applet_store_step(radio_applet_store *);
bool radio_applet_store_busy(const radio_applet_store *);
/* Slot numbers are zero-based. Expected revision is 0 for an unused slot;
 * tombstones retain revisions. Explicit begin starts erasure of the INACTIVE
 * bank; the active committed package remains intact until final commit. */
bool radio_applet_store_begin(radio_applet_store *,unsigned slot,uint32_t length,
                              uint32_t crc,uint32_t expected_revision);
bool radio_applet_store_write(radio_applet_store *,uint32_t offset,const void *,uint32_t length);
bool radio_applet_store_stage_read(const radio_applet_store *,uint32_t offset,void *,uint32_t length);
bool radio_applet_store_commit(radio_applet_store *,radio_applet_store_validator,void *context);
bool radio_applet_store_remove(radio_applet_store *,unsigned slot,uint32_t expected_revision);
/* Abandon only our staged transaction. CRC/VM-validation failures can return to
 * READY without writes and retain the previous active package/revision. I/O and
 * foreign-data failures remain closed until a fresh read-only open/scan. */
void radio_applet_store_abort(radio_applet_store *);
bool radio_applet_store_read(const radio_applet_store *,unsigned slot,uint32_t offset,void *,uint32_t length);
uint32_t radio_applet_store_crc(const void *bytes,uint32_t length);

#endif
