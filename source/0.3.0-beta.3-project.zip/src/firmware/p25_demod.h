// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_DEMOD_H
#define P25_DEMOD_H
#include "p25_rx.h"
// Bounded 8-kHz discriminator input. Ten timing hypotheses at 48 kHz.
// Sync acquires polarity, DC and gain; decision-directed timing tracks each
// hypothesis between syncs. No whole-call search, heap, or floating point.
typedef struct {
    p25_rx rx;
    int16_t history[48]; // duplicated, quantized sync history
    unsigned index, filled, quality;
    int32_t offset, gain;
    int32_t next_q16;
    int32_t sum, sum_squares;
    int32_t period_q16, previous_value, previous_symbol;
} p25_demod_lane;

// Software interpolation has exactly 60 nominal 48-kHz ticks of linear-phase
// delay. This does NOT include the radio's discriminator/recorder/IRQ latency.
#define P25_DEMOD_FIR_DELAY_TICKS 60u
#define P25_DEMOD_INPUT_STEP_TICKS 6u
#define P25_DEMOD_CONTROL_TRACK_REQUESTED 1u
#define P25_DEMOD_CONTROL_TRACK_ACTIVE 2u
#define P25_DEMOD_CONTROL_TRACK_FALLBACK 4u
#define P25_DEMOD_CONTROL_TRACK_MAX_IDLE_TICKS 7200u
typedef struct {
    uint64_t sample_tick; // Estimated symbol END, in caller's sample clock.
    uint32_t stream_epoch,lane_epoch;
    uint16_t nac;
    uint8_t duid,status,lane;
    bool selected,qualified;
} p25_demod_status;
typedef void (*p25_demod_status_fn)(const p25_demod_status *status,void *context);
typedef struct {
    p25_demod_lane lane[10];
    int16_t fir[42];
    unsigned fir_index, pending_ticks, pending_quality, pending_errors;
    p25_rx pending;
    uint32_t frames, acquisitions;
    uint64_t ticks;
    uint32_t (*clock_us)(void);
    uint32_t fir_us, sync_us, fec_us, symbol_us;
    uint32_t sync_tests, fec_candidates, fec_skipped;
    // Optional rare control-block profiling: no per-symbol clock calls.
    // Parser scope includes trellis/CRC failures before arbitration. fec_us
    // remains the separate completed-candidate arbitration decode scope.
    uint32_t (*rare_fec_clock_us)(void);
    uint32_t parser_fec_calls,parser_fec_us,parser_fec_max_us;
    int16_t previous;
    // Retain the last five milliseconds at 48 kHz, quantized exactly like
    // the sync histories. Idle rephasing must preserve an arriving sync.
    int16_t hunt_history[240];
    uint16_t hunt_index,hunt_filled,idle_ticks;
    uint32_t hunt_rearms,hunt_us,hunt_max_us;
    // Measure the rare rearm without enabling per-symbol profiling overhead.
    uint32_t (*hunt_clock_us)(void);
    // Optional sample-origin timing. Legacy push() never produces these events.
    // One timing lane, seeded by a CRC-valid TSDU, is retained until loss rather
    // than switching phase on every frame's FEC/sync arbitration winner.
    uint64_t input_tick,decision_tick,first_status_tick;
    uint32_t stream_epoch,lane_epoch;
    p25_demod_status_fn status_emit;
    void *status_context;
    uint16_t selected_nac;
    uint8_t pending_lane,selected_lane,first_status;
    bool have_input_time,decision_valid,selected_qualified,first_status_pending;
    uint8_t control_tracking_flags,control_tracking_center;
} p25_demod;
typedef void (*p25_demod_frame_fn)(const p25_rx *frame,void *context);
void p25_demod_init(p25_demod *d);
void p25_demod_gap(p25_demod *d);
// Explicit experimental control-stream optimization. Enabling only requests
// tracking: full ten-lane processing continues until ordinary status_select
// has a CRC-valid DUID7 winner. The selected lane and its circular neighbors
// then run; loss restores ten lanes after refreshing skipped histories.
// Default, reset/gap and conventional push() are full-lane mode. This is not
// sample-clock, current-NID or RF permission. Damage may change frame recovery.
void p25_demod_control_tracking(p25_demod *d,bool enabled);
// Current processing mask only: never a claim of lock/integrity/RF authority.
unsigned p25_demod_control_tracking_lanes(const p25_demod *d);
void p25_demod_push(p25_demod *d,int16_t sample,p25_demod_frame_fn emit,void *context);
// sample_tick is the actual 8-kHz input sample's origin, expressed in nominal
// 48-kHz ticks; consecutive inputs must differ by exactly 6. It is NOT the time
// this function, a task, or a serial callback ran. The caller must separately
// qualify/calibrate the hardware sample origin before using timing for RF.
// Retune, missing samples or clock reset require a new stream_epoch. A mismatch
// discards partial demodulation and emits an unqualified loss; false reports
// that discontinuity (the current sample seeds a new stream). Timestamp overflow
// is refused. Existing frame bytes and conventional push() behavior are unchanged.
// Raw status dibits are not FEC-protected. qualified means selected control lane
// + matching validated NID + continuous sample clock, never RF authorization.
// The first status of a unit is delivered after NID validation with its original
// timestamp. No past status is restamped with frame/task delivery time.
bool p25_demod_push_at(p25_demod *d,int16_t sample,uint64_t sample_tick,
                       uint32_t stream_epoch,p25_demod_frame_fn emit,
                       p25_demod_status_fn status_emit,void *context);
// Optional receive-only witness for physical status position35 before this
// unit's NID is validated. The ordinary status callback maintains the selected
// lane's previous CRC-valid control context; early-only use cannot seed it.
// early_status_emit receives selected=true, qualified=false, with NAC/DUID
// inherited from that PREVIOUS context, not decoded from the current unit.
// Its original symbol-END tick and current call's context are delivered
// synchronously. The ordinary delayed/qualified event is unchanged. The early
// callback is per-call opt-in; its pointer is never stored across pushes.
// Never feed this observational callback into a slot/session RF dispatcher.
bool p25_demod_push_at_observed(p25_demod *d,int16_t sample,uint64_t sample_tick,
                       uint32_t stream_epoch,p25_demod_frame_fn emit,
                       p25_demod_status_fn status_emit,
                       p25_demod_status_fn early_status_emit,void *context);
#endif
