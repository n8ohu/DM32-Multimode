// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit receive-only recorder observations. The borrowed PCM arena stays
// unavailable to decoding/speaker work until STOP, including after completion.
#ifndef P25_RX_PROGRESS_LIVE_H
#define P25_RX_PROGRESS_LIVE_H
#if DM32_TRUNK_SUBSCRIBER
#include "p25_rx_progress.h"
static p25_rx_progress trunk_rx_progress;
static p25_rx_chunk trunk_rx_chunk;
static bool trunk_rx_progress_chunk;
static bool trunk_rx_progress_timer_mode;
static volatile bool trunk_rx_progress_timer_running;
static bool trunk_rx_progress_dump;
static uint16_t trunk_rx_progress_readout_records;
static uint8_t trunk_rx_progress_readout_state;
static p25_rx_progress *trunk_rx_progress_current(void) {
    return trunk_rx_progress_chunk ? &trunk_rx_chunk.base : &trunk_rx_progress;
}
static const char *trunk_rx_progress_state_name(unsigned state) {
    switch(state) {
    case P25_RX_PROGRESS_WAIT_IRQ:return "waiting";
    case P25_RX_PROGRESS_RECORDING:return "recording";
    case P25_RX_PROGRESS_DONE:return "complete";
    case P25_RX_PROGRESS_CANCELLED:return "cancelled";
    case P25_RX_PROGRESS_TIMEOUT:return "timeout";
    case P25_RX_PROGRESS_CLOCK_ERROR:return "clock_error";
    default:return "idle";
    }
}
static uint8_t trunk_rx_progress_byte(void *context,unsigned offset) {
    // Pinned native modem layout: volatile BE16 recorder bytes, no SPI, codec,
    // flash or serial operations. The pure core bounds offset to0..1023.
    const volatile uint8_t *window=context;
    return window[offset];
}
static uint32_t trunk_rx_progress_clock(void *context) {(void)context;return hrc_micros();}
static bool trunk_rx_progress_half_pending(void *context) {
    (void)context;return (hrc7000_rd(dev,C7_SYS_INTERP_LIST)&(1u<<14))!=0;
}
static bool trunk_rx_progress_timer_active(void) {return trunk_rx_progress_timer_running;}
static void trunk_rx_progress_timer_stop(void) {
    if(!trunk_rx_progress_timer_running)return;
    trunk_rx_progress_timer_running=false;
    hrc_timer_stop(TIMER_BOARD);hrc_irq_enable(IRQ_TIMER5,false);
}
static void trunk_rx_progress_timer_tick(void) {
    hrc_timer_ack(TIMER_BOARD);
    if(!trunk_rx_progress_timer_running)return;
    // No board/key scan, codec, UART, SPI, receiver shutdown or finalization in
    // this ISR. The task owns admission, PTT checks, cleanup and row readout.
    if(!trunk_rx_progress_owned || !trunk_rx_progress_chunk || !trunk_enabled
       || !mon_enabled || !mon_running || mon_failed || control.cancel || !dev || !dev->buf) {
        p25_rx_progress_cancel(&trunk_rx_chunk.base);trunk_rx_progress_timer_stop();return;
    }
    p25_rx_progress_io io={.context=(void *)(dev->buf+C7_FM_RX_AUDIO),
        .read_byte=trunk_rx_progress_byte,.clock_us=trunk_rx_progress_clock,
        .half_pending=trunk_rx_progress_half_pending};
    // HRC interrupts do not nest. A pending half interrupt must run before any
    // read; a boundary becoming pending during the read explicitly invalidates
    // that operation rather than trusting unchanged CPU-published IRQ metadata.
    (void)p25_rx_chunk_step(&trunk_rx_chunk,&io,hrc_micros());
    if(!p25_rx_chunk_active(&trunk_rx_chunk))trunk_rx_progress_timer_stop();
    else hrc_timer_oneshot(TIMER_BOARD,500u);
}
static void trunk_rx_progress_irq(unsigned half,uint32_t now) {
    if(trunk_rx_progress_owned)(void)p25_rx_progress_irq(trunk_rx_progress_current(),half,now);
}
static void trunk_rx_progress_finish(void) {
    unsigned state=trunk_rx_progress_current()->state;
    if(mon_running)mon_stop(trunk_rx_progress_state_name(state));
    trunk_reason=trunk_rx_progress_state_name(state);
}
static void trunk_rx_progress_release(void) {
    if(!trunk_rx_progress_owned)return;
    // A begun row is already copied into telemetry.line. Finish only that row,
    // then cancel remaining readout before mon_start can reuse the PCM arena.
    telemetry_abort_after_row();
    trunk_rx_progress_timer_stop();
    if(mon_running)mon_stop("rx_progress_stopped");
    uint32_t lock=hrc_irq_save();
    if(trunk_rx_progress_chunk)p25_rx_chunk_cancel(&trunk_rx_chunk);
    else p25_rx_progress_cancel(&trunk_rx_progress);
    trunk_rx_progress_current()->storage=NULL;trunk_rx_progress_owned=false;
    trunk_rx_progress_dump=false;
    hrc_irq_restore(lock);
}
static bool trunk_rx_progress_context(bool down) {
    // The physical PTT wire is also UART RX; use the board's filtered key
    // scanner rather than rejecting ordinary zero bits in a serial command.
    return !down && !(board.input->scan()&ptt_mask) && normal_mode && features_ready
        && feature_p25() && frequency==TRUNK_PROBE_RX_HZ && control.nac==TRUNK_PROBE_NAC
        && !radio_channel_get_private(channel_record) && !control.cancel
        && control.state!=RADIO_FAULT && !channel_scan.running && !editing && !menu_open
        && !rx_lab && !rx_job && !rx_sampling && !call_active && !prepared && !hardware_running
        && !armed && !session_enabled && !apps_active() && !applet_owns_radio && !pcm_owner
        && !cps_link && !cps_active && !broadcast_show && !airband_show
        && !digital_dmr.owned && !digital_dmr.tx_armed && !digital_dmr.data_armed
        && !analog_fm.owned && dev && dev->buf && hooks && board.radio && board.audio
        && board.power->switch_on() && channel_in_band(frequency,false);
}
static bool trunk_rx_progress_parse(const char *text,p25_rx_progress_config *out) {
    uint32_t value[2]={0};
    for(unsigned i=0;i<2u;++i) {
        if(*text<'0' || *text>'9')return false;
        do {
            unsigned digit=(unsigned)(*text++-'0');
            if(value[i]>(8000u-digit)/10u)return false;
            value[i]=value[i]*10u+digit;
        } while(*text>='0' && *text<='9');
        if(i==0u) {if(*text++!=' ')return false;}
        else if(*text)return false;
    }
    if(!value[0] || value[0]>P25_RX_PROGRESS_MAX_ROWS
       || value[1]<P25_RX_PROGRESS_MIN_CADENCE_US || value[1]>P25_RX_PROGRESS_MAX_CADENCE_US)return false;
    *out=(p25_rx_progress_config){(uint16_t)value[0],(uint16_t)value[1],P25_RX_PROGRESS_MAX_TIMEOUT_US};
    return true;
}
static bool trunk_rx_progress_start(const p25_rx_progress_config *config,bool down) {
    if(trunk_rx_progress_owned || trunk_enabled || telemetry_pending()
       || !trunk_rx_progress_context(down))return false;
    // Every admission refusal above precedes the receiver reset. trunk_start
    // uses the existing receive-only path and never changes the saved profile.
    if(!trunk_start())return false;
    trunk_rx_feed_release();
    mon_discard_audio();
    uint32_t lock=hrc_irq_save();
    bool ok=p25_rx_progress_start(&trunk_rx_progress,(unsigned char *)monitor.pcm,
        sizeof monitor.pcm,config,hrc_micros());
    if(ok) {trunk_rx_progress_owned=true;trunk_rx_progress_chunk=false;trunk_rx_progress_timer_mode=false;}
    hrc_irq_restore(lock);
    if(!ok) {trunk_stop("rx_progress_setup_failed");return false;}
    trunk_reason="rx_progress_waiting";return true;
}
static bool trunk_rx_chunk_parse(const char *text,p25_rx_chunk_config *out) {
    uint32_t value[2]={0};
    for(unsigned i=0;i<2u;++i) {
        if(*text<'0' || *text>'9')return false;
        do {
            unsigned digit=(unsigned)(*text++-'0');
            if(value[i]>(P25_RX_CHUNK_MAX_GUARD_US-digit)/10u)return false;
            value[i]=value[i]*10u+digit;
        } while(*text>='0' && *text<='9');
        if(i==0u) {if(*text++!=' ')return false;}else if(*text)return false;
    }
    if(!value[0] || value[0]>P25_RX_CHUNK_MAX_ROWS || value[1]>P25_RX_CHUNK_MAX_GUARD_US)return false;
    *out=(p25_rx_chunk_config){(uint16_t)value[0],(uint16_t)value[1]};return true;
}
static bool trunk_rx_chunk_start(const p25_rx_chunk_config *config,bool down,bool timer) {
    if(trunk_rx_progress_owned || trunk_enabled || telemetry_pending() || !trunk_rx_progress_context(down))return false;
    if(!trunk_start())return false;
    trunk_rx_feed_release();
    mon_discard_audio();
    uint32_t lock=hrc_irq_save();
    bool ok=p25_rx_chunk_start(&trunk_rx_chunk,(unsigned char *)monitor.pcm,sizeof monitor.pcm,config,hrc_micros());
    if(ok) {
        trunk_rx_progress_owned=true;trunk_rx_progress_chunk=true;trunk_rx_progress_timer_mode=timer;
        if(timer) {
            trunk_rx_progress_timer_running=true;hrc_timer_stop(TIMER_BOARD);
            hrc_irq_enable(IRQ_TIMER5,true);hrc_timer_oneshot(TIMER_BOARD,500u);
        }
    }
    hrc_irq_restore(lock);
    if(!ok) {trunk_stop("rx_chunk_setup_failed");return false;}
    trunk_reason="rx_chunk_waiting";return true;
}
static void trunk_rx_progress_poll(bool down) {
    if(!trunk_rx_progress_owned)return;
    p25_rx_progress *current=trunk_rx_progress_current();
    if(p25_rx_progress_active(current)) {
        if(!trunk_rx_progress_context(down) || !trunk_enabled || !mon_enabled || !mon_running || mon_failed
           || (trunk_rx_progress_timer_mode && !trunk_rx_progress_timer_running)) {
            uint32_t lock=hrc_irq_save();
            trunk_rx_progress_timer_stop();
            if(trunk_rx_progress_chunk)p25_rx_chunk_cancel(&trunk_rx_chunk);else p25_rx_progress_cancel(current);
            hrc_irq_restore(lock);
            ptt_release_required=true;ptt_release_seen=false;
        } else if(!trunk_rx_progress_timer_mode) {
            p25_rx_progress_io io={.context=(void *)(dev->buf+C7_FM_RX_AUDIO),
                .read_byte=trunk_rx_progress_byte,.clock_us=trunk_rx_progress_clock};
            if(trunk_rx_progress_chunk)(void)p25_rx_chunk_poll(&trunk_rx_chunk,&io,hrc_micros());
            else (void)p25_rx_progress_poll(current,&io,hrc_micros());
        }
    }
    if(!p25_rx_progress_active(current)) {
        trunk_rx_progress_timer_stop();
        // ISR timeout publishes only state. Pairing flags are finalized here.
        if(trunk_rx_progress_chunk)(void)p25_rx_chunk_poll(&trunk_rx_chunk,NULL,hrc_micros());
        trunk_rx_progress_finish();
    }
}
static bool trunk_rx_progress_status_last(unsigned next_row) {
    return next_row==2u+(trunk_rx_progress_dump ? trunk_rx_progress_readout_records : 0u);
}
static int trunk_rx_progress_status_row(unsigned row,char *line,size_t capacity) {
    p25_rx_progress *current=trunk_rx_progress_current();
    const char *prefix_name=trunk_rx_progress_chunk ? "RXCHUNK" : "RXPROGRESS";
    if(!row && trunk_rx_progress_chunk)return snprintf(line,capacity,
        "RXCHUNK state=%s records=%u limit=%u guard_us=%u owned=%u dump=%u service=%s valid_irqs=%lu invalid_irqs=%lu sequence_errors=%lu skipped_chunks=%lu compared=%lu mismatches=%lu row_bytes=144 samples=16 nominal_sample_us=125 clock=cpu_unqualified\r\n",
        trunk_rx_progress_state_name(trunk_rx_progress_readout_state),(unsigned)trunk_rx_progress_readout_records,
        (unsigned)current->limit,(unsigned)trunk_rx_chunk.guard_us,(unsigned)trunk_rx_progress_owned,(unsigned)trunk_rx_progress_dump,
        trunk_rx_progress_timer_mode ? "timer500" : "task",
        (unsigned long)current->valid_irqs,(unsigned long)current->invalid_irqs,(unsigned long)current->sequence_errors,
        (unsigned long)trunk_rx_chunk.skipped_chunks,(unsigned long)trunk_rx_chunk.compared,(unsigned long)trunk_rx_chunk.mismatches);
    if(!row)return snprintf(line,capacity,
        "RXPROGRESS state=%s records=%u limit=%u cadence_us=%u timeout_us=%lu owned=%u valid_irqs=%lu invalid_irqs=%lu sequence_errors=%lu missed_periods=%lu row_bytes=96 clock=cpu_unqualified\r\n",
        trunk_rx_progress_state_name(trunk_rx_progress_readout_state),(unsigned)trunk_rx_progress_readout_records,
        (unsigned)trunk_rx_progress.limit,(unsigned)trunk_rx_progress.cadence_us,
        (unsigned long)trunk_rx_progress.timeout_us,(unsigned)trunk_rx_progress_owned,
        (unsigned long)trunk_rx_progress.valid_irqs,(unsigned long)trunk_rx_progress.invalid_irqs,
        (unsigned long)trunk_rx_progress.sequence_errors,(unsigned long)trunk_rx_progress.missed_periods);
    unsigned records=trunk_rx_progress_dump ? trunk_rx_progress_readout_records : 0u;
    if(row<=records) {
        if(!trunk_rx_progress_owned || !current->storage || p25_rx_progress_active(current))return -1;
        unsigned index=row-1u;
        int n=snprintf(line,capacity,"%s_ROW index=%u data=",prefix_name,index);
        if(n<0)return n;
        unsigned row_bytes=trunk_rx_progress_chunk ? P25_RX_CHUNK_ROW_BYTES : P25_RX_PROGRESS_ROW_BYTES;
        size_t prefix=(size_t)n,total=prefix+2u*row_bytes+2u;
        if(total>=capacity)return (int)total;
        static const char hex[]="0123456789ABCDEF";
        const unsigned char *bytes=current->storage+(size_t)index*row_bytes;
        for(unsigned i=0;i<row_bytes;++i) {
            line[prefix+2u*i]=hex[bytes[i]>>4];line[prefix+2u*i+1u]=hex[bytes[i]&15u];
        }
        line[total-2u]='\r';line[total-1u]='\n';line[total]=0;return (int)total;
    }
    if(row==records+1u)return snprintf(line,capacity,"%s_END records=%u state=%s\r\n",
        prefix_name,(unsigned)trunk_rx_progress_readout_records,trunk_rx_progress_state_name(trunk_rx_progress_readout_state));
    return -1;
}
static bool trunk_rx_progress_command(const char *cmd,bool down) {
    if(strncmp(cmd,"TRUNK RXPROGRESS",16))return false;
    p25_rx_progress *current=trunk_rx_progress_current();
    if(!strcmp(cmd,"TRUNK RXPROGRESS STATUS") || !strcmp(cmd,"TRUNK RXPROGRESS DUMP")) {
        bool dump=!strcmp(cmd,"TRUNK RXPROGRESS DUMP");
        if(telemetry_pending()) {command_deferred|=COMMAND_DEFER_TELEMETRY_BUSY;return true;}
        if(dump && (!trunk_rx_progress_owned || !current->storage || p25_rx_progress_active(current))) {
            send("ERR TRUNK RXPROGRESS DUMP requires a stopped capture; use STATUS or STOP\r\n");return true;
        }
        if(dump && trunk_rx_progress_chunk && !trunk_rx_chunk.finalized)
            (void)p25_rx_chunk_poll(&trunk_rx_chunk,NULL,hrc_micros());
        trunk_rx_progress_dump=dump;trunk_rx_progress_readout_records=current->count;
        trunk_rx_progress_readout_state=current->state;
        telemetry_request(TELEMETRY_RXPROGRESS);return true;
    }
    if(!strcmp(cmd,"TRUNK RXPROGRESS STOP")) {
        trunk_stop("rx_progress_operator");normal_permission();
        command_deferred|=COMMAND_DEFER_TRUNK_STOP_ACK;return true;
    }
    if(!strncmp(cmd,"TRUNK RXPROGRESS CHUNK TIMER START ",35)) {
        p25_rx_chunk_config config;
        if(!trunk_rx_chunk_parse(cmd+35,&config) || !trunk_rx_chunk_start(&config,down,true))
            send("ERR TRUNK RXPROGRESS CHUNK TIMER START requires idle lab P25 440075000 NAC293; rows1..96 guard_us0..16000; release PTT\r\n");
        else send("OK TRUNK RXPROGRESS CHUNK TIMER START receive-only; 500us service, sample timing unqualified\r\n");
        return true;
    }
    if(!strncmp(cmd,"TRUNK RXPROGRESS CHUNK START ",29)) {
        p25_rx_chunk_config config;
        if(!trunk_rx_chunk_parse(cmd+29,&config) || !trunk_rx_chunk_start(&config,down,false))
            send("ERR TRUNK RXPROGRESS CHUNK START requires idle lab P25 440075000 NAC293; rows1..96 guard_us0..16000; release PTT\r\n");
        else send("OK TRUNK RXPROGRESS CHUNK START receive-only; nominal sample timing unqualified\r\n");
        return true;
    }
    if(!strncmp(cmd,"TRUNK RXPROGRESS START ",23)) {
        p25_rx_progress_config config;
        if(!trunk_rx_progress_parse(cmd+23,&config) || !trunk_rx_progress_start(&config,down))
            send("ERR TRUNK RXPROGRESS START requires idle lab P25 440075000 NAC293; rows1..128 cadence_us250..8000; release PTT\r\n");
        else send("OK TRUNK RXPROGRESS START receive-only; CPU timing unqualified\r\n");
        return true;
    }
    send("ERR TRUNK RXPROGRESS START rows cadence_us | CHUNK [TIMER] START rows guard_us | STATUS | DUMP | STOP\r\n");return true;
}
#endif
#endif
