// SPDX-License-Identifier: GPL-3.0-or-later
// Field/FEC orientation independently checked against pinned OP25 p25craft.py
// and tk_p25.py. ISP and OSP opcode namespaces intentionally differ.
#include "p25_trunking_isp.h"
#include "p25_data_fec.h"
#include <string.h>

static bool unit(uint32_t rid) {return rid && rid<=0xffffffu;}
static bool network(uint32_t wacn,uint16_t system) {
    return wacn && wacn<=0xfffffu && system && system<=0xfffu;
}
static bool build(uint8_t out[12],uint8_t opcode,uint64_t argument) {
    if(!out)return false;
    uint8_t block[12]={0};block[0]=(uint8_t)(0x80u|opcode);
    for(unsigned i=0;i<8u;++i)block[2u+i]=(uint8_t)(argument>>(56u-i*8u));
    uint16_t crc=p25_data_crc16(block,10u);block[10]=(uint8_t)(crc>>8);block[11]=(uint8_t)crc;
    memcpy(out,block,sizeof block);return true;
}
bool p25_trunking_isp_register(uint8_t out[12],uint32_t wacn,uint16_t system,uint32_t rid) {
    if(!network(wacn,system) || !unit(rid))return false;
    return build(out,0x2cu,((uint64_t)wacn<<36)|((uint64_t)system<<24)|rid);
}
bool p25_trunking_isp_affiliate(uint8_t out[12],uint16_t system,uint16_t group,uint32_t rid) {
    if(!system || system>0xfffu || !group || !unit(rid))return false;
    return build(out,0x28u,((uint64_t)system<<40)|((uint64_t)group<<24)|rid);
}
bool p25_trunking_isp_group_request(uint8_t out[12],uint16_t group,uint32_t rid,uint8_t options) {
    if(!group || !unit(rid) || (options&~0x87u))return false;
    return build(out,0x00u,((uint64_t)options<<56)|((uint64_t)group<<24)|rid);
}
bool p25_trunking_isp_deregister(uint8_t out[12],uint32_t wacn,uint16_t system,uint32_t rid) {
    if(!network(wacn,system) || !unit(rid))return false;
    return build(out,0x2bu,((uint64_t)wacn<<36)|((uint64_t)system<<24)|rid);
}
bool p25_trunking_osp_parse(const uint8_t block[12],p25_trunking_osp *out) {
    if(!block || !out || (block[0]&0x40u) || block[1])return false;
    uint16_t crc=p25_data_crc16(block,10u);
    if(block[10]!=(uint8_t)(crc>>8) || block[11]!=(uint8_t)crc)return false;
    uint64_t arg=0;for(unsigned i=2u;i<10u;++i)arg=(arg<<8)|block[i];
    p25_trunking_osp value={0};value.opcode=block[0]&0x3fu;
    switch(value.opcode) {
    case 0x00u:
        value.type=P25_TRUNK_OSP_GROUP_GRANT;value.options=(uint8_t)(arg>>56);
        value.encrypted=(value.options&0x40u)!=0;value.channel=(uint16_t)(arg>>40);
        value.group=(uint16_t)(arg>>24);value.source=(uint32_t)(arg&0xffffffu);
        if(!value.group || !value.source)return false;
        break;
    case 0x2cu:
        if(arg&UINT64_C(0xc000000000000000))return false;
        value.type=P25_TRUNK_OSP_REGISTRATION;value.response=(uint8_t)((arg>>60)&3u);
        value.system=(uint16_t)((arg>>48)&0xfffu);value.assigned=(uint32_t)((arg>>24)&0xffffffu);
        value.target=(uint32_t)(arg&0xffffffu);
        if(!value.system || !value.target)return false;
        break;
    case 0x28u:
        if(arg&UINT64_C(0x7c00000000000000))return false;
        value.type=P25_TRUNK_OSP_AFFILIATION;value.global=(arg>>63)!=0;
        value.response=(uint8_t)((arg>>56)&3u);value.announcement=(uint16_t)(arg>>40);
        value.group=(uint16_t)(arg>>24);value.target=(uint32_t)(arg&0xffffffu);
        if(!value.group || !value.target)return false;
        break;
    case 0x20u:case 0x21u:case 0x27u:
        value.type=value.opcode==0x20u?P25_TRUNK_OSP_ACK:
                   value.opcode==0x21u?P25_TRUNK_OSP_QUEUED:P25_TRUNK_OSP_DENIED;
        value.service=(uint8_t)((arg>>56)&0x3fu);value.additional=(arg>>63)!=0;
        value.extended=value.opcode==0x20u && ((arg>>62)&1u)!=0;
        value.response=value.opcode==0x20u?0u:(uint8_t)(arg>>48);
        value.target=(uint32_t)(arg&0xffffffu);
        if(!value.target || (value.opcode!=0x20u && (!value.response || ((arg>>62)&1u))))return false;
        if(value.opcode==0x20u && value.extended && !value.additional)return false;
        if(value.opcode==0x20u && !value.extended && ((arg>>48)&0xffu))return false;
        if(value.additional && !value.extended) {
            value.source=(uint32_t)((arg>>24)&0xffffffu);value.group=(uint16_t)(arg>>24);
        }
        break;
    case 0x2au:case 0x2du:
        // Standard OSP query/registration command: reserved16,target24,source24.
        // These addresses are NOT in the same position as registration replies.
        value.type=P25_TRUNK_OSP_UNSUPPORTED;
        if(!(arg>>48)) {
            value.target=(uint32_t)((arg>>24)&0xffffffu);
            value.source=(uint32_t)(arg&0xffffffu);
        }
        break;
    case 0x32u:
        // FNE authentication response: reserved8,result32,subscriber24.
        value.type=P25_TRUNK_OSP_UNSUPPORTED;
        if(!(arg>>56))value.target=(uint32_t)(arg&0xffffffu);
        break;
    case 0x31u:
        // The reviewed authentication demand uses AMBT/DUID12 with its target
        // in a data block, not this abbreviated TSBK. Never infer its address
        // from arbitrary last24 bits. Unknown target forces RX-only upstream.
        value.type=P25_TRUNK_OSP_UNSUPPORTED;
        break;
    default:return false;
    }
    *out=value;return true;
}
