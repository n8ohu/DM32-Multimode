// SPDX-License-Identifier: GPL-3.0-or-later
// Receive-only Phase 1 control-channel interpretation and ephemeral tune policy.
#ifndef P25_TRUNKING_H
#define P25_TRUNKING_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define P25_TRUNKING_BANDS 16u
#define P25_TRUNKING_GROUPS 64u
#define P25_TRUNKING_NAC_ANY 0xffffu
#define P25_TRUNKING_ACQUIRE_MS 1500u
#define P25_TRUNKING_IDLE_MS 1000u
#define P25_TRUNKING_MAX_VOICE_MS 60000u

typedef enum { P25_TRUNKING_STOPPED, P25_TRUNKING_CONTROL, P25_TRUNKING_VOICE } p25_trunking_phase;
typedef enum { P25_TRUNKING_IGNORED, P25_TRUNKING_BANDPLAN, P25_TRUNKING_SITE,
               P25_TRUNKING_GRANT, P25_TRUNKING_UNSUPPORTED } p25_trunking_event;
typedef struct {
    uint32_t base_hz,spacing_hz;
    int32_t tx_offset_hz;
    bool valid,fdma,tx_valid;
} p25_trunking_band;
typedef struct {
    p25_trunking_band band[P25_TRUNKING_BANDS];
    uint32_t control_hz,receiver_hz,min_hz,max_hz,pending_hz;
    uint32_t tune_requested_ms,voice_started_ms,last_voice_ms,last_control_ms;
    uint32_t wacn,source,grants,tune_failures;
    uint16_t configured_nac,learned_nac,system_id,control_channel,voice_channel,group;
    uint16_t groups[P25_TRUNKING_GROUPS];
    uint8_t group_count,rfss,site,service_options;
    p25_trunking_phase phase;
    bool have_nac,have_voice,have_site,have_network;
} p25_trunking;

// No RF, persistence, TX, allocation or platform calls. Bounds come from the
// hardware's validated receiver range. Zero groups means all clear group calls.
bool p25_trunking_init(p25_trunking *t,uint32_t control_hz,uint32_t min_hz,
                      uint32_t max_hz,uint16_t nac);
bool p25_trunking_set_groups(p25_trunking *t,const uint16_t *groups,unsigned count);
// Rechecks block CRC and refuses protected/vendor blocks before interpreting
// standard opcodes. Call only for decoded DUID7 while receiving the control.
p25_trunking_event p25_trunking_consume(p25_trunking *t,uint16_t nac,
                                      const uint8_t block[12],uint32_t now_ms);
// Subscriber control-map path: same CRC/NAC/protected/vendor checks and band,
// site/network learning, but NEVER follows a grant or changes pending tuning,
// voice target, source/group/options or grant counters. Feed grant/registration
// responses separately to the addressed access policy. A passive follower must
// keep using consume(); callers explicitly choose the policy, not a saved flag.
// A CRC-valid identifier update with no usable replacement reports UNSUPPORTED
// after clearing the old mapping, so callers revoke any prepared action lease.
p25_trunking_event p25_trunking_consume_control(p25_trunking *t,uint16_t nac,
                                              const uint8_t block[12],uint32_t now_ms);
// Receive-only explicit alternate MBT, DUID12/format17/SAP61/MFID0/outbound.
// Validates canonical NID, header CRC16, trellis, exact bounded length and the
// complete data CRC32. Supports NET/RFSS metadata and passive group grants;
// follow=false never follows a grant. No subscriber response authorization.
// opcode and optional validated_block change only after all native integrity
// checks pass, including when the policy returns IGNORED. The derived block's
// CRC16 is a normalization aid, not an independent on-air checksum: provenance
// is the complete validated AMBT packet. Invalid packets leave both outputs
// unchanged. Invalid/ignored packets cannot mutate the map. NET/RFSS use
// channel-T for RX; channel-R cannot change the transmitter configuration.
p25_trunking_event p25_trunking_consume_ambt(p25_trunking *t,const uint8_t *frame,
    size_t bytes,uint32_t now_ms,bool follow,uint8_t *opcode,uint8_t validated_block[12]);
bool p25_trunking_frequency(const p25_trunking *t,uint16_t channel,uint32_t *hz);
// Subscriber uplink from the advertised signed FDMA offset. Only an advertised
// 12.5-kHz FDMA bandwidth is currently qualified for these TX-map APIs. This
// resolves a frequency only; it grants no TX permission or radio capability.
bool p25_trunking_input_frequency(const p25_trunking *t,uint16_t channel,uint32_t *hz);
// Explicit grants identify the station's transmit and receive channels
// independently: the input channel then uses its own base/spacing directly,
// without adding the implicit offset again. Outputs stay unchanged on failure.
bool p25_trunking_channel_pair(const p25_trunking *t,uint16_t downlink_channel,
    uint16_t uplink_channel,bool explicit_uplink,uint32_t *rx_hz,uint32_t *tx_hz);
// A pending request remains until acknowledged. The platform must suspend the
// recorder/audio, tune RX only, reset acquisition and then acknowledge success.
// It must never copy these frequencies to a channel record or TX configuration.
bool p25_trunking_tune_request(const p25_trunking *t,uint32_t *hz);
void p25_trunking_tune_result(p25_trunking *t,bool success,uint32_t now_ms);
// Only qualified clear voice matching the selected grant refreshes its timer.
bool p25_trunking_voice(p25_trunking *t,uint16_t nac,uint16_t group,uint32_t now_ms);
void p25_trunking_end(p25_trunking *t,uint32_t now_ms);
void p25_trunking_poll(p25_trunking *t,uint32_t now_ms);
void p25_trunking_stop(p25_trunking *t);
#endif
