// SPDX-License-Identifier: GPL-3.0-or-later
// Observed P25 status-symbol phase only. This API NEVER grants RF permission.
#ifndef P25_TRUNKING_SLOT_H
#define P25_TRUNKING_SLOT_H
#include <stdbool.h>
#include <stdint.h>

// Nominal 48-kHz sample-time ticks: one 7.5-ms microslot, at least five per
// inbound slot. Caller must calibrate timestamp origin/rate and tolerance.
#define P25_TRUNK_SLOT_MICRO_TICKS 360u
#define P25_TRUNK_SLOT_MIN_MICROS 5u
#define P25_TRUNK_SLOT_MIN_TICKS (P25_TRUNK_SLOT_MICRO_TICKS*P25_TRUNK_SLOT_MIN_MICROS)
#define P25_TRUNK_SLOT_MAX_BACKOFF 31u
#define P25_TRUNK_SLOT_MAX_WAIT_TICKS 480000u // Explicit local policy: <=10 s.

typedef struct {
    uint64_t sample_tick;
    uint32_t stream_epoch,lane_epoch;
    uint8_t status;
    bool selected,qualified;
} p25_trunking_slot_observation;

typedef struct {
    uint64_t last_tick,boundary_tick;
    uint32_t stream_epoch,lane_epoch;
    uint16_t tolerance_ticks,max_age_ticks,microslots;
    uint8_t status;
    bool configured,have_status,have_boundary,coherent;
} p25_trunking_slot;

typedef struct {
    uint64_t last_status_tick,last_boundary_tick;
    uint32_t stream_epoch,lane_epoch;
    uint16_t microslots_since_boundary;
    uint8_t last_status;
} p25_trunking_slot_phase_view;

// Explicit caller budgets, not protocol-mandated jitter/latency limits.
// tolerance < half a microslot keeps adjacent observations unambiguous;
// max_age must expire no later than the earliest next expected observation.
// Zero max_age is refused. Invalid configuration leaves the output unchanged.
bool p25_trunking_slot_init(p25_trunking_slot *t,uint16_t tolerance_ticks,
                            uint16_t max_age_ticks);
// Called for every status dibit on exactly one selected, qualified control
// timing lane. sample_tick is the over-air symbol END in one monotonic sample
// clock, never task delivery time or CPU profiling clock. Epochs change on RX
// retune, sample gap, clock reset, lane replacement or loss of qualification.
// 11: observed idle boundary; 01: busy (clears phase); 10: intraslot;
// 00: unknown/unusable. No future boundary or idle opportunity is inferred.
// Two 11 markers separated by >=5 contiguous microslots establish phase.
// False means unusable data; phase is invalidated. An epoch change can seed a
// new observation but always discards earlier phase. No heap or RF calls.
bool p25_trunking_slot_observe(p25_trunking_slot *t,
                               const p25_trunking_slot_observation *observation);
// Explicitly revoke phase on any upstream sample/lane/control loss.
void p25_trunking_slot_lost(p25_trunking_slot *t);
// A successful read reports past observations only, never an access lease.
// now_tick must use the same sample clock; stale/reordered clocks fail without
// changing output. uint64 clock wrap is loss, not an extrapolation opportunity.
bool p25_trunking_slot_phase(const p25_trunking_slot *t,uint64_t now_tick,
                             p25_trunking_slot_phase_view *out);

typedef struct {
    uint64_t boundary_tick,earliest_end_tick;
    uint32_t stream_epoch,lane_epoch;
} p25_trunking_slot_boundary_view;
// Only a fresh, actually observed %11 boundary is reported. A %10, predicted
// period, previously busy channel or task-time anchor can never satisfy this.
// earliest_end_tick is the protocol MINIMUM slot extent, not a prediction of an
// idle future slot and not a grant to begin late inside this one.
bool p25_trunking_slot_boundary(const p25_trunking_slot *t,uint64_t now_tick,
                                p25_trunking_slot_boundary_view *out);
typedef struct {
    p25_trunking_slot_boundary_view observed;
    uint64_t projected_start_tick,projected_end_tick;
} p25_trunking_slot_budget;
// Pure necessary timing-budget check, NEVER sufficient RF authorization. The
// caller supplies measured actuation and tail guard in the same sample clock.
// This does not define an allowed ISP start offset: the available primary
// overviews specify the boundary but not that hardware tolerance. Start-edge,
// site, control/uplink pair, RF ownership and physical clock qualification are
// separate mandatory controller checks. Outputs remain unchanged on refusal.
bool p25_trunking_slot_fit(const p25_trunking_slot *t,uint64_t now_tick,
                           uint16_t actuation_ticks,uint16_t burst_ticks,
                           uint16_t end_guard_ticks,p25_trunking_slot_budget *out);
typedef struct {
    uint64_t deadline_tick,last_boundary_tick,last_poll_tick;
    uint32_t stream_epoch,lane_epoch;
    uint8_t skip;
    bool active;
} p25_trunking_slot_backoff;
// Bounded local contention primitive, not the complete TIA random-access
// algorithm. Caller chooses a random skip 0..31; no PRNG or retries occur here.
// Skip is counted on NEW OBSERVED boundaries, never elapsed nominal slots.
// Arm requires existing fresh phase. Current boundary is excluded. Any busy,
// loss, stale/changed clock or expired deadline cancels this wait. After skip
// boundaries, take returns at most one fresh boundary observation; it cannot
// authorize RF, retain an idle lease or generate a future transmission time.
bool p25_trunking_slot_backoff_arm(p25_trunking_slot_backoff *b,
    const p25_trunking_slot *t,uint64_t now_tick,uint8_t skip,uint32_t wait_ticks);
bool p25_trunking_slot_backoff_take(p25_trunking_slot_backoff *b,
    const p25_trunking_slot *t,uint64_t now_tick,p25_trunking_slot_boundary_view *out);
void p25_trunking_slot_backoff_cancel(p25_trunking_slot_backoff *b);
#endif
