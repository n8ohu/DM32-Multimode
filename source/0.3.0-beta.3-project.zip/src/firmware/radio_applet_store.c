// SPDX-License-Identifier: GPL-3.0-or-later
#include "radio_applet_store.h"
#include <string.h>

static const uint8_t magic[8]={'D','3','2','A','P','P','1',0};
#define INTENT 0x41504931u

static uint32_t get32(const uint8_t *p) {
 return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static void put32(uint8_t *p,uint32_t v) {
 p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);
}
static bool erased(const void *data,uint32_t n) {
 const uint8_t *p=data;while(n--)if(*p++!=0xFFu)return false;return true;
}
static uint32_t crc_add(uint32_t crc,const void *data,uint32_t n) {
 const uint8_t *p=data;
 while(n--) {crc^=*p++;for(unsigned i=0;i<8;++i)crc=(crc>>1)^((0u-(crc&1u))&0xEDB88320u);}
 return crc;
}
uint32_t radio_applet_store_crc(const void *bytes,uint32_t length) {
 if(!bytes && length)return 0;
 return ~crc_add(~0u,bytes,length);
}
static bool in_range(uint32_t off,uint32_t n) {
 return off<=RADIO_APPLET_STORE_BYTES && n<=RADIO_APPLET_STORE_BYTES-off;
}
static bool read_at(const radio_applet_store *s,uint32_t off,void *out,uint32_t n) {
 return (!n || out) && in_range(off,n) && (!n || s->io.read(s->io.context,off,out,n));
}
static bool write_at(const radio_applet_store *s,uint32_t off,const void *data,uint32_t n) {
 return data && n && in_range(off,n) && s->io.write(s->io.context,off,data,n);
}
static bool error(radio_applet_store *s,radio_applet_store_error why) {
 s->state=RADIO_APPLET_STORE_ERROR;s->error=why;return false;
}
static uint32_t bank_address(unsigned slot,unsigned bank) {
 return (slot*2u+bank)*RADIO_APPLET_STORE_BANK_BYTES;
}
static uint32_t stage_address(const radio_applet_store *s) {
 return bank_address(s->stage_slot,s->stage_bank);
}

bool radio_applet_store_open(radio_applet_store *s,const radio_applet_store_io *io) {
 if(!s)return false;
 radio_applet_store_io copy={0};if(io)copy=*io;
 memset(s,0,sizeof *s);s->io=copy;s->state=RADIO_APPLET_STORE_ERROR;s->error=RADIO_APPLET_STORE_IO;
 if(copy.size!=RADIO_APPLET_STORE_BYTES || copy.erase_size!=RADIO_APPLET_STORE_ERASE_BYTES ||
    !copy.read || !copy.write || !copy.erase)return false;
 s->state=RADIO_APPLET_STORE_SCANNING;s->error=RADIO_APPLET_STORE_OK;return true;
}
bool radio_applet_store_busy(const radio_applet_store *s) {
 return s && s->state!=RADIO_APPLET_STORE_READY && s->state!=RADIO_APPLET_STORE_FOREIGN && s->state!=RADIO_APPLET_STORE_ERROR;
}

/* The first twelve bytes name our exact format and physical bank. Recognizable
 * uncommitted intent can be abandoned after a power cut. Anything else remains
 * foreign, including a torn magic/version: refusing writes is preferable to
 * erasing an unidentifiable sector. Never use mere erased/header-only evidence
 * to claim a bank; its whole body is scanned too. */
static void scan_header(radio_applet_store *s,const uint8_t *h,unsigned physical) {
 s->scan_blank=(uint8_t)erased(h,RADIO_APPLET_STORE_HEADER_BYTES);
 s->scan_owned=(uint8_t)(!memcmp(h,magic,sizeof magic) && h[8]==1u &&
    h[9]==physical/2u && h[10]==physical%2u && h[11]<=1u);
 s->scan_complete=s->scan_committed=0;s->scan_crc=~0u;
 s->scan_kind=h[11];s->scan_revision=get32(h+12);s->scan_length=get32(h+16);s->scan_expected_crc=get32(h+20);
 if(!s->scan_owned)return;
 bool core=s->scan_revision && s->scan_length<=RADIO_APPLET_STORE_PACKAGE_MAX &&
    (s->scan_kind ? !s->scan_length && !s->scan_expected_crc : s->scan_length!=0u) &&
    get32(h+24)==RADIO_APPLET_STORE_HEADER_BYTES && get32(h+28)==RADIO_APPLET_STORE_BANK_BYTES &&
    get32(h+32)==RADIO_APPLET_STORE_BASE && get32(h+36)==RADIO_APPLET_STORE_BYTES &&
    get32(h+40)==RADIO_APPLET_STORE_SLOTS && get32(h+44)==RADIO_APPLET_STORE_PACKAGE_MAX &&
    !get32(h+48);
 bool crc_ok=get32(h+52)==radio_applet_store_crc(h,52);
 s->scan_complete=(uint8_t)(core && crc_ok && get32(h+56)==INTENT);
 /* A self-consistent declaration of another geometry is not a torn intent.
  * Nor may a malformed committed header authorize a future erase. */
 if((crc_ok && !core) || (!get32(h+60) && !s->scan_complete))s->foreign=true;
 s->scan_committed=(uint8_t)(s->scan_complete && !get32(h+60));
}
static void select_bank(radio_applet_store *s,unsigned physical) {
 if(!s->scan_committed || ~s->scan_crc!=s->scan_expected_crc)return;
 radio_applet_slot_info *info=&s->slots[physical/2u];
 if(info->committed && info->revision==s->scan_revision &&
    (info->length!=s->scan_length || info->crc!=s->scan_expected_crc || info->present!=(s->scan_kind==0u))) {
  s->foreign=true;s->error=RADIO_APPLET_STORE_CONFLICT;
  info->committed=info->present=false;return;
 }
 if(!info->committed || (int32_t)(s->scan_revision-info->revision)>0) {
  info->revision=s->scan_revision;info->length=s->scan_length;info->crc=s->scan_expected_crc;
  info->bank=(uint8_t)(physical%2u);info->committed=true;info->present=s->scan_kind==0u;
 }
}
static bool scan_step(radio_applet_store *s) {
 uint8_t chunk[RADIO_APPLET_STORE_SCAN_BYTES];
 uint32_t off=s->progress,in_bank=off%RADIO_APPLET_STORE_BANK_BYTES;
 if(!read_at(s,off,chunk,sizeof chunk))return error(s,RADIO_APPLET_STORE_IO);
 unsigned physical=off/RADIO_APPLET_STORE_BANK_BYTES;
 if(!in_bank)scan_header(s,chunk,physical);
 if(!s->scan_owned) {
  if(!erased(chunk,sizeof chunk))s->foreign=true;
 } else {
  uint32_t data_end=RADIO_APPLET_STORE_HEADER_BYTES+(s->scan_complete ? s->scan_length : RADIO_APPLET_STORE_PACKAGE_MAX);
  uint32_t begin=in_bank<RADIO_APPLET_STORE_HEADER_BYTES ? RADIO_APPLET_STORE_HEADER_BYTES : in_bank;
  uint32_t end=in_bank+sizeof chunk;
  if(s->scan_complete && begin<data_end) {
   uint32_t stop=end<data_end ? end : data_end;
   if(stop>begin)s->scan_crc=crc_add(s->scan_crc,chunk+begin-in_bank,stop-begin);
  }
  uint32_t padding=in_bank>data_end ? in_bank : data_end;
  if(end>padding && !erased(chunk+padding-in_bank,end-padding))s->foreign=true;
 }
 s->progress+=sizeof chunk;
 if(s->progress%RADIO_APPLET_STORE_BANK_BYTES==0u)select_bank(s,physical);
 if(s->progress==RADIO_APPLET_STORE_BYTES)
  s->state=s->foreign ? RADIO_APPLET_STORE_FOREIGN : RADIO_APPLET_STORE_READY;
 return true;
}

static bool begin(radio_applet_store *s,unsigned slot,uint32_t length,uint32_t crc,uint32_t expected,bool remove) {
 if(!s || s->state!=RADIO_APPLET_STORE_READY || s->foreign || slot>=RADIO_APPLET_STORE_SLOTS ||
    length>RADIO_APPLET_STORE_PACKAGE_MAX || (!length && !remove) ||
    s->slots[slot].revision!=expected)return false;
 if(remove && !s->slots[slot].present)return false;
 s->stage_slot=(uint8_t)slot;s->stage_bank=s->slots[slot].committed ? s->slots[slot].bank^1u : 0u;
 s->stage_kind=(uint8_t)remove;s->stage_length=length;s->stage_crc=crc;
 s->stage_revision=expected+1u;if(!s->stage_revision)s->stage_revision=1;
 s->written=s->progress=0;s->erase_step=0;s->validator=NULL;s->validator_context=NULL;
 s->state=RADIO_APPLET_STORE_ERASING;s->error=RADIO_APPLET_STORE_OK;return true;
}
bool radio_applet_store_begin(radio_applet_store *s,unsigned slot,uint32_t length,uint32_t crc,uint32_t expected) {
 return begin(s,slot,length,crc,expected,false);
}
bool radio_applet_store_remove(radio_applet_store *s,unsigned slot,uint32_t expected) {
 return begin(s,slot,0,0,expected,true);
}
static void make_header(const radio_applet_store *s,uint8_t h[64]) {
 memset(h,0,64);memcpy(h,magic,sizeof magic);
 h[8]=1;h[9]=s->stage_slot;h[10]=s->stage_bank;h[11]=s->stage_kind;
 put32(h+12,s->stage_revision);put32(h+16,s->stage_length);put32(h+20,s->stage_crc);
 put32(h+24,RADIO_APPLET_STORE_HEADER_BYTES);put32(h+28,RADIO_APPLET_STORE_BANK_BYTES);
 put32(h+32,RADIO_APPLET_STORE_BASE);put32(h+36,RADIO_APPLET_STORE_BYTES);
 put32(h+40,RADIO_APPLET_STORE_SLOTS);put32(h+44,RADIO_APPLET_STORE_PACKAGE_MAX);
 put32(h+52,radio_applet_store_crc(h,52));put32(h+56,INTENT);put32(h+60,~0u);
}
static bool erase_step(radio_applet_store *s) {
 /* Keep the prior ownership header until all other sectors are erased. If
  * power fails after the final header-sector erase, the whole bank is blank. */
 uint32_t sector=(s->erase_step+1u)%(RADIO_APPLET_STORE_BANK_BYTES/RADIO_APPLET_STORE_ERASE_BYTES);
 uint32_t off=stage_address(s)+sector*RADIO_APPLET_STORE_ERASE_BYTES;
 if(!in_range(off,RADIO_APPLET_STORE_ERASE_BYTES) || !s->io.erase(s->io.context,off))return error(s,RADIO_APPLET_STORE_IO);
 ++s->erase_step;s->progress=(uint32_t)s->erase_step*RADIO_APPLET_STORE_ERASE_BYTES;
 if(s->progress==RADIO_APPLET_STORE_BANK_BYTES)s->state=RADIO_APPLET_STORE_HEADER;
 return true;
}
static bool header_step(radio_applet_store *s) {
 uint8_t h[64],check[64];make_header(s,h);
 uint32_t off=stage_address(s);
 if(!write_at(s,off,h,60) || !read_at(s,off,check,64) || memcmp(h,check,64))return error(s,RADIO_APPLET_STORE_IO);
 s->progress=0;s->verify_crc=~0u;
 s->state=s->stage_kind ? RADIO_APPLET_STORE_VERIFYING : RADIO_APPLET_STORE_WRITING;
 return true;
}
bool radio_applet_store_write(radio_applet_store *s,uint32_t off,const void *data,uint32_t n) {
 if(!s || s->state!=RADIO_APPLET_STORE_WRITING || !data || !n || n>RADIO_APPLET_STORE_WRITE_MAX ||
    off>s->stage_length || n>s->stage_length-off || off>s->written)return false;
 uint8_t check[RADIO_APPLET_STORE_WRITE_MAX];
 uint32_t addr=stage_address(s)+RADIO_APPLET_STORE_HEADER_BYTES+off;
 if(off<s->written) {
  if(n>s->written-off)return false;
  return read_at(s,addr,check,n) && !memcmp(data,check,n);
 }
 if(!write_at(s,addr,data,n) || !read_at(s,addr,check,n) || memcmp(data,check,n))return error(s,RADIO_APPLET_STORE_IO);
 s->written+=n;s->progress=s->written;return true;
}
bool radio_applet_store_stage_read(const radio_applet_store *s,uint32_t off,void *out,uint32_t n) {
 return s && (s->state==RADIO_APPLET_STORE_WRITING || s->state==RADIO_APPLET_STORE_VERIFYING) &&
    off<=s->written && n<=s->written-off &&
    read_at(s,stage_address(s)+RADIO_APPLET_STORE_HEADER_BYTES+off,out,n);
}
bool radio_applet_store_commit(radio_applet_store *s,radio_applet_store_validator validator,void *context) {
 if(!s || s->state!=RADIO_APPLET_STORE_WRITING || s->written!=s->stage_length || !validator)return false;
 s->validator=validator;s->validator_context=context;s->verify_crc=~0u;s->progress=0;
 s->state=RADIO_APPLET_STORE_VERIFYING;return true;
}
static bool verify_step(radio_applet_store *s) {
 if(s->progress<s->stage_length) {
  uint8_t chunk[RADIO_APPLET_STORE_SCAN_BYTES];uint32_t n=s->stage_length-s->progress;
  if(n>sizeof chunk)n=sizeof chunk;
  if(!read_at(s,stage_address(s)+RADIO_APPLET_STORE_HEADER_BYTES+s->progress,chunk,n))return error(s,RADIO_APPLET_STORE_IO);
  s->verify_crc=crc_add(s->verify_crc,chunk,n);s->progress+=n;return true;
 }
 if(~s->verify_crc!=s->stage_crc)return error(s,RADIO_APPLET_STORE_CRC);
 if(!s->stage_kind && (!s->validator || !s->validator(s->validator_context,s->stage_length)))
  return error(s,RADIO_APPLET_STORE_VALIDATION);
 uint8_t commit[4]={0},check[4];uint32_t off=stage_address(s)+60u;
 if(!write_at(s,off,commit,4) || !read_at(s,off,check,4) || memcmp(commit,check,4))return error(s,RADIO_APPLET_STORE_IO);
 radio_applet_slot_info *info=&s->slots[s->stage_slot];
 info->revision=s->stage_revision;info->length=s->stage_length;info->crc=s->stage_crc;
 info->bank=s->stage_bank;info->committed=true;info->present=!s->stage_kind;
 s->state=RADIO_APPLET_STORE_READY;s->validator=NULL;s->validator_context=NULL;return true;
}
bool radio_applet_store_step(radio_applet_store *s) {
 if(!s)return false;
 switch(s->state) {
 case RADIO_APPLET_STORE_SCANNING:return scan_step(s);
 case RADIO_APPLET_STORE_ERASING:return erase_step(s);
 case RADIO_APPLET_STORE_HEADER:return header_step(s);
 case RADIO_APPLET_STORE_VERIFYING:return verify_step(s);
 case RADIO_APPLET_STORE_READY:case RADIO_APPLET_STORE_WRITING:return true;
 default:return false;
 }
}
void radio_applet_store_abort(radio_applet_store *s) {
 if(!s || s->state==RADIO_APPLET_STORE_SCANNING || s->state==RADIO_APPLET_STORE_FOREIGN ||
    (s->state==RADIO_APPLET_STORE_ERROR && s->error!=RADIO_APPLET_STORE_CRC && s->error!=RADIO_APPLET_STORE_VALIDATION))return;
 s->state=RADIO_APPLET_STORE_READY;s->validator=NULL;s->validator_context=NULL;s->written=s->progress=0;
}
bool radio_applet_store_read(const radio_applet_store *s,unsigned slot,uint32_t off,void *out,uint32_t n) {
 if(!s || s->state==RADIO_APPLET_STORE_SCANNING || slot>=RADIO_APPLET_STORE_SLOTS)return false;
 const radio_applet_slot_info *info=&s->slots[slot];
 return info->committed && info->present && off<=info->length && n<=info->length-off &&
    read_at(s,bank_address(slot,info->bank)+RADIO_APPLET_STORE_HEADER_BYTES+off,out,n);
}
