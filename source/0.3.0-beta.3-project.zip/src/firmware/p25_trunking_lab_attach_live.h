// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit finite REGISTER/AFFILIATE laboratory bootstrap. No subscriber RF
// dispatcher, clock qualification or production registration flags are set.
#ifndef P25_TRUNKING_LAB_ATTACH_LIVE_H
#define P25_TRUNKING_LAB_ATTACH_LIVE_H
#include "p25_trunking_lab_attach.h"

static p25_lab_attach trunk_lab_attach;
static struct {
    typeof(trunk_preload_config) config;
    uint8_t stage; //0REGISTER,1AFFILIATE,2originalGROUP/MIC configuration.
    bool selected,dispatching,cleaning,retaining,restore_pending;
} trunk_lab_attach_io;
_Static_assert(sizeof trunk_lab_attach_io<=24u,"JOIN live adapter exceeds its compact budget");
static bool trunk_lab_attach_selected(void) {return trunk_lab_attach_io.selected;}
static bool trunk_lab_attach_preserve(void) {return trunk_lab_attach_io.selected || trunk_lab_attach_io.cleaning;}
static p25_lab_exchange_owner trunk_lab_attach_current(void) {
    p25_lab_exchange_owner o={0};
    if(control.talkgroup<1u || control.talkgroup>0xffffu)return o;
    o.sequence=trunk_lab_attach.owner.sequence;o.owner_tag=trunk_lab_return_tag();
    o.radio_id=control.source_id;o.wacn=TRUNK_PROBE_WACN;o.system=TRUNK_PROBE_SYSTEM;
    o.nac=control.nac;o.group=(uint16_t)control.talkgroup;o.profile=trunk_lab_profile;
    o.control_rx_hz=frequency;o.control_tx_hz=control.tx_frequency;
    o.request=P25_LAB_GROUP;o.expected_channel=TRUNK_PRELOAD_GROUP_CHANNEL;o.expected_options=TRUNK_PRELOAD_GROUP_OPTIONS;
    return o;
}
static bool trunk_lab_attach_identity(void) {
    typeof(trunk_preload_config) expected=trunk_lab_attach_io.config;
    if(trunk_lab_attach_io.stage<2u) {expected.request=trunk_lab_attach_io.stage;expected.voice=TRUNK_PRELOAD_VOICE_OFF;}
    return trunk_lab_attach_io.selected
        && !memcmp(&expected,&trunk_preload_config,sizeof expected)
        && control.talkgroup==trunk_preload_owner.talkgroup
        && !memcmp(channel_record,trunk_preload_owner.channel,32)
        && !memcmp(global_record,trunk_preload_owner.globals,32);
}
static bool trunk_lab_attach_permission(void) {
    return trunk_lab_attach_identity() && normal_mode && features_ready && feature_p25()
        && !trunk_enabled && trunk_probe_profile_matches() && control.split
        && !radio_channel_get_private(channel_record) && !channel_scan.running
        && !apps_active() && !pcm_owner && !applet_owns_radio && !cps_active && !cps_link
        && !editing && !menu_open && !rx_lab && !rx_job && !broadcast_show && !airband_show
        && !digital_dmr.owned && !analog_fm.owned && dev && hooks && board.audio && board.radio
        && feature_tx_settings_valid() && feature_tx_power()==0u && tx_writer==TX_WRITER_ALT1
        && tx_dac_restore && !tx_fixed && !control.cancel && !owner_tx_inhibit
        && !control.inhibit && control.state!=RADIO_FAULT && control.tx_enabled
        && !(channel_record[12]&16u) && board.power->switch_on();
}
static bool trunk_lab_attach_request_permission(void) {
    unsigned phase=trunk_lab_attach.phase;
    return ((phase>=P25_LAB_ATTACH_REGISTER && phase<=P25_LAB_ATTACH_WAIT_AFF)
            || phase==P25_LAB_ATTACH_ARM_PTT)
        && trunk_lab_attach_permission() && trunk_preload_task_ptt_released(false)
        && hrc_pin_read(PIN_PTT) && trunk_preload_warm_health();
}
static bool trunk_lab_attach_internal(void) {
    return trunk_lab_attach_io.dispatching && trunk_lab_attach_io.selected;
}
static bool trunk_lab_attach_arm_permission(void) {
    return trunk_lab_attach.phase==P25_LAB_ATTACH_ARM_PTT && trunk_lab_attach_request_permission()
        && trunk_lab_return_rf_off();
}
static bool trunk_lab_attach_commit_permitted(void) {
    if(!trunk_lab_attach_io.selected || trunk_lab_attach.phase==P25_LAB_ATTACH_ARMED)return true;
    p25_lab_exchange_owner expected=trunk_lab_attach.owner;
    if(trunk_lab_attach_io.stage==1u) {++expected.sequence;if(!expected.sequence)expected.sequence=1u;}
    expected.request=trunk_lab_attach_io.stage==0u ? P25_LAB_REGISTER:P25_LAB_AFFILIATE;
    expected.expected_channel=0;expected.expected_options=0;
    return trunk_lab_attach_identity()
        && ((trunk_lab_attach_io.stage==0u && trunk_lab_attach.phase==P25_LAB_ATTACH_WAIT_REG)
            || (trunk_lab_attach_io.stage==1u && trunk_lab_attach.phase==P25_LAB_ATTACH_WAIT_AFF))
        && trunk_lab_attach.prepared_epoch==trunk_lab_exchange.previous_epoch
        && trunk_lab_attach.prepared_us==trunk_lab_exchange.prepared_us
        && trunk_probe.sequence==expected.sequence
        && trunk_lab_exchange.phase==P25_LAB_PREPARED
        && p25_lab_exchange_owner_matches(&trunk_lab_exchange,&expected);
}
static bool trunk_lab_attach_fire_permitted(void) {
    return (!trunk_lab_attach_io.selected || trunk_lab_attach.phase==P25_LAB_ATTACH_ARMED
            || trunk_lab_attach_io.dispatching)
        && trunk_lab_attach_commit_permitted();
}
static void trunk_lab_attach_cancel(void) {
    if(!trunk_lab_attach_io.selected && !p25_lab_attach_owned(&trunk_lab_attach))return;
    uint32_t lock=hrc_irq_save();
    if(trunk_lab_attach.phase<=P25_LAB_ATTACH_ARMED)
        p25_lab_attach_cancel(&trunk_lab_attach,P25_LAB_ATTACH_CANCEL);
    trunk_lab_attach_io.restore_pending=true;
    if(!trunk_lab_attach_io.retaining && !trunk_lab_ptt_io.retaining)trunk_lab_attach_io.selected=false;
    ptt_release_required=true;ptt_release_seen=false;
    hrc_irq_restore(lock);
}
static void trunk_lab_attach_cancel_off(void) {
    if(!trunk_lab_attach_io.restore_pending || !trunk_lab_return_rf_off())return;
    uint32_t lock=hrc_irq_save();
    if(p25_lab_attach_owned(&trunk_lab_attach))
        (void)p25_lab_attach_abort_off(&trunk_lab_attach,true,hrc_micros());
    trunk_preload_config=trunk_lab_attach_io.config;
    trunk_lab_attach_io.stage=2u;trunk_lab_attach_io.restore_pending=false;
    hrc_irq_restore(lock);
}
static bool trunk_lab_attach_fail(void) {
    trunk_lab_attach_io.retaining=true;trunk_lab_return_cancel();trunk_lab_attach_io.retaining=false;
    // Natural JOIN failure returns ordinary RX. Explicit STOP/update calls the
    // cancellation hooks directly and never starts RX behind that command.
    if(trunk_lab_return_rf_off() && normal_mode && feature_p25() && board.power->switch_on()) {
        mon_enabled=true;(void)mon_start();
    }
    reason="lab_join_failed";return true;
}
static bool trunk_lab_attach_dispatch(void) {
    p25_lab_exchange_owner leg,current=trunk_lab_attach_current();
    if(!p25_lab_attach_leg_owner(&trunk_lab_attach,&leg) || !trunk_lab_return_rf_off()
       || !trunk_lab_attach_permission() || !trunk_preload_task_ptt_released(false)
       || !hrc_pin_read(PIN_PTT) || !trunk_preload_warm_health())return false;
    // The previous native reply has ended. Retire its recorder before changing
    // the volatile request purpose; no old samples/epoch can reach the new leg.
    trunk_lab_attach_io.cleaning=true;
    if(mon_running)mon_stop("lab_join_next");
    trunk_lab_attach_io.stage=leg.request==P25_LAB_REGISTER ? 0u:1u;
    trunk_preload_config.request=trunk_lab_attach_io.stage;
    trunk_preload_config.voice=TRUNK_PRELOAD_VOICE_OFF;
    trunk_lab_attach_io.dispatching=true;
    bool okay=trunk_preload_prepare(false,true);
    uint32_t lock=hrc_irq_save();
    if(okay)okay=p25_lab_attach_bind_prepared(&trunk_lab_attach,&trunk_lab_exchange,&current,hrc_micros());
    hrc_irq_restore(lock);
    if(okay)okay=trunk_preload_config.clock ? trunk_preload_clock_poll(leg.sequence,false)
        : trunk_preload_fire(leg.sequence,false);
    trunk_lab_attach_io.dispatching=false;trunk_lab_attach_io.cleaning=false;
    return okay;
}
static bool trunk_lab_attach_exchange(void) {
    if(!trunk_lab_attach_io.selected || (trunk_lab_attach.phase!=P25_LAB_ATTACH_WAIT_REG
        && trunk_lab_attach.phase!=P25_LAB_ATTACH_WAIT_AFF))return false;
    p25_lab_exchange_owner current=trunk_lab_attach_current();
    bool permission=trunk_lab_attach_permission() && trunk_preload_warm_health();
    uint32_t lock=hrc_irq_save();
    bool okay=p25_lab_attach_observe(&trunk_lab_attach,&trunk_lab_exchange,&current,
        trunk_preload_task_ptt_released(false),permission,trunk_lab_return_rf_off(),hrc_micros());
    hrc_irq_restore(lock);
    if(!okay)return trunk_lab_attach_fail();
    if(trunk_lab_attach.phase==P25_LAB_ATTACH_AFFILIATE) {
        if(!trunk_lab_attach_dispatch())return trunk_lab_attach_fail();
        return true;
    }
    if(trunk_lab_attach.phase!=P25_LAB_ATTACH_RETURN_PENDING)return trunk_lab_attach_fail();
    trunk_lab_attach_io.cleaning=true;mon_stop("lab_join_receipts");
    trunk_preload_config=trunk_lab_attach_io.config;trunk_lab_attach_io.stage=2u;
    lock=hrc_irq_save();
    okay=p25_lab_attach_begin_return(&trunk_lab_attach,trunk_lab_return_rf_off(),hrc_micros());
    hrc_irq_restore(lock);
    mon_enabled=true;if(okay)okay=mon_start();trunk_lab_attach_io.cleaning=false;
    if(!okay)return trunk_lab_attach_fail();
    trunk_lab_stages.resume_epoch=trunk_stream_epoch;trunk_lab_stages.resume_us=hrc_micros();
    reason="lab_join_return";return true;
}
static void trunk_lab_attach_poll(bool down) {
    if(!trunk_lab_attach_io.selected) {trunk_lab_attach_cancel_off();return;}
    if(trunk_lab_attach.phase>=P25_LAB_ATTACH_ARMED) {trunk_lab_attach_cancel_off();return;}
    p25_lab_exchange_owner current=trunk_lab_attach_current();
    bool released=trunk_preload_task_ptt_released(down);
    bool permission=trunk_lab_attach_permission() && trunk_preload_warm_health();
    uint32_t lock=hrc_irq_save();
    bool okay=p25_lab_attach_input(&trunk_lab_attach,&current,released,permission,hrc_micros());
    hrc_irq_restore(lock);
    if(!okay) {(void)trunk_lab_attach_fail();return;}
    if(trunk_lab_attach.phase==P25_LAB_ATTACH_REGISTER || trunk_lab_attach.phase==P25_LAB_ATTACH_AFFILIATE) {
        if(!trunk_lab_attach_dispatch())(void)trunk_lab_attach_fail();
        return;
    }
    if(trunk_preload_config.clock && trunk_preload_warmed()
       && (trunk_lab_attach.phase==P25_LAB_ATTACH_WAIT_REG || trunk_lab_attach.phase==P25_LAB_ATTACH_WAIT_AFF)) {
        trunk_lab_attach_io.dispatching=true;
        okay=trunk_preload_clock_poll(trunk_probe.sequence,down);
        trunk_lab_attach_io.dispatching=false;
        if(!okay)(void)trunk_lab_attach_fail();
        return;
    }
    if(trunk_lab_attach.phase!=P25_LAB_ATTACH_RETURN)return;
    if(!mon_running || mon_failed || mon_control_only || receiver_frequency()!=current.control_rx_hz) {
        (void)trunk_lab_attach_fail();return;
    }
    lock=hrc_irq_save();
    okay=p25_lab_attach_ready(&trunk_lab_attach,trunk_stream_epoch,monitor.raw_blocks!=0,
        released,trunk_lab_return_rf_off(),hrc_micros());
    if(okay)okay=p25_lab_attach_consume_ready(&trunk_lab_attach,&current,trunk_stream_epoch,
        released,permission,trunk_lab_return_rf_off(),hrc_micros());
    hrc_irq_restore(lock);
    if(trunk_lab_attach.phase!=P25_LAB_ATTACH_ARM_PTT)return;
    okay=okay && trunk_lab_ptt_arm(false);
    lock=hrc_irq_save();
    bool armed_okay=p25_lab_attach_armed(&trunk_lab_attach,&trunk_lab_ptt.owner,okay,hrc_micros());
    hrc_irq_restore(lock);
    if(!okay || !armed_okay)(void)trunk_lab_attach_fail();
}
static bool trunk_lab_attach_start(bool down) {
    if(down || !hrc_pin_read(PIN_PTT) || (board.input->scan()&ptt_mask)) {
        ptt_release_required=true;ptt_release_seen=false;return false;
    }
    if(!ptt_mask || trunk_lab_attach_io.selected || trunk_lab_ptt_selected()
       || trunk_lab_return_owned() || trunk_probe.active || call_active || prepared || hardware_running
       || radio_busy(&control) || rx_sampling || armed || session_enabled || !trunk_probe_mailbox_idle()
       || ptt_release_required || !trunk_preload_config.configured || !trunk_preload_config.return_rx
       || trunk_preload_config.phase || (trunk_preload_config.clock && !trunk_preload_clock_configured())
       || trunk_preload_config.request!=2u || trunk_preload_config.voice!=TRUNK_PRELOAD_VOICE_MIC
       || !trunk_probe_context() || !trunk_preload_warm_health() || !trunk_stream_epoch
       || (mon_running && (mon_sync_active(hrc_micros()) || monitor.call.active || monitor.playing
            || mon_routed || mon_pcm_pending || monitor.pcm_head!=monitor.pcm_tail)))return false;
    p25_lab_exchange_owner current=trunk_lab_attach_current();
    current.sequence=trunk_probe.sequence+1u;if(!current.sequence)current.sequence=1u;
    uint32_t lock=hrc_irq_save();
    bool okay=p25_lab_attach_start(&trunk_lab_attach,&current,trunk_stream_epoch,true,true,
        trunk_lab_return_rf_off(),hrc_micros());
    if(okay) {
        memset(&trunk_lab_attach_io,0,sizeof trunk_lab_attach_io);
        trunk_lab_attach_io.config=trunk_preload_config;trunk_lab_attach_io.stage=2u;
        trunk_lab_attach_io.selected=true;
        memcpy(trunk_preload_owner.channel,channel_record,32);memcpy(trunk_preload_owner.globals,global_record,32);
        trunk_preload_owner.talkgroup=control.talkgroup;
    }
    hrc_irq_restore(lock);
    if(okay) {reason="lab_join_started";home_hint_refresh();}return okay;
}
static bool trunk_lab_attach_command(const char *line,bool down) {
    if(!strcmp(line,"TRUNK JOIN STATUS")) {telemetry_request(TELEMETRY_LABATTACH);return true;}
    if(!strcmp(line,"TRUNK JOIN START")) {
        send(trunk_lab_attach_start(down) ? "OK TRUNK JOIN START finite REGISTER AFFILIATE then one GROUP MIC arm\r\n"
            : "ERR TRUNK JOIN START idle released PTT and GROUP RETURN MIC required\r\n");return true;
    }
    return false;
}
static int trunk_lab_attach_status_row(unsigned row,char *line,size_t capacity) {
    p25_lab_attach value;typeof(trunk_lab_attach_io) io;
    uint32_t lock=hrc_irq_save();value=trunk_lab_attach;io=trunk_lab_attach_io;hrc_irq_restore(lock);
    if(row==0u)return snprintf(line,capacity,"TRUNKJOIN selected=%u phase=%u reason=%u sequence=%lu source=%lu group=%u nac=%03x profile=%s start_us=%lu start_epoch=%lu total_limit_us=8000000 production_registration=0 production_affiliation=0 access=unqualified\r\n",
        (unsigned)io.selected,(unsigned)value.phase,(unsigned)value.reason,(unsigned long)value.owner.sequence,
        (unsigned long)value.owner.radio_id,(unsigned)value.owner.group,(unsigned)value.owner.nac,
        p25_trunking_lab_name(value.owner.profile),(unsigned long)value.start_us,(unsigned long)value.start_epoch);
    if(row==1u)return snprintf(line,capacity,"TRUNKJOIN_END reg_seq=%lu reg_epoch=%lu reg_reply_us=%lu reg_assigned=%lu reg_type=%u reg_response=%u aff_seq=%lu aff_epoch=%lu aff_reply_us=%lu aff_group=%u aff_type=%u aff_response=%u return_us=%lu ready_us=%lu ready_epoch=%lu ptt_sequence=%lu timestamps=software_not_air\r\n",
        (unsigned long)value.registration.sequence,(unsigned long)value.registration.rx_epoch,(unsigned long)value.registration.reply_us,
        (unsigned long)value.registration.assigned,(unsigned)value.registration.type,(unsigned)value.registration.response,
        (unsigned long)value.affiliation.sequence,(unsigned long)value.affiliation.rx_epoch,(unsigned long)value.affiliation.reply_us,
        (unsigned)value.affiliation.group,(unsigned)value.affiliation.type,(unsigned)value.affiliation.response,
        (unsigned long)value.return_us,(unsigned long)value.ready_us,(unsigned long)value.ready_epoch,
        (unsigned long)(trunk_lab_ptt_selected() ? trunk_lab_ptt.owner.sequence:0u));
    return -1;
}
#endif
