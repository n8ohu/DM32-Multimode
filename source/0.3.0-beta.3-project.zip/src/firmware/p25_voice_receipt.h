// SPDX-License-Identifier: GPL-3.0-or-later
// One bounded task-side receipt; no allocation, hardware access or formatting.
#ifndef P25_VOICE_RECEIPT_H
#define P25_VOICE_RECEIPT_H
#include "imbe_mic_queue.h"
#include "p25_live_tx.h"
#include <limits.h>
#include <string.h>

enum {
    P25_VOICE_RECEIPT_VALID=1u,
    P25_VOICE_RECEIPT_PTT_DOWN=2u,
    P25_VOICE_RECEIPT_TOT=4u,
    P25_VOICE_RECEIPT_SATURATED=8u
};
typedef enum {
    P25_VOICE_END_UNKNOWN, P25_VOICE_END_COMPLETE,
    P25_VOICE_END_RELEASED_BEFORE_RF, P25_VOICE_END_TIME_LIMIT,
    P25_VOICE_END_RF_UNDERRUN, P25_VOICE_END_RF_TIMING,
    P25_VOICE_END_PCM_DRIVER_LOSS, P25_VOICE_END_PCM_OVERFLOW,
    P25_VOICE_END_PCM_STALLED, P25_VOICE_END_LDU_PUBLISH,
    P25_VOICE_END_CALL_TIMEOUT, P25_VOICE_END_CODEC_OWNER,
    P25_VOICE_END_HARD_TIMEOUT, P25_VOICE_END_CANCELLED,
    P25_VOICE_END_TRUNK_TRANSPORT
} p25_voice_end_reason;
typedef struct {
    uint32_t action_id,max_gap_us;
    uint16_t captured,encoded,published,consumed,underruns,pcm_overflow;
    uint16_t driver_loss,peak,max_encode_us,mic_mean_abs;
    uint8_t state,timing_reason,stop_reason,flags;
} p25_voice_receipt;
_Static_assert(sizeof(p25_voice_receipt)==32u,"Terminal voice receipt must remain32 bytes");

// Reset only for a new admitted VOICE_START, never for control requests or RX.
// Repeating the same generation cannot erase an already-latched receipt.
static inline bool p25_voice_receipt_begin(p25_voice_receipt *r,uint32_t action_id) {
    if(!r || !action_id || r->action_id==action_id)return false;
    memset(r,0,sizeof *r);r->action_id=action_id;return true;
}
static inline p25_voice_end_reason p25_voice_receipt_reason(const char *end_reason) {
    if(!end_reason)return P25_VOICE_END_UNKNOWN;
    static const struct { const char *name;uint8_t code; } names[]={
        {"complete",P25_VOICE_END_COMPLETE},
        {"released_before_rf",P25_VOICE_END_RELEASED_BEFORE_RF},
        {"time_limit",P25_VOICE_END_TIME_LIMIT},
        {"rf_underrun",P25_VOICE_END_RF_UNDERRUN},
        {"rf_timing",P25_VOICE_END_RF_TIMING},
        {"pcm_driver_loss",P25_VOICE_END_PCM_DRIVER_LOSS},
        {"pcm_overflow",P25_VOICE_END_PCM_OVERFLOW},
        {"pcm_stalled",P25_VOICE_END_PCM_STALLED},
        {"ldu_publish",P25_VOICE_END_LDU_PUBLISH},
        {"call_timeout",P25_VOICE_END_CALL_TIMEOUT},
        {"codec_owner",P25_VOICE_END_CODEC_OWNER},
        {"hard_timeout",P25_VOICE_END_HARD_TIMEOUT},
        {"cancelled",P25_VOICE_END_CANCELLED},
        {"trunk_transport_failed",P25_VOICE_END_TRUNK_TRANSPORT}
    };
    for(unsigned i=0;i<sizeof names/sizeof names[0];++i)
        if(!strcmp(end_reason,names[i].name))return (p25_voice_end_reason)names[i].code;
    return P25_VOICE_END_UNKNOWN;
}
static inline uint16_t p25_voice_receipt_count(uint32_t value,uint8_t *flags) {
    if(value>UINT16_MAX) {*flags|=P25_VOICE_RECEIPT_SATURATED;return UINT16_MAX;}
    return (uint16_t)value;
}
// Caller holds the existing IRQ lock for a coherent source snapshot. Invoke in
// task context after RF is terminal and before cleanup, RX restart or request
// reuse. voice_action_id is the original VOICE_START generation, even during
// its later STOP action. An attempted snapshot never changes the live sources.
static inline bool p25_voice_receipt_latch(p25_voice_receipt *r,uint32_t voice_action_id,
    const p25_live_tx *tx,const imbe_mic_queue *mic,uint32_t encoded_count,
    uint32_t driver_loss_count,uint32_t max_encode_us,
    const char *end_reason,bool ptt_down,bool tot_expired) {
    if(!r || !tx || !mic || !voice_action_id || r->action_id!=voice_action_id
       ||(r->flags&P25_VOICE_RECEIPT_VALID)
       ||(tx->timing.state!=P25_TX_DONE && tx->timing.state!=P25_TX_ABORTED))return false;
    p25_voice_receipt value={0};value.action_id=voice_action_id;
    value.max_gap_us=tx->timing.max_gap_us;
    value.flags=P25_VOICE_RECEIPT_VALID
        |(ptt_down?P25_VOICE_RECEIPT_PTT_DOWN:0u)|(tot_expired?P25_VOICE_RECEIPT_TOT:0u);
    value.captured=p25_voice_receipt_count(mic->captured,&value.flags);
    value.encoded=p25_voice_receipt_count(encoded_count,&value.flags);
    value.published=p25_voice_receipt_count(tx->published,&value.flags);
    value.consumed=p25_voice_receipt_count(tx->consumed,&value.flags);
    value.underruns=p25_voice_receipt_count(tx->underruns,&value.flags);
    value.pcm_overflow=p25_voice_receipt_count(mic->overflow,&value.flags);
    value.driver_loss=p25_voice_receipt_count(driver_loss_count,&value.flags);
    value.peak=p25_voice_receipt_count(mic->peak,&value.flags);
    value.max_encode_us=p25_voice_receipt_count(max_encode_us,&value.flags);
    value.mic_mean_abs=mic->captured
        ?p25_voice_receipt_count((uint32_t)(mic->sum_abs/((uint64_t)mic->captured*160u)),&value.flags):0u;
    value.state=(uint8_t)tx->timing.state;value.timing_reason=(uint8_t)tx->timing.reason;
    value.stop_reason=(uint8_t)p25_voice_receipt_reason(end_reason);
    *r=value;return true;
}
#endif
