// SPDX-License-Identifier: GPL-3.0-or-later
// Exclusive task-context AM receiver; caller pauses all communications owners.
#ifndef RADIO_AIRBAND_H
#define RADIO_AIRBAND_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "hal_radio.h"
#include "hal_audio.h"

#define RADIO_AIRBAND_MIN_HZ 108000000u
#define RADIO_AIRBAND_MAX_HZ 137000000u // Exclusive: 137 MHz is outside airband.
#define RADIO_AIRBAND_DEFAULT_HZ 118000000u
#define RADIO_AIRBAND_STEP_25K 25000u
#define RADIO_AIRBAND_STEP_833 8333u // Exact 25000/3-Hz grid, not repeated +8333.
#define RADIO_AIRBAND_STATUS_US 25000u

typedef struct {
    const hal_radio_t *radio;
    const hal_audio_t *audio;
    radio_status_t status;
    uint32_t hz,status_due_us;
    radio_bw_t bandwidth;
    uint8_t squelch,close_count;
    bool owned,running,audio_open,have_status,failed;
} radio_airband;

static inline bool radio_airband_valid(uint32_t hz) {
    return hz>=RADIO_AIRBAND_MIN_HZ && hz<RADIO_AIRBAND_MAX_HZ;
}
static inline void radio_airband_audio(radio_airband *b,bool on) {
    if(b->audio_open!=on) {b->radio->audio(on);b->audio_open=on;}
}
// Mute and drain both speaker paths before releasing ownership. tx_off() is an
// unkey-only safety net, not a transmit request. The selected owner's subsequent
// rx()/actual mode transition restores the demodulator: set_mode(FM) alone is a
// no-op when AM already uses the board's FM hardware mode.
static inline void radio_airband_stop(radio_airband *b) {
    if(!b || !b->owned)return;
    b->radio->audio(false);b->audio_open=false;
    b->audio->stop();b->audio->speaker_pcm(false);
    b->radio->tx_off();
    b->owned=b->running=b->have_status=false;b->close_count=0;
}
static inline bool radio_airband_fail(radio_airband *b) {
    b->failed=true;radio_airband_stop(b);return false;
}
// A physical PTT never reaches tx() through this adapter. The caller must also
// inhibit its ordinary TX dispatch while this auxiliary receiver owns the HAL.
static inline bool radio_airband_start(radio_airband *b,const hal_radio_t *radio,
                                      const hal_audio_t *audio,uint32_t hz,
                                      radio_bw_t bandwidth,unsigned squelch,uint32_t now_us) {
    if(!b || b->owned || !radio_airband_valid(hz) || squelch>9u
       || (bandwidth!=RADIO_BW_12K5 && bandwidth!=RADIO_BW_25K)
       || !radio || !radio->set_mode || !radio->rx_am || !radio->audio
       || !radio->status || !radio->tx_off || !audio || !audio->stop
       || !audio->speaker_pcm)return false;
    memset(b,0,sizeof *b);b->radio=radio;b->audio=audio;
    b->hz=hz;b->bandwidth=bandwidth;b->squelch=(uint8_t)squelch;b->owned=true;
    radio->audio(false);audio->stop();audio->speaker_pcm(false);
    radio->tx_off();radio->set_mode(RADIO_MODE_FM);
    if(!radio->rx_am(hz,bandwidth))return radio_airband_fail(b);
    b->running=true;b->status_due_us=now_us;return true;
}
static inline bool radio_airband_tune(radio_airband *b,uint32_t hz) {
    if(!b || !b->owned || !b->running || !radio_airband_valid(hz)
       || (b->bandwidth!=RADIO_BW_12K5 && b->bandwidth!=RADIO_BW_25K))return false;
    radio_airband_audio(b,false);
    if(!b->radio->rx_am(hz,b->bandwidth))return radio_airband_fail(b);
    b->hz=hz;b->have_status=false;b->close_count=0;return true;
}
// AM has no meaningful FM noise or sub-audio reading. Use the upstream AM
// RSSI policy (-18 dBm reference), with the usual 3-dB/2-poll close hysteresis.
static inline bool radio_airband_poll(radio_airband *b,uint32_t now_us) {
    if(!b || !b->owned || !b->running)return false;
    if(b->have_status && (int32_t)(now_us-b->status_due_us)<0)return true;
    b->status_due_us=now_us+RADIO_AIRBAND_STATUS_US;
    b->radio->status(&b->status);b->have_status=true;
    int32_t level=-18-(int32_t)b->status.rssi_dbm;
    unsigned noise=level<0 ? 0u : level>255 ? 255u : (unsigned)level;
    unsigned threshold=b->squelch ? 64u-(b->squelch-1u)*3u : 255u;
    if(!b->audio_open) {
        if(!b->squelch || noise<threshold) {b->close_count=0;radio_airband_audio(b,true);}
    } else if(!b->squelch || noise<threshold+3u)b->close_count=0;
    else if(++b->close_count>=2u) {b->close_count=0;radio_airband_audio(b,false);}
    return true;
}
// Select grid indices rather than accumulating rounded frequencies. This also
// handles the encoder's accumulated detents and INT_MIN without signed overflow.
// Unsupported steps/invalid input/zero detents preserve the supplied frequency.
static inline uint32_t radio_airband_step(uint32_t hz,int direction,unsigned step) {
    if(!radio_airband_valid(hz) || !direction
       || (step!=RADIO_AIRBAND_STEP_25K && step!=RADIO_AIRBAND_STEP_833))return hz;
    uint32_t denominator=step==RADIO_AIRBAND_STEP_833 ? 3u : 1u;
    uint32_t count=(RADIO_AIRBAND_MAX_HZ-RADIO_AIRBAND_MIN_HZ)*denominator/25000u;
    uint32_t index=((uint64_t)(hz-RADIO_AIRBAND_MIN_HZ)*denominator+12500u)/25000u;
    if(index>=count)index=count-1u;
    int64_t next=((int64_t)index+(int64_t)direction)%(int64_t)count;
    if(next<0)next+=count;
    return RADIO_AIRBAND_MIN_HZ+(uint32_t)(((uint64_t)next*25000u+denominator/2u)/denominator);
}
// MHz decimal (118.025), or three whole-MHz digits with an optional decimal
// suffix (118025 ->118.025 MHz, 1180250 retains the older 100-Hz format).
// The UI converts # to '.' before calling. No terminator is required. Invalid
// input never changes the output, truncates significant digits or changes HAL.
static inline bool radio_airband_input_hz(const char *text,unsigned length,uint32_t *hz) {
    if(!text || !hz || length<3u || length>9u)return false;
    uint32_t whole=0,fraction=0;unsigned point=length;
    for(unsigned i=0;i<length;++i) {
        unsigned char c=(unsigned char)text[i];
        if(c=='.') {
            if(i!=3u || point!=length || i+1u==length)return false;
            point=i;continue;
        }
        if(c<'0' || c>'9')return false;
        if(i<3u)whole=whole*10u+(unsigned)(c-'0');
        else fraction=fraction*10u+(unsigned)(c-'0');
    }
    if(whole<108u || whole>=137u)return false;
    unsigned places=point==length ? length-3u : length-4u;
    if(places>6u)return false;
    while(places++<6u)fraction*=10u;
    uint32_t value=whole*1000000u+fraction;
    if(!radio_airband_valid(value))return false;
    *hz=value;return true;
}
#endif
