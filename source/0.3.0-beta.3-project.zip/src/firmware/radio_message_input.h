// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef RADIO_MESSAGE_INPUT_H
#define RADIO_MESSAGE_INPUT_H
#include "radio_call_services.h"
typedef struct {char text[RADIO_MESSAGE_TEXT_BYTES+1];uint32_t last_ms;uint8_t key,cycle;bool pending;} radio_text_input;
// A second press within 800 ms cycles one character; Right commits it early.
static inline bool radio_text_key(radio_text_input *s,unsigned key,uint32_t now) {
    static const char *const map[]={" 0",".,?!1","ABC2","DEF3","GHI4","JKL5","MNO6","PQRS7","TUV8","WXYZ9"};
    if(key>9u)return false;
    size_t n=strlen(s->text);bool same=s->pending && s->key==key && now-s->last_ms<800u && n;
    if(!same && n>=RADIO_MESSAGE_TEXT_BYTES)return false;
    s->cycle=same ? (uint8_t)((s->cycle+1u)%strlen(map[key])) : 0;
    s->text[same ? n-1u : n]=map[key][s->cycle];
    if(!same)s->text[n+1u]=0;
    s->key=(uint8_t)key;s->last_ms=now;s->pending=true;return true;
}
static inline void radio_text_erase(radio_text_input *s) {
    size_t n=strlen(s->text);if(n)s->text[n-1u]=0;s->pending=false;
}
#endif
