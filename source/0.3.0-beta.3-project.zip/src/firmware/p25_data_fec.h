// SPDX-License-Identifier: GPL-3.0-or-later
// CAI coding orientation independently checked against pinned OP25 p25craft.
#ifndef P25_DATA_FEC_H
#define P25_DATA_FEC_H
#include "p25_data.h"
#include <string.h>
static inline unsigned p25_data_get_dibit(const uint8_t *p,unsigned i) {
    return (p[i/4u]>>(6u-2u*(i%4u)))&3u;
}
static inline uint16_t p25_data_crc16(const uint8_t *p,unsigned n) {
    uint16_t c=0;
    for(unsigned i=0;i<n;++i)for(unsigned j=0;j<8;++j) {
        unsigned feedback=((c>>15)^(p[i]>>(7u-j)))&1u;
        c=(uint16_t)(c<<1);if(feedback)c^=0x1021u;
    }
    return (uint16_t)(c^0xffffu);
}
static const uint8_t p25_data_trellis[4][4]={
    {0x2,0xc,0x1,0xf},{0xe,0x0,0xd,0x3},
    {0x9,0x7,0xa,0x4},{0x5,0xb,0x6,0x8}
};
// Every emitted nibble identifies exactly one (previous,next) state pair.
// This inverse is checked against all sixteen encoder edges in host tests.
static const uint8_t p25_data_trellis_inverse[16]={
    5,2,0,7,11,12,14,9,15,8,10,13,1,6,4,3
};
// Index of an interleaved dibit in the un-interleaved 98-dibit block.
static inline unsigned p25_data_interleave_index(unsigned i) {
    unsigned pair=i/2u;
    if(pair<13u)return pair*8u+i%2u;
    pair-=13u;
    return (pair/12u+1u)*2u+(pair%12u)*8u+i%2u;
}
static inline unsigned p25_data_hamming4(unsigned v) {
    v=v-((v>>1)&5u);return (v&3u)+((v>>2)&3u);
}
// Full 4-state hard-decision Viterbi, forced zero start and tail. Packet CRCs
// provide integrity; excessive trellis damage is refused before app parsing.
static inline bool p25_data_decode_block(const uint8_t *frame,size_t bytes,
    unsigned block,uint8_t out[12]) {
    uint8_t received[98],predecessor[49][4];
    uint16_t metric[4]={0,0x3fff,0x3fff,0x3fff};
    for(unsigned i=0;i<98u;++i) {
        unsigned data=56u+block*98u+i,physical=data+data/35u;
        if(physical>=bytes*4u)return false;
        received[p25_data_interleave_index(i)]=(uint8_t)p25_data_get_dibit(frame,physical);
    }
    {
        // An exact zero-metric path is the unique Viterbi winner, provided
        // both forced endpoint states match. Use the existing predecessor
        // scratch: fallback overwrites every entry before its traceback.
        // Do not publish partial output or treat a clean codeword as a CRC.
        uint8_t *clean=(uint8_t *)predecessor;
        memset(clean,0,12u);
        unsigned state=0,t;
        for(t=0;t<49u;++t) {
            unsigned observed=(received[2u*t]<<2)|received[2u*t+1u];
            unsigned edge=p25_data_trellis_inverse[observed];
            if((edge>>2)!=state)break;
            state=edge&3u;
            if(t<48u)clean[t/4u]|=(uint8_t)(state<<(6u-2u*(t%4u)));
        }
        if(t==49u && state==0u) {memcpy(out,clean,12u);return true;}
    }
    for(unsigned t=0;t<49u;++t) {
        uint16_t next[4];unsigned observed=(received[2*t]<<2)|received[2*t+1];
        for(unsigned s=0;s<4u;++s) {
            unsigned best=0x3fff,prev=0;
            for(unsigned p=0;p<4u;++p) {
                unsigned distance=metric[p]+p25_data_hamming4(observed^p25_data_trellis[p][s]);
                if(distance<best) {best=distance;prev=p;}
            }
            next[s]=(uint16_t)best;predecessor[t][s]=(uint8_t)prev;
        }
        memcpy(metric,next,sizeof metric);
    }
    if(metric[0]>16u)return false;
    memset(out,0,12);unsigned state=0;
    for(unsigned t=49;t>0;--t) {
        if(t<49u)out[(t-1u)/4u]|=(uint8_t)(state<<(6u-2u*((t-1u)%4u)));
        state=predecessor[t-1u][state];
    }
    return state==0;
}
static inline bool p25_data_header_crc(const uint8_t header[12]) {
    uint16_t crc=p25_data_crc16(header,10u);
    return header[10]==(uint8_t)(crc>>8) && header[11]==(uint8_t)crc;
}
static inline bool p25_data_tms_header_profile(const uint8_t header[12]) {
    // Unconfirmed format, no ACK/protection flags, standard manufacturer,
    // SAP4 user data, full message, no fragment/extended-address header.
    if((header[0]&0xdfu)!=0x15u || header[1]!=0xc4u || header[2] ||
       !(header[6]&0x80u) || !(header[6]&0x7fu) ||
       (header[6]&0x7fu)>P25_DATA_MAX_BLOCKS || header[7]>11u || header[8] || header[9])return false;
    return true;
}
static inline unsigned p25_data_frame_symbols(const uint8_t *frame,size_t bytes,uint8_t header[12]) {
    if(!frame || bytes<40u || !p25_data_decode_block(frame,bytes,0u,header)
       || !p25_data_tms_header_profile(header) || !p25_data_header_crc(header))return 0;
    unsigned data=56u+(1u+(header[6]&0x7fu))*98u;
    return ((data+34u)/35u)*36u;
}
// Receive-only alternate MBT: standard unprotected outbound control, not TMS
// and not permission to act on subscriber responses. NET/RFSS/group grants
// each have one data block after the header (Viavi/Aeroflex figures5,6,19).
static inline bool p25_data_ambt_header_profile(const uint8_t header[12]) {
    if(!header || header[0]!=0x37u || header[1]!=0xfdu || header[2]
       || !(header[6]&0x80u) || (header[7]&0xc0u))return false;
    unsigned blocks=header[6]&0x7fu,opcode=header[7];
    if(blocks!=1u || (opcode!=0x3au&&opcode!=0x3bu&&opcode!=0x00u))return false;
    return true;
}
static inline bool p25_data_ambt_header(const uint8_t header[12]) {
    return p25_data_ambt_header_profile(header)&&p25_data_header_crc(header);
}
// Framer admission extends only RX length discovery. The existing
// p25_data_frame_symbols(), used by the TMS parser, remains strictly SAP4.
static inline unsigned p25_data_rx_frame_symbols(const uint8_t *frame,size_t bytes,uint8_t header[12]) {
    if(!frame || bytes<40u || !p25_data_decode_block(frame,bytes,0u,header)
       || (!p25_data_tms_header_profile(header)&&!p25_data_ambt_header_profile(header))
       || !p25_data_header_crc(header))return 0;
    unsigned data=56u+(1u+(header[6]&0x7fu))*98u;
    return ((data+34u)/35u)*36u;
}
static inline uint32_t p25_data_ambt_crc32(const uint8_t *data,unsigned bytes) {
    uint32_t crc=0;
    for(unsigned i=0;i<bytes;++i)for(unsigned j=0;j<8u;++j) {
        unsigned feedback=((crc>>31)^(data[i]>>(7u-j)))&1u;
        crc<<=1;if(feedback)crc^=0x04c11db7u;
    }
    return crc^0xffffffffu;
}
static inline bool p25_data_ambt_integrity(const uint8_t *frame,size_t bytes,
    uint8_t header[12],uint8_t payload[24]) {
    static const uint8_t sync[6]={0x55,0x75,0xf5,0xff,0x77,0xff};
    static const uint64_t generators[16]={
        0x8000cd930bdd3b2a,0x4000ab5a8e33a6be,0x2000983e4cc4e874,0x10004c1f2662743a,
        0x0800eb9c98ec0136,0x0400b85d47ab3bb0,0x02005c2ea3d59dd8,0x01002e1751eaceec,
        0x0080170ba8f56776,0x0040c616dfa78890,0x0020630b6fd3c448,0x00103185b7e9e224,
        0x000818c2dbf4f112,0x0004c1f2662743a2,0x0002ad6a38ce9afb,0x00019b2617ba7657};
    if(!frame || !header || !payload || bytes!=72u
       || memcmp(frame,sync,sizeof sync))return false;
    uint8_t h[12],packet[24]={0};
    if(!p25_data_decode_block(frame,bytes,0u,h)||!p25_data_ambt_header(h))return false;
    unsigned blocks=h[6]&0x7fu,data=56u+(1u+blocks)*98u;
    if(bytes*4u!=((data+34u)/35u)*36u)return false;
    uint64_t nid=0,canonical=0;
    for(unsigned i=24u;i<57u;++i)if(i!=35u)nid=(nid<<2)|p25_data_get_dibit(frame,i);
    uint16_t word=(uint16_t)(nid>>48);
    if((word&15u)!=12u)return false;
    for(unsigned i=0;i<16u;++i)if(word&(0x8000u>>i))canonical^=generators[i];
    // Live framing canonicalizes corrected NIDs before delivering frames.
    if(nid!=canonical)return false;
    for(unsigned i=0;i<blocks;++i)
        if(!p25_data_decode_block(frame,bytes,i+1u,packet+i*12u))return false;
    unsigned end=blocks*12u-4u;
    uint32_t received=((uint32_t)packet[end]<<24)|((uint32_t)packet[end+1u]<<16)
        |((uint32_t)packet[end+2u]<<8)|packet[end+3u];
    if(received!=p25_data_ambt_crc32(packet,end))return false;
    memcpy(header,h,12u);memcpy(payload,packet,24u);return true;
}
#endif
