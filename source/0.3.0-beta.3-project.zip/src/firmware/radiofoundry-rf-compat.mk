# SPDX-License-Identifier: GPL-3.0-or-later
# Included only by the unified live application. Public beta remains classic.
ifeq ($(DM32_RF_B_EXPERIMENTAL),1)
RF_COMPAT_GEN := $(MULTIMODE_GEN)/rf-compat
RF_COMPAT_HEADERS := $(RF_COMPAT_GEN)/drivers/rf/fd6818/fd6818.h
RF_COMPAT_OBJECTS := $(MULTIMODE_DIR)/radio_dm32.o $(MULTIMODE_DIR)/fd6818.o $(MULTIMODE_DIR)/fd6818_setup_b.o
MULTIMODE_OBJ += $(RF_COMPAT_OBJECTS)
OBJ := $(filter-out $(BUILD)/boards/dm32/radio_dm32.o $(BUILD)/drivers/rf/fd6818/fd6818.o,$(OBJ))
# Every translation unit must see the same variant structure layout.
CFLAGS_APP := -I$(RF_COMPAT_GEN)/drivers -I$(PROJECT_ROOT)/src/firmware $(CFLAGS_APP)
$(RF_COMPAT_GEN)/drivers/rf/fd6818/%: drivers/rf/fd6818/% $(PROJECT_ROOT)/scripts/generate-rf-driver-backports.py
	python3 $(PROJECT_ROOT)/scripts/generate-rf-driver-backports.py drivers/rf/fd6818/$* $< $@
$(RF_COMPAT_GEN)/radio_dm32.c: boards/dm32/radio_dm32.c $(PROJECT_ROOT)/scripts/generate-pcm-radio.py $(PROJECT_ROOT)/scripts/generate-rf-board-backport.py
	python3 $(PROJECT_ROOT)/scripts/generate-pcm-radio.py $< $@ --experimental-rf-b
$(MULTIMODE_DIR)/radio_dm32.o: $(RF_COMPAT_GEN)/radio_dm32.c $(RF_COMPAT_HEADERS) $(PROJECT_ROOT)/src/firmware/dm32_rf_compat.h $(PROJECT_ROOT)/src/firmware/radio_pcm_fm_tx.h
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_DIR)/fd6818.o: $(RF_COMPAT_GEN)/drivers/rf/fd6818/fd6818.c $(RF_COMPAT_HEADERS)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(MULTIMODE_DIR)/fd6818_setup_b.o: $(PROJECT_ROOT)/src/firmware/fd6818_setup_b.c $(RF_COMPAT_HEADERS)
	@mkdir -p $(dir $@)
	$(CC) $(CFLAGS_APP) -fstack-usage -Werror -c $< -o $@
$(RF_COMPAT_GEN)/memory-rfb.ld: boards/dm32/memory.ld $(PROJECT_ROOT)/scripts/generate-dm32-codec-memory.py
	python3 $(PROJECT_ROOT)/scripts/generate-dm32-codec-memory.py $< $@ --experimental-rf-b
# Makefile has already expanded -T into LDFLAGS. Replace it explicitly.
LDFLAGS := $(filter-out -T$(LDSCRIPT),$(LDFLAGS)) -T$(RF_COMPAT_GEN)/memory-rfb.ld
$(TARGET).elf: $(RF_COMPAT_GEN)/memory-rfb.ld
$(OBJ) $(MULTIMODE_OBJ) $(BENCH_OBJ): $(RF_COMPAT_HEADERS)
endif
