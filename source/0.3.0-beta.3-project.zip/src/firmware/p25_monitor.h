// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_MONITOR_H
#define P25_MONITOR_H
#include "p25_demod.h"
#include "p25_diagnostics.h"
#include "p25_pcm_trace.h"
#include "p25_receive_policy.h"
#include "p25_voice_policy.h"
#include <string.h>
#include <stddef.h>
#define MON_RAW_BLOCKS 16u
#define MON_PCM_FRAMES 48u
#define MON_PREFILL 18u
typedef enum {
    MON_REJECT_NONE,MON_REJECT_FEC,MON_REJECT_ENCRYPTED,MON_REJECT_PROTECTED,
    MON_REJECT_FORMAT,MON_REJECT_MFID,MON_REJECT_OPCODE,MON_REJECT_OPTIONS,
    MON_REJECT_SERVICE,MON_REJECT_ANCILLARY_CONTEXT,MON_REJECT_CALL_CONTEXT
} mon_reject_reason;
// Preserve the last rejection through later accepted units. Eight bytes, no
// frame history or dynamic allocation, and no serial formatting in the decoder.
typedef struct {
    uint8_t duid,mfid,lco,service,options,flags,reason,algid;
} mon_reject_metadata;
// Raw ISR->task ring and decoded task->speaker-task ring. Caller serializes
// publish/pop with the platform interrupt lock. No decode or I/O under lock.
typedef struct {
    p25_demod demod;
    uint8_t raw[MON_RAW_BLOCKS][512];
    // Sample order and IRQ delivery are distinct clocks. The ordinal gives
    // continuous 8-kHz sample time; IRQ timestamps are diagnostic evidence,
    // not a calibrated over-air origin or permission to transmit.
    uint64_t raw_tick[MON_RAW_BLOCKS];
    uint32_t raw_irq_us[MON_RAW_BLOCKS];
    int16_t pcm[MON_PCM_FRAMES][160];
    volatile unsigned raw_head,raw_tail,pcm_head,pcm_tail;
    unsigned pcm_pos,last_half;
    uint32_t last_raw_us,last_voice_us;
    uint32_t raw_blocks,raw_high,pcm_high,raw_overflow,pcm_overflow,gaps;
    uint32_t units,voices,corrected,rejected,played,starved,max_block_us;
    bool playing,ending,have_raw;
    // Fits inside the existing raw-capture union; never allocate a second call.
    p25_receive_policy call;
    p25_voice_policy quality;
    int16_t last_good_pcm[160];
    uint32_t metadata_bad,encrypted_units,unsupported_units,unqualified_units;
    uint32_t repeated,muted,nid_recovered,discarded_pcm;
    mon_reject_metadata rejection;
#if DM32_LAB_DIAGNOSTICS
    p25_pcm_trace trace;
#endif
} p25_monitor;
static inline void mon_record_rejection(p25_monitor *m,uint8_t duid,
        const p25_call_metadata *metadata,bool valid) {
    p25_receive_class state=m->call.state;
    if(state!=P25_RX_UNSUPPORTED && state!=P25_RX_ENCRYPTED && state!=P25_RX_BAD_METADATA)return;
    mon_reject_reason reason=MON_REJECT_CALL_CONTEXT;
    if(!valid)reason=MON_REJECT_FEC;
    else if(state==P25_RX_ENCRYPTED) {
        // A clear ESS/LC can leave an earlier encrypted latch in force. It
        // must not overwrite the header/LC that actually caused that latch.
        if(metadata->classification==P25_CALL_ENCRYPTED)
            reason=metadata->protected_flag?MON_REJECT_PROTECTED:MON_REJECT_ENCRYPTED;
    }
    else if(duid==5u && metadata->classification==P25_CALL_ANCILLARY)reason=MON_REJECT_ANCILLARY_CONTEXT;
    else if(duid==5u && metadata->classification==P25_CALL_UNSUPPORTED) {
        if(metadata->standard_format)reason=MON_REJECT_FORMAT;
        else if(!metadata->mfid_valid || !p25_call_standard_mfid(metadata->mfid))reason=MON_REJECT_MFID;
        else if(metadata->lco!=0u && metadata->lco!=3u)reason=MON_REJECT_OPCODE;
        else if(metadata->lc_options)reason=MON_REJECT_OPTIONS;
        else if(metadata->service_options&0x30u)reason=MON_REJECT_SERVICE;
    }
    // A following ESS must not erase the useful LC/header rejection fields.
    if(reason==MON_REJECT_CALL_CONTEXT && m->rejection.reason)return;
    m->rejection=(mon_reject_metadata){duid,metadata->mfid,metadata->lco,
        metadata->service_options,metadata->lc_options,
        (uint8_t)((valid?1u:0u)|(metadata->mfid_valid?2u:0u)
            |(metadata->protected_flag?4u:0u)|(metadata->standard_format?8u:0u)),(uint8_t)reason,metadata->algid};
}
static inline const char *mon_reject_label(uint8_t reason) {
    switch(reason) {
        case MON_REJECT_NONE:return "none";
        case MON_REJECT_FEC:return "metadata_fec";
        case MON_REJECT_ENCRYPTED:return "encrypted";
        case MON_REJECT_PROTECTED:return "protected_lc";
        case MON_REJECT_FORMAT:return "lc_format";
        case MON_REJECT_MFID:return "lc_mfid";
        case MON_REJECT_OPCODE:return "lc_opcode";
        case MON_REJECT_OPTIONS:return "lc_options";
        case MON_REJECT_SERVICE:return "lc_service";
        case MON_REJECT_ANCILLARY_CONTEXT:return "aux_context";
        default:return "call_context";
    }
}
static inline unsigned mon_count(unsigned head,unsigned tail,unsigned size) {return (head+size-tail)%size;}
static inline void mon_init(p25_monitor *m) {
    memset(m,0,sizeof *m);p25_demod_init(&m->demod);
#if DM32_LAB_DIAGNOSTICS
    pcm_trace_init(&m->trace,false);
#endif
}
// Replay resets queues/counters while keeping retained decoder evidence intact.
#if DM32_LAB_DIAGNOSTICS
static inline void mon_init_replay(p25_monitor *m) {
    memset(m,0,offsetof(p25_monitor,trace));p25_demod_init(&m->demod);
}
#endif
static inline bool mon_raw_push(p25_monitor *m,volatile const uint8_t *ram,unsigned half,uint32_t now) {
    if(half!=1 && half!=2) {++m->gaps;return false;}
    if(m->have_raw && (half==m->last_half || now-m->last_raw_us>48000u)) {++m->gaps;return false;}
    unsigned next=(m->raw_head+1)%MON_RAW_BLOCKS;
    if(next==m->raw_tail) {++m->raw_overflow;return false;}
    for(unsigned i=0;i<512;++i)m->raw[m->raw_head][i]=ram[(half-1)*512+i];
    m->raw_tick[m->raw_head]=(uint64_t)m->raw_blocks*256u*P25_DEMOD_INPUT_STEP_TICKS;
    m->raw_irq_us[m->raw_head]=now;
    m->last_half=half;m->last_raw_us=now;m->have_raw=true;++m->raw_blocks;
    m->raw_head=next;unsigned n=mon_count(next,m->raw_tail,MON_RAW_BLOCKS);
    if(n>m->raw_high)m->raw_high=n;
    return true;
}
static inline bool mon_raw_pop_timed(p25_monitor *m,uint8_t out[512],uint64_t *tick,uint32_t *irq_us) {
    if(m->raw_tail==m->raw_head)return false;
    if(tick)*tick=m->raw_tick[m->raw_tail];
    if(irq_us)*irq_us=m->raw_irq_us[m->raw_tail];
    memcpy(out,m->raw[m->raw_tail],512);m->raw_tail=(m->raw_tail+1)%MON_RAW_BLOCKS;return true;
}
static inline bool mon_raw_pop(p25_monitor *m,uint8_t out[512]) {
    return mon_raw_pop_timed(m,out,NULL,NULL);
}
static inline bool mon_pcm_push(p25_monitor *m,const int16_t pcm[160]) {
    unsigned next=(m->pcm_head+1)%MON_PCM_FRAMES;
    if(next==m->pcm_tail) {++m->pcm_overflow;return false;}
    memcpy(m->pcm[m->pcm_head],pcm,320);m->pcm_head=next;
    unsigned n=mon_count(next,m->pcm_tail,MON_PCM_FRAMES);if(n>m->pcm_high)m->pcm_high=n;
    return true;
}
// Peek/commit lets a full hardware FIFO retry without losing samples.
static inline const int16_t *mon_pcm_peek(p25_monitor *m) {
    unsigned n=mon_count(m->pcm_head,m->pcm_tail,MON_PCM_FRAMES);
    if(!m->playing && (n>=MON_PREFILL || (m->ending && n)))m->playing=true;
    if(!n) {
        if(m->playing && !m->ending)++m->starved;
        m->playing=false;return NULL;
    }
    return m->playing ? &m->pcm[m->pcm_tail][m->pcm_pos] : NULL;
}
// Caller chooses one backend while stopped: 32-sample FIFO or 80-sample PCM.
// Both divide a frame exactly; switching mid-frame is forbidden by the adapter.
static inline void mon_pcm_commit_samples(p25_monitor *m,unsigned samples) {
    m->pcm_pos+=samples;
    if(m->pcm_pos==160) {m->pcm_pos=0;m->pcm_tail=(m->pcm_tail+1)%MON_PCM_FRAMES;++m->played;}
}
static inline void mon_pcm_commit(p25_monitor *m) {mon_pcm_commit_samples(m,32);}
#endif
