// SPDX-License-Identifier: GPL-3.0-or-later
// RF transport adapter. Pure framing lives in p25_data; native DMR owns its MAC.
#ifndef P25_MESSAGE_RADIO_H
#define P25_MESSAGE_RADIO_H
static void message_receive(const radio_message *m,unsigned format,const uint8_t profile[32],bool truncated,uint32_t now) {
    // P25 TMS sequence duplicate guard; DMR has its native service deduplicator.
    for(unsigned i=0;i<mailbox.count;++i) {
        radio_mail_item *old=&mailbox.items[i];
        if(m->protocol==RADIO_PROTOCOL_P25 && old->state==RADIO_MAIL_RECEIVED && old->message.token==m->token
           && now-old->stamp<60000u && radio_mail_same(old,m,format,false))return;
    }
    radio_mail_item *item=radio_mail_insert(&mailbox,m,RADIO_MAIL_RECEIVED,(uint8_t)format,now);
    if(item) {memcpy(item->channel,profile,32);item->truncated=truncated;(void)radio_ux_rx_activity(&radio_lights,hrc_micros());}
}
static void message_p25_receive(const p25_rx *frame) {
    p25_data_message packet;
    if(!p25_data_parse_tms(frame->frame,frame->frame_bytes,&packet) || packet.acknowledgment
       || packet.destination!=control.source_id)return;
    radio_message m={.protocol=RADIO_PROTOCOL_P25,.kind=RADIO_CALL_INDIVIDUAL,
        .source=packet.source,.destination=packet.destination,.token=(uint32_t)packet.sequence+1u};
    memcpy(m.text,packet.text,sizeof m.text);uint8_t profile[32];memcpy(profile,channel_record,32);
    feature_put16(profile+8,frame->nac);message_receive(&m,0,profile,false,hal_millis());
}
static bool message_p25_start(radio_mail_item *item) {
    size_t n=p25_data_build_tms(message_packet,sizeof message_packet,(uint16_t)control.nac,
        item->message.source,item->message.destination,(uint8_t)item->id,item->message.text);
    if(!n || !prepare_p25_tx(true))return false;
    p25_live_tx_init(&live);
    if(!p25_live_tx_set_packet(&live,message_packet,n) || !p25_live_tx_set_rf_limit(&live,3000000u))return false;
    memset(&pcmq,0,sizeof pcmq);message_packet_tx=true;control.cancel=false;control.state=RADIO_TX_PREPARE;
    call_active=true;capture_started=hrc_micros();call_soft_limit_us=3000000u;reason="sending_message";
    start_rf();return hardware_running;
}
static void message_packet_finish(bool okay,unsigned error) {
    radio_mail_item *item=radio_mail_find(&mailbox,message_active_id);
    hardware_stop();call_active=false;pcmq.accepting=false;message_packet_tx=false;
    cleanup();radio_complete(&control,false);normal_permission();
    radio_mail_set(&mailbox,item,okay ? RADIO_MAIL_SENT : RADIO_MAIL_FAILED,error);
    message_active_id=0;reason=okay ? "message_sent_unconfirmed" : "message_failed";
}
static void message_radio_poll(bool down) {
#if DM32_TRUNK_SUBSCRIBER
    // Subscriber requests share the packet feeder, not the mailbox job owner.
    // Conventional messages cannot borrow a trunked session's RF permission.
    if(trunk_subscriber_active())return;
#endif
    if(trunk_probe.active) {trunk_probe_poll(down);return;}
    radio_dmr_message_rx received;
    while(radio_dmr_message_take(&digital_dmr,&received)) {
        radio_message m={.source=received.source,.destination=received.destination,
            .protocol=RADIO_PROTOCOL_DMR,.kind=received.group ? RADIO_CALL_GROUP : RADIO_CALL_INDIVIDUAL};
        memcpy(m.text,received.text,sizeof m.text);uint8_t profile[32];memcpy(profile,channel_record,32);
        radio_channel_set_mode(profile,RADIO_CHANNEL_DMR);pref_put(profile,received.rx_hz);
        (void)radio_channel_set_color_code(profile,received.cc);(void)radio_channel_set_timeslot(profile,received.ts);
        message_receive(&m,received.format,profile,received.truncated,received.received_ms);
    }
    radio_mail_item *item=radio_mail_find(&mailbox,message_active_id);
    if(message_packet_tx) {
        bool allowed=message_tx_permission() && item && item->message.source==control.source_id && !memcmp(item->channel,channel_record,32);
        if(!allowed || down || control.cancel) {message_packet_finish(false,RADIO_MAIL_ERROR_CANCELLED);return;}
        p25_test_tx_poll_limit(&live.timing,hrc_micros(),true,live.rf_limit_us);
        if(!p25_test_tx_active(&live.timing)) {message_packet_finish(live.timing.state==P25_TX_DONE,
            live.timing.state==P25_TX_DONE ? RADIO_MAIL_ERROR_NONE : RADIO_MAIL_ERROR_TRANSPORT);return;}
    } else if(item) {
        radio_dmr_message_state state=radio_dmr_message_status(&digital_dmr);
        if(state==RADIO_DMR_MESSAGE_SENDING)radio_mail_set(&mailbox,item,RADIO_MAIL_SENDING,0);
        else if(state==RADIO_DMR_MESSAGE_SENT || state==RADIO_DMR_MESSAGE_DELIVERED || state==RADIO_DMR_MESSAGE_FAILED) {
            radio_mail_set(&mailbox,item,state==RADIO_DMR_MESSAGE_SENT ? RADIO_MAIL_SENT : state==RADIO_DMR_MESSAGE_DELIVERED ? RADIO_MAIL_DELIVERED : RADIO_MAIL_FAILED,
                state==RADIO_DMR_MESSAGE_FAILED ? RADIO_MAIL_ERROR_TRANSPORT : 0u);message_active_id=0;
        }
    }
    if(!message_active_id)for(unsigned i=mailbox.count;i;--i) {
        item=&mailbox.items[i-1u];if(item->state!=RADIO_MAIL_QUEUED)continue;
        if(hal_millis()-item->stamp>=RADIO_MAIL_QUEUE_MS) {radio_mail_set(&mailbox,item,RADIO_MAIL_FAILED,RADIO_MAIL_ERROR_TIMEOUT);continue;}
        if(memcmp(item->channel,channel_record,32) || item->message.source!=control.source_id
           || item->message.protocol!=(feature_dmr() ? RADIO_PROTOCOL_DMR : feature_p25() ? RADIO_PROTOCOL_P25 : 0u)) {
            radio_mail_set(&mailbox,item,RADIO_MAIL_FAILED,RADIO_MAIL_ERROR_CHANNEL);continue;
        }
        if(!message_tx_permission()) {radio_mail_set(&mailbox,item,RADIO_MAIL_FAILED,RADIO_MAIL_ERROR_PERMISSION);continue;}
        if(down || call_active || prepared || channel_scan.running || (!message_menu_active() && menu_open))break;
        if(feature_dmr()) {
            const dmr_call_view_t *v=radio_dmr_view(&digital_dmr);
            if(!digital_dmr.running || !v || v->state!=DMR_CALL_STATE_IDLE)break;
            if(!radio_dmr_message_send(&digital_dmr,item->message.destination,item->message.kind==RADIO_CALL_GROUP,
                item->message.text,item->ack,item->format)) {radio_mail_set(&mailbox,item,RADIO_MAIL_FAILED,RADIO_MAIL_ERROR_TRANSPORT);break;}
        } else {
            if(mon_running && (mon_sync_active(hrc_micros()) || monitor.call.active || monitor.playing))break;
            if(!message_p25_start(item)) {hardware_stop();call_active=false;message_packet_tx=false;cleanup();radio_complete(&control,false);
                radio_mail_set(&mailbox,item,RADIO_MAIL_FAILED,RADIO_MAIL_ERROR_TRANSPORT);break;}
        }
        message_active_id=item->id;radio_mail_set(&mailbox,item,RADIO_MAIL_SENDING,0);break;
    }
    if(mailbox.serial!=message_ui_serial && display_ok && !call_active && !prepared) {
        message_ui_serial=mailbox.serial;
        if(message_menu_active())screen("MESSAGES");
    }
}
#endif
