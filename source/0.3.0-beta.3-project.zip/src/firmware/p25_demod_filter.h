// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef P25_DEMOD_FILTER_H
#define P25_DEMOD_FILTER_H
#include <stdint.h>
// 8 to 48 kHz, 121-tap Kaiser beta=5 interpolator, Q15.
static const int32_t p25_interp[121]={
0,-24,-50,-69,-71,-48,0,63,125,164,161,104,0,-130,-251,-321,-307,-195,0,235,445,561,529,332,0,-391,-734,-917,-858,-535,0,622,1161,1444,1346,836,0,-970,-1809,-2251,-2102,-1311,0,1535,2884,3624,3425,2166,0,-2639,-5095,-6615,-6514,-4339,0,6166,13424,20758,27050,31292,32790,31292,27050,20758,13424,6166,0,-4339,-6514,-6615,-5095,-2639,0,2166,3425,3624,2884,1535,0,-1311,-2102,-2251,-1809,-970,0,836,1346,1444,1161,622,0,-535,-858,-917,-734,-391,0,332,529,561,445,235,0,-195,-307,-321,-251,-130,0,104,161,164,125,63,0,-48,-71,-69,-50,-24,0
};
// input points to the newest of21 contiguous history samples; older samples
// are input[-1]..input[-20]. Preserve the full integer convolution, truncation
// toward zero and final int16 saturation, including full-scale adversarial PCM.
static inline void p25_interp_sample(const int16_t *input,int16_t output[6]) {
    // Phase0 has only its center coefficient: the other20 coefficients are0.
    int32_t center=(input[-10]*(int32_t)32790)/32768;
    if(center>32767)center=32767;
    if(center< -32768)center= -32768;
    output[0]=(int16_t)center;
    for(unsigned phase=1;phase<6u;++phase) {
        int32_t left=0,right=0;
        if(phase==3u) {
            // This20-tap phase is symmetric. Pair17-bit input sums before
            // multiplying, preserving the exact convolution with10 multiplies.
            // The first9 coefficients have absolute sum15966: their partial
            // is bounded by15966*65536=1046347776. The final20758 product is
            // bounded by1360396288. Both fit int32, including -32768 inputs.
            for(int j=0;j<9;++j)
                left+=p25_interp[3+6*j]*((int32_t)input[-j]+input[j-19]);
            right=p25_interp[57]*((int32_t)input[-9]+input[-10]);
        } else {
            const int16_t *sample=input;
            // Each10-tap partial has absolute coefficient sum<=42363. Therefore
            // every intermediate is bounded by42363*32768=1388150784<INT32_MAX.
            for(unsigned k=phase;k<60u;k+=6u) {
                left+=p25_interp[k]*(int32_t)*sample;
                right+=p25_interp[k+60u]*(int32_t)sample[-10];
                --sample;
            }
        }
        // Full phases2..4 exceed INT32_MAX; retain the wide combine and the
        // original truncation toward zero before final int16 saturation.
        int64_t sum=(int64_t)left+right;
        int32_t value=(int32_t)(sum/32768);
        if(value>32767)value=32767;
        if(value< -32768)value= -32768;
        output[phase]=(int16_t)value;
    }
}
#endif
